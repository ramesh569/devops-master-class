targetScope = 'subscription'

@minLength(5)
@maxLength(50)
@description('Provide a globally unique name of your Azure Container Registry')
param acrName string

param acrResourceId string

// create private endpoints to the ACR in the various private endpoint networks
var privateEndPointsNetworks = [
  {
    shortName: 'GatewayDevWestEurope'
    resourceGroup: 'rg-pep-dev-weu'
    vnetName: 'vnet-pep-dev-weu'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/56dc79ab-09ed-4e9e-a24f-0a3269836a47/resourceGroups/rg-private-dns-zones-dev/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'GatewayTestNorthEurope'
    resourceGroup: 'rg-pep-test-neu'
    vnetName: 'vnet-pep-test-neu'
    subnetName: 'PepSubnet'
    location: 'northeurope'
    privateDnsZoneResourceId: '/subscriptions/56dc79ab-09ed-4e9e-a24f-0a3269836a47/resourceGroups/rg-private-dns-zones-test/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'GatewayTestIc3WestEurope'
    resourceGroup: 'rg-pep-test-weu-ic3'
    vnetName: 'vnet-pep-test-weu-ic3'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/56dc79ab-09ed-4e9e-a24f-0a3269836a47/resourceGroups/rg-private-dns-zones-test-ic3/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'MomDevWestEurope'
    resourceGroup: 'rg-mom-dev'
    vnetName: 'vnet-dev-aks-mom-weu'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/56dc79ab-09ed-4e9e-a24f-0a3269836a47/resourceGroups/rg-mom-dev/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'GatewayTestOnelabWestEurope'
    resourceGroup: 'rg-pep-test-weu-onelab'
    vnetName: 'vnet-pep-test-weu-onelab'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/56dc79ab-09ed-4e9e-a24f-0a3269836a47/resourceGroups/rg-private-dns-zones-test-onelab/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
]

module privateEndPoints './pep.bicep' = [for pepNetworkDetails in privateEndPointsNetworks: {
  name: 'pep-acr-${pepNetworkDetails.shortName}'
  scope: resourceGroup(pepNetworkDetails.resourceGroup)
  params:{
    acrName: acrName
    acrResourceId: acrResourceId
    vnetName: pepNetworkDetails.vnetName
    subnetName: pepNetworkDetails.subnetName
    location: pepNetworkDetails.location
    privateDnsZoneId: pepNetworkDetails.privateDnsZoneResourceId
  }
}]
