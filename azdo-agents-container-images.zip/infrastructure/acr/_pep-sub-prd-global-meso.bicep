targetScope = 'subscription'

@minLength(5)
@maxLength(50)
@description('Provide a globally unique name of your Azure Container Registry')
param acrName string

param acrResourceId string

// create private endpoints to the ACR in the various private endpoint networks
var privateEndPointsNetworks = [
  {
    shortName: 'GatewayProdWestEurope'
    resourceGroup: 'rg-pep-prod-weu'
    vnetName: 'vnet-pep-prod-weu'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/69dfc25b-32a0-4f72-94ee-89ecd603700b/resourceGroups/rg-private-dns-zones-prod/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'MomProdWestEurope'
    resourceGroup: 'rg-mom-prod'
    vnetName: 'vnet-prod-aks-mom-weu'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/69dfc25b-32a0-4f72-94ee-89ecd603700b/resourceGroups/rg-mom-prod/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'GatewayProdIc3WestEurope'
    resourceGroup: 'rg-pep-prod-weu-ic3'
    vnetName: 'vnet-pep-prod-weu-ic3'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/69dfc25b-32a0-4f72-94ee-89ecd603700b/resourceGroups/rg-private-dns-zones-prod-ic3/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
  {
    shortName: 'GatewayProdOnelabWestEurope'
    resourceGroup: 'rg-pep-prod-weu-onelab'
    vnetName: 'vnet-pep-prod-weu-onelab'
    subnetName: 'PepSubnet'
    location: 'westeurope'
    privateDnsZoneResourceId: '/subscriptions/69dfc25b-32a0-4f72-94ee-89ecd603700b/resourceGroups/rg-private-dns-zones-prod-onelab/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io'
  }
]

module privateEndPoints './pep.bicep' = [for pepNetworkDetails in privateEndPointsNetworks: {
  name: 'pep-acr-${pepNetworkDetails.shortName}'
  scope: resourceGroup(pepNetworkDetails.resourceGroup)
  params:{
    acrName: acrName
    acrResourceId: acrResourceId
    vnetName: pepNetworkDetails.vnetName
    subnetName: pepNetworkDetails.subnetName
    location: pepNetworkDetails.location
    privateDnsZoneId: pepNetworkDetails.privateDnsZoneResourceId
  }
}]
