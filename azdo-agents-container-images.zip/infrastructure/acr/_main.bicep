targetScope = 'resourceGroup'

@minLength(5)
@maxLength(50)
@description('Provide a globally unique name of your Azure Container Registry')
param acrName string
param acrMainRegistryLocation string
param acrReplicaRegistryLocations array

var contributorRoles = [
  {
    // required for service connection to connect private endpoint to ACR
    shortName: 'sc-reg-prd-eu-tas'
    managedIdentityPrincipalId: '8f70e93f-5a90-4ff1-85bb-d9439a43ea4a'
    principalType: 'ServicePrincipal'
  }
  {
    // required for service connection to connect private endpoint to ACR
    shortName: 'sc-reg-dev-eu-tas'
    managedIdentityPrincipalId: 'd177425d-4b65-46a0-b659-a8b9e4db045a'
    principalType: 'ServicePrincipal'
  }
  {
    // required for service connection to connect private endpoint to ACR
    shortName: 'sc-reg-dev-global-meso'
    managedIdentityPrincipalId: 'a3356ae0-e239-4d83-ab4d-b10593787b3c'
    principalType: 'ServicePrincipal'
  }
]

resource acrMainRegistry 'Microsoft.ContainerRegistry/registries@2023-01-01-preview' = {
  name: acrName
  location: acrMainRegistryLocation
  sku: {
    name: 'Premium'
  }
  tags: {
    'AcceptedException_containerregistry-H-003': 'Repository contains old images that are not used in production, but are still reported by policy. We scan our images during build using the official dependency scanner, making this obsolete and due to to it scanning everything also useless and noisy'
  }
  properties: {
    anonymousPullEnabled: false
    adminUserEnabled: false
    publicNetworkAccess: 'Disabled'
    zoneRedundancy: 'Enabled'
    networkRuleBypassOptions: 'AzureServices'
    policies: {
      softDeletePolicy: {
        status: 'disabled'
      }
    }
    networkRuleSet: {
      defaultAction: 'Deny'
    }
  }
}

resource cacheRuleUbuntu 'Microsoft.ContainerRegistry/registries/cacheRules@2023-01-01-preview' = {
  parent: acrMainRegistry
  name: 'cacherule-ubuntu'
  properties: {
    sourceRepository: 'public.ecr.aws/ubuntu/ubuntu'
    targetRepository: 'ubuntu'
  }
}

resource cacheRuleOpenSearchOperator 'Microsoft.ContainerRegistry/registries/cacheRules@2023-01-01-preview' = {
  parent: acrMainRegistry
  name: 'cacherule-opensearch-operator'
  properties: {
    sourceRepository: 'public.ecr.aws/opensearchproject/opensearch-operator'
    targetRepository: 'opensearch-operator'
  }
}

resource cacheRuleOpenSearch 'Microsoft.ContainerRegistry/registries/cacheRules@2023-01-01-preview' = {
  parent: acrMainRegistry
  name: 'cacherule-opensearch'
  properties: {
    sourceRepository: 'public.ecr.aws/opensearchproject/opensearch'
    targetRepository: 'opensearch'
  }
}

resource cacheRuleOpenSearchDashboard 'Microsoft.ContainerRegistry/registries/cacheRules@2023-01-01-preview' = {
  parent: acrMainRegistry
  name: 'cacherule-opensearch-dashboard'
  properties: {
    sourceRepository: 'public.ecr.aws/opensearchproject/opensearch-dashboards'
    targetRepository: 'opensearch-dashboards'
  }
}

resource cacheRuleBusybox 'Microsoft.ContainerRegistry/registries/cacheRules@2023-01-01-preview' = {
  parent: acrMainRegistry
  name: 'cacherule-busybox'
  properties: {
    sourceRepository: 'public.ecr.aws/docker/library/busybox'
    targetRepository: 'busybox'
  }
}

resource acrReplicas 'Microsoft.ContainerRegistry/registries/replications@2019-12-01-preview' = [for replicaLocation in acrReplicaRegistryLocations: {
  parent: acrMainRegistry
  name: replicaLocation
  location: replicaLocation
}]

module roleAssignmentContributors './assignRole.bicep' = [for contributorRoleDetails in contributorRoles: {
  name: 'role-contributor-${contributorRoleDetails.shortName}'
  params:{
    managedIdentityPrincipalId: contributorRoleDetails.managedIdentityPrincipalId
    roleId: 'b24988ac-6180-42a0-ab88-20f7382dd24c' // Contributor
    roleName: 'Contributor'
    principalType: contributorRoleDetails.principalType
  }
}]

output acrResourceId string = acrMainRegistry.id
