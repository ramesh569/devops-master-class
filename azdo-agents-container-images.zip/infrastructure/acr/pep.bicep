targetScope = 'resourceGroup'
param vnetName string
param acrName string
param acrResourceId string
param location string
param privateDnsZoneId string
param subnetName string

var pvtEndpointDnsGroupName = '${acrName}/agentsacr'

var subnetId = resourceId('Microsoft.Network/virtualNetworks/subnets', vnetName, subnetName)

resource privateEndpoint 'Microsoft.Network/privateEndpoints@2021-08-01' = {
  name: acrName
  location: location
  properties: {
    subnet: {
      id: subnetId
    }
    privateLinkServiceConnections: [
      {
        name: acrName
        properties: {
          privateLinkServiceId: acrResourceId
          groupIds: [
            'registry'
          ]
        }
      }
    ]
  }
}

resource pvtEndpointDnsGroup 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2021-08-01' = {
  name: pvtEndpointDnsGroupName
  dependsOn: [
    privateEndpoint
  ]
  properties: {
    privateDnsZoneConfigs: [
      {
        name: '${acrName}-config'
        properties: {
          privateDnsZoneId: privateDnsZoneId
        }
      }
    ]
  }
}
