targetScope = 'resourceGroup'

param managedIdentityPrincipalId string
param roleId string
param roleName string
@allowed([
  'ServicePrincipal'
  'Group'
  'User'
])
param principalType string = 'ServicePrincipal'

resource AssignContributorToAksMi 'Microsoft.Authorization/roleAssignments@2020-10-01-preview' = {
  name: guid(resourceGroup().id, managedIdentityPrincipalId, roleName) // want consistent GUID on each run
  properties: {
    principalId: managedIdentityPrincipalId
    principalType: principalType
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', roleId)
  }
}
