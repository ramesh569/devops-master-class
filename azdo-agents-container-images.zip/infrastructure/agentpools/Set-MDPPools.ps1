<#
.SYNOPSIS
    Create MDP agent queues based on configuration
.DESCRIPTION
    Reads mdppools-*.xml configuration and ensures each referenced MDP agent pool is available as an agent queue in the target projects.
.PARAMETER Mode
    Determines the execution mode of the script:
    - list: Only lists the configuration without planning or applying changes.
    - plan: Generates and displays the plan of actions without applying changes.
    - execute: Generates the plan and applies all changes to match the configuration.
.NOTES
    Script does not detect if an agentpool is removed from the configuration files
#>
[CmdletBinding(SupportsShouldProcess)]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$false)]
    [ValidateSet('list','plan','execute')]
    [string]$Mode = 'plan'
)

# Pipeline safety: stop on errors for clear failure handling
$ErrorActionPreference = 'Stop'

#[configuration]
$defaultsConfigPath = ".\azdo-agents-container-images\infrastructure\agentpools\config\defaults.xml"
$mdpPoolsConfigXsdPath = ".\azdo-agents-container-images\infrastructure\agentpools\config\mdppools.xsd"
$mdpConfigFiles = ".\azdo-agents-container-images\infrastructure\agentpools\config"
$mdpTerraformConfigPath = ".\azdo-agents-vm\infrastructure\terraform\_variables\mdp"


#[functions]
. .\azdo-agents-container-images\images\_shared\jobs\Functions-AzdoApi.ps1
. .\azdo-agents-container-images\images\_shared\jobs\Functions-Xml.ps1

class MDPAgentPool {
    [string]$Name
    [string]$Organization
    [string[]]$Projects
    [bool]$MdpValidation
    [bool]$IsValid = $true #will be set to false if misconfiguration is detected

    MDPAgentPool() { $this.Init(@{}) }
    MDPAgentPool([hashtable]$Properties) { $this.Init($Properties) }

    [void] Init([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }
}
function Get-TerraformConfiguration {
    $agentPoolsConfig = @{}
    $tfvarsFiles = Get-ChildItem -Path $mdpTerraformConfigPath -Recurse -Filter *.tfvars

    foreach ($tfvars in $tfvarsFiles) {
        write-host "Processing $($tfvars.name)"
        #load terraform config as powershell object
        $mdpConfigRaw = Get-Content -Path $tfvars.FullName
        $agentPoolName = ($mdpConfigRaw | Select-String -Pattern 'agent_pool_name\s*=\s*"([^"]+)"').Matches.Groups[1].Value
        if ($agentPoolName -ne $tfvars.BaseName) {
            Write-Host "##vso[task.logissue type=warning]Agent pool name $agentPoolName defined in $($tfvars.name) does not match the filename."
            continue
        }
        $organizations = $mdpConfigRaw | Select-String -Pattern 'https://dev.azure.com/([\w-]*)' | ForEach-Object { $_.Matches.Groups[1].Value }
        $agentPoolsConfig[$agentPoolName] = $organizations
    }
    return $agentPoolsConfig
}

function Get-AgentPoolConfiguration {
    $agentPoolDefinitions = @()
    foreach($config in Get-ChildItem -Path $mdpConfigFiles -Filter "mdppools-*.xml") {
    Write-Host "Processing $($config.name)"
    $doc = Get-XmlContent -XmlPath $config.FullName -XsdPath (Get-Item $mdpPoolsConfigXsdPath).FullName

    foreach($agentpool in $doc.managedevopspools.mdp)
    {
        $agentPoolDefinition = [MDPAgentPool]::new(@{
            Name = $agentpool.name
            Organization = $agentpool.organization
            Projects = @($defaults.organizations.organization | Where-Object -Property name -eq $agentpool.organization).defaultProjects.project
            MdpValidation = $true #default to true unless specified otherwise in configuration
        })

        if ($agentPool.mdpValidation -eq 'false') {
            $agentPoolDefinition.MdpValidation = $false
        }

        if ($agentpool.projects.project) {
            $agentPoolDefinition.Projects += @($agentpool.projects.project)
        }
        if ($agentpool.allProjects -eq 'true') {
            $agentPoolDefinition.Projects += '*'
        }

        #check if a pool with this name is already defined in the organization
        if($agentPoolDefinitions | Where-Object {
            $_.Name -eq $agentPoolDefinition.Name -and
            $_.Organization -eq $agentPoolDefinition.Organization
        }) {
            Write-Host "##vso[task.logissue type=warning]Agentpool $($agentPoolDefinition.Organization)\$($agentPoolDefinition.Name) is defined more than once in the configuration files. This could lead to unpredictable configuration, script will take first definition."
            Write-Host "##vso[task.complete result=SucceededWithIssues;]"
        } else {
            $agentPoolDefinitions += $agentPoolDefinition
        }
    }
}
return $agentPoolDefinitions
}

function Test-Configuration {
    param(
        [MDPAgentPool[]]$AgentPoolDefinitions,
        [hashtable]$TerraformConfig
    )
    $issues=0

    #check if all agent pools defined in configuration files are also defined in terraform configuration
    foreach($agentPoolDefinition in $AgentPoolDefinitions) {
        if ($agentPoolDefinition.MdpValidation -eq $false) {
            Write-Host "[Skip] validation for $($agentPoolDefinition.Organization)\$($agentPoolDefinition.Name) as mdpValidation is set to false."
            continue
        }
        Write-Host "Validating $($agentPoolDefinition.Organization)\$($agentPoolDefinition.Name) against terraform configuration"
        if($TerraformConfig.ContainsKey($agentPoolDefinition.Name)) {
            $configuredOrgs = $TerraformConfig[$agentPoolDefinition.Name]
            if(-not ($configuredOrgs -contains $agentPoolDefinition.Organization)) {
                $agentPoolDefinition.IsValid = $false
                Write-Host "[##vso[task.logissue type=warning]Agentpool] $($agentPoolDefinition.Name) is not configured in terraform for organization $($agentPoolDefinition.Organization)."
                $issues++
            }
        } else {
            $agentPoolDefinition.IsValid = $false
            Write-Host "##vso[task.logissue type=warning]Agentpool $($agentPoolDefinition.Name) is not configured in terraform."
            $issues++
        }
    }

    #check if all agent pools defined in terraform configuration are also defined in configuration files
    foreach($agentPoolName in $TerraformConfig.Keys) {
        Write-Host "Validating $agentPoolName defined in terraform against configuration files"
        foreach($org in $TerraformConfig[$agentPoolName]) {
            if(-not ($AgentPoolDefinitions | Where-Object { $_.Name -eq $agentPoolName -and $_.Organization -eq $org })) {
                Write-Host "##vso[task.logissue type=warning]Agentpool $agentPoolName is configured in terraform for organization $org but not defined in configuration files."
                $issues++
            }
        }
    }

    if ($issues -ne 0) {
        Write-Host "$issues issue(s) found between configuration and terraform configuration. Please review warnings above."
        Write-Host "##vso[task.complete result=SucceededWithIssues;]"
        exit 1
    }
    Write-Host "No issues found between configuration and terraform configuration."
}

#[script]
Write-Host "Script is in $Mode mode."
$accessToken = Get-AuthToken

#load and verify defaults configuration
$defaults = Get-XmlContent -XmlPath $defaultsConfigPath

Write-Host "Reading Agent Pool Configuration"
$agentPoolDefinitions = Get-AgentPoolConfiguration

Write-Host "Agent Pool Configuration"
$agentPoolDefinitions | ForEach-Object {
    Write-Host "$($_.Name) in $($_.Organization) for Projects: $($_.Projects -join ',')"
}

Write-Host "Validate Agent Pool Configuration against Terraform Configuration"
Test-Configuration `
    -AgentPoolDefinitions $agentPoolDefinitions `
    -TerraformConfig (Get-TerraformConfiguration)

if ($Mode -eq 'list') {
    Write-Host "##vso[task.complete result=Succeeded;]"
    exit 0
}

Write-Host "Filter out invalid pools"
$agentPoolDefinitions = $agentPoolDefinitions | Where-Object -Property IsValid -eq $true

#loop through all agent pools configured (in various configuration files) but group them by organization for efficiency
$index = 0
$total = $agentPoolDefinitions.Count
foreach($azdoOrganization in ($agentPoolDefinitions | Group-Object -Property Organization)) {
    Write-Host "Processing agent pools in $($azdoOrganization.Name)"

    #get all projects in the organization
    $organizationProjects = Get-ProjectsInOrganization -AzdoOrganization $azdoOrganization.Name -AccessToken $accessToken

    # loop through each agent pool as specified in the configuration files for this organization
    foreach($agentpool in $azdoOrganization.Group){
        $index++
        Write-host "`t[$index/$total] $($agentpool.Name)"
        try {
            $agentPoolDetails = Get-AgentPool -AzdoOrganization $azdoOrganization.Name -AgentPoolName $agentpool.Name -AccessToken $accessToken
        } catch {
            Write-Host "##vso[task.logissue type=error]Failed to get details for agent pool $($azdoOrganization.Name)\$($agentpool.Name). Error: $_"
        }
        if(!($agentPoolDetails)) {
            write-host "`t`t[Skip] Pool isn't created yet"
            continue
        }

        #if deployment to all projects is defined (denoted by asteriks), deploy to all projects in organization
        if ($agentpool.Projects.contains('*')) {
            $agentpool.Projects = $organizationProjects.name
        }

        #if mode is in execute, add agent pool to each project
        if ($Mode -eq 'execute') {
            New-AgentQueue -AzdoOrganization $azdoOrganization.Name -AgentPoolName $agentPoolDetails.name -AgentPoolId $agentPoolDetails.id -Projects $agentpool.projects -AccessToken $accessToken
        }
    }
}