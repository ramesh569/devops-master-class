﻿<#
.SYNOPSIS
    Create agent pools based on configuration
.DESCRIPTION
    Create and remove AZDO agent pools based on configuration file
.PARAMETER Mode
    Determines the execution mode of the script:
    - list: Only lists the configuration without planning or applying changes.
    - plan: Generates and displays the plan of actions without applying changes.
    - execute: Generates the plan and applies all changes to match the configuration.
.PARAMETER SyncOrganizationAccess
    When set, synchronizes organization access on existing pools.
.PARAMETER SyncProjectAccess
    When set, synchronizes project access on existing pools.
.PARAMETER SyncOwner
    When set, ensures the pool owner matches defaults configuration.
.PARAMETER SyncQueues
    When set, ensures pools are added to all target projects as per configuration.
.NOTES
    - Requires Azure DevOps Personal Access Token (PAT) available to the sourced Functions-AzdoApi.ps1 logic (Get-AuthToken).
    - PAT should have at least: Agent Pools (Read, Manage), Project and Team (Read), Graph (Read) scopes.
    - Script does not detect if an agent pool is removed from the configuration files.
.EXAMPLE
    ./Set-AgentPools.ps1 -Preview
    Plans actions for all configured organizations/pools and prints the plan without applying.
#>
[CmdletBinding(SupportsShouldProcess)]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("list", "plan", "execute")]
    [string]$Mode = "plan",
    [Parameter(Mandatory=$false)]
    [switch]$SyncOrganizationAccess,
    [Parameter(Mandatory=$false)]
    [switch]$SyncProjectAccess,
    [Parameter(Mandatory=$false)]
    [switch]$SyncOwner,
    [Parameter(Mandatory=$false)]
    [switch]$SyncQueues
)

# Pipeline safety: stop on errors for clear failure handling
$ErrorActionPreference = 'Stop'

#[configuration]
$configFolder = ".\infrastructure\agentpools\config"
$defaultsConfigPath = ".\infrastructure\agentpools\config\defaults.xml"
$agentPoolsConfigXsdPath = ".\infrastructure\agentpools\config\agentpools.xsd"

#[functions]
. .\images\_shared\jobs\Functions-Xml.ps1
. .\images\_shared\jobs\Functions-AzdoApi.ps1
. "$PSScriptRoot\Set-AgentPoolClasses.ps1"

<#
.SYNOPSIS
    Normalize principal name
.DESCRIPTION
    Trims and standardizes principal names to avoid issues with extra spaces or inconsistent formatting in configuration files
    which can cause GUID resolution to fail
.PARAMETER PrincipalName
    The principal name string to normalize
#>
function Get-NormalizedPrincipalName {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$PrincipalName
    )
    #split on double slash, then trim all seperate parts, and rejoin them
    return $PrincipalName.Split('\\').trim() -join '\\'

}
<#
.SYNOPSIS
    Create a plan action record.
.DESCRIPTION
    Encapsulates a unit of work against an organization/pool with payload details.
.PARAMETER Kind
    The action type to perform.
.PARAMETER Organization
    Target Azure DevOps organization.
.PARAMETER PoolName
    Target agent pool name.
.PARAMETER Payload
    Optional additional data for the action.
#>
function New-PlanAction {
    [CmdletBinding()]
    [OutputType([PlanAction])]
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '', Justification = 'Plan action creation does not change system state. And previewing actions is supported differently')]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet(
            'CreatePool',
            'SetOwner',
            'GrantOrgAccess',
            'GrantProjectAccess',
            'AddToProject',
            'RemoveProjects',
            'DisableAgentQueuePermissionInheritence',
            'EnableAgentQueuePermissionInheritence',
            'RevokeProjectAccess'
        )][string]$Kind,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$Organization,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$PoolName,
        [Parameter(Mandatory=$false)]$Payload
    )

    return [PlanAction]::new(
        $Kind,
        $Organization,
        $PoolName,
        $Payload
    )
}

<#
.SYNOPSIS
    Load and validate agent pool configuration files
.DESCRIPTION
    Reads defaults and agentpools XML files, validates against XSD, and produces typed definitions
.PARAMETER DefaultsConfigPath
    Path to defaults.xml file
.PARAMETER AgentPoolsConfigXsdPath
    Path to agentpools.xsd schema for validation
.PARAMETER ConfigFolder
    Folder containing agentpools-*.xml files
.PARAMETER Filter
    Optional file filter pattern
#>
function Get-Configuration {
    [CmdletBinding()]
    [OutputType([object[]])]
    param(
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$DefaultsConfigPath,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$AgentPoolsConfigXsdPath,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$ConfigFolder,
        [Parameter(Mandatory=$false)][string]$Filter = 'agentpools-*.xml'
    )

    $defaults = Get-XmlContent -XmlPath $DefaultsConfigPath
    $agentPoolDefinitions = @()

    foreach($config in Get-ChildItem -Path $ConfigFolder -Filter $Filter) {
        Write-Host "Processing $($config.Name)"
        $doc = Get-XmlContent -XmlPath $config.FullName -XsdPath (Get-Item $AgentPoolsConfigXsdPath).FullName

        foreach($agentpool in $doc.agentpools.agentpool) {
            $agentPoolDefinition = [AgentPoolConfig]::new([hashtable]@{
                Name = $agentpool.name
                Organization = $agentpool.organization
                Projects = @($defaults.organizations.organization | Where-Object -Property name -eq $agentpool.organization).defaultProjects.project
                AdminsOrganizationalLevel = @($defaults.organizations.organization | Where-Object -Property name -eq $agentpool.organization).admins.admin | ForEach-Object { Get-NormalizedPrincipalName -PrincipalName $_ }
                ReadersOrganizationalLevel = @($defaults.organizations.organization | Where-Object -Property name -eq $agentpool.organization).readers.reader | ForEach-Object { Get-NormalizedPrincipalName -PrincipalName $_ }
            })

            if ($null -eq $agentpool.allProjects) {
                $agentPoolDefinition.AllProjects = $false
            } else {
                $agentPoolDefinition.AllProjects = ([string]$agentpool.allProjects).ToLower() -eq 'true'
            }

            if ($null -eq $agentpool.inheritance) {
                $agentPoolDefinition.Inheritance = $true
            } else {
                $agentPoolDefinition.Inheritance = ([string]$agentpool.inheritance).ToLower() -eq 'true'
            }

            if ($agentpool.projects.project) { $agentPoolDefinition.Projects += @($agentpool.projects.project) }
            if ($agentpool.admins.admin) {
                foreach($adminEntry in $agentpool.admins.admin) {
                     $normalizedName = Get-NormalizedPrincipalName -PrincipalName $adminEntry
                     $agentPoolDefinition.AdminsOrganizationalLevel += $normalizedName

                     # special case for mentat
                     # even though the admin is defined at agent pool (e.g. organization) level
                     # they also want the same group to have agent queue (e.g. project) level permissions
                     # the XML currently does not support defining agent queue level permissions and we have no use case
                     # besides mentat needing this, so not implementing it in XML at this point
                     if ($normalizedName -eq "[CCC AWS Internal]\EP Mentat Cross Azdo Projects") {
                        $agentPoolDefinition.AdminsProjectLevel += $normalizedName
                     }
                }
            }
            if ($agentpool.readers.reader) { $agentPoolDefinition.ReadersProjectLevel += @($agentpool.readers.reader | ForEach-Object { Get-NormalizedPrincipalName -PrincipalName $_ }) }
            if ($agentpool.users.user) { $agentPoolDefinition.UsersProjectLevel += @($agentpool.users.user | ForEach-Object { Get-NormalizedPrincipalName -PrincipalName $_ }) }

            # deduplicate by org+name (take first definition)
            if($agentPoolDefinitions | Where-Object { $_.Name -eq $agentPoolDefinition.Name -and $_.Organization -eq $agentPoolDefinition.Organization }) {
                Write-Host "##vso[task.logissue type=warning]Agentpool $($agentPoolDefinition.Organization)\$($agentPoolDefinition.Name) is defined more than once in configuration. Taking the first definition."
                Write-Host "##vso[task.complete result=SucceededWithIssues;]"
            } else {
                $agentPoolDefinitions += $agentPoolDefinition
            }
        }
    }

    return [pscustomobject]@{
        Defaults = $defaults
        AgentPools = $agentPoolDefinitions
    }
}

<#
.SYNOPSIS
    Build a plan of actions to reconcile desired and current state
.DESCRIPTION
    Computes create, ownership, access, and project membership changes per organization/pool
.PARAMETER AccessToken
    Azure DevOps PAT token
.PARAMETER AgentPoolDefinitions
    Array of agent pool definition objects
.PARAMETER OrganizationsDefaultConfig
    Array of organization default configuration objects
.PARAMETER RunOptions
    Run options object specifying mode and sync flags
#>
function Build-AgentPoolsPlan {
    [CmdletBinding()]
    [OutputType([Plan])]
    param(
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$AccessToken,
        [Parameter(Mandatory=$true)][object[]]$AgentPoolDefinitions,
        [Parameter(Mandatory=$true)][object[]]$OrganizationsDefaultConfig,
        [Parameter(Mandatory=$true)][RunOptions]$RunOptions
    )

    $plan = [Plan]::new()

    $totalAgentPools = $AgentPoolDefinitions.Count
    $currentAgentPoolIndex = 0
    foreach($agentPoolsByOrgName in ($AgentPoolDefinitions | Group-Object -Property Organization)) {
        #get organizational defaults from config
        $organizationDefaults =  $OrganizationsDefaultConfig | Where-Object -Property name -eq $agentPoolsByOrgName.Name

        #create organization object to hold current state and cache info for calls related to this organization
        $organization = [Organization]::new()
        $organization.Name = $agentPoolsByOrgName.Name

        #cache all groups in this organization for faster resolution of group principal names to guids
        $organization.GetGroupCache($AccessToken)

        #convert organizational defaults config in organization object
        $organization.DefaultConfig = [OrganizationDefaultConfig]::new()
        $organization.DefaultConfig.owner = [AzdoIdentity]::new([string] $organizationDefaults.owner, $organization.GroupCache)
        $organization.DefaultConfig.admins = @($organizationDefaults.admins.admin) | ForEach-Object { [AzdoIdentity]::new([string] $_, $organization.GroupCache) }
        $organization.DefaultConfig.readers = @($organizationDefaults.readers.reader) | ForEach-Object { [AzdoIdentity]::new([string] $_, $organization.GroupCache) }
        $organization.DefaultConfig.defaultProjects = $organizationDefaults.defaultProjects.project

        #get organizationl agent pools and projects
        $organization.GetAgentPools($AccessToken)
        $organization.GetProjects($AccessToken)

        #process each agent pool in group (organization)
        foreach($agentPoolConfig in $agentPoolsByOrgName.Group) {
            $currentAgentPoolIndex++
            write-host  "`t[$currentAgentPoolIndex/$totalAgentPools] Planning for pool: $($agentPoolConfig.Name)"

            #determine future actions to plan (these settings are modified for new pools)
            $agentPoolConfig.SetActionsToPlan($RunOptions)

            #determine which project the agent pool(queue) should be provisione for
            $agentPoolConfig.SetTargetPools($organization)

            #get existing agent pool matching the name (could return null if it doesn't exist)
            $agentPoolConfig.SetExistingPool($organization)
            $agentPoolConfig.PlanPoolCreation($plan, $organization)
            $agentPoolConfig.PlanSyncOwner($plan, $organization)

            # Plan actions to provision agent queues in projects
            $agentPoolConfig.PlanSyncQueues($plan, $organization, $AccessToken)

            #get access guids (required to plan changes to access levels)
            $accessGuids = Get-AccessGuidList `
                -AccessToken $AccessToken `
                -Agentpool $agentPoolConfig `
                -Organization $organization

            # Plan actions to update agent pool permissions
            $agentPoolConfig.PlanSyncOrganizationAccess($plan, $accessGuids, $organization, $AccessToken)

            # Plan actions to update agent queue permissions
            $agentPoolConfig.PlanSyncProjectAccess($plan, $accessGuids, $organization, $AccessToken)
        }
    }
    return $plan
}

<#
.SYNOPSIS
    Resolve GUID for group/identity in an organization
.DESCRIPTION
    Uses Functions-AzdoApi helper to resolve originId for given principal name
.PARAMETER AccessToken
    Azure DevOps PAT token
.PARAMETER Organization
    Target organization
.PARAMETER PrincipalName
    Group/identity string to resolve
#>
function Get-Guid {
    [CmdletBinding()]
    [OutputType([string])]
    param (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$AccessToken,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][Organization]$Organization,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$PrincipalName
    )

    $normalizedPrincipalName = Get-NormalizedPrincipalName -PrincipalName $PrincipalName
    #resolve from cache if possible
    if ($Organization.GroupCache) {
        $cachedGroup = $Organization.GroupCache | Where-Object { $_.PrincipalName -eq $normalizedPrincipalName }
        if ($cachedGroup) {
            return $cachedGroup.Guid
        }
    }

    Write-Host "`t`tResolving guid for '$normalizedPrincipalName'"
    #entry not in cache (likely a user instead of a group) or no cache provided, resolve
    try {
        #this call frequently fails for owner which is caught and logged
        $guid = Get-GroupIdentifier -azdoOrganization $Organization.Name -groupName $normalizedPrincipalName -returnField originId -accessToken $AccessToken
    } catch {
        Write-Host "##vso[task.logissue type=warning]Error resolving GUID for '$normalizedPrincipalName' in '$($Organization.Name)'. Error: $_"
    }

    #because error gets caught, check if the value is set
    if (-not $guid) {
        Write-Host "##vso[task.logissue type=warning]Could not resolve GUID for '$normalizedPrincipalName' in '$($Organization.Name)'"
        return ""
    }
    Write-Host "`t`t`tGuid: $guid"
    return $guid
}

<#
.SYNOPSIS
    Get Project Valid Users GUID list for agent pool
.DESCRIPTION
    Resolves user access level GUIDs for each project in the agent pool
.PARAMETER AccessToken
    Azure DevOps PAT token
.PARAMETER Agentpool
    Agent pool definition object
.PARAMETER Organization
    Target organization object
#>
function Get-ProjectValidUsersGuidList {
    [CmdletBinding()]
    [OutputType([hashtable])]
    param(
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$AccessToken,
        [Parameter(Mandatory=$true)][ValidateNotNull()][AgentPoolConfig]$Agentpool,
        [Parameter(Mandatory=$true)][ValidateNotNull()][Organization]$Organization
    )

    #only resolve users guids if we need to sync project access
    if (-not $AgentPool.ShouldSyncProjectAccess) {
        return @{}
    }

    #if agent pool is configured for all projects and we have a cache of all valid users in the organization
    # use the cache to populate userGuids for each project
    if ($Agentpool.AllProjects -and $Organization.AllProjectsValidUserGuidsCache) {
        Write-Verbose "Pool '$($Agentpool.Name)' is configured for all projects, using cached Project Valid Users GUIDs for organization '$($Agentpool.Organization)'"
        return $Organization.AllProjectsValidUserGuidsCache
    }

    $userAccessLevelGuids = @{}
    if ($Agentpool.Projects.Count -gt 0) {
        # Add all explicitly configured users to the list of guids
        # These users should be added for each agent queue (regardless of project)
        $configuredUserAccessLevelGuids = @()
        write-verbose "Lookup $($Agentpool.UsersProjectLevel.Count) explicitly configured user access GUIDs for pool '$($Agentpool.Name)' in organization '$($Agentpool.Organization)'"
        foreach ($principalName in $Agentpool.UsersProjectLevel) {
            $configuredUserAccessLevelGuids += Get-Guid -AccessToken $AccessToken -Organization $Organization -PrincipalName $principalName
        }
        write-verbose "Lookup $($AgentPool.Projects.Count) Project Valid Users access GUIDs for pool '$($Agentpool.Name)' in organization '$($Agentpool.Organization)'"
        # add 'Project Valid Users' guid for each project
        foreach ($project in $AgentPool.Projects) {
            #get project valid user group guid for this project
            $currentProjectValidUserGroupGuid = Get-Guid -AccessToken $AccessToken -Organization $Organization -PrincipalName "[$project]\Project Valid Users"

            #Combine the configured guids (which is to be set for each queue) and the project specific project valid user group guid
            $userAccessLevelGuids[$project] = @($configuredUserAccessLevelGuids + $currentProjectValidUserGroupGuid)
        }
    }

    #if no cache has been set for the organization and the current agent pool is configured for all projects
    #we just resolved the project valid user group guids for all projects
    #so cache the result at the organization level to reuse for other pools configured (which are configured with AllProjects)
    if (-not $organization.AllProjectsValidUserGuidsCache -and $agentPoolConfig.AllProjects) {
        #if userguids has not been set, and we just resolved guids for all projects, cache
        $organization.AllProjectsValidUserGuidsCache = $userAccessLevelGuids
    }

    return $userAccessLevelGuids
}

<#
.SYNOPSIS
    Collect all relevant access GUIDs for an agent pool
.DESCRIPTION
    Resolves admin/reader GUIDs at org and project levels, and combines Project Valid Users with configured users
.PARAMETER AccessToken
    Azure DevOps PAT token
.PARAMETER Agentpool
    Agent pool definition object
.PARAMETER Organization
    Target organization object
#>
function Get-AccessGuidList {
    [CmdletBinding()]
    [OutputType([AccessGuidList])]
    param (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$AccessToken,
        [Parameter(Mandatory=$true)][ValidateNotNull()][AgentPoolConfig]$Agentpool,
        [Parameter(Mandatory=$true)][ValidateNotNull()][Organization]$Organization
    )

    #only execute if sync access on organization or project level is expected
    if (-not $agentPoolConfig.ShouldSyncOrgAccess -and -not $agentPoolConfig.ShouldSyncProjectAccess) {
        return $null
    }

    Write-Verbose "Lookup access GUIDs for pool '$($agentPoolConfig.Name)' in organization '$($Organization.Name)'"

    #get user level access guids (only exists at project level)
    $usersGuids = Get-ProjectValidUsersGuidList `
            -AccessToken $AccessToken `
            -Agentpool $Agentpool `
            -Organization $Organization

    write-verbose "Lookup organizational and project level access GUIDs for pool '$($Agentpool.Name)' in organization '$($Organization.Name)'"
    $organizationalLevelAdminGuids = @()
    foreach ($principalName in $Agentpool.AdminsOrganizationalLevel) {
        $organizationalLevelAdminGuids += Get-Guid -AccessToken $AccessToken -Organization $Organization -PrincipalName $principalName
    }

    $projectLevelAdminGuids = @()
    if (-not $Agentpool.AllProjects) {
        foreach ($principalName in $Agentpool.AdminsProjectLevel) {
            $projectLevelAdminGuids += Get-Guid -AccessToken $AccessToken -Organization $Organization -PrincipalName $principalName
        }
    }

    $organizationalLevelReaderGuids = @()
    foreach ($principalName in $Agentpool.ReadersOrganizationalLevel) {
        $organizationalLevelReaderGuids += Get-Guid -AccessToken $AccessToken -Organization $Organization -PrincipalName $principalName
    }

    $projectLevelReaderGuids = @()
    if (-not $Agentpool.AllProjects) {
        foreach ($principalName in $Agentpool.ReadersProjectLevel) {
            $projectLevelReaderGuids += Get-Guid -AccessToken $AccessToken -Organization $Organization -PrincipalName $principalName
        }
    }

    return [AccessGuidList]::new(@{
         OrganizationalLevelAdminGuids = $organizationalLevelAdminGuids
         ProjectLevelAdminGuids = $projectLevelAdminGuids
         OrganizationalLevelReaderGuids = $organizationalLevelReaderGuids
         ProjectLevelReaderGuids = $projectLevelReaderGuids
         UserGuids = $UsersGuids
    })
}

#[script]
$accessToken = Get-AuthToken

# Determine run options (and put it in an object for convience)
$runOptions = [RunOptions]::new(@{
    Mode = $Mode
    SyncOrganizationAccess = $SyncOrganizationAccess
    SyncProjectAccess = $SyncProjectAccess
    SyncOwner = $SyncOwner
    SyncQueues = $SyncQueues
})
Write-Host "Run Options"
$runOptions

# Load Configuration
$config = Get-Configuration `
    -DefaultsConfigPath $defaultsConfigPath `
    -AgentPoolsConfigXsdPath $agentPoolsConfigXsdPath `
    -ConfigFolder $configFolder
Write-Host "Agent Pool Configuration"
$config.AgentPools

# Exit if we are only listing configuration for review
if ($runOptions.Mode -eq "list") {
    Write-Host "##vso[task.complete result=Succeeded;]"
    exit 0
}

# Plan
$plan = Build-AgentPoolsPlan -AccessToken $accessToken -AgentPoolDefinitions $config.AgentPools -OrganizationsDefaultConfig $config.Defaults.organizations.organization -RunOptions $runOptions
Write-Host "Plan Created"

# Show Plan
$plan.ShowPlan()
if ($plan.Actions.Count -eq 0) {
    Write-Host "##vso[task.complete result=Succeeded;]"
    exit 0
}

# Execute Plan
if ($runOptions.Mode -ne "execute") {
    # Exit if we are in plan mode and not supposed to apply changes
    Write-Host "Run mode is set to '$($runOptions.Mode)'. No changes will be applied."
    Write-Host "##vso[task.complete result=Succeeded;]"
    exit 0
}
$plan.ExecutePlan($accessToken)
Write-Host "Plan execution completed."
Write-Host "##vso[task.complete result=Succeeded;]"

