<#
.SYNOPSIS
    This script removes agent queues from Azure DevOps projects based on specified filters
.DESCRIPTION
    The script iterates through specified Azure DevOps organizations and their projects,
    identifies agent queues that match the provided agent pool names, and removes those queues from the respective projects.
    The script logs all actions and errors to a specified log file.
.EXAMPLE
    .\Remove-AgentQueues.ps1
    This will remove all agent queues matching the filter in all organizations, and log the output to "remove-agentqueues.log" in the current directory.
.EXAMPLE
    .\Remove-AgentQueues.ps1 -AzdoOrganizations "raboweb", "raboweb-test" -AgentPools "Rabo-Linux-Canary", "Rabo-Windows-Canary"
    This will remove all agent queues matching the filter in the specified organizations, and log the output to "remove-agentqueues.log" in the current directory.
.EXAMPLE
    .\Remove-AgentQueues.ps1 -AzdoOrganizations "raboweb", "raboweb-test" -LogFileName "C:\temp\remove-agentqueues.log"
    This will remove all agent queues matching the filter in the specified organizations, and log the output to the specified log file.
.NOTES
    PAT Token requires Agent Pools (Read & Manage) Permissions
#>
[CmdletBinding(SupportsShouldProcess)]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter', 'LogFileName', Justification = 'Optional parameter. Using default value if none is provided')]
param (
    [Parameter(Mandatory=$false)]
    [ValidateSet("raboweb", "raboweb-test", "raboweb-na", "raboweb-brazil", "raboweb-dublin", "raboweb-ftbtr")]
    [string[]]
    $AzdoOrganizations = @("raboweb", "raboweb-test", "raboweb-na", "raboweb-brazil", "raboweb-dublin", "raboweb-ftbtr"),

    [Parameter(Mandatory=$false)]
    [string]$LogFileName = "remove-agentqueues.log",

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [string[]]$AgentPools = @(
    "Rabo-CloudOnly-Kubernetes-Brazil-Linux-Production-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Brazil-Linux-Production-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Brazil-Linux-Production",
    "Rabo-CloudOnly-Kubernetes-Brazil-Linux-ProductionblueCanary",
    "Rabo-CloudOnly-Kubernetes-Brazil-Linux-ProductiongreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-DotNet",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-Java",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-NodeJS-build",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-NodeJS",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-Python",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover-Testing",
    "Rabo-CloudOnly-Kubernetes-Linux-Failover",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-DotNet",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-Java",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-NodeJS-build",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-NodeJS-Build",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-NodeJS",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-Python",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback-Testing",
    "Rabo-CloudOnly-Kubernetes-Linux-Fallback",
    "Rabo-CloudOnly-Kubernetes-Linux-Preview-Python",
    "Rabo-CloudOnly-Kubernetes-Linux-Preview",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Australia-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Australia-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Australia",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-AustraliablueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-AustraliagreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Brazil-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Brazil-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Brazil",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-BrazilblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-BrazilgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Compliancy-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Compliancy-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-CompliancyblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-CompliancygreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-DotNet-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-DotNet-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-DotNet",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-DotNetblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-DotNetgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Java-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Java-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Java",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-JavablueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-JavagreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-build-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-build-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-build",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-buildblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-buildgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJS",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJSblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-NodeJSgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-Australia-blueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-Australia-greenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-Australia",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-AustraliablueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-AustraliagreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-Brazil-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-Brazil-greenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-Brazil",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-BrazilblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-BrazilgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-US-blueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-US-greenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-US",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-USblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python-USgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Python",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-PythonblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-PythongreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Testing-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Testing-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-Testing",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-TestingblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-TestinggreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-US-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-US-greenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-US",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-USblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production-USgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Production",
    "Rabo-CloudOnly-Kubernetes-Linux-ProductionblueCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-ProductiongreenCanary",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-DotNet",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-Java",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-NodeJS-build",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-NodeJS",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-Python",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-Testing",
    "Rabo-CloudOnly-Kubernetes-Linux-Test-US",
    "Rabo-CloudOnly-Kubernetes-Linux-Test",
    "Rabo-CloudOnly-Kubernetes-North-America-Linux-Production-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-North-America-Linux-Production-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-North-America-Linux-Production",
    "Rabo-CloudOnly-Kubernetes-Windows-Failover-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Windows-Failover-Dotnet",
    "Rabo-CloudOnly-Kubernetes-Windows-Failover",
    "Rabo-CloudOnly-Kubernetes-Windows-Fallback-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Windows-Fallback-Dotnet",
    "Rabo-CloudOnly-Kubernetes-Windows-Fallback-DotNet",
    "Rabo-CloudOnly-Kubernetes-Windows-Fallback",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-Compliancy-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-Compliancy-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-CompliancyblueCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-CompliancygreenCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-DotNet-BlueCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-DotNet-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-Dotnet",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-DotNet",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-DotNetblueCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-DotNetgreenCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production-GreenCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Production",
    "Rabo-CloudOnly-Kubernetes-Windows-ProductionblueCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-ProductiongreenCanary",
    "Rabo-CloudOnly-Kubernetes-Windows-Test-Compliancy",
    "Rabo-CloudOnly-Kubernetes-Windows-Test-Dotnet",
    "Rabo-CloudOnly-Kubernetes-Windows-Test",
    "Rabo-Kubernetes-Linux-Canary-Docker",
    "Rabo-Kubernetes-Linux-Dev-AWS",
    "Rabo-Kubernetes-Linux-Dev-Compliancy",
    "Rabo-Kubernetes-Linux-Dev-DotNet",
    "Rabo-Kubernetes-Linux-Dev-Java",
    "Rabo-Kubernetes-Linux-Dev-NodeJS-build",
    "Rabo-Kubernetes-Linux-Dev-NodeJS",
    "Rabo-Kubernetes-Linux-Dev-OneLab",
    "Rabo-Kubernetes-Linux-Dev-Testing",
    "Rabo-Kubernetes-Linux-Dev",
    "Rabo-Kubernetes-Linux-Failover-Compliancy",
    "Rabo-Kubernetes-Linux-Failover-DotNet",
    "Rabo-Kubernetes-Linux-Failover-Java",
    "Rabo-Kubernetes-Linux-Failover-NodeJS-build",
    "Rabo-Kubernetes-Linux-Failover-NodeJS",
    "Rabo-Kubernetes-Linux-Failover-Python",
    "Rabo-Kubernetes-Linux-Failover-Testing",
    "Rabo-Kubernetes-Linux-Failover",
    "Rabo-Kubernetes-Linux-Fallback-Compliancy",
    "Rabo-Kubernetes-Linux-Fallback-DotNet",
    "Rabo-Kubernetes-Linux-Fallback-Java",
    "Rabo-Kubernetes-Linux-Fallback-NodeJS-build",
    "Rabo-Kubernetes-Linux-Fallback-NodeJS-Build",
    "Rabo-Kubernetes-Linux-Fallback-NodeJS",
    "Rabo-Kubernetes-Linux-Fallback-Python",
    "Rabo-Kubernetes-Linux-Fallback-Testing",
    "Rabo-Kubernetes-Linux-Fallback",
    "Rabo-Kubernetes-Linux-Kaniko-Test",
    "Rabo-Kubernetes-Linux-Preview-Python",
    "Rabo-Kubernetes-Linux-Preview",
    "Rabo-Kubernetes-Linux-Production-Ansible",
    "Rabo-Kubernetes-Linux-Production-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-Compliancy-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-Compliancy-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-Compliancy",
    "Rabo-Kubernetes-Linux-Production-CompliancyblueCanary",
    "Rabo-Kubernetes-Linux-Production-CompliancygreenCanary",
    "Rabo-Kubernetes-Linux-Production-DotNet-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-DotNet-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-DotNet",
    "Rabo-Kubernetes-Linux-Production-DotNetblueCanary",
    "Rabo-Kubernetes-Linux-Production-DotNetgreenCanary",
    "Rabo-Kubernetes-Linux-Production-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-Java-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-Java-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-Java",
    "Rabo-Kubernetes-Linux-Production-JavablueCanary",
    "Rabo-Kubernetes-Linux-Production-JavagreenCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS-build-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS-build-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS-build-senses-memory",
    "Rabo-Kubernetes-Linux-Production-NodeJS-build-senses",
    "Rabo-Kubernetes-Linux-Production-NodeJS-build",
    "Rabo-Kubernetes-Linux-Production-NodeJS-buildblueCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS-buildgreenCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJS",
    "Rabo-Kubernetes-Linux-Production-NodeJSblueCanary",
    "Rabo-Kubernetes-Linux-Production-NodeJSgreenCanary",
    "Rabo-Kubernetes-Linux-Production-OneLab",
    "Rabo-Kubernetes-Linux-Production-Python-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-Python-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-Python",
    "Rabo-Kubernetes-Linux-Production-PythonblueCanary",
    "Rabo-Kubernetes-Linux-Production-PythongreenCanary",
    "Rabo-Kubernetes-Linux-Production-Testing-BlueCanary",
    "Rabo-Kubernetes-Linux-Production-Testing-GreenCanary",
    "Rabo-Kubernetes-Linux-Production-Testing",
    "Rabo-Kubernetes-Linux-Production-TestingblueCanary",
    "Rabo-Kubernetes-Linux-Production-TestinggreenCanary",
    "Rabo-Kubernetes-Linux-Production",
    "Rabo-Kubernetes-Linux-ProductionblueCanary",
    "Rabo-Kubernetes-Linux-ProductiongreenCanary",
    "Rabo-Kubernetes-Linux-Test-Ansible",
    "Rabo-Kubernetes-Linux-Test-AWS",
    "Rabo-Kubernetes-Linux-Test-Compliancy",
    "Rabo-Kubernetes-Linux-Test-DotNet",
    "Rabo-Kubernetes-Linux-Test-Fallback",
    "Rabo-Kubernetes-Linux-Test-Java",
    "Rabo-Kubernetes-Linux-Test-NodeJS-build-senses",
    "Rabo-Kubernetes-Linux-Test-NodeJS-build",
    "Rabo-Kubernetes-Linux-Test-NodeJS",
    "Rabo-Kubernetes-Linux-Test-Python",
    "Rabo-Kubernetes-Linux-Test-Testing",
    "Rabo-Kubernetes-Linux-Test",
    "Rabo-Kubernetes-Windows-Dev-Compliancy",
    "Rabo-Kubernetes-Windows-Dev-DotNet",
    "Rabo-Kubernetes-Windows-Dev",
    "Rabo-Kubernetes-Windows-Failover-Compliancy",
    "Rabo-Kubernetes-Windows-Failover-DotNet",
    "Rabo-Kubernetes-Windows-Failover",
    "Rabo-Kubernetes-Windows-Fallback-Compliancy",
    "Rabo-Kubernetes-Windows-Fallback-DotNet",
    "Rabo-Kubernetes-Windows-Fallback",
    "Rabo-Kubernetes-Windows-Production-BlueCanary",
    "Rabo-Kubernetes-Windows-Production-Compliancy-BlueCanary",
    "Rabo-Kubernetes-Windows-Production-Compliancy-GreenCanary",
    "Rabo-Kubernetes-Windows-Production-Compliancy",
    "Rabo-Kubernetes-Windows-Production-CompliancyblueCanary",
    "Rabo-Kubernetes-Windows-Production-CompliancygreenCanary",
    "Rabo-Kubernetes-Windows-Production-DotNet-BlueCanary",
    "Rabo-Kubernetes-Windows-Production-DotNet-GreenCanary",
    "Rabo-Kubernetes-Windows-Production-DotNet",
    "Rabo-Kubernetes-Windows-Production-DotNetblueCanary",
    "Rabo-Kubernetes-Windows-Production-DotNetgreenCanary",
    "Rabo-Kubernetes-Windows-Production-GreenCanary",
    "Rabo-Kubernetes-Windows-Production",
    "Rabo-Kubernetes-Windows-ProductionblueCanary",
    "Rabo-Kubernetes-Windows-ProductiongreenCanary",
    "Rabo-Kubernetes-Windows-Test-Compliancy",
    "Rabo-Kubernetes-Windows-Test-DotNet",
    "Rabo-Kubernetes-Windows-Test",
    "Rabo-Linux-Canary",
    "Rabo-Linux-Dev-Base",
    "Rabo-Linux-Dev-Compliancy",
    "Rabo-Linux-Dev-Dotnet",
    "Rabo-Linux-Dev-Java",
    "Rabo-Linux-Dev-NodeJS-build",
    "Rabo-Linux-Dev-NodeJS",
    "Rabo-Linux-Dev-Python",
    "Rabo-Linux-Dev-Testing",
    "Rabo-Linux-Fallback-Base",
    "Rabo-Linux-Fallback-Compliancy",
    "Rabo-Linux-Fallback-Dotnet",
    "Rabo-Linux-Fallback-Java",
    "Rabo-Linux-Fallback-NodeJS-build",
    "Rabo-Linux-Fallback-NodeJS",
    "Rabo-Linux-Fallback-Python",
    "Rabo-Linux-Fallback-Testing",
    "Rabo-Linux-Fallback",
    "Rabo-Linux-Meso",
    "Rabo-Linux-Production",
    "Rabo-Linux-Test-Base",
    "Rabo-Linux-Test-Compliancy",
    "Rabo-Linux-Test-Dotnet",
    "Rabo-Linux-Test-Java",
    "Rabo-Linux-Test-NodeJS-build",
    "Rabo-Linux-Test-NodeJS",
    "Rabo-Linux-Test-Python",
    "Rabo-Linux-Test-Testing",
    "Rabo-Linux-Test",
    "Rabo-Windows-Canary",
    "Rabo-Windows-Fallback",
    "Rabo-Windows-Meso",
    "Rabo-Windows-Production-North-America",
    "Rabo-Windows-Production-North-Europe",
    "Rabo-Windows-Production",
    "Rabo-Windows-Test"
    )
)

#[configuration]
#none all can be done through parameters

#[functions]
. .\images\_shared\jobs\Functions-AzdoApi.ps1

class RemoveAgentQueueAction {
    [string]$AzdoOrganization
    [string]$ProjectName
    [string]$QueueName
    [string]$QueueId
}

function Write-LogEntry() {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Message,

        [Parameter(Mandatory=$true)]
        [ValidateSet("Info", "Warning", "Error")]
        [string]$LogLevel
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] $Message"
    Add-Content -Path $LogFileName -Value $logEntry -WhatIf:$false #override whatif value to ensure we log all entries, even when running in whatif mode

    switch ($LogLevel) {
        "Info" { Write-Output $logEntry }
        "Warning" { Write-Warning $logEntry }
        "Error" { Write-Error $logEntry -ErrorAction Continue } # continue to allow processing of remaining items, but log the error
        Default {
            Write-Output $logEntry
        }
    }
}

#[script]
$accessToken = Get-AuthToken

$plannedActions = @()
$organizationIndex = 0
$organizationCount = $AzdoOrganizations.Count
foreach($azdoOrganization in $AzdoOrganizations) {
    $organizationIndex++
    Write-LogEntry "Querying organization [$organizationIndex\$organizationCount]: $azdoOrganization" -LogLevel Info

    $projects = Get-ProjectsInOrganization `
        -AzdoOrganization $azdoOrganization `
        -AccessToken $accessToken `
        | Sort-Object -Property name

    $projectIndex = 0
    $projectCount = $projects.Count
    foreach($project in $projects) {
        $projectIndex++
        Write-LogEntry "Querying project [$projectIndex\$projectCount]: $($project.name)" -LogLevel Info

        #get all agent queues
        $allAgentQueues = Get-AgentQueuesInProject -AzdoOrganization $azdoOrganization -Project $project.name -AccessToken $accessToken

        #remove all agent queues for the agent pools matching the filter
        foreach($agentQueue in $allAgentQueues | Where-Object { $_.Name -in $AgentPools }) {
            $plannedActions += [RemoveAgentQueueAction]@{
                AzdoOrganization = $azdoOrganization
                ProjectName = $project.name
                QueueName = $agentQueue.name
                QueueId = $agentQueue.id
            }
        }
    }
}

$actionCount = $plannedActions.Count
Write-LogEntry "Planned actions: $actionCount." -LogLevel Info
$plannedActions #show in console only

#abort script if whatif flag is enabled
if (-not ($PSCmdlet.ShouldProcess("Remove agent queues"))) {
    Write-LogEntry "WhatIf flag is defined, no action will be performed." -LogLevel Info
    exit 0
}

$confirm = Read-Host "Do you want to continue? (y/n)"
if ($confirm -ne 'y') {
    Write-LogEntry "Aborting script." -LogLevel Info
    exit 1
}

$actionIndex = 0
foreach($action in $plannedActions) {
    $actionIndex++
    try {
        Remove-AgentQueueInProject `
            -AzdoOrganization $action.AzdoOrganization `
            -Project $action.ProjectName `
            -QueueId $action.QueueId `
            -AccessToken $accessToken `
            -Silent
        Write-LogEntry "[OK] ($actionIndex\$actionCount) Deleted $($action.AzdoOrganization)\$($action.ProjectName)\$($action.QueueName) [$($action.QueueId)]" -LogLevel Info
    } catch {
        Write-LogEntry "[Error] ($actionIndex\$actionCount) Failed to Delete $($action.AzdoOrganization)\$($action.ProjectName)\$($action.QueueName) [$($action.QueueId)]. Message: $_" -LogLevel Error
    }
}