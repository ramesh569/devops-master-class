
class RunOptions {
    [string]$Mode
    [bool]$SyncOrganizationAccess
    [bool]$SyncProjectAccess
    [bool]$SyncOwner
    [bool]$SyncQueues

    RunOptions() { }
    RunOptions([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }
}
class AgentPoolConfig {
    #properties set by config (xml)
    [string]$Name
    [string]$Organization
    [bool]$AllProjects
    [bool]$Inheritance
    [string[]]$Projects
    [string[]]$AdminsOrganizationalLevel
    [string[]]$AdminsProjectLevel
    [string[]]$ReadersOrganizationalLevel
    [string[]]$ReadersProjectLevel
    [string[]]$UsersProjectLevel

    #properties set by logic (script)
    [bool]$ShouldSyncOrgAccess
    [bool]$ShouldSyncProjectAccess
    [bool]$ShouldSyncQueues
    [bool]$ShouldSyncOwner
    [AzdoAgentPool]$ExistingPool

    AgentPoolConfig() { }
    AgentPoolConfig([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }

    SetActionsToPlan([RunOptions]$RunOptions) {
        $this.ShouldSyncOrgAccess = $RunOptions.syncOrganizationAccess
        $this.ShouldSyncProjectAccess = $RunOptions.syncProjectAccess
        $this.ShouldSyncQueues = $RunOptions.SyncQueues
        $this.ShouldSyncOwner = $RunOptions.SyncOwner
    }

    SetTargetPools([Organization]$Organization) {
        Write-Verbose "Determining target projects for pool '$($this.Name)' in organization '$($Organization.Name)'"
        if ($this.AllProjects) {
            #all projects attribute is set to true, so all projects in organization
            $this.Projects = $Organization.AllProjects.name #if all AllProjects is true, take all projects from organization
        } else {
            #not all projects attribute is set or is false, so only projects explicitly listed in the config (if any) as nodes
            $this.Projects = ($this.Projects | Select-Object -Unique)
        }
    }

    SetExistingPool([Organization]$Organization) {
        Write-Verbose "Checking if pool '$($this.Name)' already exists in organization '$($Organization.Name)'"
        $this.ExistingPool = $Organization.AgentPools | Where-Object -Property name -eq $this.Name

    }

    PlanPoolCreation([Plan]$plan, [Organization]$Organization) {
        if ($this.ExistingPool) {
            return #pool exists, return
        }

        #pool does not exist, so plan to create it
        Write-Verbose "Add Action: New Pool '$($this.Name)' in organization '$($Organization.Name)'"
        $newAction = New-PlanAction -Kind CreatePool -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
            OwnerGuid = $Organization.DefaultConfig.owner.Guid
            AllProjects = $this.AllProjects
        })
        $plan.Actions.Add($newAction)

        #new pools need permissions to be set as well
        $this.ShouldSyncOrgAccess = $true
        $this.ShouldSyncProjectAccess = $true

        #new pools don't need to sync the owner, as it will be set correctly on creation
        $this.ShouldSyncOwner = $false

        if ($this.AllProjects) {
            #new pool is provisioned for all projects
            #we don't need to create seperate queues
            $this.ShouldSyncQueues = $false
        } else {
            #new pool is not provisioned for all projects
            #so we should plan actions to add queues in the specified projects
            $this.ShouldSyncQueues = $true
        }
    }

    PlanSyncOwner([Plan]$plan, [Organization]$Organization) {
        #if pool exists and sync owner flag is set, plan action to set owner
        if (-not $this.ShouldSyncOwner) {
            return
        }
        Write-Verbose "Planning action to sync owner for pool '$($this.Name)' in organization '$($Organization.Name)'"
        if ($this.ExistingPool.owner.Guid -ne $Organization.DefaultConfig.owner.Guid) {
            Write-Verbose "Add Action: Set Owner for Pool '$($this.Name)' in organization '$($Organization.Name)' to '$($Organization.DefaultConfig.owner.Name)'"
            $newAction = New-PlanAction -Kind SetPoolOwner -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                OwnerGuid = $Organization.DefaultConfig.owner.Guid
            })
            $plan.Actions.Add($newAction)
        }
    }

    PlanSyncQueues([Plan]$plan, [Organization]$Organization, [string]$AccessToken) {
        if (-not $this.ShouldSyncQueues) {
            return
        }
        Write-Verbose "Planning actions to provision agent queues for pool '$($this.Name)' in organization '$($Organization.Name)'"
        $projectsToBeAddedTo = [System.Collections.ArrayList]@()
        foreach($project in $this.Projects) {
            #get all project queues so we can check if the pool is already added to the project before planning to add it
            $allProjectAgentQueues = Get-AgentQueuesInProject -AzdoOrganization $Organization.Name -ProjectName $project -AccessToken $AccessToken
            if ($allProjectAgentQueues.Name -notcontains $this.Name) {
                $projectsToBeAddedTo.Add($project)
            }
        }
        if ($projectsToBeAddedTo.Count -eq 0) {
            return
        }

        Write-Verbose "Add Action: Add queue '$($this.Name)' to $($projectsToBeAddedTo.Count) projects in organization '$($Organization.Name)'"
        $newAction = New-PlanAction -Kind AddToProject -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
            Projects = $projectsToBeAddedTo
        })
        $plan.Actions.Add($newAction)
    }

    PlanSyncOrganizationAccess([Plan]$plan, [AccessGuidList]$AccessGuids, [Organization]$Organization, [string]$AccessToken) {
        if (-not $this.ShouldSyncOrgAccess) {
            return
        }
        if (-not $AccessGuids) {
            Write-Verbose "No access guids could be resolved for pool '$($this.Name)' in organization '$($Organization.Name)', skipping planning organizational level access"
            return
        }

        $readerGuidsForOrganization = $AccessGuids.OrganizationalLevelReaderGuids
        $adminGuidsForOrganization = $AccessGuids.OrganizationalLevelAdminGuids

        $existingAgentPoolPermissions = $null
        if ($this.ExistingPool) {
            Write-Verbose "Retrieving existing permissions for pool '$($this.Name)' in organization '$($Organization.Name)'"
            $existingAgentPoolPermissions = Get-AgentPoolAccessOnOrganizationLevel -AzdoOrganization $Organization.Name -AgentPoolId $this.ExistingPool.Id -AccessToken $AccessToken
        }

        #filter out any permissions that are already correctly set to avoid unnecessary API calls
        if ($existingAgentPoolPermissions) {
            Write-Verbose "Filtering already granted access (reader and admin) on organizational level to avoid unnecessary API calls"
            $preFilterReaderCount = $readerGuidsForOrganization.count
            $currentReaderPermissions = ($existingAgentPoolPermissions | Where-Object { $_.role.displayName -eq 'Reader' }).identity.id
            $readerGuidsForOrganization = $readerGuidsForOrganization | Where-Object { $_ -notin $currentReaderPermissions }
            Write-Verbose "Filtered organizational reader permissions $($readerGuidsForOrganization.Count)/$preFilterReaderCount remaining"

            $preFilterAdminCount = $adminGuidsForOrganization.count
            $currentAdminPermissions = ($existingAgentPoolPermissions | Where-Object { $_.role.displayName -eq 'Administrator' }).identity.id
            $adminGuidsForOrganization = $adminGuidsForOrganization | Where-Object { $_ -notin $currentAdminPermissions }
            Write-Verbose "Filtered organizational admin permissions $($adminGuidsForOrganization.Count)/$preFilterAdminCount remaining"
        }

        if ($readerGuidsForOrganization.Count -eq 0 -and $adminGuidsForOrganization.Count -eq 0) {
            Write-Verbose "[Skip] No organizational level permission changes needed for pool '$($this.Name)' in organization '$($Organization.Name)'"
            return
        }

        #ensure data meets requirements of API (empty arrays will cause API calls to fail, so set to null if empty)
        if ($readerGuidsForOrganization.Count -eq 0) { $readerGuidsForOrganization = @() }
        if ($adminGuidsForOrganization.Count -eq 0) { $adminGuidsForOrganization = @() }

        Write-Verbose "Add Action: Grant organizational level access to pool '$($this.Name)' in organization '$($Organization.Name)' for $($readerGuidsForOrganization.Count) readers and $($adminGuidsForOrganization.Count) admins"
        $newAction = New-PlanAction -Kind GrantOrgAccess -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
            ReaderGuids = $readerGuidsForOrganization
            AdminGuids = $adminGuidsForOrganization
        })
        $plan.Actions.Add($newAction)
    }

    PlanSyncProjectAccess([Plan]$plan, [AccessGuidList]$AccessGuids, [Organization]$Organization, [string]$AccessToken) {
        if (-not $this.ShouldSyncProjectAccess) {
            return
        }
        if (-not $AccessGuids) {
            Write-Verbose "No access guids could be resolved for pool '$($this.Name)' in organization '$($Organization.Name)', skipping planning project level access"
            return
        }

        Write-Verbose "Verifiying Grant Project Access for queue '$($this.Name)' to $($this.Projects.Count) projects in organization '$($Organization.Name)'"
        foreach($project in $this.Projects) {
            $projectQueueScopeId = $organization.allprojects | Where-Object -Property Name -eq $project | Select-Object -ExpandProperty Id
            $readerGuidsForProject = $accessGuids.ProjectLevelReaderGuids
            $adminGuidsForProject = $accessGuids.ProjectLevelAdminGuids
            $userGuidsForProject = $accessGuids.UserGuids[$project]
            if ($null -eq $userGuidsForProject) { $userGuidsForProject = @() }

            $existingAgentQueuePermissions = $null
            if ($this.ExistingPool) {
                #get all agent queues in project (this call is in cache)
                $allProjectAgentQueues = Get-AgentQueuesInProject -AzdoOrganization $Organization.Name -ProjectName $project -AccessToken $AccessToken
                $targetAgentQueue = ($allProjectAgentQueues | Where-Object { $_.pool.id -eq $this.ExistingPool.id })
                if (-not $targetAgentQueue) {
                    Write-verbose "Could not find agent queue scope ID for pool '$($this.Name)' in project '$project' in organization '$($Organization.Name)'. Assume it is not present and all permissions as configured"
                } else {
                    $agentQueueScopeId = "$($targetAgentQueue.projectId)_$($targetAgentQueue.id)"
                    $existingAgentQueuePermissions = Get-AgentQueueAccessOnProjectLevel -AzdoOrganization $Organization.Name -ScopeId $agentQueueScopeId -AccessToken $AccessToken

                    $currentlyInheritedPermissions = $existingAgentQueuePermissions | Where-Object -Property access -eq 'inherited'
                    if ($this.Inheritance -eq $false) {
                        #permission inheritance is to be disabled
                        if ($currentlyInheritedPermissions.count -eq 0) {
                            #if there are no inherited permissions, we can assume inheritance is already disabled
                            #no need to remove access or disable inheritence
                        } else {
                            #if there are inherited permissions, disable inheritance
                            $actionDisableInheritance = New-PlanAction -Kind DisableAgentQueuePermissionInheritence -Organization  $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                                ProjectName = $project
                                AgentPoolQueueScopeId = $agentQueueScopeId
                                ProjectPoolQueueScopeId = $projectQueueScopeId
                            })
                            $plan.Actions.Add($actionDisableInheritance)

                            #this will convert all inherited permissions to explicitly assigned permissions
                            #so plan to remove those GUIDs as well
                            $actionRemoveInheritedAccess = New-PlanAction -Kind RevokeProjectAccess -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                                AgentPoolQueueScopeId = $agentQueueScopeId
                                ProjectPoolQueueScopeId = $projectQueueScopeId
                                ProjectName = $project
                                Guids = $currentlyInheritedPermissions.identity.id
                            })
                            $plan.Actions.Add($actionRemoveInheritedAccess)
                        }

                        #consider assigned permissions as the actual existing permissions
                        #this needs to be set in order for the next step (assinging permissions) to not assume permissions are granted
                        #when they are inherited (and therefor removed in the just planned actions)
                        $existingAgentQueuePermissions = $existingAgentQueuePermissions | Where-Object -Property access -eq 'assigned'
                    } else {
                        #permission inheritance is to be enabled
                        if ($currentlyInheritedPermissions.count -gt 0) {
                            #there are inherited permissions, so we can assume that inheritence is on
                            #no further action required
                        } else {
                            #inheritence needs to be turned on, create action
                            #inherited permissions will be automatically set when enabling inheritence
                            $actionDisableInheritance = New-PlanAction -Kind EnableAgentQueuePermissionInheritence -Organization  $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                                ProjectName = $project
                                AgentPoolQueueScopeId = $agentQueueScopeId
                                ProjectPoolQueueScopeId = $projectQueueScopeId
                            })
                        }
                    }
                }
            } else {
                #new agent pool
                if ($this.Inheritance -eq $false) {
                    #inheritence is to be disabled on the new pool
                    #but it doesn't exist yet so we need to get permissions from the level above (project agent queues)
                    $defaultAgentQueuesPermissions = Get-AgentQueueAccessOnProjectLevel -AzdoOrganization $Organization.Name -ScopeId $projectQueueScopeId -AccessToken $AccessToken

                    #plan actions to disable inheritance on new pool
                    $actionDisableInheritance = New-PlanAction -Kind DisableAgentQueuePermissionInheritence -Organization  $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                        ProjectName = $project
                        AgentPoolQueueScopeId = 'new-pool'
                        ProjectPoolQueueScopeId = $projectQueueScopeId
                    })
                    $plan.Actions.Add($actionDisableInheritance)

                    #since the pool will be created before we disable inheritance
                    #all the inherited rights will already be set, and converted to explicit permissions
                    #so plan to remove those GUIDs as well
                    $actionRemoveInheritedAccess = New-PlanAction -Kind RevokeProjectAccess -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                        AgentPoolQueueScopeId = 'new-pool'
                        ProjectPoolQueueScopeId = $projectQueueScopeId
                        ProjectName = $project
                        Guids = $defaultAgentQueuesPermissions.identity.id
                    })
                    $plan.Actions.Add($actionRemoveInheritedAccess)
                }
            }

            #when inheritance is disabled the permissions that are to be set on all agent queues in the project
            #will not be inherited, so set those permissions explicitly on the agent queue lvel
            if ($this.Inheritance -eq $false) {
                $adminGuidsForProject += $accessGuids.OrganizationalLevelAdminGuids
                $readerGuidsForProject += $accessGuids.OrganizationalLevelReaderGuids
            }

            #filter out any permissions that are already correctly set to avoid unnecessary API calls
            if ($existingAgentQueuePermissions) {
                Write-Verbose "Filtering already granted access (reader, user and admin) on project level to avoid unnecessary API calls"
                $preFilterReaderCount = $readerGuidsForProject.count
                $currentReaderPermissions = ($existingAgentQueuePermissions | Where-Object { $_.role.displayName -eq 'Reader' }).identity.id

                $readerGuidsForProject = $readerGuidsForProject | Where-Object { $_ -notin $currentReaderPermissions }
                Write-Verbose "Filtered project reader permissions $($readerGuidsForProject.Count)/$preFilterReaderCount remaining"

                $preFilterAdminCount = $adminGuidsForProject.count
                $currentAdminPermissions = ($existingAgentQueuePermissions | Where-Object { $_.role.displayName -eq 'Administrator' }).identity.id
                $adminGuidsForProject = $adminGuidsForProject | Where-Object { $_ -notin $currentAdminPermissions }
                Write-Verbose "Filtered project admin permissions $($adminGuidsForProject.Count)/$preFilterAdminCount remaining"

                $preFilterUserCount = $userGuidsForProject.count
                $currentUserPermissions = ($existingAgentQueuePermissions | Where-Object { $_.role.displayName -eq 'User' }).identity.id
                $userGuidsForProject = $userGuidsForProject | Where-Object { $_ -notin $currentUserPermissions }
                Write-Verbose "Filtered project user permissions $($userGuidsForProject.Count)/$preFilterUserCount remaining"
            }

            if ($readerGuidsForProject.Count -eq 0 -and $adminGuidsForProject.Count -eq 0 -and $userGuidsForProject.Count -eq 0) {
                Write-Verbose "[Skip] No project level permission changes needed for pool '$($this.Name)' in project '$project' in organization '$($Organization.Name)'"
                return
            }

            #ensure data meets requirements of API (empty arrays will cause API calls to fail, so set to null if empty)
            if ($readerGuidsForProject.Count -eq 0) { $readerGuidsForProject = @() }
            if ($adminGuidsForProject.Count -eq 0) { $adminGuidsForProject = @() }
            if ($userGuidsForProject.Count -eq 0) { $userGuidsForProject = @() }

            $newAction = New-PlanAction -Kind GrantProjectAccess -Organization $Organization.Name -PoolName $this.Name -Payload ([pscustomobject]@{
                Project = $project
                ReaderGuids = $readerGuidsForProject
                AdminGuids = $adminGuidsForProject
                UserGuids = $userGuidsForProject
                Inheritance = $this.Inheritance
            })
            $plan.Actions.Add($newAction)
        } #end of project loop
    }
}

class AccessGuidList {
    [string[]]$OrganizationalLevelAdminGuids
    [string[]]$ProjectLevelAdminGuids
    [string[]]$OrganizationalLevelReaderGuids
    [string[]]$ProjectLevelReaderGuids
    [hashtable]$UserGuids

    AccessGuidList() { }
    AccessGuidList([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }
}

class AzdoIdentity {
    [string]$Guid #also known as originId
    [string]$PrincipalName

    AzdoIdentity([string]$PrincipalName) {
        $this.PrincipalName = $PrincipalName
    }
    AzdoIdentity([string]$PrincipalName, [string]$Guid) {
        $this.PrincipalName = $PrincipalName
        $this.Guid = $Guid
    }
    AzdoIdentity([string]$PrincipalName, [AzdoIdentity[]]$GroupCache) {
        $this.PrincipalName = $PrincipalName
        $this.ResolveGuid($GroupCache)
    }
    ResolveGuid([AzdoIdentity[]]$GroupCache) {
        foreach ($Identity in $GroupCache) {
            if ($Identity.PrincipalName -eq $this.PrincipalName) {
                $this.Guid = $Identity.Guid
                return
            }
        }
        throw "Could not resolve guid for identity with principal name $($this.PrincipalName)"
    }
}

class AzdoAgentPool {
    [int]$Id
    [string]$Name
    [AzdoIdentity]$owner
    [string]$Scope

    AzdoAgentPool() { }
    AzdoAgentPool([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }
}

class AzdoProject {
    [string]$Id
    [string]$Name

    AzdoProject() { }
    AzdoProject([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }
}


class OrganizationDefaultConfig {
    [AzdoIdentity]$owner
    [AzdoIdentity[]]$admins
    [AzdoIdentity[]]$readers
    [string[]]$defaultProjects

    OrganizationDefaultConfig() { }
    OrganizationDefaultConfig([hashtable]$Properties) {
        foreach ($Property in $Properties.Keys) {
            $this.$Property = $Properties.$Property
        }
    }
}


class Organization {
    [string]$Name
    [OrganizationDefaultConfig]$DefaultConfig
    [AzdoAgentPool[]]$AgentPools
    [AzdoProject[]]$AllProjects
    [AzdoIdentity[]]$GroupCache
    [object]$AllProjectsValidUserGuidsCache #a complete list of all project valid user group guids within the organization, saves time when an agent pool specifies AllProjects=True

    GetGroupCache([string]$AccessToken) {
        write-host "`tLoading groups cache for organization $($this.Name)"
        $allGroups = Get-AllGroupsIdentifier -AzdoOrganization $this.Name -AccessToken $AccessToken
        $this.GroupCache = [AzdoIdentity[]]::new($allGroups.Count)
        for ($i = 0; $i -lt $allGroups.Count; $i++) {
            $group = $allGroups[$i]
            $this.GroupCache[$i] = [AzdoIdentity]::new($group.principalName, $group.originId)
        }
        write-host "`tFinished loading groups cache for organization $($this.Name) continuing with creating planning"
    }

    GetAgentPools([string]$AccessToken) {
        Write-Verbose "Retrieving existing agent pools for organization '$($this.Name)'"
        try {
            $organizationAgentPools = Get-AgentPoolsInOrganization -AzdoOrganization $this.Name -AccessToken $AccessToken
            #initialize the right size array to avoid resizing during the loop
            $this.AgentPools = [AzdoAgentPool[]]::new($organizationAgentPools.Count)
            for ($i = 0; $i -lt $organizationAgentPools.Count; $i++) {
                $agentPool = $organizationAgentPools[$i]
                $this.AgentPools[$i] = [AzdoAgentPool]::new([hashtable]@{
                    Id = $agentPool.id
                    Name = $agentPool.name
                    Scope = $agentPool.scope
                    owner = [AzdoIdentity]::new([string]$agentPool.owner.displayName, [string]$agentPool.owner.id)
                })
            }
        } catch {
            Write-Host "Failed to retrieve agent pools for organization '$($this.Name)'. Error: $_"
            continue
        }
    }

    GetProjects([string]$AccessToken) {
        Write-Verbose "Retrieving existing projects for organization '$($this.Name)'"
        try {

            $organizationProjects = Get-ProjectsInOrganization -AzdoOrganization $this.Name -AccessToken $AccessToken
            $this.AllProjects = [AzdoProject[]]::new($organizationProjects.Count)
            for ($i = 0; $i -lt $organizationProjects.Count; $i++) {
                $project = $organizationProjects[$i]
                $this.AllProjects[$i] = [AzdoProject]::new([hashtable]@{
                    Id = $project.id
                    Name = $project.name
                })
            }
        } catch {
            Write-Host "Failed to retrieve projects for organization '$($this.Name)'. Error: $_"
            continue
        }
    }
}

class Plan {
    [System.Collections.Generic.List[PlanAction]]$Actions
    Plan() {
        $this.Actions = [System.Collections.Generic.List[PlanAction]]::new()
    }

    ShowPlan() {
        if ($this.Actions.Count -eq 0) {
            Write-Host "No actions needed, target state already matches desired state."
            return
        }

        Write-Host "Plan contains $($this.Actions.Count) actions:"
        foreach($action in $this.Actions) {
            $target = "$($action.Organization)::$($action.PoolName)"
            switch ($action.Kind) {
                'CreatePool' { Write-Host " - $($action.Kind) $target (AllProjects=$($action.Payload.AllProjects))" }
                'SetOwner'   { Write-Host " - $($action.Kind) $target" }
                'GrantOrgAccess' { Write-Host " - $($action.Kind) $target" }
                'AddToProject' { Write-Host " - $($action.Kind) $target -> [$($action.Payload.Projects -join ', ')]" }
                'GrantProjectAccess' { Write-Host " - $($action.Kind) $target -> $($action.Payload.Project)" }
                'DisableAgentQueuePermissionInheritence' { Write-Host " - $($action.Kind) $target -> $($action.Payload.ProjectName)" }
                'EnableAgentQueuePermissionInheritence' { Write-Host " - $($action.Kind) $target -> $($action.Payload.ProjectName)" }
                'RevokeProjectAccess' { Write-Host " - $($action.Kind) $target -> $($action.Payload.ProjectName)" }
                default { Write-Host " - $($action.Kind) $target" }
            }
        }
    }

    ExecutePlan([string]$AccessToken) {
        $totalActions = $this.Actions.Count
        $currentActionIndex = 0
        write-host "Performing plan with $totalActions actions..."
        foreach($action in $this.Actions) {
            $currentActionIndex++
            $organisationName = $action.Organization
            $poolName = $action.PoolName

            switch ($action.Kind) {
                'CreatePool' {
                    Write-Host "[$currentActionIndex/$totalActions] Creating pool $organisationName::$poolName"
                    $ownerGuid = $action.Payload.OwnerGuid
                    if (-not $ownerGuid) { throw "Missing OwnerGuid for $organisationName::$poolName in CreatePool action." }
                    New-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -OwnerGuid $ownerGuid -ProvisionInAllProjects $action.Payload.AllProjects -AccessToken $AccessToken | Out-Null
                }
                'SetOwner' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    if ($poolId) {
                        Write-Host "[$currentActionIndex/$totalActions] Setting owner for $organisationName::$poolName"
                        Set-AgentPoolOwner -AzdoOrganization $organisationName -AgentPoolId $poolId -OwnerGuid $action.Payload.OwnerGuid -AccessToken $AccessToken | Out-Null
                    } else {
                        Write-Host "##vso[task.logissue type=warning]Unable to resolve pool for SetOwner: $organisationName::$poolName"
                    }
                }
                'GrantOrgAccess' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    if ($poolId) {
                        Write-Host "[$currentActionIndex/$totalActions] Granting org-level access for $organisationName::$poolName"
                        New-AgentPoolAccessOnOrganizationLevel -AzdoOrganization $organisationName -AgentPoolId $poolId -ReaderGuids $action.Payload.ReaderGuids -AdminGuids $action.Payload.AdminGuids -AccessToken $AccessToken | Out-Null
                    } else {
                        Write-Host "##vso[task.logissue type=warning]Unable to resolve pool for GrantOrgAccess: $organisationName::$poolName"
                    }
                }
                'AddToProject' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    if ($poolId) {
                        Write-Host "[$currentActionIndex/$totalActions] Adding pool to projects for $organisationName::$poolName"
                        #create agent queue, we skip the check because this action would not have been planned if the queue already existed for the project
                        New-AgentQueue -AzdoOrganization $organisationName -AgentPoolName $poolName -AgentPoolId $poolId -Projects $action.Payload.Projects -AccessToken $AccessToken -SkipCheck | Out-Null
                    } else {
                        Write-Host "##vso[task.logissue type=warning]Unable to resolve pool for AddToProject: $organisationName::$poolName"
                    }
                }
                'GrantProjectAccess' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    $inheritance = $action.Payload.Inheritance
                    if ($poolId) {
                        $projectName = $action.Payload.Project
                        Write-Host "[$currentActionIndex/$totalActions] Granting project-level access for $organisationName::$poolName -> $projectName"
                        $queueScopeId = Get-AgentQueueScopeId -AzdoOrganizationName $organisationName -AgentPoolId $poolId -ProjectName $projectName -AccessToken $AccessToken
                        if (-not $queueScopeId) {
                            Write-Host "##vso[task.logissue type=warning][Error]Unable to resolve queue scope for GrantProjectAccess: $organisationName::$poolName -> $projectName"
                            continue
                        }
                        New-AgentQueueAccessOnProjectLevel -AzdoOrganization $organisationName -AgentQueueScopeId $queueScopeId -ReaderGuids $action.Payload.ReaderGuids -AdminGuids $action.Payload.AdminGuids -UserGuids $action.Payload.UserGuids -Inheritance $inheritance -AccessToken $AccessToken | Out-Null
                    } else {
                        Write-Host "##vso[task.logissue type=warning][Error]Unable to resolve pool for GrantProjectAccess: $organisationName::$poolName"
                    }
                }
                'DisableAgentQueuePermissionInheritence' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    $projectName = $action.Payload.ProjectName
                    if ($poolId) {
                        $agentPoolQueueScopeId = $action.Payload.AgentPoolQueueScopeId
                        if ($agentPoolQueueScopeId -eq 'new-pool') {
                            $agentQueue = Get-AgentQueue -AzdoOrganization $organisationName -ProjectName $projectName -AgentQueueName $poolName -AccessToken $AccessToken
                            $agentPoolQueueScopeId = "$($action.Payload.ProjectPoolQueueScopeId)_$($agentQueue.Id)"
                        }
                        Write-Host "[$currentActionIndex/$totalActions] Disabling permission inheritance for $organisationName::$projectName::$poolName"
                        Set-AgentQueueInheritance -AzdoOrganization $organisationName -AgentQueueScopeId $agentPoolQueueScopeId -Inheritance $false -AccessToken $AccessToken
                    } else {
                        Write-Host "##vso[task.logissue type=warning][Error]Unable to resolve pool for DisableAgentQueuePermissionInheritence: $organisationName::$projectName::$poolName"
                    }
                }
                'EnableAgentQueuePermissionInheritence' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    $projectName = $action.Payload.ProjectName
                    if ($poolId) {
                        $agentPoolQueueScopeId = $action.Payload.AgentPoolQueueScopeId
                        Write-Host "[$currentActionIndex/$totalActions] Enabling permission inheritance for $organisationName::$projectName::$poolName"
                        Set-AgentQueueInheritance -AzdoOrganization $organisationName -AgentQueueScopeId $agentPoolQueueScopeId -Inheritance $true -AccessToken $AccessToken
                    } else {
                        Write-Host "##vso[task.logissue type=warning][Error]Unable to resolve pool for EnableAgentQueuePermissionInheritence: $organisationName::$projectName::$poolName"
                    }
                }
                'RevokeProjectAccess' {
                    $poolId = (Get-AgentPool -AzdoOrganization $organisationName -AgentPoolName $poolName -AccessToken $AccessToken).id
                    $projectName = $action.Payload.ProjectName
                    if ($poolId) {
                        $agentPoolQueueScopeId = $action.Payload.AgentPoolQueueScopeId
                        if ($agentPoolQueueScopeId -eq 'new-pool') {
                            $agentQueue = Get-AgentQueue -AzdoOrganization $organisationName -ProjectName $projectName -AgentQueueName $poolName -AccessToken $AccessToken
                            $agentPoolQueueScopeId = "$($action.Payload.ProjectPoolQueueScopeId)_$($agentQueue.Id)"
                        }
                        Write-Host "[$currentActionIndex/$totalActions] Revoking access on $organisationName::$projectName::$poolName"
                        Remove-AgentQueueAccessOnProjectLevel -AzdoOrganization $organisationName -AgentPoolQueueScopeId $agentPoolQueueScopeId -RoleAssignmentIds $action.Payload.Guids -AccessToken $AccessToken
                    } else {
                        Write-Host "##vso[task.logissue type=warning][Error]Unable to resolve pool for DisableAgentQueuePermissionInheritence: $organisationName::$projectName::$poolName"
                    }
                }
                default {
                    Write-Host "##vso[task.logissue type=warning]Unknown action kind: $($action.Kind)"
                }
            }
        }
    }
}
class PlanAction {
    [string]$Kind
    [string]$Organization
    [string]$PoolName
    [pscustomobject]$Payload

    PlanAction([string]$Kind, [string]$Organization, [string]$PoolName, [pscustomobject]$Payload) {
        $this.Kind = $Kind
        $this.Organization = $Organization
        $this.PoolName = $PoolName
        $this.Payload = $Payload
    }
}