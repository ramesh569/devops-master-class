<#
.SYNOPSIS
    This script sets default agent queue on pipelines in an Azure DevOps organization.
.SUMMARY
    The script will set the default agent queue on pipelines (in the UI, this is the "Default agent pool" setting)
    The pipeline will only be modified if the current default agent queue is not found (e.g. because it was deleted)
    It will attempt to lookup the old agent queue name from the cache file (created with snapshot mode) and then try and find a agent pool with the exact name
    If it can't find an agent pool with the same name it will set the agent queue default to the provided default agent pool parameter
.PARAMETER AzdoOrganization
    The Azure DevOps organization name (e.g. raboweb-test)
.PARAMETER StandardAgentPool
    The standard agent pool name to set as default on pipelines when no cached agent pool name is (remember that not all agents are available in each organization)
.PARAMETER Mode
    The mode to run the script in:
    - snapshot: Take a snapshot of current default agent pools and save to cache (on disk)
    - plan: Plan changes to set default agent queue on all pipelines
    - execute: Execute changes to set default agent queue on all pipelines (this mode includes Plan actions prior to execution)
.PARAMETER ResumeAfterProject
    (Optional) When specified resume processing after the specified project name. It will process whatever comes after the specified project
.NOTES
    Access Token needs Build (Read) permissions to run snapshot mode
    Access Token needs Build (Read) and Agent Pools (Read) permissions to run plan mode
    Access Token needs Build (Read & Execute) and Agent Pools (Read) permissions to run execute mode
.EXAMPLE
    .\Set-DefaultAgents.ps1 -AzdoOrganization raboweb-test -StandardAgentPool Shared-EU-VM-Linux-Lean-M-Prod -Mode snapshot
    .\Set-DefaultAgents.ps1 -AzdoOrganization raboweb-test -StandardAgentPool Shared-EU-VM-Linux-Lean-M-Prod -Mode plan
#>
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output and logging in this script')]
param (
    [Parameter(Mandatory)]
    [string]$AzdoOrganization,

    [Parameter(Mandatory)]
    [string]$StandardAgentPool,

    [Parameter(Mandatory)]
    [ValidateSet('snapshot', 'plan', 'execute')]
    [string]$Mode,

    [Parameter(Mandatory=$false)]
    [string]$ResumeAfterProject = ""
)
#[config]
$snapshotFileName = "pipeline-default-agentpool-cache.xml"
$logFileName = "set-defaultagents.log"

#[functions]
. .\images\_shared\jobs\Functions-AzdoApi.ps1

class DefaultAgentQueueChange {
    [string]$AzdoOrganization
    [string]$ProjectName
    [string]$PipelineName
    [string]$PipelineId
    [string]$NewAgentQueueName
    [string]$NewAgentQueueId
}

function Write-LogEntry() {
    param (
        [string]$Message
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] $Message"
    Add-Content -Path $logFileName -Value $logEntry
    Write-Host $logEntry
}

function Get-TargetAgentPoolName() {
    param (
        [string]$CacheKey
    )

    #cache key is in format "organization|projectId|old-queue-id"
    $defaultAgentPoolId = $CacheKey.Split('|')[2]

    #when there is no cache hit, we don't know which pool the old queue ID maps to, so return the default pool
    if (!($agentPoolCache.ContainsKey($CacheKey))) {
        Write-LogEntry "  No cached agent pool name found for ID: $defaultAgentPoolId. Setting pool to $StandardAgentPool"
        return $StandardAgentPool
    }

    #get cached pool name
    $cachedAgentPoolName = $agentPoolCache[$CacheKey]

    #if the cached name is "Unknown", we don't know which pool the old queue ID maps to, so return the default pool
    #this situation can happen when the cache was created but the agent queue was already invalid/blank
    if ($cachedAgentPoolName -eq "Unknown") {
        Write-LogEntry "  Cached agent pool name is 'Unknown' for ID: $defaultAgentPoolId. Setting pool to $StandardAgentPool"
        return $StandardAgentPool
    }

    #cache has an actual poolname, return
    Write-LogEntry "  Found cached agent pool name '$cachedAgentPoolName' for ID: $defaultAgentPoolId."
    return $cachedAgentPoolName
}

#[script]
$accessToken = Get-AuthToken

#validate the provided standard pool exists in the organization
Get-AgentPool -AzdoOrganization $AzdoOrganization -AgentPoolName $StandardAgentPool -AccessToken $accessToken | Out-Null

#caches and plans
$agentPoolCache = @{} #key: "organization|projectId|old-queue-id" value: "agent-pool-name"
$plannedChanges = @()

if ($ResumeAfterProject -ne "") {

}

if(Test-Path -Path $snapshotFileName) {
    Write-LogEntry "Snapshot file found at $snapshotFileName"
    Write-LogEntry "Loading 'AgentQueueID <-> Agent Pool Name' snapshot from $snapshotFileName"
    $agentPoolCache = Import-Clixml -Path $snapshotFileName
} else {
    Write-LogEntry "No snapshot file found at $snapshotFileName"
    if ($Mode -eq 'plan' -or $Mode -eq 'execute') {
        #if no cache file is found, ask user for confirmation
        write-host "No snapshot file found at $snapshotFileName. Running plan or execute will set all non-specified default agent pool to the standard agent pool: $StandardAgentPool instead of restoring the previous selected agent queue selection"
        #confirm if the user wants to continue
        $confirm = Read-Host "Do you want to continue? (y/n)"
        if ($confirm -ne 'y') {
            write-host "Aborting script."
            exit 1
        }
    }
}

#keep statistics (for sanity check)
$totalProcessedProjects = 0
$totalProcessedPipelines = 0

#configure skipping
$skipping=$true #keep track if we are skipping projects until we reach resume point
if ($ResumeAfterProject -eq "") {
    $skipping=$false
}

#loop through each project
$projects = Get-ProjectsInOrganization -AzdoOrganization $AzdoOrganization -AccessToken $accessToken

$projectIndex = 0
foreach ($project in $projects) {
    $projectIndex++

    #skip until we reach resume point
    if ($skipping) {
        Write-LogEntry "Skipping project [$projectIndex/$($projects.Count)] : $($project.name)"
        if ($project.name -eq $ResumeAfterProject) {
            Write-LogEntry "Resuming after at next project."
            $skipping = $false
        }
        continue
    }

    Write-LogEntry "Processing project [$projectIndex/$($projects.Count)] : $($project.name)"
    $totalProcessedProjects++

    if ($Mode -eq 'snapshot') {
        #get agent queues for this project
        $agentQueues = Get-AgentQueuesInProject -AzdoOrganization $AzdoOrganization -ProjectName $project.name -AccessToken $accessToken

        foreach($agentQueue in $agentQueues) {
            $cacheKey = "$AzdoOrganization|$($project.id)|$($agentQueue.id)"
            $agentPoolCache[$cacheKey] = $agentQueue.name
            Write-LogEntry "  Agent Queue $($agentQueue.name) (ID: $($agentQueue.id))"
        }

        continue #next project
    }

    #get pipelines in project
    $pipelines = Get-PipelinesInProject -AzdoOrganization $AzdoOrganization -Project $project.name -AccessToken $accessToken

    $pipelineIndex = 0
    foreach ($pipeline in $pipelines) {
        $pipelineIndex++
        Write-LogEntry " Processing pipeline [$pipelineIndex/$($pipelines.Count)]: $($pipeline.name)"
        $totalProcessedPipelines++

        #get pipeline definition
        $cacheDefinition = ($Mode -eq 'execute') #cache call if we are in execute mode because we need to make this call again when updating
        $pipelineDefinition = Get-PipelineDefinition -AzdoOrganization $AzdoOrganization -Project $project.name -PipelineId $pipeline.id -AccessToken $accessToken -AllowCache:$cacheDefinition

        #get default agent pool ID
        $defaultAgentPoolId = $pipelineDefinition.queue.id
        $cacheKey = "$AzdoOrganization|$($project.id)|$defaultAgentPoolId"

        #if default agent pool id is null or empty, skip
        if ([string]::IsNullOrEmpty($defaultAgentPoolId)) {
            Write-LogEntry "  [no-default] Pipeline '$($pipeline.name)' has no default agent queue defined."
            continue #next pipeline
        }

        if ($Mode -eq 'plan' -or $Mode -eq 'execute') {
            #if pool name is specified in pipeline definition, the queue exists, no action needed
            if ($pipelineDefinition.queue.name) {
                Write-LogEntry "  [skip] Default Agent Queue for pipeline '$($pipeline.name)' is already set to '$($pipelineDefinition.queue.name)'. No action needed."
                continue #next pipeline
            }

            #lookup agent queue name in cache so we can find an appropriate replacement
            $targetAgentPoolName = Get-TargetAgentPoolName -CacheKey $cacheKey

            # #Enable This to  only fix MDP Pool (-VM-Linux- or -VM-Windows-)
            # if ($targetAgentPoolName -notmatch "-VM-(Linux|Windows)-") {
            #     Write-LogEntry "  [skip] Target Agent Pool '$targetAgentPoolName' for pipeline '$($pipeline.name)' is not a MDP pool. Skipping."
            #     continue #next pipeline
            # }

            #lookup agent queue id
            $targetAgentQueue = $null
            try {
                $targetAgentQueue = Get-AgentQueue -AzdoOrganization $AzdoOrganization -ProjectName $project.name -AgentQueueName $targetAgentPoolName -AccessToken $accessToken
            } catch {
                Write-LogEntry "  [error] Failed to lookup agent queue '$targetAgentPoolName' in project '$($project.name)'."
                continue #next pipeline
            }

            #store action (to update pipeline with new target agent queue) in plan
            Write-LogEntry "  [plan] Update Default Agent Queue for pipeline '$($pipeline.name)' to '$targetAgentPoolName' (ID: $($targetAgentQueue.id))"
            $plannedChanges += [DefaultAgentQueueChange]@{
                AzdoOrganization = $AzdoOrganization
                ProjectName = $project.name
                PipelineName = $pipeline.name
                PipelineId = $pipeline.id
                NewAgentQueueName = $targetAgentPoolName
                NewAgentQueueId = $targetAgentQueue.id
            }
        }
    }
}

if ($Mode -eq 'snapshot') {
    Write-LogEntry "Saving 'AgentQueueID <-> Agent Pool Name' snapshot; $($agentPoolCache.Count) entries to $snapshotFileName"
    Export-Clixml -InputObject $agentPoolCache -Path $snapshotFileName
}

if ($Mode -eq 'plan') {
    Write-LogEntry "Planned Changes to set Default Agent Queues:"
    $plannedChanges | Format-Table -AutoSize
}

if ($Mode -eq 'execute') {
    Write-LogEntry "Execute Plan"
    $changeIndex = 0
    foreach($change in $plannedChanges) {
        $changeIndex++
        try {
            #set default agent queue in pipeline definition
            Set-DefaultAgentQueueInPipelineDefinition `
                -AzdoOrganization $change.AzdoOrganization `
                -ProjectName $change.ProjectName `
                -PipelineId $change.PipelineId `
                -NewAgentQueueName $change.NewAgentQueueName `
                -NewAgentQueueId $change.NewAgentQueueId `
                -AccessToken $accessToken `
                -AllowCache
            Write-LogEntry "  [updated] ($changeIndex/$($plannedChanges.Count)) Setting Default Agent Queue for pipeline '$($change.PipelineName)' [$($change.PipelineId)] in project '$($change.ProjectName)' to '$($change.NewAgentQueueName)' [$($change.NewAgentQueueId)]"
        } catch {
            Write-LogEntry "    [error] ($changeIndex/$($plannedChanges.Count))  Failed to set default agent queue for pipeline '$($change.PipelineName)' in project '$($change.ProjectName)'. Error: $_"
        }
    }
}

#print statistics
Write-LogEntry "Mode was set to $Mode"
if ($ResumeAfterProject -ne "") {
    Write-LogEntry "Resumed processing after project: $ResumeAfterProject"
    Write-LogEntry "Total processed projects: $totalProcessedProjects (count excludes skipped projects)"
} else {
    Write-LogEntry "Total processed projects: $totalProcessedProjects"
}
Write-LogEntry "Total processed pipelines: $totalProcessedPipelines"
if ($Mode -eq 'plan') {
    if ($ResumeAfterProject -ne "") {
        Write-LogEntry "Total planned changes to apply: $($plannedChanges.Count) (count excludes skipped projects)"
    } else {
        Write-LogEntry "Total planned changes to apply: $($plannedChanges.Count)"
    }
}
if ($Mode -eq 'execute') {
    if ($ResumeAfterProject -ne "") {
        Write-LogEntry "Total changes applied: $($plannedChanges.Count) (count excludes skipped projects)"
    } else {
        Write-LogEntry "Total changes applied: $($plannedChanges.Count)"
    }
}

Write-LogEntry "Script Completed"