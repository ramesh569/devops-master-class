<#
.SYNOPSIS
    script to report deployment pool usage by builds.
.DESCRIPTION
    - Enumerates deployment pools in an organization
    - Lists targets (agents) for each pool
    - Scans builds in all projects (or a single project if specified) for the last N days
    - Scans build timelines to find which pools were used by each build
.EXAMPLE
    .\collect-pools-runs.ps1 -Days 7
    .\collect-pools-runs.ps1 -Days 30 -Project "MyProject"
#>

[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]

param(
    [string]$Org = 'raboweb',
    [int]$Days = 7,
    [string]$Project
)

$ErrorActionPreference = 'Stop'

#[functions]
. .\images\_shared\jobs\Functions-AzdoApi.ps1

$accessToken = Get-AuthToken

$headers = Get-BasicAuthHeaders -AccessToken $accessToken


function Invoke-WithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Uri,
        [hashtable]$Headers,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )
    $attempt = 0
    while ($attempt -lt $MaxAttempts) {
        try {
            $attempt++
            $resp = Invoke-RestMethod -Uri $Uri -Headers $Headers -Method Get -ErrorAction Stop
            return $resp
        } catch {
            Write-Warning ("[Attempt {0}] Request failed: {1}" -f $attempt, $_)
            if ($attempt -ge $MaxAttempts) { throw $_ }
            Start-Sleep -Seconds ([int]($DelaySeconds * [math]::Pow(2, $attempt - 1)))
        }
    }
}

function Invoke-WebRequest-WithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Uri,
        [hashtable]$Headers,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    $attempt = 0
    while ($attempt -lt $MaxAttempts) {
        try {
            $attempt++
            $resp = Invoke-WebRequest -Uri $Uri -Headers $Headers -Method Get -ErrorAction Stop
            return $resp
        } catch {
            Write-Warning ("[Attempt {0}] Web request failed: {1}" -f $attempt, $_)
            if ($attempt -ge $MaxAttempts) { throw $_ }
            Start-Sleep -Seconds ([int]($DelaySeconds * [math]::Pow(2, $attempt - 1)))
        }
    }
}

function Get-DeploymentPools{
    $uri = "https://dev.azure.com/$Org/_apis/distributedtask/pools?poolType=deployment&api-version=7.1"
    $resp = Invoke-WithRetry -Uri $uri -Headers $headers
    if ($resp -and $resp.value) { Write-Host ("Fetched pools: {0}" -f ($resp.value.Count -as [string])) }
    return $resp
}

function Get-AgentsForPool {
    param([string]$PoolId)
    $uri = "https://dev.azure.com/$Org/_apis/distributedtask/pools/$PoolId/agents?api-version=7.1"
    try {
        $resp = Invoke-WithRetry -Uri $uri -Headers $headers
        Write-Host ("Fetched agents for pool {0} : {1}" -f $PoolId, ($resp.value.Count -as [string]))
        return $resp
    } catch {
        Write-Warning ("Failed to fetch agents for pool {0}: {1}" -f $PoolId, $_)
        return $null
    }
}


function Get-BuildsSince {
    param([string]$ProjectName, [string]$MinTime)
    $enc = [uri]::EscapeDataString($ProjectName)
    $baseUri = "https://dev.azure.com/$Org/$enc/_apis/build/builds?minTime=$MinTime&api-version=7.1"
    Write-Host ("Fetching builds for project {0} since {1} -> {2}" -f $ProjectName, $MinTime, $baseUri)

    $allValues = @()
    $continuation = $null
    $top = 500
    do {
        $uri = if ($continuation) { "$baseUri&continuationToken=$continuation&`$top=$top" } else { "$baseUri&`$top=$top" }
        $resp = Invoke-WebRequest-WithRetry -Uri $uri -Headers $headers
        if (-not $resp) { break }

        try {
            $page = $resp.Content | ConvertFrom-Json
        } catch {
            Write-Warning ("Failed to parse builds response JSON for project {0}: {1}" -f $ProjectName, $_)
            break
        }

        if ($page -and $page.value) { $allValues += $page.value }

        $continuation = $resp.Headers['x-ms-continuationtoken']

    } while ($continuation)

    Write-Host ("Fetched builds for {0}: {1}" -f $ProjectName, ($allValues.Count -as [string]))
    return @{ value = $allValues }
}

function Get-BuildTimeline {
    param([string]$ProjectName, [string]$BuildId)
    $enc = [uri]::EscapeDataString($ProjectName)
    $uri = "https://dev.azure.com/$Org/$enc/_apis/build/builds/$BuildId/timeline?api-version=7.1"
    # Write-Host ("Fetching timeline for build {0} in project {1} " -f $BuildId, $ProjectName)
        try {
            $resp = Invoke-WithRetry -Uri $uri -Headers $headers
            return $resp
        } catch {
            Write-Warning ("Failed to fetch timeline for build {0}: {1}" -f $BuildId, $_)
            return $null
        }
}

# Main
try {
    $poolsResp = Get-DeploymentPools
} catch {
    Write-Error "Failed to fetch pools: $_"
    exit 3
}

$agentsByPool = @{}
foreach ($p in $poolsResp.value) {
    $poolId = [string]$p.id
    $agentsResp = Get-AgentsForPool -PoolId $poolId
    $list = @()
    if ($agentsResp -and $agentsResp.value) {
        foreach ($a in $agentsResp.value) {
            $created = $null
            if ($a.createdOn) {
                try { $created = [datetime]$a.createdOn } catch { $created = $null }
            }
            $list += [PSCustomObject]@{
                AgentId   = [string]$a.id
                AgentName = $a.name
                CreatedOn = $created
            }
        }
    }
    $agentsByPool[$poolId] = $list

}

# Build agent->pool map for timeline matching
$agentToPool = @{}
foreach ($kv in $agentsByPool.GetEnumerator()) {
    $poolIdKey = $kv.Key
    foreach ($a in $kv.Value) {
        if ($a.AgentId) { $agentToPool[[string]$a.AgentId] = $poolIdKey }
        if ($a.AgentName) { $agentToPool["name::" + $a.AgentName] = $poolIdKey }
    }
}

$start = (Get-Date).ToUniversalTime().AddDays(-$Days)
$minTime = $start.ToString("yyyy-MM-ddTHH:mm:ss'Z'")

if ($Project) {
    $projects = @{ value = @(@{ name = $Project }) }
} else {
    $projArray = Get-ProjectsInOrganization -AzdoOrganization $Org -AccessToken $accessToken
    Write-Host ("Fetched projects: {0}" -f ($projArray.Count -as [string])); 
    $projects = @{ value = $projArray }
}

if (-not $projects -or -not $projects.value) {
    Write-Warning "No projects found; exiting."
    exit 0
}

# initialize pool counts: include all pools
$poolCounts = @{}
foreach ($p in $poolsResp.value) {
    $poolId = [string]$p.id
    $agentsList = @()
    if ($agentsByPool.ContainsKey($poolId)) { $agentsList = $agentsByPool[$poolId] }
    # Include all deployment pools, even those with zero agents
    $poolCounts[$poolId] = @{ Pool = $p; Count = 0; LastRun = $null }
}

foreach ($proj in $projects.value) {
    $projName = $proj.name
    Write-Host "Scanning builds for project $projName since $minTime"
    try {
        $buildsResp = Get-BuildsSince -ProjectName $projName -MinTime $minTime
    } catch { Write-Warning ("Failed to fetch builds for {0}: {1}" -f $projName, $_); continue }
    if (-not $buildsResp -or -not $buildsResp.value) { continue }

    foreach ($b in $buildsResp.value) {
        # Determine a representative timestamp for the build (finish > start > queue)
        $bTimestamp = $null
        if ($b.finishTime) { try { $bTimestamp = [datetime]$b.finishTime } catch { $bTimestamp = $null } }
        if (-not $bTimestamp -and $b.startTime) { try { $bTimestamp = [datetime]$b.startTime } catch { $bTimestamp = $null } }
        if (-not $bTimestamp -and $b.queueTime) { try { $bTimestamp = [datetime]$b.queueTime } catch { $bTimestamp = $null } }

        # Log build timestamps for diagnostics
        $tsInfo = if ($bTimestamp) { $bTimestamp.ToString("yyyy-MM-ddTHH:mm:ss") } else { "<no-timestamp>" }
        # Write-Host ("Build {0} timestamps: finish={1}, start={2}, queue={3} -> chosen={4}" -f $b.id, ($b.finishTime -as [string]), ($b.startTime -as [string]), ($b.queueTime -as [string]), $tsInfo)

        # Skip builds that are older than the requested window
        if ($bTimestamp -and $bTimestamp -lt $start) {
            Write-Host ("Skipping build {0} because timestamp {1} is older than window start {2}" -f $b.id, $bTimestamp.ToString("yyyy-MM-ddTHH:mm:ss"), $start.ToString("yyyy-MM-ddTHH:mm:ss"))
            continue
        }

        $timeline = Get-BuildTimeline -ProjectName $projName -BuildId $b.id
        if (-not $timeline -or -not $timeline.records) { continue }
        $seenPools = @{}
        foreach ($rec in $timeline.records) {
            $poolId = $null
            if ($rec.agentId -and $agentToPool.ContainsKey([string]$rec.agentId)) { $poolId = $agentToPool[[string]$rec.agentId] }
            if (-not $poolId -and $rec.workerId -and $agentToPool.ContainsKey([string]$rec.workerId)) { $poolId = $agentToPool[[string]$rec.workerId] }
            if (-not $poolId -and $rec.workerName -and $agentToPool.ContainsKey("name::" + $rec.workerName)) { $poolId = $agentToPool["name::" + $rec.workerName] }
            if ($poolId) { $seenPools[$poolId] = $true }
        }
        if ($seenPools.Keys.Count -gt 0) {
            # Determine a timestamp for LastRun: prefer finishTime, fallback to startTime, then queueTime
            $finish = $null
            if ($b.finishTime) {
                try { $finish = [datetime]$b.finishTime } catch { $finish = $null }
            } elseif ($b.startTime) {
                try { $finish = [datetime]$b.startTime; Write-Host ("Note: Build {0} has no finishTime; using startTime for LastRun" -f $b.id) } catch { $finish = $null }
            } elseif ($b.queueTime) {
                try { $finish = [datetime]$b.queueTime; Write-Host ("Note: Build {0} has no finish/start; using queueTime for LastRun" -f $b.id) } catch { $finish = $null }
            }
            foreach ($poolId in $seenPools.Keys) {
                # only count pools that were fetched as deployment pools with agents
                if (-not $poolCounts.ContainsKey($poolId)) { continue }
                $poolCounts[$poolId].Count += 1
                $newCount = $poolCounts[$poolId].Count
                $poolName = $poolCounts[$poolId].Pool.name
                Write-Host ("Increment: Build {0} -> Pool {1} ({2}): RunCount={3}" -f $b.id, $poolId, $poolName, $newCount)
                if ($finish) {
                    if (-not $poolCounts[$poolId].LastRun -or $finish -gt [datetime]$poolCounts[$poolId].LastRun) { $poolCounts[$poolId].LastRun = $finish }
                }
            }
        }
    }
}

# prepare final rows
$rows = @()
foreach ($k in $poolCounts.Keys) {
    $entry = $poolCounts[$k]
    $agents = @()
    if ($agentsByPool.ContainsKey($k)) { $agents = $agentsByPool[$k] }
    $agentList = ''
     if ($agents.Count -gt 0) {
        $agentList = ($agents | ForEach-Object {
            if ($_.CreatedOn) { "{0} ({1}) [Created: {2}]" -f $_.AgentName, $_.AgentId, ([datetime]$_.CreatedOn).ToString("yyyy-MM-ddTHH:mm:ss.ff'Z'") }
            else { "{0} ({1})" -f $_.AgentName, $_.AgentId }
        }) -join '; '
    }

    $rows += [PSCustomObject]@{
        DeploymentPoolId = $entry.Pool.id
        DeploymentPoolName = $entry.Pool.name
        CreatedOn = if ($entry.Pool.createdOn) { ([datetime]$entry.Pool.createdOn).ToString("yyyy-MM-ddTHH:mm:ss.ff'Z'") } else { $null }
        CreatedByDisplayName = $entry.Pool.createdBy.displayName
        EmailId = $entry.Pool.createdBy.uniqueName
        AgentCount = @($agents).Count
        AgentList = $agentList
        NewAgents = @($agents | Where-Object { $_.CreatedOn -ge $start }).Count
        NewAgentsList = @($agents | Where-Object { $_.CreatedOn -ge $start } | ForEach-Object {
            if ($_.CreatedOn) { "{0} ({1}) [Created: {2}]" -f $_.AgentName, $_.AgentId, ([datetime]$_.CreatedOn).ToString("yyyy-MM-ddTHH:mm:ss.ff'Z'") }
            else { "{0} ({1})" -f $_.AgentName, $_.AgentId }
        }) -join '; '
        RunCount = $entry.Count
        LastRun = if ($entry.LastRun) { ([datetime]$entry.LastRun).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss'Z'") }
    }
}

# Print each pool's run count for quick inspection
Write-Host "Run counts per pool:"
foreach ($r in $rows) {
    $last = if ($r.LastRun) { ([datetime]$r.LastRun).ToString("yyyy-MM-ddTHH:mm:ss'Z'") } else { "<never>" }
    Write-Host ("{0} - {1}: RunCount={2}, LastRun={3}" -f $r.DeploymentPoolId, $r.DeploymentPoolName, $r.RunCount, $last)

}

# Save to CSV
$outDir = $env:BUILD_ARTIFACTSTAGINGDIRECTORY
if (-not (Test-Path -Path $outDir/report)) {
    New-Item -Path $outDir/report -ItemType Directory -Force | Out-Null
}

$csvName = "deployment_pools_runs_$(Get-Date -Format yyyyMMdd_HHmmss).csv"
$csvPath = Join-Path -Path $outDir/report -ChildPath $csvName
$rows | Sort-Object -Property @{Expression={[int]$_.RunCount};Descending=$true} | Export-Csv -Path $csvPath -NoTypeInformation
Write-Host "Saved consolidated report to $csvPath"

# end
