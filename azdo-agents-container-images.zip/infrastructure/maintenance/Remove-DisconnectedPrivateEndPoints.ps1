<#
.SYNOPSIS
    Remove all private endpoints that are in disconnected state
.DESCRIPTION
    Remove all private endpoints that are in disconnected state in
    Only remove resources that have a matching build-id tag and are not part of the legacy environment
#>
param (
    [Parameter(Mandatory=$false)]
    [switch]$WhatIf
)

#[configuration]
$targetResourceRegex = 'rg-(cloudonly-kubernetes|agents)-.*-private-endpoint|rg-pep-(prod|test|dev)-(weu|neu|eus|eau|sbr)(-gdp)*(-[0-9]+)*'

#[script]
$currentSubscription = (Get-AzContext).Subscription
Write-Output "Executing script on subscription $($currentSubscription.id) ($($currentSubscription.Name))"
$argQuery = @"
    resources
    | where type =~ 'microsoft.network/privateendpoints'
    | where subscriptionId == '$($currentSubscription.id)'
    | where resourceGroup matches regex '$targetResourceRegex'
    | where tostring(properties) contains 'Disconnected'
"@
Write-Output "Query:`n$argQuery"

Write-Output "Executing query to get disconnected private endpoints"
$disconnectedPrivateEndPoints = Search-AzGraph -Query $argQuery

#no private endpoints to be deleted, exit script
if ($disconnectedPrivateEndPoints.Count -eq 0) {
    Write-Output "No disconnected private endpoints found. Exiting script"
    exit 0
}

Write-Output "Private endpoints to remove:"
$disconnectedPrivateEndPoints.Name | ForEach-Object {
    Write-Output "`t$_"
}

$tempRemovedLocks = @()
try {
    foreach($privateEndPointResourceGroup in $disconnectedPrivateEndPoints.resourceGroup | Select-Object -Unique) {

        #this gets locks on group as well as lock on individual private endpoints (including ones not to be deleted)
        Write-Output "`tGet locks on PEP resource group $privateEndPointResourceGroup"
        $allLocksOnResourceGroup = Get-AzResourceLock -ResourceGroupName $privateEndPointResourceGroup

        #get resource group locks
        $allLocksOnResourceGroup | Where-Object -Property ResourceType -eq 'Microsoft.Authorization/locks' | ForEach-Object {
            $tempRemovedLocks += $_ #store so we can restore later
            $LockArguments = @{
                LockId = $_.LockId
                WhatIf = $WhatIf
                Force = !($WhatIf)
                Verbose = $true
            }
            Write-Output "`t`tRemove Lock on Resource Group"
            Remove-AzResourceLock @LockArguments
        }

          #get the resource group of the associated dns zones group (based on nanming convention)
          $resourceGroupNameDnsZones = $privateEndPointResourceGroup -replace "private-endpoint", "private-dns-zones"
          Write-Output "`tGet locks on DNS resource group $resourceGroupNameDnsZones"
          $resourceGroupDnsZones = Get-AzResourceGroup -Name $resourceGroupNameDnsZones -ErrorAction SilentlyContinue
          if ($resourceGroupDnsZones) {
              Get-AzResourceLock -ResourceGroupName $resourceGroupNameDnsZones | Where-Object -Property ResourceType -eq 'Microsoft.Authorization/locks' | ForEach-Object {
                  $tempRemovedLocks += $_ #store so we can restore later
                  $LockArguments = @{
                      LockId = $_.LockId
                      WhatIf = $WhatIf
                      Force = !($WhatIf)
                      Verbose = $true
                  }
                  Write-Output "`t`tRemove DNS Resource Group Lock"
                  Remove-AzResourceLock @LockArguments
              }
          }
    }

    if ($tempRemovedLocks.Count -gt 0) {
        Write-Output "Sleeping 20 seconds after unlocking resource groups to ensure PEP isn't still locked"
        Start-Sleep -Seconds 20
    }

    foreach($privateEndPoint in $disconnectedPrivateEndPoints) {
        Write-Output "---`nPrivate endpoint $($privateEndPoint.Name) in resource group $($privateEndPoint.resourceGroup)"

        #this gets locks on group as well as lock on individual private endpoints (including ones not to be deleted)
        Write-Output "`tGet locks on PEP resource group"
        $allLocksOnResourceGroup = Get-AzResourceLock -ResourceGroupName $privateEndPoint.resourceGroup

        #get all locks for private endpoint to be deleted
        $privateEndPointLocks = $allLocksOnResourceGroup | Where-Object -Property ResourceType -eq 'Microsoft.Network/privateEndpoints' | Where-Object -Property ResourceName -eq $_.name
        $privateEndPointLocks | ForEach-Object {
            $LockArguments = @{
                LockId = $_.LockId
                WhatIf = $WhatIf
                Force = !($WhatIf)
                Verbose = $true
            }
            Write-Output "`tRemove PEP Lock"
            Remove-AzResourceLock @LockArguments
        }

        #remove private endpoint
        $PrivateEndpointArguments = @{
            Name = $privateEndPoint.Name
            ResourceGroupName = $privateEndPoint.resourceGroup
            WhatIf = $WhatIf
            Force = !($WhatIf)
            Verbose = $true
        }
        Write-Output "`tRemove PEP"
        Remove-AzPrivateEndpoint @PrivateEndpointArguments
    }
    Write-Output "Removed all disconnected private endpoints"
} finally {
    if ($tempRemovedLocks.Count -eq 0) {
        Write-Output "No locks were removed, therefor no need to restore"
    } else {
        Write-Output "Sleeping 20 seconds before restoring locks"
        Start-Sleep -Seconds 20

        #restore locks
        Write-Output "Restore locks"
        $tempRemovedLocks | Select-Object -Unique Name, Properties, ResourceGroupName, ResourceName, ResourceType | ForEach-Object {
            $LockArguments = @{
                LockName = $_.Name
                LockLevel = $_.Properties.level
                Whatif = $WhatIf
                Force = !($WhatIf)
                Verbose = $true
            }
            if ($_.ResourceType -eq  'Microsoft.Authorization/locks') {
                $LockArguments.Add("ResourceGroupName", $_.ResourceGroupName)
            } else {
                $LockArguments.Add("ResourceName", $_.ResourceName)
                $LockArguments.Add("ResourceType", $_.ResourceType)
            }
            if (!([string]::IsNullOrEmpty($_.Properties.notes))) {
                $LockArguments.Add("LockNotes", $_.Properties.notes)
            }
            Write-Output "`tAdd Lock $($_.Name)"
            New-AzResourceLock @LockArguments
        }
    }
}
Write-Output "Script completed"
