<#
.SYNOPSIS
    Export container images currently in use by ScaledJobs in AKS clusters.
.DESCRIPTION
    Checks all AKS clusters visible in the current Azure subscription context and writes the discovered ScaledJob image usage to disk as CLIXML.
.PARAMETER SubscriptionName
    Expected Azure subscription name for this export.
.PARAMETER OutputPath
    Path to write the CLIXML export to.
.PARAMETER Force
    Continue the script even if the script can't determine all versions in use for an individual cluster.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$SubscriptionName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputPath,

    [Parameter(Mandatory=$false)]
    [switch]$Force
)

Write-Host "Checking Subscription $SubscriptionName"
az account set --subscription $SubscriptionName --only-show-errors
if ($LASTEXITCODE -ne 0) {
    throw "Failed to set Azure subscription to $SubscriptionName. Unable to safely proceed."
}

Write-Host "Getting AKS clusters"
$clusters = (az aks list -o json --only-show-errors) | ConvertFrom-Json

if ($null -eq $clusters -or $clusters.Count -eq 0) {
    throw "No AKS clusters found in subscription $SubscriptionName. Unable to safely proceed."
}

$listOfAllScaledJobs = @()
foreach ($cluster in $clusters) {
    Write-Host "Checking cluster $($cluster.name)"

    az aks get-credentials `
        --resource-group $cluster.resourceGroup `
        --name $cluster.name `
        --overwrite-existing `
        --only-show-errors | Out-Null

    if ($LASTEXITCODE -ne 0) {
        if ($Force) {
            Write-Host "Failed to login to AKS cluster $($cluster.name) in resource group $($cluster.resourceGroup). Continuing script due to -Force."
            continue
        }

        throw "Failed to login to AKS cluster $($cluster.name) in resource group $($cluster.resourceGroup). Unable to safely proceed, pass flag -Force to ignore this situation."
    }

    kubelogin convert-kubeconfig -l azurecli 2>$null
    if ($LASTEXITCODE -ne 0) {
        if ($Force) {
            Write-Host "Failed to convert kubeconfig for AKS cluster $($cluster.name). Continuing script due to -Force."
            continue
        }

        throw "Failed to convert kubeconfig for AKS cluster $($cluster.name). Unable to safely proceed, pass flag -Force to ignore this situation."
    }

    $scaledJobEndpointLogFile = 'kubectl.log'
    $scaledJobEndpointJson = kubectl get ScaledJob --all-namespaces -o json 2> $scaledJobEndpointLogFile
    $scaledJobEndpointExitCode = $LASTEXITCODE
    $scaledJobEndpointError = ''
    if (Test-Path($scaledJobEndpointLogFile)) {
        $scaledJobEndpointErrorContent = Get-Content -Path $scaledJobEndpointLogFile -Raw
        if ($null -ne $scaledJobEndpointErrorContent) {
            $scaledJobEndpointError = $scaledJobEndpointErrorContent.Trim()
        }
        Remove-Item -Path $scaledJobEndpointLogFile -Force
    }

    if ($scaledJobEndpointExitCode -ne 0) {
        if ($scaledJobEndpointError -match 'the server doesn''t have a resource type "ScaledJob"') {
            Write-Host "ScaledJob resource type not found in cluster $($cluster.name). So no images in use"
            continue
        }

        if ($Force) {
            Write-Host "Error occurred while fetching scaled jobs in cluster $($cluster.name): '$($scaledJobEndpointError)'. Continuing script due to -Force."
            continue
        }

        throw "Error occurred while fetching scaled jobs in cluster $($cluster.name): '$($scaledJobEndpointError)'. Unable to safely proceed, pass flag -Force to ignore this situation."
    }

    $scaledJobEndpointResponse = $scaledJobEndpointJson | ConvertFrom-Json

    $properties = @(
    @{
        Name = 'Subscription'
        Expression = {$SubscriptionName}
    },
    @{
        Name = 'Namespace'
        Expression = {$_.metadata.namespace}
    },
    @{
        Name = 'Image'
        Expression = {$_.spec.jobTargetRef.template.spec.containers[0].image -replace '.*/(.+)\:(.+)','$1'}
    },
    @{
        Name = 'Version'
        Expression = {$_.spec.jobTargetRef.template.spec.containers[0].image -replace '.*/(.+)\:(.+)','$2'}
    },
    @{
        Name = 'Cluster'
        Expression = {$cluster.name}
    })

    Write-Host "Getting $($cluster.name) Versions"
    $listOfAllScaledJobs += $scaledJobEndpointResponse.items | Select-Object $properties
}

if ($listOfAllScaledJobs.Count -eq 0) {
    throw "No in-use images were indexed for subscription $SubscriptionName. Refusing to write an empty export."
}

$outputDirectory = Split-Path -Path $OutputPath -Parent
if (-not [string]::IsNullOrWhiteSpace($outputDirectory)) {
    New-Item -Path $outputDirectory -ItemType Directory -Force | Out-Null
}

$export = [PSCustomObject]@{
    SubscriptionName = $SubscriptionName
    ExportedAtUtc = (Get-Date).ToUniversalTime()
    ClusterCount = @($clusters).Count
    ImageCount = @($listOfAllScaledJobs).Count
    Images = @($listOfAllScaledJobs)
}

$export | Export-Clixml -Path $OutputPath

$outputFileName = [System.IO.Path]::ChangeExtension($OutputPath, '.txt')
Write-Host "Writing readable output to $outputFileName"
$listOfAllScaledJobs | Sort-Object -Property Image, Version | Format-Table -AutoSize | Out-File -FilePath $outputFileName -Width 270
Get-Content $outputFileName

Write-Host "Exported $($listOfAllScaledJobs.Count) in-use image records for subscription $SubscriptionName to $OutputPath"
