<#
.SYNOPSIS
    Remove all container images older than <PARAM> days from the mesoagents ACR
.DESCRIPTION
    Remove all container images older than <PARAM> days from the mesoagents ACR, does not remove locked container images
    Script checks current images in use across all AKS clusters in the specified subscriptions.
.PARAMETER RemoveOlderThanNrDays
    Number of days threshold, beyond which container images will be deleted
.PARAMETER InUseImagesPath
    Paths to CLIXML exports containing images currently in use. Must include DEV and PROD exports.
.PARAMETER DryRun
    Show which images and manifests would be deleted, without deleting them
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$RemoveOlderThanNrDays,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string[]]$InUseImagesPath,

    [Parameter(Mandatory=$false)]
    [switch]$DryRun
)

# [Functions]

function Import-InUseImages() {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$Path
    )

    $expectedSubscriptions = @(
        "sub-dev-global-meso"
        "sub-prd-global-meso"
    )

    $exports = @()
    foreach ($inUseImagesFile in $Path) {
        if (-not (Test-Path -LiteralPath $inUseImagesFile)) {
            throw "In-use image export file '$inUseImagesFile' does not exist. Aborting"
        }

        $export = Import-Clixml -Path $inUseImagesFile
        if ($null -eq $export) {
            throw "In-use image export file '$inUseImagesFile' could not be imported. Aborting"
        }

        if ([string]::IsNullOrWhiteSpace($export.SubscriptionName)) {
            throw "In-use image export file '$inUseImagesFile' does not contain a subscription name. Aborting"
        }

        if ($expectedSubscriptions -notcontains $export.SubscriptionName) {
            throw "In-use image export file '$inUseImagesFile' is for unexpected subscription '$($export.SubscriptionName)'. Aborting"
        }

        if ($null -eq $export.Images -or @($export.Images).Count -eq 0) {
            throw "In-use image export file '$inUseImagesFile' contains no indexed images for subscription '$($export.SubscriptionName)'. Aborting"
        }

        Write-Host "Loaded $(@($export.Images).Count) in-use image records for subscription $($export.SubscriptionName) from $inUseImagesFile"
        $exports += $export
    }

    foreach ($expectedSubscription in $expectedSubscriptions) {
        $matchingExports = @($exports | Where-Object { $_.SubscriptionName -eq $expectedSubscription })
        if ($matchingExports.Count -ne 1) {
            throw "Expected exactly one in-use image export for subscription $expectedSubscription, found $($matchingExports.Count). Aborting"
        }
    }

    return @($exports | ForEach-Object { $_.Images })
}

$repositories = (az acr repository list --name mesoagents -o json) | ConvertFrom-Json

if ($RemoveOlderThanNrDays -notmatch '^(?<Days>\d+)d?$') {
    throw "RemoveOlderThanNrDays must be a number of days, optionally followed by 'd'. Value was '$RemoveOlderThanNrDays'."
}

$removeOlderThanDate = (Get-Date).ToUniversalTime().AddDays(-[int]$Matches.Days)
$listOfAllScaledJobs = Import-InUseImages -Path $InUseImagesPath
$imagesInUse = @{}
foreach ($scaledJob in $listOfAllScaledJobs) {
    if ([string]::IsNullOrWhiteSpace($scaledJob.Image) -or [string]::IsNullOrWhiteSpace($scaledJob.Version)) {
        continue
    }

    $imagesInUse["$($scaledJob.Image):$($scaledJob.Version)"] = $true
}

# determine unique images
$uniqueImages = $imagesInUse.Keys | Sort-Object -Unique
Write-Host "Images in use (unique)"
foreach ($uniqueImage in $uniqueImages) {
    Write-Host "`t$uniqueImage"
}

Write-Host "Removing all images older than $RemoveOlderThanNrDays days, except images currently in use"
foreach ($repository in $repositories | Where-Object { $_ -like "windows-*" -or $_ -like "linux-*" }) {
    Write-Host "`tChecking $repository"
    $manifestMetadataList = (az acr manifest list-metadata --registry mesoagents --name $repository -o json --only-show-errors) | ConvertFrom-Json
    foreach ($manifestMetadata in $manifestMetadataList) {
        $tags = @($manifestMetadata.tags | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

        # Skip manifests that have no tags associated with them
        if ($tags.Count -eq 0) {
            continue
        }

        # Skip manifests that have been updated more recently than the removal threshold
        $lastUpdateTime = [DateTimeOffset]::Parse($manifestMetadata.lastUpdateTime).UtcDateTime
        if ($lastUpdateTime -ge $removeOlderThanDate) {
            continue
        }

        # Skip manifests that have tags currently in use
        $tagsInUse = @($tags | Where-Object { $imagesInUse.ContainsKey("$($repository):$($_)") })
        if ($tagsInUse.Count -gt 0) {
            Write-Host "`t`tSkipping in-use tag(s): $($tagsInUse -join ', '), $($manifestMetadata.digest)"
            continue
        }

        if ($DryRun) {
            Write-Host "`t`tDry run: would remove repository: $repository, tag(s): $($tags -join ', '), digest: $($manifestMetadata.digest)"
        } else {
            Write-Host "`t`tRemoving repository: $repository, tag(s): $($tags -join ', '), digest: $($manifestMetadata.digest)"
            az acr manifest delete --registry mesoagents --name $repository@$($manifestMetadata.digest) --yes --only-show-errors
        }
    }
}

<#
### IMPORTANT ###
# The following code works for removing dangling manifests in the container registry
# However Microsoft has in their infinite wisdom decided to add metadata to images in the form of manifests
# Except they neglected to associate these manifests with tags properly, leading to dangling manifests that are not easily identifiable.
# Removing them causes the images to be corrupted and undownloadable
#
# This code can be enabled once the metadata manifest files are no longer generated on images
# and all images that still rely on them are no longer in use
#>

# Dangling manifests are image manifests in the container registry that do not have any tags associated with them.
# They are essentially orphaned images that are not referenced by any tag and can be safely removed to free up space.
# Write-Host "Removing Dangling Manifests"
# foreach ($repository in $repositories | Where-Object { $_ -like "windows-*" -or $_ -like "linux-*" }) {
#     Write-Host "`tChecking $repository"
#     $danglingManifests = (az acr manifest list-metadata --registry mesoagents --name $repository --query "[?tags[0]==null].digest" -o json --only-show-errors) | ConvertFrom-Json
#     Write-Host "`tFound $($danglingManifests.count) dangling manifests"
#     foreach ($danglingManifest in $danglingManifests) {
#         #Known Issue, sometimes the following commands prompts for username and password. It appears that on subsequent runs the issue dissapears
#         #which could indicate the order in which manifests are deleted is relevant, or that the credentials just glitch sometimes
#         if ($DryRun) {
#             Write-Host "`t`tDry run: would remove repository: $repository, digest: $danglingManifest"
#         } else {
#             Write-Host "`t`tRemoving repository: $repository, digest: $danglingManifest"
#             az acr manifest delete --registry mesoagents --name $repository@$danglingManifest --yes --only-show-errors
#         }
#     }
# }

Write-Host "Script Completed"
