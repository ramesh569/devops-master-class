<#
.SYNOPSIS
    Moves Azure DevOps pipelines from one folder to another within a specified project and organization.
.DESCRIPTION
    This script moves all pipelines in a specified source folder to a target folder in a given Azure DevOps project and organization.
.NOTES
    Requires an Azure DevOps PAT with Build (Read & Execute) and Edit Pipeline permissions
    It does not copy empty folders and it does not remove folders that are empty (after moving)
.EXAMPLE
    .\Move-Pipelines.ps1
#>

#[configuration]

# Constants: Set your organization and project here
$AzdoOrganization = "raboweb"
$ProjectName = "Tribe Tech4Engineering"

# Source and target folder roots (only the first part will be replaced)
$SourceRoot = "\OLD - Area Tech4Dev (reorg)\Squad Meso"
$TargetRoot = "\Area Tech4DevOps\SubArea Tech4Dev\Squad Meso"

# Log file
$logFileName = "set-pipelinelocation.log"

#[functions]
. .\images\_shared\jobs\Functions-AzdoApi.ps1

function Write-LogEntry {
    param (
        [string]$Message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] $Message"
    Add-Content -Path $logFileName -Value $logEntry
    Write-Output $logEntry
}

#[script]
$accessToken = Get-AuthToken

Write-LogEntry "Fetching pipelines in project $ProjectName in organization $AzdoOrganization."
$allProjectPipelines = Get-PipelinesInProject -AzdoOrganization $AzdoOrganization -ProjectName $ProjectName -AccessToken $accessToken
$pipelines = $allProjectPipelines | Where-Object -Property folder -like "$SourceRoot*"

# Collect planned moves
$plannedMoves = @()
foreach ($pipeline in $pipelines) {
    if ($pipeline.folder -like "$SourceRoot*") {
        $newFolder = $pipeline.folder -replace [regex]::Escape($SourceRoot), $TargetRoot
        $plannedMoves += [PSCustomObject]@{
            Name = $pipeline.name
            Id = $pipeline.id
            OldFolder = $pipeline.folder
            NewFolder = $newFolder
        }
    }
}

if ($plannedMoves.Count -eq 0) {
    Write-LogEntry "No pipelines found to move."
    return
}

Write-LogEntry "Planned pipeline moves:"
$plannedMoves | ForEach-Object {
    Write-Output "$($_.Name) [$($_.Id)]`n  From:`t$($_.OldFolder)`n  To:`t$($_.NewFolder)"
}


$confirm = Read-Host "Proceed with moving these $($plannedMoves.Count) pipelines? (y/n)"
if ($confirm -ne 'y') {
    Write-LogEntry "Aborting script by user request."
    return
}


# Perform the moves
$moveCount = 0
foreach ($plannedMove in $plannedMoves) {
    Write-LogEntry "Moving pipeline '$($plannedMove.Name)' (ID: $($plannedMove.Id)) from '$($plannedMove.OldFolder)' to '$($plannedMove.NewFolder)'..."
    try {
        $definition = Get-PipelineDefinition -AzdoOrganization $AzdoOrganization -ProjectName $ProjectName -PipelineId $plannedMove.Id -AccessToken $accessToken
        $definition.path = $plannedMove.NewFolder
        $commentText = "Migrate pipeline from '$($plannedMove.OldFolder)' to '$($plannedMove.NewFolder)'"
        if ($definition.comment) {
            $definition.comment = $commentText
        } else {
            $definition | Add-Member -MemberType NoteProperty -Name "comment" -Value $commentText
        }
        $uri = "https://dev.azure.com/$AzdoOrganization/$ProjectName/_apis/build/definitions/$($plannedMove.Id)?api-version=7.1"
        $body = $definition | ConvertTo-Json -Depth 100
        $headers = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($accessToken)")) }
        Invoke-RestMethod -Uri $uri -Method PUT -Headers $headers -ContentType 'application/json' -Body $body
        Write-LogEntry "  [updated] Pipeline '$($plannedMove.Name)' moved to '$($plannedMove.NewFolder)'."
        $moveCount++
    } catch {
        Write-LogEntry "  [error] Failed to move pipeline '$($plannedMove.Name)': $_"
    }
}

Write-LogEntry "Total pipelines moved: $moveCount"
Write-LogEntry "Script Completed"
