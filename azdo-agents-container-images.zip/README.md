# Container Images Repository

This repository builds Linux and Windows Docker images for Azure DevOps agents, publishes them to Azure Container Registry, and integrates them with AKS agent pools.

## Local Development

- Set up your Git Hooks

  - Install lefthook. Instructions can be found [on Confluence](https://confluence.dev.rabobank.nl/spaces/vsts/pages/1567985447/How-To+Setup+your+local+development+environment)
  - Run `lefthook install` to initialize it in the repository (always do this on a new clone)
  - Install [PSScriptAnalyzer](https://www.powershellgallery.com/packages/PSScriptAnalyzer)
    - Run the following in PowerShell: `Install-Module -Name PSScriptAnalyzer`
  - Install [Shellcheck](https://github.com/koalaman/shellcheck#user-content-installing)
    - Windows: `winget install --id koalaman.shellcheck`
    - macOS: `brew install shellcheck`
  - Tip: You can run `lefthook run pre-commit --all-files` at any time to run it without committing

## Architecture

### The architecture for Kubernetes Event-Driven Automation (KEDA)

![Architecture diagram](_docs/architecture.png "Architecture diagram")

### Docker build in an user pipeline

![User docker build in pipeline flow diagram](_docs/User_builds_image_flow.png "User docker build in pipeline flow diagram")

### AKS architecture

![AKS architecture diagram](_docs/AKS_Architecture.png "AKS architecture diagram")

## Interacting with Azure Container Registry

### Creating a Azure Container Register

We have created a pipeline [aks-acr](https://dev.azure.com/raboweb/Tribe%20Tech4Engineering/_build?definitionId=71572) to provision a Azure Container Registry. It will create a [mesoagents.azurecr.io](https://portal.azure.com/#@raboweb.onmicrosoft.com/resource/subscriptions/69dfc25b-32a0-4f72-94ee-89ecd603700b/resourceGroups/rg-agents-registry/providers/Microsoft.ContainerRegistry/registries/mesoagents/overview)

```bash
az login
az account set --subscription 69dfc25b-32a0-4f72-94ee-89ecd603700b
az acr login --name agentsmeso
```

### Create a Service Connection

To be able to push Docker images from a pipeline to an ACR you need a service connection.
In the rabobank environment you cannot create this using the DevOps UI with 'Docker Registry/Azure Container Registry' because the DevOps account you are using does not match the rabobank Azure eu account and therefore the Save button will stay disabled.
As a workaround you can use the 'Other' tab to create the connection. First we need to enable 'Admin User' on the ACR.

### Enable Admin User

Complete the following steps to enable Admin User.

1. In Azure Portal navigate to the Container registry.
2. Open the 'Access keys' tab.
3. Enable 'Admin user'
4. You will need the information on this screen in the following steps.

### Create the Connection

Complete the following steps to create the Connection.

1. In Azure DevOps open project settings.
2. Go to 'Service connections'.
3. Create a new service connection of type 'Docker Registry'.
4. Open the 'Others' tab.
5. Complete the form using the table below:

| Service Connection      | Azure Container Registry                 | Example               |
| ----------------------- | ---------------------------------------- | --------------------- |
| Docker Registry         | Login server, do not forget to add https | mesoagents.azurecr.io |
| Docker ID               | Username                                 | agents                |
| Docker Password         | password                                 | xxxxx                 |
| Service connection name | Just come up with a nice name            | mesoagents.azurecr.io |

Press Save, congrats, you should now have a connection with the name aksacrdev.azurecr.io. Remember this name, you will need it to push images to the ACR.

### Building the Docker images

Base images provide shared software; flavour images extend a base or build directly from an OS image. All image pipelines can be found at [\Area Tech4Dev\Squad Meso\Azdo Agents\Kubernetes\Images](https://dev.azure.com/raboweb/Tribe%20Tech4Engineering/_build?definitionScope=%5CArea%20Tech4Dev%5CSquad%20Meso%5CAzdo%20Agents%5CKubernetes%5CImages).

### Documenting installed software and certificates

MOT 5.0.0 or newer is required by the image build and SBOM sync pipelines. Its
manifest lives at `/install/documentation.json` on Linux and
`C:\install\documentation.json` on Windows.

#### Installer records

Record application-specific information in the installer with
`mot docs applications add`. Supply the installed version, category, and stable
executable path; include environment variables only when the installer actually
sets them. For example:

```bash
mot docs applications add \
    --name "Python" \
    --category "Runtimes" \
    --version "$full_version" \
    --artifact "$python_executable" \
    --generate-hash
```

`--artifact` must point to an existing file when using `--generate-hash`. Add
repeated `--environment-variables KEY=VALUE` arguments for relevant, non-secret
environment metadata. Windows installers use `Invoke-Mot` from
[InstallHelper.ps1](images/windows/_shared/helpers/InstallHelper.ps1), which
checks native-command exit codes.

MOT upserts matching category/name/version records. Do not delete the manifest,
restore a baseline, or read existing records merely to skip updates: derived
images inherit installer-authored records from their base image.

#### Build-time inventory

After installation, each image runs its documentation generator:

| Image OS | Generator                                                                     | Additional inventory                                                                                                         |
| -------- | ----------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Ubuntu   | [generate-docs.sh](images/linux/_shared/scripts/generate-docs.sh)             | APT packages, Python toolcache packages when present, and PowerShell modules                                                 |
| UBI      | [ubi-generate-docs.sh](images/linux/_shared/scripts/ubi/ubi-generate-docs.sh) | RPM packages and PowerShell modules                                                                                          |
| Windows  | [New-Documentation.ps1](images/windows/_shared/scripts/New-Documentation.ps1) | Windows applications, Visual C++ components, Windows features, .NET SDKs/runtimes, and modules from both PowerShell editions |

These passes update the existing manifest and render build-time Markdown.
Package inventories complement native-binary scanning; they are not replaced by
it. There is no separate Node.js package documentation helper.

#### Post-build scans and published artifacts

[stage-build.yml](images/_shared/jobs/stage-build.yml) starts a separate,
network-disabled container from the completed image and runs:

```text
mot docs applications scan
mot docs certificates scan
mot docs generate-md --out <markdown-path>
```

Application scanning discovers native runnable ELF programs on Linux and PE
executables on Windows, not scripts or libraries. It also refreshes documented
artifact paths. Version probes have a per-probe timeout; a hash is used when a
version cannot be detected. Keep installer records for richer metadata and
software that native scanning cannot discover.

Certificate inventory is generated by `mot docs certificates scan`; no separate
certificate-report script is needed. Trust-store configuration remains the
responsibility of the certificate installation scripts.

Linux scanning uses a privileged root container for sandbox namespaces. Windows
uses `ContainerAdministrator`, with restricted MOT version probes. Scan failures
stop publication, and the temporary container is removed after export.

The pipeline publishes the scanned JSON and regenerated Markdown in the
`InstalledSoftware` artifact as `documentation.json` and `documentation.md`.
Post-build scan results are not written back into the image layers.

Metadata includes `build-id` and either `base-commit` for base builds or
`derived-commit` for extension builds, using the checked-out repository revision.
Extensions retain `base-commit` from their actual base image, including when an
older base tag is selected. If that base predates provenance tracking, its
`base-commit` is absent rather than inferred from the current checkout.

### Ubuntu APT repository proxies

Images built directly from Ubuntu (base, AWS, and sealed) run [configure-apt.sh](images/linux/_shared/scripts/configure-apt.sh) before installing any packages, including the initial locale packages. Images built from `linux-base` inherit this configuration without running the script again; rebuild `linux-base` first and use its updated tag when building derived images. The script replaces Ubuntu archive and security URLs in both legacy `.list` and deb822 `.sources` files with these anonymous-read Nexus proxies:

- `https://nexus01-eu-west-1.artifactcentral.aws.rabo.cloud/repository/ubuntu-archive-com/`
- `https://nexus01-eu-west-1.artifactcentral.aws.rabo.cloud/repository/ubuntu-security-com/`

Suites, components, and Ubuntu signing keys remain unchanged. Existing APT indexes and cached packages are cleared so Ubuntu packages and dependencies are fetched through Nexus. These source settings persist in the final images and apply to both `apt` and `apt-get`, including subsequent pipeline installs. There is no fallback to the public Ubuntu archive if Nexus is unavailable.

[import-certificates-os.sh](images/linux/_shared/scripts/import-certificates-os.sh) runs once before APT configuration and all package installs. It registers the certificates already copied into `/install/content/certificates` in `/usr/local/share/ca-certificates` and prepares the standard OS bundle at `/etc/ssl/certs/ca-certificates.crt`. The supplied certificates must include the CAs required to verify Nexus. On minimal Ubuntu, the script bootstraps the bundle without OpenSSL, MOT, or package downloads; if `update-ca-certificates` is available, it uses that instead. Installing `ca-certificates` subsequently performs its normal trust-store refresh using the registered certificates. Certificate blocks are explicitly separated, including files without a final newline.

APT uses standard OS trust, with no separate APT CA bundle or build-agent certificate copy. Certificate documentation is generated by the post-build MOT scan described above, independently of trust-store setup. TLS verification and APT signature verification remain enabled; no repository credentials are stored. APT index download errors fail the build immediately rather than falling back to stale or missing indexes.

Third-party APT repositories (such as Microsoft, Git PPA, Adoptium, Mozilla, and PostgreSQL) are unchanged and are **not** covered by the Ubuntu proxies. UBI images use RPM repositories and are unaffected.

### Testing the image

Now that the image has been created we should test if it actually works. We can pull it from the ACR and run it from our local Docker.
Complete the following steps to test the image locally:

1. Pull the image from the ACR.
2. Create an agent pool.

### Pull the image from the ACR

Login the ACR, in the azure portal, go to your ACR and open the 'Access keys' page. Your LoginServer, username and password should be there if you enabled 'Admin user'. In our POC you should enter the following values:

| Field       | Value                 |
| ----------- | --------------------- |
| LoginServer | mesoagents.azurecr.io |
| Username    | mesoagents            |

```bash
$ docker login <LoginServer>

Username: mesoagents
Password:
```

Pull the image.

> Note: In azure portal navigate to the ACR/Repositories. Go to your repository and open the image. There you can find the docker pull command.

```bash
$ docker pull mesoagents.azurecr.io/linux-base:1957717

1957717: Pulling from mesoagents.azurecr.io
e756f3fdd6a3: Pull complete
Digest: sha256:3f1d6c17773a45c97bd8f158d665c9709d7b29ed7917ac934086ad96f92e4510
Status: Downloaded newer image for mesoagents.azurecr.io/linux-base:1957717
mesoagents.azurecr.io/linux-base:1957717
```

Verify that the image is locally available.

```bash
$ docker image ls

REPOSITORY                         TAG       IMAGE ID       CREATED        SIZE
mesoagents.azurecr.io/linux-base   1957717   2bcd0daa9388   12 hours ago   56.4GB
```

Create a test agent pool, in this case 'Test Docker Image Pool' and run the following command to start the docker container with the agent. Wait a few moments and the agent should appear in the pool.

```bash
docker run -e AZP_URL=<Azure DevOps Url> -e AZP_TOKEN=<PAT token> -e AZP_AGENT_NAME=TestDockerLinuxAgent -e AZP_POOL="Test Docker Image Pool" mesoagents.azurecr.io/linux-base:1957717 --once
```

Follow the link below for more information about running agent in docker containers:
[Run a self-hosted agent in Docker](https://docs.microsoft.com/en-us/azure/devops/pipelines/agents/docker?view=azure-devops)
