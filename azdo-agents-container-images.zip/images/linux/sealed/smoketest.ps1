﻿<#
.SYNOPSIS
    Runs all the smoke tests in sequence that are specified below.
.NOTES
    Called by pipeline-extension-image.yml when calling the specific flavour's smoke tests
    Each flavour has its own smoketest file.
.PARAMETER AgentPoolName
    The name of the agent pool that the smoke test is run on
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#import smoke test helpers
Import-Module ".\SmokeTest.Helpers.psm1"

. .\Verify-ConnectionsMinimal.ps1 -AgentPoolName $AgentPoolName
. .\Verify-PowerShellCore.ps1
. .\Verify-Git.ps1
. .\Verify-AzureCLI.ps1
. .\Verify-Yq.ps1
. .\Verify-NodeJS.ps1 -Yarn
. .\Verify-PipPackages.ps1
. .\Verify-LzmaPython.ps1
. .\Verify-Lzma.ps1
. .\Verify-Locale.ps1
. .\Verify-FilePermissions.ps1
. .\Verify-AgentInstallation.ps1
. .\Verify-Certificates.ps1
. .\Verify-NvmWrapper.ps1
. .\Verify-GeneratedDocumentation.ps1
. .\Verify-UbuntuCommonTools.ps1

write-host "Smoke Test Completed"