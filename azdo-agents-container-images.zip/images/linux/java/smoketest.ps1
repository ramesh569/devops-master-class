﻿<#
.SYNOPSIS
    Runs all the smoke tests in sequence that are specified below.
.NOTES
    Called by pipeline-extension-image.yml when calling the specific flavour's smoke tests
    Each flavour has its own smoketest file.
.PARAMETER AgentPoolName
    The name of the agent pool that the smoke test is run on
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#import smoke test helpers
Import-Module ".\SmokeTest.Helpers.psm1"

. .\Verify-ConnectionsOnPrem.ps1 -AgentPoolName $AgentPoolName
. .\Verify-ConnectionsCloud.ps1 -AgentPoolName $AgentPoolName
. .\Verify-SonarQube.ps1
. .\Verify-NexusIQ.ps1
. .\Verify-OpenJdk.ps1 -Version '§javaLTS11§' -DefaultHomeVersion '§javaLTS17§'
. .\Verify-OpenJdk.ps1 -Version '§javaLTS17§' -DefaultHomeVersion '§javaLTS17§'
. .\Verify-OpenJdk.ps1 -Version '§javaLTS21§' -DefaultHomeVersion '§javaLTS17§'
. .\Verify-OpenJdk.ps1 -Version '§javaLTS25§' -DefaultHomeVersion '§javaLTS17§'
. .\Verify-Locale.ps1
. .\Verify-FilePermissions.ps1
. .\Verify-AgentInstallation.ps1
. .\Verify-JavaBuildTools.ps1 -Ant -Maven -Structurizr
. .\Verify-GeneratedDocumentation.ps1

write-host "Smoke Test Completed"