﻿<#
.SYNOPSIS
    Runs all the smoke tests in sequence that are specified below.
.NOTES
    Called by pipeline-extension-image.yml when calling the specific flavour's smoke tests
    Each flavour has its own smoketest file.
.PARAMETER AgentPoolName
    The name of the agent pool that the smoke test is run on
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#import smoke test helpers
Import-Module ".\SmokeTest.Helpers.psm1"

. .\Verify-ConnectionsOnPrem.ps1 -AgentPoolName $AgentPoolName
. .\Verify-ConnectionsCloud.ps1 -AgentPoolName $AgentPoolName
. .\Verify-PowerShellCore.ps1
. .\Verify-Git.ps1 #no specific version installed
. .\Verify-AzureCLI.ps1
. .\Verify-PowershellModules.ps1
. .\Verify-AWSCLI.ps1
. .\Verify-Psycopg.ps1
. .\Verify-PipPackages.ps1
. .\Verify-LzmaPython.ps1
. .\Verify-Locale.ps1
. .\Verify-AgentInstallation.ps1
. .\Verify-Certificates.ps1
. .\Verify-GeneratedDocumentation.ps1
. .\Verify-SqlPlus.ps1
. .\Verify-UbiComponents.ps1
. .\Verify-UbiPythonTools.ps1

write-host "Smoke Test Completed"