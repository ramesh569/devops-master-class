﻿<#
.SYNOPSIS
    Runs all the smoke tests in sequence that are specified below.
.NOTES
    Called by pipeline-extension-image.yml when calling the specific flavour's smoke tests
    Each flavour has its own smoketest file.
.PARAMETER AgentPoolName
    The name of the agent pool that the smoke test is run on
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#import smoke test helpers
Import-Module ".\SmokeTest.Helpers.psm1"

. .\Verify-ConnectionsOnPrem.ps1 -AgentPoolName $AgentPoolName
. .\Verify-ConnectionsCloud.ps1 -AgentPoolName $AgentPoolName
. .\Verify-Yq.ps1
. .\Verify-PowerShellCore.ps1
. .\Verify-Git.ps1 #no specific version installed
. .\Verify-AzureCLI.ps1
. .\Verify-Lzma.ps1
. .\Verify-PostgreSQL-client.ps1
. .\Verify-AWSCLI.ps1
. .\Verify-AWSSessionManager.ps1
. .\Verify-Tflint.ps1
. .\Verify-Terraform.ps1
. .\Verify-Ansible.ps1
. .\Verify-Kubectl.ps1
. .\Verify-Kubelogin.ps1
. .\Verify-Helm.ps1
. .\Verify-Deck.ps1
. .\Verify-PowershellModules.ps1
. .\Verify-AzCopy.ps1
. .\Verify-Rsync.ps1
. .\Verify-OpenBao.ps1
. .\Verify-CloudFoundry.ps1
. .\Verify-Locale.ps1
. .\Verify-OpenTofu.ps1
. .\Verify-Mongosh.ps1
. .\Verify-Pulumi.ps1
. .\Verify-SqlPlus.ps1
. .\Verify-Nginx.ps1
. .\Verify-OpenJdk.ps1 -Version '§javaLTS8§' -DefaultHomeVersion '§javaLTS17§'
. .\Verify-OpenJdk.ps1 -Version '§javaLTS17§' -DefaultHomeVersion '§javaLTS17§'
. .\Verify-Bicep.ps1
. .\Verify-DotNet.ps1
. .\Verify-FilePermissions.ps1
. .\Verify-AgentInstallation.ps1
. .\Verify-Miga.ps1
. .\Verify-Mssql.ps1
. .\Verify-Terragrunt.ps1
. .\Verify-Go.ps1
. .\Verify-Certificates.ps1 -Chrome
. .\Verify-GeneratedDocumentation.ps1
. .\Verify-UbuntuCommonTools.ps1

write-host "Smoke Test Completed"