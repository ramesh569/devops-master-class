#!/bin/bash -e
################################################################################
##  File:  gitleaks.sh
##  Desc:  Installs Gitleaks (secrets scanner)
################################################################################

target_version=§gitleaks§

echo "Installing Gitleaks $target_version"

mot asset download \
  --tool-id "gitleaks" \
  --source "github.com/gitleaks/gitleaks/releases/download/v§version§/gitleaks_§version§_linux_x64.tar.gz" \
  --destination "gitleaks.tar.gz"

tar -xzf gitleaks.tar.gz
chmod +x gitleaks

# Move the binary to /usr/local/bin
mv gitleaks /usr/local/bin/gitleaks

# Clean up the downloaded tar file
rm -f gitleaks.tar.gz

# Confirm installation succeeded
echo "The installed GitLeaks version is $(gitleaks --version)"

# Log the installation
version=$(gitleaks --version)
echo "gitleaks ${version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Gitleaks" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/gitleaks" \
  --generate-hash

echo "Gitleaks installation completed successfully."
