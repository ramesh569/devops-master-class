#!/bin/bash -e
################################################################################
##  File:  edge-driver.sh
##  Desc:  Installs Microsoft Edge and matching EdgeDriver on Linux
################################################################################

source /install/helpers/etc-environment.sh

version=§edge§

echo "Installing Microsoft Edge and EdgeDriver..."

# Add Microsoft Edge repository and install Edge
curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor -o /usr/share/keyrings/microsoft.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/edge stable main" >/etc/apt/sources.list.d/microsoft-edge.list
apt-get update -y

# Brief check: warn if apt candidate differs from requested version
candidate_version=$(apt-cache policy microsoft-edge-stable | awk '/Candidate:/ {print $2}')
if [[ -n "$candidate_version" && "$candidate_version" != "(none)" && "$candidate_version" != "$version" ]]; then
  echo "##vso[task.logissue type=warning]Newer Edge available in apt: $candidate_version (requested: $version)"
fi

apt-get install -y microsoft-edge-stable=$version

# Determine Edge version and major
edge_version=$(microsoft-edge --version || msedge --version)
if [[ -z "$edge_version" ]]; then
	echo "ERROR: Unable to determine Microsoft Edge version."
	exit 1
fi

# Expected format: "Microsoft Edge <full_version>"
edge_full_version=$(echo "$edge_version" | awk '{print $3}')
edge_major_version=$(echo "$edge_full_version" | cut -d'.' -f1)

echo "Detected Edge version: $edge_full_version ($edge_major_version)"

# Use the installed Edge full version directly for the driver
microsoft_base="https://msedgedriver.microsoft.com"
driver_version="$edge_full_version"
echo "Using EdgeDriver version: $driver_version"

# Download and install EdgeDriver
workdir=$(mktemp -d)
pushd "$workdir"
curl -fsSL "${microsoft_base}/${driver_version}/edgedriver_linux64.zip" -o edgedriver_linux64.zip
unzip -o edgedriver_linux64.zip

# The zip contains 'msedgedriver'
install -m 0755 msedgedriver /usr/local/bin/msedgedriver
set_etc_environment_variable "EDGEWEBDRIVER" "/usr/local/bin/msedgedriver"

popd
rm -rf "$workdir"

# Print installation verification
echo "Verification:"
echo " - $(microsoft-edge --version 2>/dev/null || msedge --version 2>/dev/null)"
echo " - $(/usr/local/bin/msedgedriver --version)"

# Fail if not installed
if ! command -v microsoft-edge >/dev/null 2>&1 && ! command -v msedge >/dev/null 2>&1; then
  echo "ERROR: Microsoft Edge installation failed." >&2
  exit 1
fi

if ! /usr/local/bin/msedgedriver --version >/dev/null 2>&1; then
  echo "ERROR: msedgedriver installation verification failed." >&2
  exit 1
fi

#remove added apt source list
rm -f /etc/apt/sources.list.d/microsoft-edge.list
rm -f /etc/apt/sources.list.d/microsoft-edge.list.save

# Record installed software
edge_ver_out=$(microsoft-edge --version 2>/dev/null || msedge --version 2>/dev/null)
edge_ver_out=$(echo "$edge_ver_out" | grep -oP '(\d+\.\d+\.\d+\.\d+)')
edgedriver_ver_out=$(/usr/local/bin/msedgedriver --version | grep -oP '(\d+\.\d+\.\d+\.\d+)')
echo "Microsoft Edge ${edge_ver_out}  " >> /install/InstalledSoftware.txt
echo "Microsoft Edge WebDriver ${edgedriver_ver_out}  " >> /install/InstalledSoftware.txt

mot docs applications add \
  --name "Microsoft Edge" \
  --category "Browsers" \
  --version "${edge_ver_out}" \
  --artifact "$(command -v microsoft-edge || command -v msedge)" \
  --generate-hash

mot docs applications add \
  --name "Microsoft Edge Driver" \
  --category "Browsers" \
  --version "${edgedriver_ver_out}" \
  --artifact "/usr/local/bin/msedgedriver" \
  --generate-hash

echo "Microsoft Edge and EdgeDriver installation complete."