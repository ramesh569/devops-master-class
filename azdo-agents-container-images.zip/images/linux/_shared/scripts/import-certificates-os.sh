#!/bin/bash -e
################################################################################
##  File:  import-certificates-os.sh
##  Desc:  Establishes OS certificate trust before any package downloads
################################################################################
src_dir=/install/content/certificates
dest_dir=/usr/local/share/ca-certificates
ca_bundle=/etc/ssl/certs/ca-certificates.crt

echo "Starting OS certificate import before package installation."
shopt -s nullglob
certificates=("$src_dir"/*.crt)
if [ "${#certificates[@]}" -eq 0 ]; then
    echo "##vso[task.logissue type=error]No OS certificates found in $src_dir."
    exit 1
fi

echo "Step 1/2: Register ${#certificates[@]} certificates in $dest_dir."
mkdir -p "$dest_dir" /etc/ssl/certs
for certificate in "${certificates[@]}"; do
    echo "Registering OS certificate: $(basename "$certificate")"
    # Normalize the final newline so the package's later trust-store refresh also produces valid PEM.
    {
        cat "$certificate"
        printf '\n'
    } > "$dest_dir/$(basename "$certificate")"
done

echo "Step 2/2: Update the standard OS CA bundle at $ca_bundle."
if command -v update-ca-certificates >/dev/null 2>&1; then
    echo "Refreshing OS trust with update-ca-certificates."
    update-ca-certificates
else
    # Minimal Ubuntu lacks ca-certificates. Seed its standard bundle without downloading tools.
    # Retain any existing system trust, and let ca-certificates maintain the bundle once installed.
    echo "ca-certificates is not installed yet; bootstrapping its standard CA bundle."
    temporary_bundle=$(mktemp /etc/ssl/certs/ca-certificates.XXXXXX)
    trap 'rm -f "$temporary_bundle"' EXIT
    {
        if [ -f "$ca_bundle" ]; then
            cat "$ca_bundle"
            printf '\n'
        fi
        for certificate in "$dest_dir"/*.crt; do
            cat "$certificate"
            printf '\n'
        done
    } > "$temporary_bundle"
    chmod 644 "$temporary_bundle"
    mv "$temporary_bundle" "$ca_bundle"
    trap - EXIT
fi
echo "OS certificate import completed; APT and other system-trust clients can now verify Nexus."
