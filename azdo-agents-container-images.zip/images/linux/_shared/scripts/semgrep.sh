#!/bin/bash -e
################################################################################
##  File:  semgrep.sh
##  Desc:  Installs Semgrep (code analysis tool)
################################################################################
python_version=$1

source /install/helpers/python-functions.sh

python_install_package "semgrep"
python_create_package_symboliclink "$python_version" "/bin/semgrep" "/usr/local/bin"
