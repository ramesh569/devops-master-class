#!/bin/bash
set -e # Exit immediately if a command exits with a non-zero status.
################################################################################
##  Desc: Install sqlfluff
################################################################################
python_version=$1

source /install/helpers/python-functions.sh

python_install_package "sqlfluff"
python_create_package_symboliclink "$python_version" "/bin/sqlfluff" "/usr/local/bin"
