#!/bin/bash -e
################################################################################
##  File:  tox.sh
##  Desc:  Installs Tox (Python testing tool)
################################################################################
source /install/helpers/python-functions.sh

python_install_package "tox"
python_create_package_symboliclink "§python311§" "/bin/tox" "/usr/local/bin"
