#!/bin/bash -e 
################################################################################
##  File:  rsync.sh
##  Desc:  Installs Rsync
##  Original Requestor: amir.parkar@rabobank.nl
##  Support Ticket: https://dev.azure.com/raboweb/Tribe%20Tech4Engineering/_workitems/edit/12724331
################################################################################
#install rsync from apt packages
echo "Installing Rsync"
source ./scripts/apt-packages.sh default true "rsync:latest"