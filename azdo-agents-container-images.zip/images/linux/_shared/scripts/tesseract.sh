#!/bin/bash -e
################################################################################
##  File:  tesseract.sh
##  Desc:  Installs Tesseract OCR
################################################################################
echo "Installing tesseract"
# Update the package list
apt-get update

# We always install the latest version of tesseract because older versions are not maintained on apt.
# Install tesseract
echo "Installing tesseract"
apt-get install -y tesseract-ocr
apt-get install -y tesseract-ocr-eng

# Give execute rights to file
echo "Ensuring tesseract-ocr is executable..."
chmod +x /usr/bin/tesseract

# Verify the installation
tesseract --version

#Verify the installation and extract version
installed_version=$(tesseract --version | head -n 1 | awk '{print $2}')
echo "Tesseract installed version: ${installed_version}"

echo "Tesseract ${installed_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Tesseract" \
  --category "Tools" \
  --version "${installed_version}" \
  --artifact "/usr/bin/tesseract" \
  --generate-hash