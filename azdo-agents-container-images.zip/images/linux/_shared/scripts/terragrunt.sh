#!/bin/bash -e
################################################################################
##  File:  terragrunt.sh
##  Desc:  Installs Terragrunt (Terraform wrapper)
################################################################################
version="§terragrunt§"

echo "Installing terragrunt $version"

mot asset download \
  --tool-id "terragrunt" \
  --source "github.com/gruntwork-io/terragrunt/releases/download/v§version§/terragrunt_linux_amd64" \
  --destination "terragrunt_linux_amd64"

# Rename file to terragrunt and move to local bin
mv terragrunt_linux_amd64 /usr/local/bin/terragrunt

# Give execute rights to file
chmod +x /usr/local/bin/terragrunt

# Update installed software list (add 2 spaces for new line)
echo "Terragrunt $version  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Terragrunt" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/terragrunt" \
  --generate-hash