#!/bin/bash -e 
################################################################################
##  File:  mssql.sh
##  Desc:  Installs Microsoft SQL Server tools
##        The list of versions to install is stored in version.xml
################################################################################

mssql_version=§msSql§
ubuntu_version=§ubuntu§

echo "Get the Microsoft repository signing key"
curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor -o /usr/share/keyrings/microsoft-prod.gpg

echo "Adding Microsoft repository source list for MSSQL tools"
curl https://packages.microsoft.com/config/ubuntu/${ubuntu_version}/prod.list -o /etc/apt/sources.list.d/mssql-release.list

echo "Updating the list of packages"
apt update

echo "Installing MSSQL Tool $mssql_version"
export ACCEPT_EULA=Y
apt install msodbcsql$mssql_version -y
apt install mssql-tools$mssql_version -y
apt install unixodbc-dev -y

echo "Adding MSSQL tools to PATH"
ln -sf /opt/mssql-tools18/bin/sqlcmd /usr/local/bin

echo "Cleaning apt sources"
rm /etc/apt/sources.list.d/mssql-release.list

echo "check sqlcmd version"
sqlcmd -?
