#!/bin/bash -e
################################################################################
##  File:  trivy.sh
##  Desc:  Installs Trivy (vulnerability scanner)
################################################################################
version=§trivy§

echo "Installing Trivy $version"

mot asset download \
  --tool-id "trivy" \
  --source "github.com/aquasecurity/trivy/releases/download/v§version§/trivy_§version§_Linux-64bit.deb" \
  --destination "trivy.deb"

echo "Installing Trivy..."
dpkg -i trivy.deb

# Verify installation
trivy --version
echo "Trivy installation completed successfully."

echo "Trivy $(trivy --version)  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Trivy" \
  --category "Tools" \
  --version "${version}" \
  --artifact "$(command -v trivy)" \
  --generate-hash