#!/bin/bash -e
################################################################################
##  File:  nginx.sh
##  Desc:  Installs and configures nginx
################################################################################

echo "Installing nginx packages"
source ./scripts/apt-packages.sh default false " \
    nginx:latest
    "

# Configure nginx defaults for restricted non-root agent containers.
# - Use unprivileged port 8080 instead of 80.
# - Expose a deterministic /health endpoint for smoke tests.
cat <<'EOF' > /etc/nginx/sites-available/default
server {
    listen 8080 default_server;
    listen [::]:8080 default_server;

    server_name _;
    root /var/www/html;
    index index.html index.htm index.nginx-debian.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /health {
        add_header Content-Type text/plain;
        return 200 'ok';
    }
}
EOF

# Configure global nginx settings for non-root runtime.
if grep -q '^user ' /etc/nginx/nginx.conf; then
    sed -i 's|^user .*;|# user disabled for non-root agent containers;|' /etc/nginx/nginx.conf
fi
if grep -q '^pid ' /etc/nginx/nginx.conf; then
    sed -i 's|^pid .*;|pid /var/lib/nginx/nginx.pid;|' /etc/nginx/nginx.conf
fi

# Set nginx permissions so users can start and run it in their pipeline.
mkdir -p /var/lib/nginx /var/log/nginx
chown -R AzDevOps:AzDevOps /var/lib/nginx /var/log/nginx
chmod -R 0777 /var/lib/nginx /var/log/nginx

# Validate nginx configuration generated during build.
nginx -t

# nginx -t runs as root during the image build and leaves a root-owned PID file.
# Remove it so the runtime user can create its own PID file.
rm -f /var/lib/nginx/nginx.pid

# Disable automatic startup of nginx.
if command -v systemctl >/dev/null 2>&1; then
    systemctl disable nginx || true
fi
