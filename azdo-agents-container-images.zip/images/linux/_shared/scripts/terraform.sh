#!/bin/bash -e
################################################################################
##  File:  terraform.sh
##  Desc:  Installs HashiCorp Terraform
################################################################################
terraform_version=$1

echo "Install gnupg"
apt-get update && apt-get install -y gnupg

# Download the HashiCorp repository GPG keys
echo "Downloading Hashicorp Key"
wget -O- https://apt.releases.hashicorp.com/gpg | \
    gpg --dearmor | \
    tee /usr/share/keyrings/hashicorp-archive-keyring.gpg

# Verify GPG key
echo "Verify Hashicorp Key"
gpg --no-default-keyring \
    --keyring /usr/share/keyrings/hashicorp-archive-keyring.gpg \
    --fingerprint

# Register the HashiCorp repository to the system
echo "Inlcude Hashicorp Packages list to APT"
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] \
    https://apt.releases.hashicorp.com $(lsb_release -cs) main" | \
    tee /etc/apt/sources.list.d/hashicorp.list

# Get all the updates from enabled repositories.
echo "Update APT Database"
apt-get update

echo "Installing Terraform"
apt-get install terraform="${terraform_version}-*" #we append -* because it is required by terraform when installing the package

#remove added apt source list
echo "Remove Hashicorp Packages list from APT"
rm -f /etc/apt/sources.list.d/hashicorp.list
rm -f /etc/apt/sources.list.d/hashicorp.list.save

# Test if installation works
version=$(terraform -version | grep -oP '(?<=v)\d+\.\d+\.\d+')
echo "${version}"

#update installed software list (add 2 spaces for new line)
echo "Terraform $version  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Terraform" \
  --category "Tools" \
    --version "${version}" \
    --artifact "$(command -v terraform)" \
    --generate-hash