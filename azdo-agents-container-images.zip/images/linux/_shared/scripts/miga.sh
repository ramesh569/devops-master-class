#!/bin/bash -e
################################################################################
##  File:  miga.sh
##  Desc:  Installs Meso Intelligence Gathering Agent (MIGA)
################################################################################

echo "# Install MIGA from Nexus repository"
mot asset download \
  --tool-id "miga" \
  --source "https://repo.nexuscloud.aws.rabo.cloud/repository/raw-55/meso/internal/miga/miga/§version§/miga-linux-amd64" \
  --destination "./miga"

install -o root -g root -m 0755 "./miga" "/usr/local/bin/miga"

mkdir -p /etc/miga
tee /etc/miga/config.yaml > /dev/null <<EOF
diagnostics_path: "/azp/_diag"
metra_endpoint: "metra-linux.metra.svc.cluster.local:8080"
EOF

rm -rf miga

version=$(miga --version | awk -F'[ =]' '{print $3}')

echo "MIGA ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "MIGA" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/miga" \
  --generate-hash
