#!/bin/bash -e
################################################################################
##  File:  ripgrep.sh
##  Desc:  Installs ripgrep (command line search tool)
################################################################################
version=§ripgrep§
 
echo "Installing ripgrep $version ..."
 
mot asset download \
  --tool-id "ripgrep" \
  --source "https://github.com/burntsushi/ripgrep/releases/download/§version§/ripgrep_§version§-1_amd64.deb" \
  --destination "ripgrep.deb"
 
dpkg -i ripgrep.deb

rm -f ripgrep.deb
 
rg --version

echo "ripgrep installation completed successfully."

echo "ripgrep $(rg --version)  " >> /install/InstalledSoftware.txt
 