#!/bin/bash -e
################################################################################
##  File:  dotnet-runtime.sh
##  Desc:  Installs the .NET Runtime for running .NET applications. Downloads required assets and configures runtime versions.
################################################################################
export ubuntu_version=§ubuntu§

package_filename=packages-microsoft-prod.deb

file_path="/install/${package_filename}"

# download the Microsoft package repository configuration file
# this file is also cached in nexus (but the version is oudated)
# and since there is no version in the url we can't replace the old file
mot asset download \
  --source "https://packages.microsoft.com/config/ubuntu/${ubuntu_version}/packages-microsoft-prod.deb" \
  --destination "$file_path" \
  --skip-nexus

dpkg -i "$file_path"
rm "$file_path"

# Update the list of packages after we added packages.microsoft.com
apt-get update

#install transport package
apt install -y apt-transport-https

export major_versions_list=("§dotnetSdkLTS§")
for version in "${major_versions_list[@]}"; do
    # Install the Runtime
    apt install -y aspnetcore-runtime-"$version"
done

#update installed software list (add 2 spaces for new line)
# shellcheck disable=SC2016
# SC2016: Expressions don't expand in single quotes, use double quotes for that.
# the single quoted value doesn't need to be expanded but send to powershell verbatim
pwsh -Command 'Add-Content -Path "/install/InstalledSoftware.txt" -Value ((dotnet --list-runtimes | Select-String -pattern "([0-9]+\.*){3}").Matches.Value | Sort-Object -Unique | ForEach-Object { ".NET Runtime $_  "; mot docs applications add --name ".NET Runtime" --category "Frameworks" --version $_ | Out-Null; if ($LASTEXITCODE -ne 0) { throw "Failed to document .NET Runtime $_" } })'
