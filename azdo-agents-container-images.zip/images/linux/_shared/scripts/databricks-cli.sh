#!/bin/bash -e
################################################################################
##  File:  databricks-cli.sh
##  Desc:  Installs Databricks CLI
##  Notes: https://learn.microsoft.com/en-us/azure/databricks/dev-tools/cli/install
################################################################################

version=§databricks-cli§
install_directory="/opt/databricks-cli"

echo "Installing Databricks CLI $version"

mot asset download \
  --tool-id "databricks-cli" \
  --source "github.com/databricks/cli/releases/download/v§version§/databricks_cli_§version§_linux_amd64.zip" \
  --destination "databricks_cli.zip"

# Create installation directory
mkdir -p "$install_directory"

# Unzip the file and provide execute rights
unzip databricks_cli.zip -d "$install_directory"
rm databricks_cli.zip

# Set access to the executable
chmod +x "$install_directory/databricks"

# Create symbolic link
echo "creating symbolic link /usr/local/bin/databricks -> $install_directory/databricks"
ln -s -f "$install_directory/databricks" "/usr/local/bin/databricks"

installed_version=$(databricks --version | grep -oP '(?<=v)\d+\.\d+\.\d+')
echo "The installed version is $installed_version"
echo "Databricks CLI ${installed_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
	--name "Databricks" \
	--category "Tools" \
	--version "${installed_version}" \
	--artifact "/usr/local/bin/databricks" \
	--generate-hash