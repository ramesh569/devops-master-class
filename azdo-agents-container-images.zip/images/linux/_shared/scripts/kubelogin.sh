#!/bin/bash -e
################################################################################
##  File:  kubelogin.sh
##  Desc:  Installs kubelogin (Azure AD authentication for kubectl)
##  Kubelogin Docs: https://azure.github.io/kubelogin/install.html
##  Kubelogin Versions: https://github.com/Azure/kubelogin/releases
################################################################################

target_version=§kubelogin§

# Install kubelogin
echo "Installing kubelogin $target_version"
mot asset download \
  --tool-id "kubelogin" \
  --source "github.com/Azure/kubelogin/releases/download/v§version§/kubelogin-linux-amd64.zip"

unzip -o "kubelogin-linux-amd64.zip" -d kubelogin-linux-amd64
install -o root -g root -m 0755 kubelogin-linux-amd64/bin/linux_amd64/kubelogin /usr/local/bin/kubelogin

# Remove the downloaded files
rm -rf "kubelogin-linux-amd64.zip" kubelogin-linux-amd64

# Validate kubelogin
echo "# Validating kubelogin installation"
version=$(kubelogin --version)

echo "$version"

# extract version number from output
# output example: kubelogin version git hash: v0.2.10/a6281673932f597014cd966c0aa5cfa12f650ea4 Go version: go1.23.11 Build time: 2025-07-16T21:17:25Z Platform: windows/amd64
# selected output 0.2.10
version=$(echo "$version" | grep -oP '(?<=v)\d+\.\d+\.\d+')

echo "Kubelogin ${version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Kubelogin" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/kubelogin" \
  --generate-hash