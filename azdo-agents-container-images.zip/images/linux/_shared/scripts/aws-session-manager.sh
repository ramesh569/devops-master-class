#!/bin/bash -e
################################################################################
##  File:  aws-session-manager.sh
##  Desc:  Installs AWS Session Manager plugin
################################################################################
version=§aws-session-manager-plugin§

echo "Installing AWS Session Manager..."

mot asset download \
  --tool-id "aws-session-manager-plugin" \
  --source "s3.amazonaws.com/session-manager-downloads/plugin/§version§/ubuntu_64bit/session-manager-plugin.deb" \
  --destination "session-manager-plugin.deb"

#Run the install program
dpkg -i "session-manager-plugin.deb"

#Clean up installation files
echo "Cleaning up installation files..."
rm "session-manager-plugin.deb"

echo "AWS Session Manager ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "AWS Session Manager" \
  --category "Tools" \
  --version "${version}" \
  --artifact "$(command -v session-manager-plugin)" \
  --generate-hash
