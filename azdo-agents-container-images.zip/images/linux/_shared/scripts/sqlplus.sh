#!/bin/bash -e
################################################################################
##  File:  sqlplus.sh
##  Desc:  Installs SQL*Plus
##  Note:  Installs libaio, and oracle (not so) instant client as pre-requisite
################################################################################
source /install/helpers/install.sh

#download url taken from https://www.oracle.com/database/technologies/instant-client/linux-x86-64-downloads.html pointing to latest
baseclient_download_url="https://download.oracle.com/otn_software/linux/instantclient/instantclient-basiclite-linuxx64.zip"
sqlplus_download_url="https://download.oracle.com/otn_software/linux/instantclient/instantclient-sqlplus-linuxx64.zip"

echo "Installing SQL*Plus with dependencies"

# Part 1: Install Pre-requisites
echo "Installing libaio1 apt package"

# install libaio which is a dependency for the oracle instant client
apt-get update
apt-get install -y libaio1t64

# ubuntu is switching to time64 libaio named libaio1t64 but oracle client still expects libaio
# so we need to create a symlink from libaio.so.1 to libaio.so.1t64
ln -s /usr/lib/x86_64-linux-gnu/libaio.so.1t64 /usr/lib/x86_64-linux-gnu/libaio.so.1

# Part 2: Install Oracle Instaclient
echo "Installing Oracle Instant Client Lite"
oracle_directory="/opt/oracle"

# Create installation directory if it doesn't exist
if [ ! -d "$oracle_directory" ]; then
    echo "creating $oracle_directory"
    mkdir -p "$oracle_directory"
fi

echo "Downloading Oracle Instant Client Basic Lite from $baseclient_download_url"
baseclient_archive_file="instantclient-basiclite-linuxx64.zip"
curl "$baseclient_download_url" --output "$baseclient_archive_file"

echo "Unzip Archive"
unzip "$baseclient_archive_file" -d "$oracle_directory"

# get directory instantclient_<major>_<minor>
instantclient_directory=$(find "$oracle_directory" -maxdepth 1 -type d -name "instantclient_*" | head -n 1)

echo "Extract SQL*Plus version from BASIC_LITE_README"
oracleclient_readme_file="${instantclient_directory}/BASIC_LITE_README"
if [ ! -f "$oracleclient_readme_file" ]; then
    echo "ERROR: Expected file not found: $oracleclient_readme_file"
    exit 1
fi
instantclient_version="$(
    grep -E 'Client Shared Library' "$oracleclient_readme_file" \
        | grep -Eo '([0-9]+\.){4}[0-9]+' \
        | head -n 1
)"
echo "Detected Oracle Client version: $instantclient_version"

# Part 3: Install SQL*Plus Client Addon/Optional Package
sqlplus_archive_file="instantclient-sqlplus-linuxx64.zip"

echo "Downloading SQL*Plus from $sqlplus_download_url"
curl "$sqlplus_download_url" --output "$sqlplus_archive_file"

echo "Unzip Archive"
# Extract contents of zip and overwrite (required because META-INF folder is already present)
unzip -o "$sqlplus_archive_file" -d "$oracle_directory"

echo "Extract SQL*Plus version from SQLPLUS_README"
sqlplus_readme_file="${instantclient_directory}/SQLPLUS_README"
if [ ! -f "$sqlplus_readme_file" ]; then
    echo "ERROR: Expected file not found: $sqlplus_readme_file"
    exit 1
fi
sqlplus_version="$(
    grep -E 'Client Shared Library' "$sqlplus_readme_file" \
        | grep -Eo '([0-9]+\.){4}[0-9]+' \
        | head -n 1
)"
echo "Detected SQL*Plus version: $sqlplus_version"

echo "Grant execute access"
chmod 755 "$oracle_directory"

# add ORACLE_HOME to env variables
echo "export ORACLE_HOME=$instantclient_directory" >> /usr/local/start-commands.sh
echo "export LD_LIBRARY_PATH=$instantclient_directory:\${LD_LIBRARY_PATH:-}" >> /usr/local/start-commands.sh

# add oracle instant client to PATH
echo "Add ${instantclient_directory} to PATH"
AddToPath "${instantclient_directory}"

echo "Registering $instantclient_directory with ldconfig"
echo "$instantclient_directory" > /etc/ld.so.conf.d/oracle-instantclient.conf
ldconfig --verbose

echo "Testing Installation"
"$instantclient_directory/sqlplus" -v #specify full path because PATH isn't updated in this session

# Document the installation
echo "Document Oracle Instant Client version: $instantclient_version"
echo "Oracle Instant Client ${instantclient_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Oracle Instant Client Light" \
  --category "Oracle Tools" \
    --version "${instantclient_version}" \
    --environment-variables "ORACLE_HOME=${instantclient_directory}" \
    --environment-variables "LD_LIBRARY_PATH=${instantclient_directory}:\${LD_LIBRARY_PATH:-}"

echo "Document SQL*Plus version: $sqlplus_version"
echo "SQL*Plus ${sqlplus_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "SQL*Plus" \
  --category "Oracle Tools" \
    --version "${sqlplus_version}" \
    --artifact "${instantclient_directory}/sqlplus" \
    --generate-hash \
    --environment-variables "ORACLE_HOME=${instantclient_directory}" \
    --environment-variables "LD_LIBRARY_PATH=${instantclient_directory}:\${LD_LIBRARY_PATH:-}"

