#!/bin/bash -e
################################################################################
##  File:  aws-cli.sh
##  Desc:  Installs AWS CLI
################################################################################
source /install/helpers/helper-functions.sh
version=§aws-cli§

echo "Installing AWS CLI..."

mot asset download \
  --tool-id "aws-cli" \
  --source "awscli.amazonaws.com/awscli-exe-linux-x86_64-§version§.zip" \
  --destination "awscli-exe.zip"

unzip "awscli-exe.zip"

# Run the install program
./aws/install

# Verify the installation
aws --version

# Clean up installation files
echo "Cleaning up installation files..."
rm -rf "awscli-exe.zip" aws

echo "AWS CLI ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "AWS CLI" \
  --category "Tools" \
  --version "${version}" \
  --artifact "$(command -v aws)" \
  --generate-hash