#!/bin/bash -e
################################################################################
##  File:  poetry.sh
##  Desc:  Installs Poetry (Python dependency manager)
################################################################################
python_version="$1" #provided version will be the one linked in /usr/local/bin
source /install/helpers/python-functions.sh

python_install_package "poetry"
python_create_package_symboliclink "$python_version" "/bin/poetry" "/usr/local/bin"
python_create_package_symboliclink "$python_version" "/bin/poetry" "/etc/poetry"