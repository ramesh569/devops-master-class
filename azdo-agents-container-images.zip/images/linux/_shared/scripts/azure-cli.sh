#!/bin/bash -e
################################################################################
##  File:  azure-cli.sh
##  Desc:  Installs Azure CLI (az)
##  Notes: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt
################################################################################
version=§azure-cli§
az_repo=$(lsb_release -cs)

#download and install the Microsoft signing key
curl -sL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null

#add the Azure CLI software repository
echo "linux distribution codename: $az_repo"
echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $az_repo main" |
    tee /etc/apt/sources.list.d/azure-cli.list

#update apt respositories
apt-get update

#display available versions
echo "Available versions"
apt-cache show azure-cli | grep Version

#install specific version
echo "Installing ${version}"
apt-get install "azure-cli=${version}-1~${az_repo}"

#remove added apt source list
rm -f /etc/apt/sources.list.d/azure-cli.list
rm -f /etc/apt/sources.list.d/azure-cli.list.save

#display installed version
echo "azure-cli version"
az version --output table

#update installed software list (add 2 spaces for new line)
echo "Azure CLI ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
    --name "Azure CLI" \
    --category "Tools" \
    --version "${version}" \
    --artifact "$(command -v az)" \
    --generate-hash