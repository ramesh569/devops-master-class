#!/bin/bash -e
################################################################################
##  File:  helm.sh
##  Desc:  Installs Helm (Kubernetes package manager)
##  Helm Docs: https://helm.sh/docs/intro/install/
##  Helm Versions: https://github.com/helm/helm/releases
################################################################################

# select version
target_version=§helm§

echo "Installing helm $target_version"

mot asset download \
  --tool-id "helm" \
  --source "get.helm.sh/helm-v§version§-linux-amd64.tar.gz" \
  --destination "./helm-linux-amd64.tar.gz"

mkdir -p helm-linux-amd64
tar -xvzf "helm-linux-amd64.tar.gz" -C helm-linux-amd64
install -o root -g root -m 0755 helm-linux-amd64/linux-amd64/helm /usr/local/bin/

rm -rf helm-linux-amd64 "helm-linux-amd64.tar.gz"

#update installed software list (add 2 spaces for new line)
echo "Helm ${target_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Helm" \
  --category "Tools" \
  --version "${target_version}" \
  --artifact "/usr/local/bin/helm" \
  --generate-hash
