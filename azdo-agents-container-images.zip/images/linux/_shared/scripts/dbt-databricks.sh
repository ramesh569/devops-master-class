#!/bin/bash -e
################################################################################
##  File:  dbt-databricks.sh
##  Desc:  Installs dbt-databricks (data build tool for Databricks)
################################################################################
source /install/helpers/python-functions.sh

python_install_package "dbt-databricks"
python_create_package_symboliclink "§python311§" "/bin/dbt-databricks" "/usr/local/bin"