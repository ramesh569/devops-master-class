#!/bin/bash -e
################################################################################
##  File:  selenium.sh
##  Desc:  Installs Selenium Server jar on Linux and records version
################################################################################

source /install/helpers/etc-environment.sh

version=§selenium§
echo "Installing Selenium Server jar (${version})..."

install_dir="/opt/selenium"
install_temp="${install_dir}/temp"
jar_filename=selenium-server-${version}.jar

mkdir -p "$install_dir"

mot asset download \
  --tool-id "selenium" \
  --source "github.com/SeleniumHQ/selenium/releases/download/selenium-§version§/selenium-server-§version§.zip" \
  --destination "${install_dir}/selenium-server.zip"

echo "create temporary directory"
mkdir "$install_temp"

echo "unzip ${install_dir}/selenium-server.zip to $install_temp"
unzip -o "${install_dir}/selenium-server.zip" -d "$install_temp"

echo "moving ${install_temp}/${jar_filename} to ${install_dir}"
mv "${install_temp}/${jar_filename}" "${install_dir}/selenium-server.jar"

echo "cleaning up zip file ${install_dir}/selenium-server.zip"
rm "${install_dir}/selenium-server.zip"

echo "cleaning up temporary files in ${install_temp}"
rm -rf $install_temp

echo "creating symbolic link"
# Provide a stable symlink for usage: java -jar /usr/local/bin/selenium-server.jar
ln -sf "${install_dir}/selenium-server.jar" /usr/local/bin/selenium-server.jar

set_etc_environment_variable "SELENIUM_JAR_PATH" "/usr/local/bin/selenium-server.jar"

# Record installed version
echo "Selenium Server ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Selenium Server" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/selenium-server.jar" \
  --generate-hash

echo "Selenium Server jar installation complete (version: ${version})."

