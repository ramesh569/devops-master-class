#!/bin/bash -e
################################################################################
##  File:  python.sh
##  Desc:  Installs Python and common packages for the build environment. Supports version selection and venv setup.
################################################################################
source /install/helpers/install.sh

python_version=$1
install_additional="${2:-false}"

export agent_toolsdirectory=/azp/_work/_tool
nexus_base_url="https://repo.nexuscloud.aws.rabo.cloud/repository/raw-55/meso/third-party/python.org/python-linux"
target_platform="linux-24.04-x64"
IFS=. read -r major minor <<< "$python_version"

# Retrieve the latest subversion from python.org.
# Some directories may exist before the final release is published and only contain rc artifacts,
# so select the newest version that actually has the expected final source tarball.
full_version=""
while IFS= read -r candidate; do
    if curl -fsSI "https://www.python.org/ftp/python/${candidate}/Python-${candidate}.tgz" >/dev/null 2>&1; then
        full_version="$candidate"
        break
    fi
done < <(curl --silent "https://www.python.org/ftp/python/" | grep -o ''"${major}"'\.'"${minor}"'\.[0-9]*' | sort --version-sort -r | uniq)

if [ -z "${full_version}" ]; then
    echo "Unable to resolve a Python version for ${major}.${minor} from python.org" >&2
    exit 1
fi

echo "Python version specified: ${python_version}"
echo "Installing version: ${full_version}"

echo "Install dependencies"
apt-get update

#xmlstarlet is required for parsing the versions.xml file in python-functions.sh and determine python package versions
apt-get install -y \
    libbz2-1.0 \
    libffi8 \
    libgdbm6t64 \
    libgdbm-compat4t64 \
    liblzma5 \
    libncursesw6 \
    libreadline8t64 \
    libsqlite3-0 \
    libssl3t64 \
    libtcl8.6 \
    libtk8.6 \
    libuuid1 \
    zlib1g \
    xmlstarlet

echo "Install Python version"
mkdir -p /azp/tmp
python_archive="python-${full_version}-${target_platform}.tar.gz"
mot asset download \
    --tool-id "python${major}${minor}" \
    --source "${nexus_base_url}/${python_archive}" \
    --destination "/azp/tmp/${python_archive}"
tar -xzf "/azp/tmp/${python_archive}" -C /azp

if [ ! -x "/azp/Python-${full_version}/bin/python3" ]; then
    echo "Downloaded archive is missing /azp/Python-${full_version}/bin/python3" >&2
    exit 1
fi

# Add python at start of PATH (meaning it will load before any other python that might be in the path already)
# note that this will onyl be available in the current context, not in the eventual agent
export PATH="/azp/Python-${full_version}/bin:${PATH}"

# Creating python directory structure
# $AGENT_TOOLSDIRECTORY/
#     Python/
#        {version number}/
#            {platform}/
#            {platform}.complete
# file structure documented at https://learn.microsoft.com/en-us/azure/devops/pipelines/tasks/reference/use-python-version-v0?view=azure-pipelines#how-can-i-configure-a-self-hosted-agent-to-use-this-task
echo "Create directory"
mkdir -p "${agent_toolsdirectory}/Python/${full_version}"

echo "Create symlink"
echo "Creating symlink from ${agent_toolsdirectory}/Python/${python_version} to ${agent_toolsdirectory}/Python/${full_version}"
ln -sfv "${agent_toolsdirectory}/Python/${full_version}" "${agent_toolsdirectory}/Python/${python_version}"

echo "Install latest pip (global)" # because pip is used to create the virtual environment, and it should use latest pip
python3 -m pip install --upgrade pip

echo "Install pipx (global)"
python3 -m pip install --upgrade pipx==§python314.pipx§

echo "Create python virtual environment"
cd "$agent_toolsdirectory/Python/${full_version}"
python3 -m venv x64 #create python virtual directory

# create complete file to indicate python is installed
echo "Add installation completed flag"
touch x64.complete #just an empty file, but needed

echo "Install Python packages related to package management"
"${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" -m pip install --upgrade pip pipx==§python314.pipx§ wheel setuptools

if $install_additional; then
  "${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" -m pip install --upgrade boto3 pytest
fi

echo "Cleanup installation files"
rm -rf /azp/tmp

#adding python to the path environment through start commands will make all executables (including those installed by pip) availble for the agent
echo "Add python to path through start-commands.sh"
PrependToPath "${agent_toolsdirectory}/Python/${full_version}/x64/bin"

mot docs applications add \
    --name "Python" \
    --category "Runtimes" \
    --version "${full_version}" \
    --artifact "${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" \
    --generate-hash

pipx_version=$("${agent_toolsdirectory}/Python/${full_version}/x64/bin/pipx" --version | awk '{print $1}')
mot docs applications add \
    --name "pipx" \
    --category "Tools" \
    --version "${pipx_version}" \
    --artifact "${agent_toolsdirectory}/Python/${full_version}/x64/bin/pipx" \
    --generate-hash

echo "Python installation completed successfully"
