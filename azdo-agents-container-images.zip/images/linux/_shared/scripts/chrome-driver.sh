#!/bin/bash -e
################################################################################
##  File:  google-chrome.sh (Copied from Runner Images)
##  Desc:  Installs google-chrome, chromedriver and chromium
##  Commit: 899fcf9b160060d94b8825f971057159686ee50d
##  Date: 29/05/2024
##  Override: Remove liboss4-salsa-asound2 to avoid conflicts with libasound2 before installing Chrome
################################################################################

# Source the helpers for use with the script
source /install/helpers/install.sh
source /install/helpers/etc-environment.sh

#remove liboss4-salsa-asound2 to avoid conflicts with libasound2
echo "remove liboss4-salsa-asound2"
apt remove liboss4-salsa-asound2

# Update package lists and remove unnecessary packages
# fix for "E: Unable to correct problems, you have held broken packages." error message
# see also https://askubuntu.com/questions/223237/unable-to-correct-problems-you-have-held-broken-packages
echo "apt-get update"
apt-get update

echo "apt-get autoremove"
apt-get autoremove


get_chromium_revision() {
    local chrome_revision=$1

    # Take the first part of the revision variable to search not only for a specific version,
    # but also for similar ones, so that we can get a previous one if the required revision is not found
    chrome_revision_prefix=${chrome_revision:0:${#chrome_revision}/2+1}
    search_url="https://www.googleapis.com/storage/v1/b/chromium-browser-snapshots/o?delimiter=/&prefix=Linux_x64"
    # Revision can include a hash instead of a number. Need to filter it out https://github.com/actions/runner-images/issues/5256
  revisions_available=$(curl -s "$search_url"/"${chrome_revision_prefix}" | jq -r '.prefixes[]' | grep -E "Linux_x64\/[0-9]+\/"| cut -d "/" -f 2 | sort --version-sort)

    # If required Chromium revision is not found in the list
    # we should have to decrement the revision number until we find one.
    # This is mentioned in the documentation we use for this installation:
    # https://www.chromium.org/getting-involved/download-chromium
  latest_valid_revision=$(echo "$revisions_available" | cut -f 1 -d " ")
    for revision in $revisions_available; do
        if [ "$chrome_revision" -lt "$revision" ]; then
          break
        fi

        latest_valid_revision=$revision
    done

    echo "$latest_valid_revision"
}

# Download and install Google Chrome
chrome_deb_url="https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"
chrome_deb_path=$(download_with_retry "$chrome_deb_url")
echo "apt-get install $chrome_deb_path -f"
apt-get install "$chrome_deb_path" -f
set_etc_environment_variable "CHROME_BIN" "/usr/bin/google-chrome"

# Remove Google Chrome repo
rm -f /etc/cron.daily/google-chrome /etc/apt/sources.list.d/google-chrome.list /etc/apt/sources.list.d/google-chrome.list.save

# Parse Google Chrome version
full_chrome_version=$(google-chrome --product-version)
chrome_version=${full_chrome_version%.*}
echo "Chrome version is $full_chrome_version"

# Get chrome versions information
chrome_platform="linux64"
chrome_versions_url="https://googlechromelabs.github.io/chrome-for-testing/latest-patch-versions-per-build-with-downloads.json"
chrome_versions_json=$(curl -fsSL "${chrome_versions_url}")

# Download and unpack the latest release of chromedriver
chromedriver_version=$(echo "${chrome_versions_json}" | jq -r '.builds["'"$chrome_version"'"].version')
chromedriver_url=$(echo "${chrome_versions_json}" | jq -r '.builds["'"$chrome_version"'"].downloads.chromedriver[] | select(.platform=="'"${chrome_platform}"'").url')
chromedriver_dir="/usr/local/share/chromedriver-linux64"
chromedriver_bin="$chromedriver_dir/chromedriver"

echo "Installing chromedriver version $chromedriver_version"
driver_archive_path=$(download_with_retry "$chromedriver_url")
unzip -qq "$driver_archive_path" -d /usr/local/share

chmod +x $chromedriver_bin
ln -s "$chromedriver_bin" /usr/bin/
set_etc_environment_variable "CHROMEWEBDRIVER" "${chromedriver_dir}"

# Download and unpack Chromium
chrome_revision=$(echo "${chrome_versions_json}" | jq -r '.builds["'"$chrome_version"'"].revision')
chromium_revision=$(get_chromium_revision "$chrome_revision")
chromium_url="https://www.googleapis.com/download/storage/v1/b/chromium-browser-snapshots/o/Linux_x64%2F${chromium_revision}%2Fchrome-linux.zip?alt=media"
chromium_dir="/usr/local/share/chromium"
chromium_bin="${chromium_dir}/chrome-linux/chrome"

echo "Installing chromium revision $chromium_revision"
chromium_archive_path=$(download_with_retry "$chromium_url")
mkdir "$chromium_dir"
unzip -qq "$chromium_archive_path" -d "$chromium_dir"

ln -s $chromium_bin /usr/bin/chromium
ln -s $chromium_bin /usr/bin/chromium-browser

echo "Google Chrome ${chrome_version}  " >> /install/InstalledSoftware.txt
echo "Google Chrome Driver Revision ${chrome_revision}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Google Chrome" \
  --category "Browser" \
  --version "${chrome_version}" \
  --artifact "${chromium_bin}" \
  --generate-hash
mot docs applications add \
  --name "Google Chrome Driver Revision" \
  --category "Browsers" \
  --version "${chrome_revision}" \
  --artifact "${chromedriver_bin}" \
  --generate-hash