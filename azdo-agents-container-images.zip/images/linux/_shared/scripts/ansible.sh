#!/bin/bash -e
################################################################################
##  File:  ansible.sh
##  Desc:  Installs Ansible
################################################################################

# configuration
ppa_repo="ppa:ansible/ansible"

# install ansible
echo "Installing Ansible"
source ./scripts/apt-packages.sh $ppa_repo true "ansible:latest"
