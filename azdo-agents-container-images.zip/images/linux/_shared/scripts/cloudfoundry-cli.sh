#!/bin/bash -e
################################################################################
##  File:  cloudfoundry-cli.sh
##  Desc:  Installs the Cloud Foundry CLI and essential plugins for application deployment and management.
##  Note:  This tool has special ownership: https://confluence.dev.rabobank.nl/spaces/vsts/pages/1422859650/Reference+-+Tool+Ownership
##             Keep this ownership in mind when making changes.
################################################################################

# Source install function
source /install/helpers/install.sh

version="§pcf-cli§"
pcf_major_verison=${version%%.*}
echo "Installing PCF version $version"

export app_dir="/etc/pcf${pcf_major_verison}"
mkdir "$app_dir"

mot asset download \
  --tool-id "pcf-cli" \
  --source "github.com/cloudfoundry/cli/releases/download/v§version§/cf8-cli_§version§_linux_x86-64.tgz" \
  --destination "$app_dir/cf-cli.tgz"

cd "$app_dir"

tar -xvf "$app_dir/cf-cli.tgz"
rm "$app_dir/cf-cli.tgz"

#define executable path
executable_path="$app_dir/cf"

# check if it works
"$executable_path" --version

# create CF_HOME env variable
echo "CF_HOME=${app_dir}" | tee -a /etc/environment
export CF_HOME=${app_dir}
[ -d "$CF_HOME" ] || mkdir -p "$CF_HOME"

echo "install PCF CLI plugins"
echo "CF_PLUGIN_HOME=${app_dir}" | tee -a /etc/environment
export CF_PLUGIN_HOME="${app_dir}"

# Source: https://github.com/bluemixgaragelondon/cf-blue-green-deploy
echo "  Installing pcf-blue-green-deploy"
mot asset download \
  --tool-id "pcf-blue-green-deploy" \
  --source "github.com/bluemixgaragelondon/cf-blue-green-deploy/releases/download/v§version§/blue-green-deploy.linux64" \
  --destination "$app_dir/cf-blue-green-deploy.linux64"
"$executable_path" install-plugin "$app_dir/cf-blue-green-deploy.linux64" -f

# Source: https://github.com/rabobank/scheduler-plugin
echo "  Installing pcf-scheduler-plugin"
mot asset download \
  --tool-id "pcf-scheduler-plugin" \
  --source "github.com/rabobank/scheduler-plugin/releases/download/v§version§/scheduler-plugin_linux_amd64" \
  --destination "$app_dir/scheduler-plugin_linux_amd64"
"$executable_path" install-plugin "$app_dir/scheduler-plugin_linux_amd64" -f

#Source: https://github.com/cloudfoundry/app-autoscaler-cli-plugin
echo "  Installing pcf-autoscaler-plugin"
mot asset download \
  --tool-id "pcf-autoscaler-plugin" \
  --source "github.com/cloudfoundry/app-autoscaler-cli-plugin/releases/download/v§version§/ascli-linux-amd64-§version§-release+0" \
  --destination "$app_dir/ascli-linux-amd64-release+0"
"$executable_path" install-plugin "$app_dir/ascli-linux-amd64-release+0" -f

#Source: https://github.com/rabobank/credhub-plugin
echo "  Installing pcf-credhub-plugin"
mot asset download \
  --tool-id "pcf-credhub-plugin" \
  --source "github.com/rabobank/credhub-plugin/releases/download/v§version§/credhub-plugin-v§version§-linux-amd64" \
  --destination "$app_dir/credhub-plugin-linux-amd64"
"$executable_path" install-plugin "$app_dir/credhub-plugin-linux-amd64" -f

# TODO install pcf-cfs-plugin once its available in github

jq -r '.Plugins | to_entries | map([.key] + [(.value.Version | [.Major, .Minor, .Build] | map(tostring) | join("."))]) | .[] | join(" ")' "$CF_PLUGIN_HOME"/.cf/plugins/config.json | \
    while read -r line; do echo "plugin: $line"; done

"$executable_path" plugins

chown 10001:10001 -R "$app_dir"
chmod -R 755 "$app_dir"

# add pcf to path
PrependToPath "$app_dir"
export PATH=${app_dir}:$PATH

# settings current PCF as default
echo "Linking ${executable_path} to /usr/local/bin/cf"
ln -s "${executable_path}" /usr/local/bin/cf -f

echo "export CF_PLUGIN_HOME=${app_dir}" >> /usr/local/start-commands.sh

version=$($executable_path --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+')
echo "CloudFoundry CLI version installed is: ${version}"

#update installed software list (add 2 spaces for new line)
echo "CloudFoundry CLI ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
	--name "CloudFoundry CLI" \
	--category "Tools" \
	--version "${version}" \
	--artifact "${executable_path}" \
	--generate-hash \
  --environment-variables "CF_HOME=${CF_HOME}" \
  --environment-variables "CF_PLUGIN_HOME=${CF_PLUGIN_HOME}"
