#!/bin/bash -e
################################################################################
##  File:  nodejs.sh
##  Desc:  Installs NVM and multiple Node.js versions, sets up global packages, and configures environment for build agents.
################################################################################

################################################################################
## Pipeline Usage Note
################################################################################
##
## Usually one would source the nvm.sh in ~/.bash_profile or ~/.bashrc
## to avoid having to execute nvm.sh each time a shell is started
## however due to implementation of bash@3 task both ~/.bash_profile or ~/.bashrc are ignored
## and the /usr/local/start-commands.sh gets loaded when the container starts, it will load
## environment variables such as NVM_DIR but it will not make nvm available as a native command
##
## Example Bash:
##   - task: Bash@3
##     inputs:
##      targetType: 'inline'
##      script: |
##        source $NVM_DIR/nvm.sh #only required if nvm command is to be used or npm packages such as yarn
##        nvm use 18 #only required if the default isn't what you want
##        echo "##vso[task.prependPath]$NVM_BIN" #add this line to persist the switch beyond the current script
##        npm install -g lodash
##        npm ls -g
##
## Example Powershell:
##   - task: PowerShell@2
##     inputs:
##      targetType: 'inline'
##      script: |
##        . $Env:NVM_DIR/nvm.ps1 #only required if nvm command is to be used
##        nvm use 18 #only required if the default isn't what you want
##        npm install -g lodash
##        npm ls -g
################################################################################
source /install/helpers/helper-functions.sh

#[Configuration]
nvm_version="§nvm-sh§"
# shellcheck disable=SC2206 # SC2206: Quote to prevent word splitting, but we expect a single value or an array
nodejs_versions=($1)
nodejs_default_version=${nodejs_versions[-1]}
#determining the latest version
pwsh -c ". /install/content/helpers/VersionHelper.ps1;Get-GitHubDownloadUrl \
    -RepoOwner 'nvm-sh' \
    -RepoName 'nvm' \
    -ApplicationName 'nvm' \
    -TargetVersion $nvm_version \
    -ArtifactRegex 'ignore'"

echo "Script will install following node versions:"

for version in "${nodejs_versions[@]}"; do
    echo "$version"
    #detemining latest using EOL
    latest_version=$(pwsh -c ". /install/content/helpers/VersionHelper.ps1;Get-LatestEndOfLifeVersionAsString \
                        -ApplicationId 'nodejs' \
                        -ApplicationName 'Node JS' \
                        -TargetVersion '$version'")

    #determing the latest version using dpkg
    verify_latest_version "$latest_version" "$version" "Node JS"
done
echo "The default version will be: $nodejs_default_version"

npm_package_list=("yarn") #list of NPM packages to be installed for each NodeJS version
custom_capability_list=("yarn") #list of capabilities to be added to agent (which corrosponds with the NPM packages installed)

######################
## NVM Installation ##
######################
echo "Create NVM_DIR $NVM_DIR"
mkdir "$NVM_DIR"

url="https://raw.githubusercontent.com/nvm-sh/nvm/v$nvm_version/install.sh"
echo "Download and Execute URL ${url}"
curl -o- $url | bash

echo "execute nvm.sh" #required to run nvm commands in THIS script, not eventual docker container
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

echo "get nvm version" #
nvm -v

#update installed software list (add 2 spaces for new line)
echo "nvm ${nvm_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "NVM" \
  --category "Tools" \
  --version "${nvm_version}" \
  --environment-variables "NVM_DIR=$NVM_DIR"

#########################
## NodeJS Installation ##
#########################

for version in "${nodejs_versions[@]}"; do
    echo "Install NodeJS version $version"
    nvm install "$version"
    npm config set registry https://nexus3.rabobank.nl/repository/npmjs-org/

    # shellcheck disable=SC2016
    # SC2016: Expressions don't expand in single quotes, use double quotes for that.
    # the single quoted value doesn't need to be expanded but send to powershell verbatim
    pwsh -Command '$version=(node --version | Select-String -pattern "([0-9]+\.*){3}").Matches.Value;$executable=(Get-Command node).Source;Add-Content -Path "/install/InstalledSoftware.txt" -Value "NodeJS $version";mot docs applications add --name "NodeJS" --category "Frameworks" --version $version --artifact $executable --generate-hash | Out-Null;if ($LASTEXITCODE -ne 0) { throw "Failed to document NodeJS $version" }'

    echo "Install NPM Packages for NodeJS $version"
    for package in "${npm_package_list[@]}"; do
        echo "NPM Package: $package"
        npm install -g "$package"
    done
done

#Installing PNPM using NPM
echo "Install pnpm"
npm install -g pnpm
pnpm --version

# shellcheck disable=SC2016
# SC2016: Expressions don't expand in single quotes, use double quotes for that.
# the single quoted value doesn't need to be expanded but send to powershell verbatim
pwsh -Command '$version=(pnpm --version | Select-String -pattern "([0-9]+\.*){3}").Matches.Value;$executable=(Get-Command pnpm).Source;Add-Content -Path "/install/InstalledSoftware.txt" -Value "PNPM $version";mot docs applications add --name "PNPM" --category "Package Managers" --version $version --artifact $executable --generate-hash | Out-Null;if ($LASTEXITCODE -ne 0) { throw "Failed to document PNPM $version" }'

#################################
## Finish NVM and grant access ##
#################################

#add environment variables to be picked up as capabilities, required for demands
for capability in "${custom_capability_list[@]}"; do
    echo "Adding Capability (Envrionment Variable) '$capability'"
    echo "export $capability=True" >> /usr/local/start-commands.sh
done

#load NVM_DIR into environment variables on agent startup
echo "writing environment variables" #required to export NVM_DIR value to pipeline and scripts started in pipeline
echo "export NVM_DIR=$NVM_DIR" >> /usr/local/start-commands.sh

#load nvm into path variable at startup
echo "source $NVM_DIR/nvm.sh" >> /usr/local/start-commands.sh

#copy nvm powershell wrapper to same location as nvm.sh for consistency
cp "/install/scripts/nvm-wrapper.ps1" "$NVM_DIR/nvm.ps1"

#set default node version
nvm alias default "$nodejs_default_version"

#configure access to NVM directory
#this command should run after the NodeJS installations otherwise you get access error as AzDevOps user when installing node_modules
echo "configure access" #required so AzDevOps user has execute access
chown 10001:10001 -R "$NVM_DIR"
chmod 755 -R "$NVM_DIR"
