#!/bin/bash -e
################################################################################
##  File:  playwright.sh
##  Desc:  Installs system dependencies required by Playwright on Debian/Ubuntu
################################################################################
source /install/helpers/python-functions.sh

python_version=$1

set -o pipefail
export DEBIAN_FRONTEND=noninteractive

echo "Installing Python Playwright package and system dependencies..."

python_install_package playwright
# Create a symlink for the Playwright CLI from the selected Python (expects major.minor, e.g., 3.10)
# The CLI is installed into the Python "x64/bin" directory under AGENT_TOOLSDIRECTORY
python_create_package_symboliclink "$python_version" "/x64/bin/playwright" "/usr/local/bin"

# Resolve the Playwright CLI path for the requested Python version
python_dir=$(find "$AGENT_TOOLSDIRECTORY/Python" -mindepth 1 -maxdepth 1 -name "${python_version}*" -type d | head -n1)
if [[ -z "$python_dir" ]]; then
	echo "ERROR: Python ${python_version} not found under $AGENT_TOOLSDIRECTORY/Python" >&2
	exit 1
fi
cli_path="${python_dir}/x64/bin/playwright"
if [[ ! -x "$cli_path" ]]; then
	echo "ERROR: Playwright CLI not found at ${cli_path}" >&2
	ls -la "${python_dir}/x64/bin" || true
	exit 1
fi

# Record Playwright package version
playwright_ver=$("${python_dir}/x64/bin/python3" - <<'PY'
try:
	import importlib.metadata as md
	print(md.version('playwright'))
except Exception:
	try:
		import pkg_resources as pr
		print(pr.get_distribution('playwright').version)
	except Exception:
		print('')
PY
)
echo "Playwright Python package version: ${playwright_ver}"
echo "Playwright (python) ${playwright_ver}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Playwright" \
  --category "Tools" \
  --version "${playwright_ver}" \
  --artifact "$cli_path" \
  --generate-hash

# Rely exclusively on Python Playwright helper (no fallbacks)
if ! "$cli_path" install-deps; then
	echo "ERROR: playwright install-deps failed." >&2
	exit 1
fi

echo "Playwright dependencies installation complete."
