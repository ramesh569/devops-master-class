#!/bin/bash
set -e # Exit immediately if a command exits with a non-zero status.
################################################################################
##  Desc: Install sqlfluff-templater-dbt
################################################################################
python_version=$1

source /install/helpers/python-functions.sh

python_install_package "sqlfluff-templater-dbt"
python_create_package_symboliclink "$python_version" "/bin/sqlfluff-templater-dbt" "/usr/local/bin"
