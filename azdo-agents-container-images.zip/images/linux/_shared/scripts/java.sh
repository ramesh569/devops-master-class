#!/bin/bash -e
################################################################################
##  File:  java.sh
##  Desc:  Installs Java (OpenJDK) and configures JAVA_HOME. Imports certificates and sets default version if specified.
################################################################################
major_version="$1"
set_default="$2"

# Source the helpers for use with the script
source /install/helpers/install.sh

function get_os_version_label {
    lsb_release -cs
}

os_label=$(get_os_version_label)
java_path="/usr/lib/jvm/temurin-${major_version}-jdk-amd64"

# get the repo for adoptium JAVA OpenJDK
wget -qO - https://packages.adoptium.net/artifactory/api/security/keypair/default-gpg-key/public | gpg --dearmor > /usr/share/keyrings/adoptium.gpg
echo "deb [signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb/ $os_label main" > /etc/apt/sources.list.d/adoptium.list

#Install Java
echo "Installing Java OpenJDK ${major_version}"
apt update
apt-get install -y temurin-"${major_version}"-jdk --no-install-recommends

#set JAVA_HOME_Version
echo "export JAVA_HOME_${major_version}_X64=$java_path" >> /usr/local/start-commands.sh

if [ "$set_default" = "true" ]; then
    echo "Setting JAVA default version to v$major_version"
    echo "export JAVA_HOME=$java_path" >> /usr/local/start-commands.sh
  #Replaces the previous version (if installed) in the PATH sys variable if it has been previously added to start-commands.sh

  #TODO: After the maintenance window on 27/03/2024 default version is to be updated
  #PrependToPath "$java_path"
fi

#install cerficiates for java
function import_certificates_for_jdk() {
    local java_path="$1"
    echo "Import certificates into cacerts"

    keytool="$java_path/bin/keytool"
    if [ ! -f "$keytool" ]; then
        echo -e "##vso[task.logissue type=warning]Failed to import certificates for JAVA. No keytool found at $keytool, skipping $java_path"
        return
    fi

    storepass=changeit
    for cert_file in /usr/local/share/ca-certificates/*.crt; do
        cert_alias=$(basename "$cert_file" | sed -e 's/\.crt$//' -e 's/ /_/g')

        if [ "$major_version" = "8" ]; then # IF Block can be removed when Java 8 is no longer plaguing our world
            cacerts="$java_path/lib/security/cacerts"
            if [ ! -f "$cacerts" ]; then cacerts="$java_path/jre/lib/security/cacerts"; fi
            if [ ! -f "$cacerts" ]; then
                echo "No cacerts file found, skipping $java_path"
                continue
            fi
            if "$keytool" -keystore "$cacerts" -storepass "$storepass" -noprompt -list -alias "$cert_alias" >/dev/null; then
                echo "$cert_alias: already imported. skip"
            else
                echo "$cert_alias: importing in cacerts"
                "$keytool" -keystore "$cacerts" -storepass "$storepass" -noprompt -importcert -alias "$cert_alias" -file "$cert_file"
            fi
        else
            # For Java 9 and later -cacerts should be used instead of -keystore (using keystore will generate warnings)
            if "$keytool" -list -cacerts -storepass "$storepass" -noprompt -alias "$cert_alias" >/dev/null; then
                echo "$cert_alias: already imported. skip"
            else
                echo "$cert_alias: importing in cacerts"
                "$keytool" -importcert -cacerts -storepass "$storepass" -noprompt -alias "$cert_alias" -file "$cert_file"
            fi
        fi
    done
}

import_certificates_for_jdk "$java_path"

# cleanup
rm -f /etc/apt/sources.list.d/adoptium.list
rm -f /usr/share/keyrings/adoptium.gpg

#Disable cleanup: this prevent other installations to download items such as chrome driver
#apt-get clean && apt-get autoremove && rm -rf /var/lib/apt/lists/*

#update-java-alternatives is a program to update alternatives for jre/jdk installations.
#TODO: This is not tested with multiple java versions.
update-java-alternatives -s "$java_path"

#update installed software list (add 2 spaces for new line)
#TODO: Remove if statement when we get rid of java v8
if [ "$major_version" = "8" ]; then
    "$java_path/bin/javac" -version 2> /tmp/version.txt
    version_output=$(cat /tmp/version.txt)
else
    version_output=$("$java_path/bin/javac" -version)
fi

version=${version_output:5}
echo "Java ${version}  " >> /install/InstalledSoftware.txt
mot_environment_variables=(--environment-variables "JAVA_HOME_${major_version}_X64=$java_path")
if [ "$set_default" = "true" ]; then
        mot_environment_variables+=(--environment-variables "JAVA_HOME=$java_path")
fi
mot docs applications add \
  --name "Java" \
  --category "Frameworks" \
  --version "${version}" \
  --artifact "$java_path/bin/javac" \
  --generate-hash \
  "${mot_environment_variables[@]}"