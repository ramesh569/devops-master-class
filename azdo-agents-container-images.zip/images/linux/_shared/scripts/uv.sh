#!/bin/bash -e
################################################################################
##  File:  uv.sh
##  Desc:  Installs uv
################################################################################
uv_version="§uv§"

echo "Installing uv $uv_version"

mot asset download \
  --tool-id "uv" \
  --source "github.com/astral-sh/uv/releases/download/§version§/uv-x86_64-unknown-linux-gnu.tar.gz" \
  --destination "uv.tar.gz"

tar -xzf uv.tar.gz

# Find and move uv binary to /usr/local/bin
find . -type f -name "uv" -exec mv {} /usr/local/bin/uv \;
find . -type f -name "uvx" -exec mv {} /usr/local/bin/uvx \;

#cleanup uv tar file
rm uv.tar.gz

chmod +x /usr/local/bin/uv
chmod +x /usr/local/bin/uvx

#Verify the installation and extract version
installed_version=$(uv --version)

# Extract only the version number (e.g., 0.8.15)
uv_version=$(echo "$installed_version" | grep -oP 'uv \K[0-9]+\.[0-9]+\.[0-9]+')
echo "Installed uv version: $uv_version"

echo UV "$uv_version" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "UV" \
  --category "Tools" \
  --version "${uv_version}" \
  --artifact "/usr/local/bin/uv" \
  --generate-hash

echo "uv installed successfully!"
