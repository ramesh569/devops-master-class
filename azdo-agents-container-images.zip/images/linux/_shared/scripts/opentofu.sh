#!/bin/bash -e
################################################################################
##  File:  opentofu.sh
##  Desc:  Installs OpenTofu, downloads specific version, extracts the binary
##         and verifies installation.
################################################################################

mot asset download \
  --tool-id "opentofu" \
  --source "github.com/opentofu/opentofu/releases/download/v§version§/tofu_§version§_linux_amd64.tar.gz" \
  --destination "opentofu.tar.gz"

echo "Extracting archive"
tar -xzf opentofu.tar.gz -C /usr/local/bin tofu
rm opentofu.tar.gz

# give user execute access
echo "Granting execute access"
chmod +x /usr/local/bin/tofu

# display installed version
echo "Checking version"
version=$(tofu --version)
echo "The installed version is: $version"
if [[ -z "$version" ]]; then
  echo "Failed to run opentofu --version"
  exit 1
fi

# extract version number from output
# output example: OpenTofu v0.2.10
# selected output 0.2.10
tofu_version=$(echo "$version" | grep -oP '(?<=v)\d+\.\d+\.\d+')
if [[ -z "$tofu_version" ]]; then
  echo "Failed to extract OpenTofu version"
  exit 1
fi

# update installed software list
echo "update installed software list"
echo "OpenTofu ${tofu_version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "OpenTofu" \
  --category "Tools" \
  --version "${tofu_version}" \
  --artifact "/usr/local/bin/tofu" \
  --generate-hash

