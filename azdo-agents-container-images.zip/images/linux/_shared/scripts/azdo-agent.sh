#!/bin/bash -e
################################################################################
##  File:  azdo-agent.sh
##  Desc:  Installs Azure DevOps Agent
##  Note: Configuring the agents happens in another script (start.sh)
################################################################################

mkdir -p /azp/_work
cp /install/scripts/start.sh /azp/start.sh

echo "granting execute rights on /etc/profile.d/*"
# important to remove for UBI image type
if [ -f "/etc/profile.d/colorgrep.csh" ]; then
    rm /etc/profile.d/colorgrep.csh
fi
chmod -R 755 /etc/profile.d
echo "Access granted"

agent_version=§azure-devops-agent§

echo "Installing Azure DevOps Agent $agent_version"
cd /azp

mot asset download \
  --tool-id "azure-devops-agent" \
  --source "download.agent.dev.azure.com/agent/§version§/pipelines-agent-linux-x64-§version§.tar.gz" \
  --destination "pipelines-agent.tar.gz"

tar -xzvf "pipelines-agent.tar.gz"

echo "Installed Azure DevOps Agent $agent_version"

# Add azure-devops extension for az artifacts command
su - AzDevOps -c 'az extension add --name azure-devops' #requires azure cli to be installed
echo "Added az extension for azure-devops"

#note shelljs and minmatch are not longer required to be updated
#because they are no longer bundled with the agent
#see https://github.com/microsoft/azure-pipelines-agent/releases/tag/v4.260.0
#and https://github.com/microsoft/azure-pipelines-agent/pull/5277

echo "Setting permissions on agent files"
chmod 755 /azp
chown 10001:10001 -R /azp
chmod +x /azp/start.sh

echo "Setting permissions on /home/AzDevOps files"
chmod 755 /home/AzDevOps
chown 10001:10001 -R /home/AzDevOps

#update installed software list (add 2 spaces for new line)
echo "AzureDevOps Agent ${agent_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "AzureDevOps Agent" \
  --category "Tools" \
  --version "${agent_version}"