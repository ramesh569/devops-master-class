#!/bin/bash -e
################################################################################
##  File:  bicep.sh
##  Desc:  Installs Bicep CLI standalone
################################################################################
echo "Installing Bicep CLI..."

mot asset download \
	--tool-id "bicep" \
	--source "github.com/Azure/bicep/releases/download/v§version§/bicep-linux-x64" \
	--destination "bicep"

# Make the binary executable and move to /usr/local/bin
install_path=/usr/local/bin/bicep
mv bicep "${install_path}"
chmod +x "${install_path}"

# Verify the installation
version=$(bicep --version | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+')
echo "Bicep CLI version: $version"

echo "Bicep CLI ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
	--name "Bicep CLI" \
	--category "Tools" \
	--version "${version}" \
	--artifact "${install_path}" \
	--generate-hash