#!/bin/bash -e
################################################################################
##  File:  openbao.sh
##  Desc:  Installs OpenBao, downloads the latest release, extracts the binary, and verifies installation.
##  Note:  This tool has special ownership: https://confluence.dev.rabobank.nl/spaces/vsts/pages/1422859650/Reference+-+Tool+Ownership
##             Keep this ownership in mind when making changes.
################################################################################

mot asset download \
  --tool-id "openbao" \
  --source "github.com/openbao/openbao/releases/download/v§version§/openbao_§version§_Linux_amd64.tar.gz" \
  --destination "bao.tar.gz"

echo "Extracting archive"
tar -xzf bao.tar.gz -C /usr/local/bin
rm bao.tar.gz

# give user execute access
echo "Granting execute access"
chmod +x /usr/local/bin/bao

# display installed verison
echo "Checking version"
version=$(bao --version)
echo "The installed version is: $version"
if [[ -z "$version" ]]; then
  echo "Failed to run bao --version"
  exit 1
fi

# extract version number from output
# output example: OpenBao v2.3.2 (b1a68f558c89d18d38fbb8675bb6fc1d90b71e98), built 2025-08-08T04:05:45Z
# selected output 0.2.10
version=$(echo "$version" | grep -oP '(?<=v)\d+\.\d+\.\d+')
if [[ -z "$version" ]]; then
  echo "Failed to extract OpenBao version"
  exit 1
fi

#get bao version
echo "document installation"
echo "OpenBao ${version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "OpenBao" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/bao" \
  --generate-hash
