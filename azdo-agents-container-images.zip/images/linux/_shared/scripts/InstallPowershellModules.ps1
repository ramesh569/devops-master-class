﻿<#
.SYNOPSIS
    Install Powershell Modules
.DESCRIPTION
    Installs the following Powershell modules:
    - AZ
    - Pester
    - PSScriptAnalyzer
    - MarkdownPS
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error

#[functions]
function Install-PowershellModule {
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $Name,

        [Parameter(Mandatory=$true)]
        [version]
        $Version
    )

    #display information which module is being installed
    write-host "`t$Name $Version"

    #get latest available module information
    $latestModule = Find-Module -Name $Name -Repository PSGallery


    #display warning if there is a newer version available
    if ($latestModule.Version -gt $Version) {
        #%0D%0A is carriage return;new line using the powershell native `n results in only the first line being displayed in the warning on the AzureDevOps pipeline run page
        Write-Host "##vso[task.logissue type=warning]Newer version of $Name Powershell Module is available.%0D%0A`tInstalled Version: $Version%0D%0A`tAvailable Version: $($latestModule.Version)"
        Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    }

    #install version that was specified
    Install-Module -Name $Name -RequiredVersion $Version -Scope AllUsers -Repository PSGallery -Force
}


#Allow PSGallery
write-host "Allow PSGallery"
Set-PSRepository -InstallationPolicy Trusted -Name PSGallery

#Install AZ Module
write-host "Installing Powershell Modules"

#add environment variables to be picked up as capabilities, required for demands
#some task demand 'azureps' which is to mean Azure Powershell Modules
#see also https://stackoverflow.com/questions/58416327/azureps-system-capability-is-not-available-on-a-newly-installed-vsts-agent
write-host "Adding Capability (Envrionment Variable) 'azureps'"
Add-Content -Path /usr/local/start-commands.sh -Value "export azureps=True"

Install-PowershellModule -Name "AZ" -Version "§powershell.az§"
Install-PowershellModule -Name "Pester" -Version "§powershell.pester§"
Install-PowershellModule -Name "PSScriptAnalyzer" -Version "§powershell.psScriptAnalyzer§"
Install-PowershellModule -Name "MarkdownPS" -Version "§powershell.markdownPS§"
Install-PowershellModule -Name "SqlServer" -Version "§powershell.sqlServer§"