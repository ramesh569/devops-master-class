#!/bin/bash -e
################################################################################
##  File:  common.sh
##  Desc:  Installs common APT packages and sets up container variables
################################################################################
echo "Start"
#configure APT to run silently
export DEBIAN_FRONTEND=noninteractive
echo "APT::Get::Assume-Yes \"true\";" > /etc/apt/apt.conf.d/90assumeyes #otherwise apt install aborts on prompt "Do you want to continue? [Y/n]"

#automatically download depdencies when installing apt-get packages
echo 'Dpkg::Options {"--force-confdef";"--force-confnew"}' > /etc/apt/apt.conf.d/local

# Update the list of packages
apt-get update

#install some default packages required for other scripts
#run apt-packages.sh from same directory as this script
echo "Installing default packages"
source ./scripts/apt-packages.sh default false " \
    apt-utils:latest \
    traceroute:latest \
    curl:latest \
    wget:latest \
    dialog:latest \
    lzma:latest \
    zip:latest \
    unzip:latest \
    jq:latest \
    ca-certificates:latest \
    fontconfig:latest \
    fonts-noto-color-emoji:latest \
    wget:latest \
    apt-transport-https:latest \
    software-properties-common:latest \
    build-essential:latest \
    python3-jinja2:latest \
    gpg-agent:latest \
    mysql-client:latest \
    file:latest \
    libnss3-tools:latest \
    gdb:latest \
    osslsigncode:latest
    "

# Refresh font cache so newly installed fonts are available
fc-cache -f -v

#create start-commands.sh
echo "echo running start commands" > /usr/local/start-commands.sh

#add environment variables to be picked up as capabilities required for demands
#FCTB.DbDeployer.DbDeployer.DbDeployer@0 task requires 'SHELL' but in reality it just requires bash/sh so set the capability
echo "Adding Capability (Environment Variable) 'SHELL'"
echo "export SHELL=True" >> /usr/local/start-commands.sh
