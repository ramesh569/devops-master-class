#!/bin/bash -e
################################################################################
##  File:  structurizr-cli.sh
##  Desc:  Installs Structurizr CLI (architecture diagrams)
################################################################################
version="§structurizr§"
application_directory="/azp/structurizr-cli"

echo "Installing Structurizr CLI $version"

mkdir -p "$application_directory"

mot asset download \
  --tool-id "structurizr" \
  --source "github.com/structurizr/cli/releases/download/v§version§/structurizr-cli.zip" \
  --destination "$application_directory/structurizr-cli.zip"

#unzip
echo "unzip Structurizr"
unzip "$application_directory/structurizr-cli.zip" -d "$application_directory"

#remove archive
echo "Remove temporary files"
rm -f "$application_directory/structurizr-cli.zip"

ln -s "$application_directory/structurizr.sh" /usr/local/bin/structurizr

#update installed software list (add 2 spaces for new line)
echo "Structurizr CLI ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Structurizr CLI" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/structurizr" \
  --generate-hash

echo "Completed Structurizr"
