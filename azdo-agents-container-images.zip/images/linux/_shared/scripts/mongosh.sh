#!/bin/bash -e
################################################################################
##  File:  mongosh.sh
##  Desc:  Installs MongoDB Shell
################################################################################
echo "Installing MongoDB Shell..."
az_repo=$(lsb_release -cs)

apt-get update -y
apt-get install -y wget gnupg
wget -qO- https://www.mongodb.org/static/pgp/server-8.0.asc | tee /etc/apt/trusted.gpg.d/server-8.0.asc > /dev/null

echo "linux distribution codename: $az_repo"
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu $az_repo/mongodb-org/8.0 multiverse" |
    tee /etc/apt/sources.list.d/mongodb-org-8.0.list
apt-get update -y
apt-get install -y mongodb-mongosh

#display installed version
echo "MongoDB Shell version $(mongosh --version)"

#update installed software list (add 2 spaces for new line)
echo "MongoDB Shell (mongosh) $(mongosh --version)  " >> /install/InstalledSoftware.txt
mot docs applications add \
    --name "MongoDB Shell" \
    --category "Tools" \
    --version "$(mongosh --version)" \
    --artifact "$(command -v mongosh)" \
    --generate-hash