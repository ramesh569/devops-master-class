#!/bin/bash -e
################################################################################
##  File:  kubectl.sh
##  Desc:  Installs kubectl
##  Kubectl Docs: https://kubernetes.io/docs/tasks/tools/install-kubectl-linux/
##  Kubectl Versions: https://dl.k8s.io/release/stable.txt
################################################################################

version=§kubectl§

echo "Installing kubectl $version"

mot asset download \
  --tool-id "kubectl" \
  --source "dl.k8s.io/release/v§version§/bin/linux/amd64/kubectl"

# Install kubectl
install -o root -g root -m 0755 kubectl "/usr/local/bin/kubectl"

# Remove the downloaded file
rm kubectl

# Validate kubectl
echo "# Validating kubectl installation"
kubectl version --client

echo "Kubectl ${version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Kubectl" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/kubectl" \
  --generate-hash
