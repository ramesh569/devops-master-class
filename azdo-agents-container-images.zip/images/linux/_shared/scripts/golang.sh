#!/bin/bash -e
################################################################################
##  File:  golang.sh
##  Desc:  Installs the Go programming language for the build environment. Downloads and configures the latest Go version.
################################################################################
source /install/helpers/helper-functions.sh

# Configure variables
target_version=§go-lang-LTS§
file_name=go$target_version.linux-amd64.tar.gz
repo=https://go.dev/dl/$file_name

#determine latest version
if ! response=$(curl -s https://go.dev/dl/ | awk -F'[><]' '/<span.*>go[0-9]+\.[0-9]+(\.[0-9]+)?/ {print $3; exit}'); then
   echo "Warning:failed to fetch go download page"
   exit 0
fi
latest_version=$(echo "$response" | awk -F'[.]' '{print substr($1, 3) "." $2 "." $3}')
if [[ -z "$latest_version" ]]; then
   echo "Failed to determine the latest version."
   exit 0
fi

#determing the latest version using dpkg
verify_latest_version "$latest_version" "$target_version" "Go Lang"

# Run System updates
apt-get update && apt-get upgrade -y

# Download and install Go
curl -LO "$repo"
tar -C /usr/local -xzf "$file_name"

# Setting Go Environment
ln -sf /usr/local/go/bin/go /usr/local/bin

#update installed software list (add 2 spaces for new line)
version=$(go version | grep -oP '(\d+\.\d+\.\d+)')
echo -e Go "${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Go Lang" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/go/bin/go" \
  --generate-hash
