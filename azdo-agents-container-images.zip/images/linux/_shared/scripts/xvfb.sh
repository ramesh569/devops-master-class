#!/bin/bash -e
################################################################################
##  File:  xvfb.sh
##  Desc:  Installs Xvfb (X virtual framebuffer)
################################################################################
source /install/helpers/python-functions.sh

python_version=$1

echo "Installing Xvfb..."

apt-get install -y xvfb xserver-xephyr

python_install_package pyvirtualdisplay
python_create_package_symboliclink "$python_version" "/bin/pyvirtualdisplay" "/usr/local/bin"

# optional
apt-get install -y scrot

python_install_package pillow
python_install_package pyscreenshot
python_create_package_symboliclink "$python_version" "/bin/pyscreenshot" "/usr/local/bin"