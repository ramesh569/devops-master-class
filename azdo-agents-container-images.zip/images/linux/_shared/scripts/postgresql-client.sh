#!/bin/bash -e 
################################################################################
##  File:  postgresql-client.sh
##  Desc:  Installs the PostgreSQL client for database connectivity. Adds official repo and verifies installation.
##  Documentation: https://www.postgresql.org/download/linux/ubuntu/
################################################################################
apt install curl ca-certificates
install -d /usr/share/postgresql-common/pgdg
curl -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc --fail https://www.postgresql.org/media/keys/ACCC4CF8.asc
sh -c 'echo "deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'

#Update the packge list
apt-get update

#Install the default version of the PostgreSQL client from Ubuntu
apt-get install -y postgresql-client-16

#checking the installed version of the software
echo "The installed version is $(psql --version)"