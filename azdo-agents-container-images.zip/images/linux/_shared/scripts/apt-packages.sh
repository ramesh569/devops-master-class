#!/bin/bash -e
################################################################################
##  File:  apt-packages.sh
##  Desc:  Installs apt packages, optionally from a custom repository. Supports version pinning and install recommendations.
##  Param 1 - Package Repo (such as ppa:ansible/ansible, default is 'default')
##  Param 2 - Install Recommends (true[default]/false)
##  Param 3 - Packages to install (format: "package1:version package2:version")
################################################################################
package_repo=$1
install_recommends=$2
packages=$3

if [ -z "$package_repo" ]; then
    echo "Package repository is not provided, using default"
    package_repo="default"
fi

if [ -z "$install_recommends" ]; then
    echo "Install recommends flag is not provided, installing recommended packages"
    install_recommends=true
fi

if [ -z "$packages" ]; then
    echo "No packages provided to install"
    exit 1
fi

# packages variable is in the following format: "package1:version package2:version package3:version"
# split into individual packages
IFS=' ' read -r -a package_array <<< "$packages"

# if package repository is not default, add it
if [ "$package_repo" != "default" ]; then
    echo "Adding package repository: $package_repo"
    if [[ "$package_repo" == ppa:* ]]; then
        add-apt-repository --yes --update "$package_repo"
    else
        # Attempt to add custom repo .list file
        repo_list_file="${package_repo//[^a-zA-Z0-9]/_}.list"
        if ! echo "deb [arch=amd64] $package_repo $(lsb_release -cs) main" | tee "/etc/apt/sources.list.d/$repo_list_file"; then
            echo "Failed to add custom repository $package_repo"
            exit 1
        fi
    fi
fi

# update apt cache
echo "Updating apt cache"
apt-get update

# loop through all packages
for package in "${package_array[@]}"; do
    # processing each package
    echo "Processing package: $package"
    package_name=$(echo "$package" | cut -d':' -f1)
    package_version=$(echo "$package" | cut -d':' -f2)

    # get latest version of package
    latest_version=$(apt-cache policy "$package_name" | grep "Candidate:" | awk '{print $2}')

    if [ "$package_version" == "latest" ]; then
        echo "Version set to latest, using $latest_version"
        package_version=$latest_version
    else
        # if provided version is not latest, create pipeline warning
        if [ "$latest_version" != "$package_version" ]; then
            # %0D%0A is carriage return;new line using the bash native \n results in only the first line being displayed in the warning on the AzureDevOps pipeline run page
            echo -e "##vso[task.logissue type=warning]Newer version of $package_name is available.%0D%0A\tInstalled Version: $package_version %0D%0A\tAvailable Version: $latest_version"
            echo "##vso[task.complete result=SucceededWithIssues;]"
        fi
    fi

    # echo install package
    echo "Installing package: $package_name version: $package_version"
    if [ "$install_recommends" = true ]; then
        echo "Installing with recommended packages"
        apt-get install --yes --install-recommends "$package_name=$package_version"
    else
        echo "Installing without recommended packages"
        apt-get install --yes --no-install-recommends "$package_name=$package_version"
    fi
done

# if package repository is not default, remove it
if [ "$package_repo" != "default" ]; then
    echo "Removing package repository: $package_repo"
    if [[ "$package_repo" == ppa:* ]]; then
        add-apt-repository --remove "$package_repo"
    else
        # Attempt to remove custom repo .list file
        repo_list_file="${package_repo//[^a-zA-Z0-9]/_}.list"
        if [ -f "/etc/apt/sources.list.d/$repo_list_file" ]; then
            rm -f "/etc/apt/sources.list.d/$repo_list_file"
            echo "Removed /etc/apt/sources.list.d/$repo_list_file"
        else
            echo "No .list file found for $package_repo in /etc/apt/sources.list.d/"
        fi
    fi
fi

# clean up cache
echo "Cleaning up apt cache"
apt-get clean
rm -rf /var/lib/apt/lists/*