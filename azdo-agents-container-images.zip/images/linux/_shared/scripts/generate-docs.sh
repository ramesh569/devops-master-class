#!/bin/bash -e
################################################################################
##  File:  generate-docs.sh
##  Desc:  Generates documentation for the completed Ubuntu-based image.
################################################################################
set -o pipefail

doc_directory=/tmp/InstalledSoftware
doc_json_path="$doc_directory/documentation.json"
doc_md_path="$doc_directory/documentation.md"

source ./scripts/apt-packages.sh default false "lsb-release:latest"

mkdir -p "$doc_directory"
# MOT updates existing records in place and preserves installer-authored entries.

desc=$(lsb_release -d | cut -f2-)
os_name=$(echo "$desc" | sed -E 's/ [0-9].*$//')
os_version=$(echo "$desc" | sed -E 's/^[^0-9]*//')
mot docs metadata add \
    --set "os-name=$os_name" \
    --set "os-version=$os_version" \
    --set "os-kernel=$(uname -r)"

source /install/helpers/python-functions.sh
python_document_installation
pwsh -File /install/helpers/Generate-PowershellModulesDocs.ps1

dpkg-query --show --showformat='${Package} | ${Version}\n' | while IFS='|' read -r package version; do
    if [[ -z "$package" ]]; then
        continue
    fi
    mot docs applications add \
        --name "$package" \
        --category "APT Packages" \
        --version "$version" >/dev/null
done

mot docs metadata add --set build-id=§BuildId§ --set "§CommitMetadataKey§=§SourceCommit§"

cp /install/documentation.json "$doc_json_path"
chmod 0644 "$doc_json_path"

mot docs generate-md --out "$doc_md_path"
