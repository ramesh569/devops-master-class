#!/bin/bash -e
################################################################################
##  File:  git.sh
##  Desc:  Installs Git, Git LFS
################################################################################
# Source the helpers for use with the script
source /install/helpers/install.sh

## Install git, git-lfs, git-ftp
git_repo="ppa:git-core/ppa"
add-apt-repository "$git_repo" -y

package_filename=script.deb.sh

# download script that sets up git PPA and keychain
# note: it is questionable to download this script and execute it
# but the previous implementation was using the same remote script
# however it was cached in nexus causing it to become stale and outdated
mot asset download \
  --source "https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh" \
  --destination "$package_filename" \
  --skip-nexus

apt-get install -y git --no-install-recommends \
  git-lfs \
  git-ftp
echo "removing packagecloud.io from apt repo"
add-apt-repository --remove "$git_repo"

echo "increasing git buffer size"
git config --global http.postBuffer 1048576000

# cleanup
apt-get clean && apt-get autoremove && rm -rf /var/lib/apt/lists/*

rm "$package_filename"

echo "git install script completed"