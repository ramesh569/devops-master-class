#!/bin/bash -e
################################################################################
##  File:  configure-apt.sh
##  Desc:  Routes Ubuntu APT packages through the Nexus repository proxies
################################################################################
repository_base="https://nexus01-eu-west-1.artifactcentral.aws.rabo.cloud/repository"

echo "Starting Ubuntu APT proxy configuration."
echo "Ubuntu archive proxy: $repository_base/ubuntu-archive-com/"
echo "Ubuntu security proxy: $repository_base/ubuntu-security-com/"
echo "Step 1/3: Configure Ubuntu repository URLs."

# Support both legacy and deb822 sources; ignore unmatched globs on images using only one format.
shopt -s nullglob
source_files=(/etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources)
configured=false
for source_file in "${source_files[@]}"; do
    [ -f "$source_file" ] || continue
    echo "Processing APT source file: $source_file"
    # Replace only Ubuntu URLs, including regional mirrors, preserving suites, components, and signing options.
    # Vendor repositories remain unchanged because the Ubuntu proxies cannot serve their packages.
    sed -E -i \
        -e "s@https?://([[:alnum:]-]+\.)*archive\.ubuntu\.com/ubuntu/?([[:space:]]|$)@$repository_base/ubuntu-archive-com/\2@g" \
        -e "s@https?://security\.ubuntu\.com/ubuntu/?([[:space:]]|$)@$repository_base/ubuntu-security-com/\1@g" \
        "$source_file"
    if grep -Fq "$repository_base/ubuntu-archive-com/" "$source_file"; then
        echo "Confirmed Ubuntu archive proxy in: $source_file"
        configured=true
    fi

    echo "================ Showing $source_file ========================"
    cat "$source_file"
    echo "================ End $source_file ============================"
done

# Fail rather than report success for an image whose Ubuntu sources were not recognized.
if [ "$configured" != true ]; then
    echo "##vso[task.logissue type=error]No Ubuntu archive APT source found to configure."
    exit 1
fi
echo "Ubuntu repository URL configuration completed; third-party repository URLs are unchanged."

echo "Step 2/3: Configure strict repository index downloads."
echo "Using standard OS certificate trust prepared by import-certificates-os.sh."
echo "TLS verification and APT package signature verification remain enabled."
# APT otherwise reports some download failures as warnings and can continue with missing or stale indexes.
mkdir -p /etc/apt/apt.conf.d
echo 'APT::Update::Error-Mode "any";' > /etc/apt/apt.conf.d/80update-error-mode
echo "APT index downloads will fail immediately on errors instead of using stale indexes."

# Discard indexes and cached packages from the original sources before any install.
echo "Step 3/3: Clear cached packages and repository indexes from previous sources."
echo "Running apt-get clean."
apt-get clean
if [ -d /var/lib/apt/lists ]; then
    echo "Removing stale repository indexes from /var/lib/apt/lists."
    # Keep the lists directory itself while removing indexes that still reference public Ubuntu URLs.
    find /var/lib/apt/lists -mindepth 1 -delete
else
    echo "No /var/lib/apt/lists directory exists; no repository indexes to remove."
fi
echo "Ubuntu APT proxy configuration completed successfully."
echo "Subsequent apt and apt-get installs will use the configured Ubuntu proxies."
