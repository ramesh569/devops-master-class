#!/bin/bash -e
################################################################################
##  File:  golangci-lint.sh
##  Desc:  Installs golangci-lint for Go projects.
################################################################################

echo "Installing golangci-lint..."
GOBIN=/usr/local/bin go install github.com/golangci/golangci-lint/v2/cmd/golangci-lint@latest

echo "Determining version"
golangci_lint_version=$(golangci-lint --version | grep -oP 'version \K[^ ]+')

echo "Documenting Installation"
echo -e "golangci-lint ${golangci_lint_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
	--name "golangci-lint" \
	--category "Tools" \
	--version "${golangci_lint_version}" \
	--artifact "/usr/local/bin/golangci-lint" \
	--generate-hash

echo "golangci-lint installation complete."