#!/bin/bash -e
################################################################################
##  File:  ant.sh
##  Desc:  Installs Apache Ant (Java build automation tool for compiling, testing, and packaging projects)
################################################################################
source /install/helpers/helper-functions.sh
source /install/helpers/install.sh

version=§ant§
keys_filename="ant.keys"
archive_filename="apache-ant-${version}-bin.tar.gz"
signature_filename="${archive_filename}.asc"
install_path="/usr/local/ant"

#determine the latest version using endoflife.date
latest_version=$(pwsh -c ". /install/content/helpers/VersionHelper.ps1;Get-LatestEndOfLifeVersionAsString \
                    -ApplicationId 'ant' \
                    -ApplicationName 'Apache Ant' \
                    -TargetVersion '$version'")

#determing the latest version using dpkg
verify_latest_version "$latest_version" "$version" "Ant"

#download public key (to verify download)
echo "Download public keys"
curl https://downloads.apache.org/ant/KEYS --output "$keys_filename"

#import public keys
echo "Import public keys"
gpg --import "$keys_filename"

#download ANT
echo "Download ANT and signature"
curl "https://downloads.apache.org/ant/binaries/${archive_filename}" --output "$archive_filename"
curl "https://downloads.apache.org/ant/binaries/${signature_filename}" --output "$signature_filename"

#verify download
echo "Verify signature on filename"
gpg --verify "$signature_filename" "$archive_filename"

#extract archive
echo "Extract ANT"
tar -xf "$archive_filename"

#remove archive, signature and key file
echo "Remove temporary files"
rm "$archive_filename"
rm "$signature_filename"
rm "$keys_filename"

#move extracted folder to bin
echo "Move ant to correct folder"
mv -v "./apache-ant-${version}/" "$install_path"
ln -s "$install_path/bin/ant" /usr/local/bin/ant

# this adds it as env variable in the action container, export doesn't work in docker build
echo "Add ANT_HOME and extend PATH"
echo "export ANT_HOME=${install_path}" >> /usr/local/start-commands.sh
AddToPath "${install_path}/bin"

#update installed software list (add 2 spaces for new line)
echo "ANT ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
   --name "ANT" \
   --category "Tools" \
   --version "${version}" \
   --artifact "${install_path}/bin/ant" \
   --generate-hash \
   --environment-variables "ANT_HOME=${install_path}"