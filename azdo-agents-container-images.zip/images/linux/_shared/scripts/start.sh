#!/bin/bash -e
################################################################################
##  File:  start.sh
##
##  Desc:
##    Entrypoint for Azure DevOps agent containers.
##    - Configures and registers the agent
##    - Handles authentication and environment setup
##    - Manages signal handling and cleanup
##    - Starts the agent and manages its lifecycle
################################################################################
echo "running start.sh..."

# Relevant ENV variables
# AZURE_FEDERATED_TOKEN_FILE
# AZURE_CLIENT_ID
# AZURE_TENANT_ID
# AZURE_AUTHORITY_HOST

# This resource is the "Resource App Id" of the Azure Devops User Impersonation permission
# You can find it in the App Registration > API Permissions > user_impersonation > Popup window
# The .default is here because we are using the client credentials flow, and can not request concent
resource="499b84ac-1321-427f-aa17-267ca6975798/.default"
azp_token=""
miga_pid=""

echo "# Registering agent with Azure DevOps"
echo "# AZURE_AUTHORITY_HOST > $AZURE_AUTHORITY_HOST"
echo "# AZURE_CLIENT_ID > $AZURE_CLIENT_ID"
echo "# AZURE_TENANT_ID > $AZURE_TENANT_ID"
echo "# AZURE_FEDERATED_TOKEN_FILE > $AZURE_FEDERATED_TOKEN_FILE"
echo "# Azure Resource > $resource"

if [ -z "$AZP_URL" ]; then
  echo 1>&2 "error: missing AZP_URL environment variable"
  exit 1
fi

fetch_jwt_token() {
  azure_federated_token=$(cat "$AZURE_FEDERATED_TOKEN_FILE")

  jwt_token=$(curl -X POST \
  -H "Authorization: Bearer $azure_federated_token" \
  -d "resource=$resource&grant_type=client_credentials&client_id=$AZURE_CLIENT_ID&client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer&client_assertion=$azure_federated_token" \
  "https://login.microsoftonline.com/$AZURE_TENANT_ID/oauth2/token" | jq -r '.access_token')

  echo "$jwt_token"
}

get_auth_token() {
  # Check if the AZP_AWS_TOKEN is set, if not, use the federated token by default
  if [[ -n "${AZP_AWS_TOKEN}" ]]; then
    echo "Using AWS PAT token for authentication" >&2
    echo "$AZP_AWS_TOKEN"
    return 0
  fi

  echo "Using federated token for authentication" >&2
  fetch_jwt_token
  return 0
}

if [ -n "$AZP_WORK" ]; then
  mkdir -p "$AZP_WORK"
fi

cleanup() {
  if [[ -e "/usr/local/bin/miga" ]]; then
    echo "Stopping MIGA..."
    kill "${miga_pid}" 2>/dev/null || true
  fi

  # Prefer the persisted token file if present, otherwise try to fetch a token.
  if [[ -n "${AZP_TOKEN_FILE}" && -f "${AZP_TOKEN_FILE}" ]]; then
    azp_token=$(cat "${AZP_TOKEN_FILE}")
  else
    azp_token=$(get_auth_token)
  fi

  if [ -e config.sh ]; then
    print_header "Cleanup. Removing Azure Pipelines agent..."

    # If the agent has some running jobs, the configuration removal process will fail.
    # So, give it some time to finish the job.
    for i in {1..5}; do
       echo "Attempt $i/5 to remove agent from pool"
      ./config.sh remove --unattended --auth PAT --token "$azp_token" && break

      echo "Retrying in 30 seconds..."
      sleep 30
    done

  fi
}

print_header() {
  lightcyan='\033[1;36m'
  nocolor='\033[0m'
  echo -e "${lightcyan}$1${nocolor}"
}

# Let the agent ignore the token and Kubernetes service env variables
export VSO_AGENT_IGNORE=AZURE_CLIENT_ID,AZURE_TENANT_ID,AZP_TOKEN,AZP_AWS_TOKEN,AZP_TOKEN_FILE,KUBERNETES_PORT,KUBERNETES_PORT_443_TCP,KUBERNETES_PORT_443_TCP_ADDR,KUBERNETES_PORT_443_TCP_PORT,KUBERNETES_PORT_443_TCP_PROTO,KUBERNETES_SERVICE_HOST,KUBERNETES_SERVICE_PORT,KUBERNETES_SERVICE_PORT_HTTPS

source /usr/local/start-commands.sh
source ./env.sh

print_header "1. Configuring Azure Pipelines agent..."

#run all shell scripts in profile.d to configure paths
for script in /etc/profile.d/*.sh; do
  [ -e "$script" ] && source "$script"
done

AZP_TOKEN=$(get_auth_token)

# Persist the token to a file so cleanup handlers can read it even if
# environment variables are lost during shutdown.
AZP_TOKEN_FILE=${AZP_TOKEN_FILE:-/azp/.azp_token}
if [[ -n "${AZP_TOKEN}" ]]; then
  echo "Storing AZP token to $AZP_TOKEN_FILE"
  printf "%s" "$AZP_TOKEN" > "$AZP_TOKEN_FILE"
fi

if [ "$REGISTER_PLACEHOLDER_AGENT" = "yes" ]; then
  echo 1>&2 "note: register placeholder agent but do not run"
  ./config.sh --unattended \
  --agent "PlaceholderAgent" \
  --url "$AZP_URL" \
  --auth PAT \
  --token "$AZP_TOKEN" \
  --pool "${AZP_POOL:-Default}" \
  --work "${AZP_WORK:-_work}" \
  --replace \
  --acceptTeeEula & wait $!

  exit 0
fi

./config.sh --unattended \
  --agent "${AZP_AGENT_NAME:-$(hostname)}" \
  --url "$AZP_URL" \
  --auth PAT \
  --token "$AZP_TOKEN" \
  --pool "${AZP_POOL:-Default}" \
  --work "${AZP_WORK:-_work}" \
  --replace \
  --acceptTeeEula & wait $!

print_header "2. Running Azure Pipelines agent..."

# If AZP_AWS_TOKEN is set skip the cleanup process
if [[ -z "${AZP_AWS_TOKEN}" ]]; then
  if [[ -e "/usr/local/bin/miga" ]]; then
    miga_log=/azp/miga.log

    env MIGA_CONFIG_FILE=/etc/miga/config.yaml \
      /usr/local/bin/miga daemon > >(tee "$miga_log") 2>&1 &
    miga_pid=$!
  fi

  trap 'cleanup; exit 0' EXIT
  trap 'cleanup; exit 130' INT
  trap 'cleanup; exit 143' TERM
fi

unset AZP_TOKEN
unset AZP_AWS_TOKEN

# Unset Azure client credentials to avoid leaking them
for var in AZURE_CLIENT_ID AZURE_TENANT_ID AZURE_CLIENT_SECRET; do
  if env | grep -q "^${var}="; then
    echo "Unsetting $var"
    unset "$var"
  fi
done

# To be aware of TERM and INT signals call run.sh
# Running it with the --once flag at the end will shut down the agent after the build is executed
cd /azp
./run.sh "$@" --once