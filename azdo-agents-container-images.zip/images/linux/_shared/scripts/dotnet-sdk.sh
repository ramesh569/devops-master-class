#!/bin/bash -e
################################################################################
##  File:  dotnet-sdk.sh
##  Desc:  Installs .NET SDK
################################################################################
source /install/helpers/install.sh

ubuntu_version=§ubuntu§
major_versions_list=("§dotnetSdkLTS§" "§dotnetSdkCurrent§" "§dotnetSdk10§")

# Add the Microsoft package signing key to your list of trusted keys and add the package repository
wget https://packages.microsoft.com/config/ubuntu/${ubuntu_version}/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
yes | dpkg -i packages-microsoft-prod.deb
rm packages-microsoft-prod.deb


# This is required for .NET SDK versions served from the Ubuntu backports PPA
# See official docs:
# https://learn.microsoft.com/en-us/dotnet/core/install/linux-ubuntu-install?pivots=os-linux-ubuntu-2404&tabs=dotnet9
needs_dotnet_backports=false
for version in "${major_versions_list[@]}"; do
    if [ "$version" == "9.0" ]; then
        needs_dotnet_backports=true
        break
    fi
done

if [ "$needs_dotnet_backports" == "true" ]; then
    echo "Checking Launchpad .NET backports PPA metadata"
    launchpad_metadata_path="/tmp/dotnet-backports-launchpad.json"
    launchpad_api_url="https://api.launchpad.net/devel/~dotnet/+archive/ubuntu/backports"
    if ! curl -fsSL --retry 3 --retry-delay 5 --connect-timeout 10 --max-time 30 "$launchpad_api_url" -o "$launchpad_metadata_path"; then
        echo "Unable to reach Launchpad PPA API: $launchpad_api_url"
        exit 1
    fi

    if ! grep -Eq '"signing_key_fingerprint": "[0-9A-F]{40}"' "$launchpad_metadata_path"; then
        echo "Launchpad PPA metadata did not include a signing key fingerprint"
        head -c 1000 "$launchpad_metadata_path"
        echo
        exit 1
    fi

    dotnet_backports_signing_key_fingerprint=$(sed -nE 's/.*"signing_key_fingerprint": "([0-9A-F]{40})".*/\1/p' "$launchpad_metadata_path" | head -n 1)

    echo "Checking Ubuntu keyserver access for .NET backports signing key"
    ubuntu_keyserver_url="https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x${dotnet_backports_signing_key_fingerprint}"
    if ! curl -fsSL --retry 3 --retry-delay 5 --connect-timeout 10 --max-time 30 "$ubuntu_keyserver_url" | grep -q "BEGIN PGP PUBLIC KEY BLOCK"; then
        echo "Unable to retrieve .NET backports signing key from Ubuntu keyserver: $ubuntu_keyserver_url"
        exit 1
    fi

    echo "Checking Launchpad PPA package index access"
    # shellcheck disable=SC1091
    source /etc/os-release
    launchpad_ppa_release_url="https://ppa.launchpadcontent.net/dotnet/backports/ubuntu/dists/${VERSION_CODENAME}/Release"
    if ! curl -fsSL --retry 3 --retry-delay 5 --connect-timeout 10 --max-time 30 "$launchpad_ppa_release_url" >/dev/null; then
        echo "Unable to reach Launchpad PPA package index: $launchpad_ppa_release_url"
        exit 1
    fi

    add-apt-repository ppa:dotnet/backports
fi

# Update the list of packages after we added packages.microsoft.com
apt-get update

#install transport package
apt install -y apt-transport-https

DOTNET_INSTALL_SCRIPT="https://dot.net/v1/dotnet-install.sh"
install_script_path="/tmp/dotnet-install.sh"
curl -sSL "$DOTNET_INSTALL_SCRIPT" -o "$install_script_path"
chmod +x "$install_script_path"

for version in "${major_versions_list[@]}"; do
    echo "Attempting to install .NET SDK $version via apt-get"
    if ! apt-get install -y dotnet-sdk-"$version"; then
        echo ".NET SDK $version not available via apt-get. Attempting manual install via dotnet-install.sh"
        release_url="https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/${version}/releases.json"
        latest_sdk=$(curl -sSL "$release_url" | jq -r '[.releases[].sdk.version, (.releases[].sdks[]?.version)] | flatten | map(select((contains("preview") or contains("rc")) | not)) | sort_by(.) | last')
        if [ -n "$latest_sdk" ]; then
            echo "Installing latest stable .NET SDK $latest_sdk for channel $version via dotnet-install.sh"
            "$install_script_path" --version "$latest_sdk" --install-dir /usr/lib/dotnet --no-path
            ln -sf /usr/lib/dotnet/dotnet /usr/bin/dotnet
        else
            echo "No stable SDK found for channel $version. Skipping installation."
        fi
    fi
done

#For installations not through apt-get, tools path must be added to PATH
echo "add .NET tools to path through start-commands.sh"

# nuget.org is set automatically as a source during installation of dotnet sdk
dotnet nuget list source
su - AzDevOps -c 'dotnet nuget list source'

AddToPath "/home/AzDevOps/.dotnet/tools"

dotnet_version=$(dotnet --version)
mot docs applications add \
    --name ".NET" \
    --category "Frameworks" \
    --version "${dotnet_version}" \
    --artifact "$(command -v dotnet)" \
    --generate-hash

#update installed software list (add 2 spaces for new line)
# shellcheck disable=SC2016
# SC2016: Expressions don't expand in single quotes, use double quotes for that.
# the single quoted value doesn't need to be expanded but send to powershell verbatim
pwsh -Command 'Add-Content -Path "/install/InstalledSoftware.txt" -Value ((dotnet --list-sdks | Select-String -pattern "([0-9]+\.*){3}").Matches.Value | ForEach-Object { ".NET SDK $_  "; mot docs applications add --name ".NET SDK" --category "Frameworks" --version $_ | Out-Null; if ($LASTEXITCODE -ne 0) { throw "Failed to document .NET SDK $_" } })'
