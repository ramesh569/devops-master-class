#!/bin/bash -e
################################################################################
##  File: maven.sh
##  Desc: Install Maven
################################################################################
# select version
target_version=§maven§

echo "Installing maven $target_version"

mot asset download \
  --tool-id "maven" \
  --source "downloads.apache.org/maven/maven-3/§version§/binaries/apache-maven-§version§-bin.zip" \
  --destination "/tmp/maven.zip"

echo "Unzip maven zip file"
unzip -qq -d /usr/share /tmp/maven.zip

echo "Creating symbolic link"
ln -s /usr/share/apache-maven-${target_version}/bin/mvn /usr/bin/mvn

echo "Copy configuration to maven directory"
mv /install/content/configuration/maven/settings.xml "/usr/share/apache-maven-${target_version}/conf/"

#update installed software list (add 2 spaces for new line)
echo "Maven ${target_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Maven" \
  --category "Tools" \
  --version "${target_version}" \
  --artifact "/usr/share/apache-maven-${target_version}/bin/mvn" \
  --generate-hash
