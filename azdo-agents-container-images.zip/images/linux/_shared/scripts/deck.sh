#!/bin/bash -e
################################################################################
##  File:  deck.sh
##  Desc:  Installs Kong decK (Kong declarative configuration tool) for managing Kong API Gateway configurations.
################################################################################

version="§kong-deck§" # version released on 2nd of February 2024

echo "Installing Kong decK $version"

mot asset download \
  --tool-id "kong-deck" \
  --source "github.com/kong/deck/releases/download/v§version§/deck_§version§_linux_amd64.tar.gz" \
  --destination "deck.tar.gz"

tar -xf deck.tar.gz -C /tmp
cp /tmp/deck /usr/local/bin/

# cleanup by remove downloaded archive
rm deck.tar.gz

# update installed software list (add 2 spaces for new line)
echo "Kong decK ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Kong decK" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/deck" \
  --generate-hash