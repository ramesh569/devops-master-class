#!/bin/bash -e
################################################################################
##  File:  azcopy.sh
##  Desc:  Installs Microsoft AzCopy, a command-line utility for copying data to and from Microsoft Azure Blob, File, and Table storage.
################################################################################

# Source the helpers for use with the script
source /install/helpers/install.sh

version="§azcopy§"

# Download and install AzCopy
archive_path=$(download_with_retry "https://aka.ms/downloadazcopy-v${version}-linux")
tar xzf "$archive_path" --strip-components=1 -C /tmp
rm "$archive_path" # Remove the archive after extraction
mv /tmp/azcopy /usr/local/bin/azcopy

# Verify installation
azcopy_version=$(azcopy --version)

# Print the version of AzCopy
echo "$azcopy_version"

# Extract only the version number
azcopy_version_number=$(echo "$azcopy_version" | grep -oP '\d+\.\d+\.\d+')

# Print the extracted version number
echo "$azcopy_version_number"

# Add AzCopy to the installed software file
echo "AzCopy ${azcopy_version_number}" >> /install/InstalledSoftware.txt
mot docs applications add \
    --name "AzCopy" \
    --category "Tools" \
    --version "${azcopy_version_number}" \
    --artifact /usr/local/bin/azcopy \
    --generate-hash