#!/bin/bash -e
################################################################################
##  File: ubi-common.sh
##  Desc: Install Common APT Packages and setting common variables.
##        Also create start-commands.sh file which is executed at start of container
################################################################################
echo "Common packages installation for UBI image"

# In restricted networks, public EPEL mirrors are blocked. Default to disabling
# EPEL for this step, and enforce an internal Artifact Central EPEL URL.
ARTIFACT_CENTRAL_EPEL_BASEURL="https://ac-nx-eu-west-1.artifactcentral.aws.rabonet.com/repository/dl-fedoraproject-org"
DNF_REPO_FLAGS=(--disablerepo=epel --disablerepo=epel-modular)

echo "Configuring internal EPEL repo"
cat > /etc/yum.repos.d/epel-artifactcentral.repo <<EOF
[epel-artifactcentral]
name=EPEL 9 - Artifact Central
baseurl=${ARTIFACT_CENTRAL_EPEL_BASEURL}
enabled=1
gpgcheck=1
repo_gpgcheck=0
EOF
DNF_REPO_FLAGS+=(--enablerepo=epel-artifactcentral)

dnf clean all

# Update the list of packages
dnf update -y "${DNF_REPO_FLAGS[@]}"

# Update maven to latest
dnf module enable -y maven:3.8 "${DNF_REPO_FLAGS[@]}"

#install some default packages required for other scripts
dnf install -y --allowerasing "${DNF_REPO_FLAGS[@]}" \
    maven \
    rpm \
    procps-ng \
    git \
    curl \
    wget \
    zip \
    unzip \
    jq \
    gnupg2 \
    ca-certificates \
    && rm -rf /var/cache/dnf/*

#create start-commands.sh
echo "echo running start commands" > /usr/local/start-commands.sh
chmod +x /usr/local/start-commands.sh

#add environment variables to be picked up as capabilities, required for demands
#FCTB.DbDeployer.DbDeployer.DbDeployer@0 task requires 'SHELL' but in reality it just requires bash/sh so set the capability
echo "Adding Capability (Environment Variable) 'SHELL'"
echo "export SHELL=True" >> /usr/local/start-commands.sh
