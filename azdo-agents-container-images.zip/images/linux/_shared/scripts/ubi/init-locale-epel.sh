#!/bin/bash
set -euo pipefail
# Purpose: Initialize locale (en_US.UTF-8) and enable EPEL repository for UBI image build.

echo "[locale-epel] Cleaning DNF metadata & updating base packages"
dnf clean all

dnf update -y

echo "[locale-epel] Installing locale packages"
dnf install -y glibc-locale-source glibc-langpack-en

if ! locale -a | grep -q '^en_US\.utf8$'; then
  echo "[locale-epel] Generating en_US.UTF-8 locale"
  localedef -i en_US -f UTF-8 en_US.UTF-8 || true
fi

echo "[locale-epel] Removing redhat.repo (to slim metadata)"
rm -f /etc/yum.repos.d/redhat.repo || true

echo "[locale-epel] Installing epel-release"
dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm

echo "[locale-epel] Enabling EPEL repository"
dnf config-manager --set-enabled epel || true

echo "[locale-epel] Listing enabled repositories"
dnf repolist || true

# Export locale env (Dockerfile also sets these but useful for interactive shells during build)
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8

cat >/etc/profile.d/locale.sh <<'EOF'
export LANG=en_US.UTF-8
export LANGUAGE=en_US:en
export LC_ALL=en_US.UTF-8
EOF

echo "[locale-epel] Completed"
