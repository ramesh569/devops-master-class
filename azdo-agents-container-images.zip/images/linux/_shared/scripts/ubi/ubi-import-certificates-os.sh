#!/bin/bash -e 
################################################################################
##  File: ubi-import-certificates-os.sh
##  Desc: Import all certificates in the OS certificate store
################################################################################
# install as trusted into the OS
src_dir=/install/content/certificates
dest_dir=/usr/local/share/ca-certificates
mkdir -p $dest_dir
cp $src_dir/*.crt $dest_dir

#update ca certificate store
update-ca-trust extract
