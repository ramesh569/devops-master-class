#!/bin/bash -e
################################################################################
##  File: ubi-oracle-suite.sh
##  Desc: Donwload and Install Oracle packages, requires java to be installed
################################################################################
ubi_jdk_version=§ubi-oracle-jdk§

nexus_username=$1
nexus_password=$2
nexus_url=$3
suite_version=$4

nexus_group="meso/third-party"

#STRICTLY TEMPORARY
patch_file_names=("p28186730_1394219_Generic.zip" "p37680629_122140_Generic.zip")
####################

oracle_home_suite_version="${suite_version//./}"
echo "${oracle_home_suite_version}"

# Source nexuscloud download/upload process helper functions
source /install/helpers/common-nexus-cloud.sh

mkdir -p "/install/${oracle_home_suite_version%?}"

compressed="."
alt_url="."
dest_path="/install/${oracle_home_suite_version%?}"

######################################################################
# Temporarily install Oracle JDK 8
file_name="jdk-${ubi_jdk_version}-linux-x64.rpm"
file_full_url="$nexus_url/$nexus_group/oracle/java/${file_name}"
file_path="${dest_path}/${file_name}"
echo "Downloading ${file_name}"
if ! nexus_ops "$file_full_url" "$file_path" "$compressed" "$nexus_username" "$nexus_password" "$alt_url"; then
    echo "Error: nexus_ops command failed"
    exit 1
fi
echo "Installing ${file_name}"
dnf install -y "$file_path"
######################################################################

######################################################################
# Install Oracle Suite Tools
install_file_postfix=("infrastructure" "wls" "soa" "osb")
response_file_name=("fmw.rsp" "wls.rsp" "soa.rsp" "osb.rsp")

oracle_home="/agent/oracle/${oracle_home_suite_version%?}/product/fmw${oracle_home_suite_version%?}"
echo "${oracle_home}"
inventory_loc="/agent/oracle/${oracle_home_suite_version%?}/oraInventory"
base_url="$nexus_url/$nexus_group/oracle"
ora_file_name="oraInst.loc"
ora_file_full_url="$base_url/fusion-middleware/reference/$ora_file_name"
ora_file_path="${dest_path}/${ora_file_name}"

echo "Downloading $ora_file_name and replacing tokens"
if ! nexus_ops "$ora_file_full_url" "$ora_file_path" "$compressed" "$nexus_username" "$nexus_password" "$alt_url"; then
    echo "Error: nexus_ops command failed"
    exit 1
fi

sed -i "s|__INLOC__|$inventory_loc|g" "$ora_file_path"
mkdir -p "$oracle_home" "$inventory_loc"

for file_index in "${!response_file_name[@]}"; do

    ### RESPONSE FILES ###
    response_file_full_url="${base_url}/fusion-middleware/reference/${response_file_name[$file_index]}"
    response_file_path="${dest_path}/${response_file_name[$file_index]}"
    echo "Downloading response file ${response_file_name[$file_index]} and replacing tokens"
    if ! nexus_ops "$response_file_full_url" "$response_file_path" "$compressed" "$nexus_username" "$nexus_password" "$alt_url"; then
        echo "Error: nexus_ops command failed"
        exit 1
    fi
    sed -i "s|__OHOME__|$oracle_home|g" "$response_file_path"

    ### INSTALL JAVA PACKAGES ###
    install_file_name="fmw_${suite_version}_${install_file_postfix[$file_index]}.jar"
    install_file_full_url="$base_url/fusion-middleware/${install_file_name}"
    install_file_path="${dest_path}/${install_file_name}"
    echo "Downloading and installing ${install_file_name}"
    if ! nexus_ops "$install_file_full_url" "$install_file_path" $compressed "$nexus_username" "$nexus_password" $alt_url; then
        echo "Error: nexus_ops command failed"
        exit 1
    fi
    chown 10001:10001 -R "$oracle_home" "$inventory_loc"
    chmod -R 755 "$dest_path"
    echo "Access granted"
    su - AzDevOps -c "java -jar '$install_file_path' -silent -responseFile '$response_file_path' -invPtrLoc '$ora_file_path' -ignoreSysPrereqs"

    latest_dir=$(find /tmp -maxdepth 1 -type d -name 'OraInstall2025-06-25_*' | sort -r | head -1)
    cat "$latest_dir"/install2025-06-25_*.log
    rm -rf /tmp/OraInstall* /tmp/orc*

    # install_file_postfix contains "basic-23.7.0.25.01", first part is the toolname, second the version
    tool_name=${install_file_postfix[$file_index]}
    tool_version=$suite_version
    echo "Oracle Fusion Middleware - $tool_name $tool_version" >> /install/InstalledSoftware.txt
    mot docs applications add \
        --name "${tool_name}" \
        --category "Oracle Fusion Middleware" \
        --version "${tool_version}"

done

echo "Installation complete"

#TEMPORARY Patch installed only on the latest SOA version
if [[ $suite_version == "12.2.1.4.0" ]]; then

    ######################################################################
    # Temporarily install Oracle JDK 8, but now a different version
    # file_name=("jdk-8u451-linux-x64.rpm")
    # file_full_url="$nexus_url/$nexus_group/oracle/java/${file_name}"
    # file_path="${dest_path}/${file_name}"
    # echo "Downloading ${file_name}"
    # if ! nexus_ops $file_full_url $file_path $compressed $nexus_username $nexus_password $alt_url; then
    #     echo "Error: nexus_ops command failed"
    #     exit 1
    # fi
    # echo "Installing ${file_name}"
    # dnf install -y $file_path
    ######################################################################

    for file in "${!patch_file_names[@]}"; do
        # Download both patch files for the new SOA version
        patch_file_a_full_url="$base_url/soa-patches/${patch_file_names[$file]}"
        patch_file_path="${dest_path}/${patch_file_names[$file]}"

        echo "Downloading patch file ${patch_file_names[$file]}"
        if ! nexus_ops "$patch_file_a_full_url" "$patch_file_path" "compressed" "$nexus_username" "$nexus_password" "$alt_url"; then
            echo "Error: nexus_ops command failed"
            exit 1
        fi

        unzip -qq "$patch_file_path" -d "$dest_path" # -qq avoids terminal spam, the patch is huge
    done

    echo "Patch files downloaded and unzipped"
    ls "$dest_path"

    chown 10001:10001 -R "$dest_path"
    chmod -R 755 "$dest_path"

    patch_dir_a="$dest_path/6880880"
    echo "Applying patch in $patch_dir_a"
    su - AzDevOps -c "java -jar '$patch_dir_a/opatch_generic.jar' -silent oracle_home='$oracle_home'"
    patch_dir_b="$dest_path/37680629"
    su - AzDevOps -c "cd $patch_dir_b && $oracle_home/OPatch/opatch apply -silent"

    echo "Patch Installation complete"
fi

######################################################################
# Remove temporary Oracle JDK 8
dnf remove -y "$file_path"
######################################################################