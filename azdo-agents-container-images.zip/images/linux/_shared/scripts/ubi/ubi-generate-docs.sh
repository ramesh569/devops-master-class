#!/bin/bash -e
################################################################################
##  File:  ubi-generate-docs.sh
##  Desc:  Generates documentation for the completed UBI image.
################################################################################
set -o pipefail

doc_directory=/tmp/InstalledSoftware
doc_json_path="$doc_directory/documentation.json"
doc_md_path="$doc_directory/documentation.md"

mkdir -p "$doc_directory"
# MOT updates existing records in place and preserves installer-authored entries.

# Record normalized OS metadata rather than copying all distribution properties.
(
    source /etc/os-release
    : "${NAME:?NAME is required in /etc/os-release}"
    : "${VERSION_ID:?VERSION_ID is required in /etc/os-release}"
    mot docs metadata add \
        --set "os-name=$NAME" \
        --set "os-version=$VERSION_ID"
)

pwsh -File /install/helpers/Generate-PowershellModulesDocs.ps1

rpm -qa --queryformat '%{NAME} | %{VERSION}\n' | while IFS='|' read -r package version; do
    if [[ -z "$package" ]]; then
        continue
    fi
    mot docs applications add \
        --name "$package" \
        --category "RPM Packages" \
        --version "$version" >/dev/null
done

mot docs metadata add --set "os-kernel=$(uname -r)" --set build-id=§BuildId§ --set "§CommitMetadataKey§=§SourceCommit§"

cp /install/documentation.json "$doc_json_path"
chmod 0644 "$doc_json_path"

mot docs generate-md --out "$doc_md_path"
