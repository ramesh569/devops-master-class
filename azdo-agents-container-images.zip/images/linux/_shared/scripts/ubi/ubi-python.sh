#!/bin/bash -e
################################################################################
##  File:  python.sh
##  Desc:  Installs Python and common packages for the build environment. Supports version selection and venv setup.
################################################################################
source /install/helpers/install.sh
python_version=$1
export agent_toolsdirectory=/azp/_work/_tool
IFS=. read -r major minor <<< "$python_version"


echo "Detecting package manager"
if command -v microdnf >/dev/null 2>&1; then
    PKG_MANAGER="microdnf"
    PKG_UPDATE=(:)
    PKG_INSTALL=(microdnf install -y)
    PKG_CLEAN=(microdnf clean all)
elif command -v dnf >/dev/null 2>&1; then
    PKG_MANAGER="dnf"
    PKG_UPDATE=(dnf -y makecache)
    PKG_INSTALL=(dnf -y install)
    PKG_CLEAN=(dnf clean all)
elif command -v yum >/dev/null 2>&1; then
    PKG_MANAGER="yum"
    PKG_UPDATE=(yum -y makecache)
    PKG_INSTALL=(yum -y install)
    PKG_CLEAN=(yum clean all)
else
    echo "No supported package manager found (microdnf/dnf/yum)." >&2
    exit 1
fi

echo "Install dependencies using $PKG_MANAGER (package manager)"
"${PKG_UPDATE[@]}"
deps=(
    tar              # unpack Python source archive
    gzip             # decompress .tgz
    findutils        # common base utilities (often missing from minimal images)

    make             # build system for compiling Python
    gcc              # C compiler for CPython
    gcc-c++          # required by some build steps / extension builds

    zlib-devel       # headers/libs for zlib module (gzip/zip support)
    libffi-devel     # headers/libs for _ctypes
    openssl-devel    # headers/libs for _ssl and hashlib
    sqlite-devel     # headers/libs for _sqlite3
    bzip2-devel      # headers/libs for bz2 module
    xz-devel         # headers/libs for lzma module
)

"${PKG_INSTALL[@]}" "${deps[@]}"
"${PKG_CLEAN[@]}"

echo "Resolve full Python version"
# Retrieve the latest patch version from python.org for the given major.minor.
# Some directories may exist before the final release is published and only contain rc artifacts,
# so select the newest version that actually has the expected final source tarball.
full_version=""
while IFS= read -r candidate; do
    if curl -fsSI "https://www.python.org/ftp/python/${candidate}/Python-${candidate}.tgz" >/dev/null 2>&1; then
        full_version="$candidate"
        break
    fi
done < <(curl -fsSL "https://www.python.org/ftp/python/" | grep -o ''"${major}"'\.'"${minor}"'\.[0-9]*' | sort --version-sort -r | uniq)

if [ -z "${full_version}" ]; then
    echo "Unable to resolve a Python version for ${major}.${minor} from python.org" >&2
    exit 1
fi

echo "Python version specified: ${python_version}"
echo "Installing version: ${full_version}"

echo "Install Python version"
mkdir -p /azp/tmp
cd /azp/tmp
curl -fsSL -o "Python-${full_version}.tgz" "https://www.python.org/ftp/python/${full_version}/Python-${full_version}.tgz"
tar -zxf "Python-${full_version}.tgz"
cd "Python-${full_version}"
./configure --prefix="/azp/Python-${full_version}" --enable-loadable-sqlite-extensions
make
make install

#Install python venv
export PATH="/azp/Python-${full_version}/bin:${PATH}"

# Creating structure needed for extension usePythonVersion
echo "Create directory"
mkdir -p "${agent_toolsdirectory}/Python/${full_version}/x64"

echo "Create symlink"
ln -sf "${agent_toolsdirectory}/Python/${full_version}" "${agent_toolsdirectory}/Python/${python_version}"

echo "Install library module needed for usePythonVersion"
cd "$agent_toolsdirectory/Python/${full_version}"
python3 -m venv x64 #run library module as a script
touch x64.complete #just an empty file, but needed for some reason

echo "Install Python packages related to package management"
"${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" -m pip install --upgrade pip wheel setuptools twine

echo "Install commonly used Python packages"
"${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" -m pip install --upgrade requests pytest pytest-cov isort flake8 black boto3 awscli mypy pyyaml

echo "Install Python packages requested by AWS team"
"${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" -m pip install --upgrade psycopg psycopg2-binary

echo "Installing pipx"
"${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" -m pip install --upgrade pipx

#adding python to the path environment through start commands will make all executables (including those installed by pip) availble for the agent
echo "Add python to path through start-commands.sh"
PrependToPath "${agent_toolsdirectory}/Python/${full_version}/x64/bin"

#update installed software list (add 2 spaces for new line)
echo "Python ${python_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Python" \
    --category "Runtimes" \
    --version "${python_version}" \
    --artifact "${agent_toolsdirectory}/Python/${full_version}/x64/bin/python3" \
    --generate-hash

echo "Python installation completed successfully"

