#!/bin/bash -e
################################################################################
##  File: ubi-java.sh
##  Desc: Donwload and Install Open Java 8 JDK
################################################################################

ubi_jdk_version="§ubi-open-jdk§"

echo "Installing JDK Version ${ubi_jdk_version}"
pkg_name="java-$ubi_jdk_version-openjdk"
dnf install -y "${pkg_name}-devel"
java_to_select=$(alternatives --display java | grep "family $pkg_name" | cut -d' ' -f1)
alternatives --set java "$java_to_select"

#update installed software list (add 2 spaces for new line)
echo "Open JDK ${ubi_jdk_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Open JDK" \
  --category "Frameworks" \
  --version "${ubi_jdk_version}" \
  --artifact "${java_to_select}" \
  --generate-hash

