#!/bin/bash -e
################################################################################
##  File: ubi-pscore.sh
##  Desc:  Install powershellcore
##  Source: https://docs.microsoft.com/en-us/powershell/scripting/install/install-ubuntu
################################################################################
version="§ubi-powershell§"
package_filename="powershell-${version}-1.rh.x86_64.rpm"

nexus_username=$1
nexus_password=$2
nexus_url=$3
nexus_group="meso/installer-cache"

# Source nexuscloud download/upload process helper functions
source /install/helpers/common-nexus-cloud.sh

full_url="$nexus_url/$nexus_group/github.com/PowerShell/PowerShell/releases/download/v${version}/${package_filename}"
dest_path="/install"
compressed="compressed"
file_path="${dest_path}/${package_filename}"
alt_url="https://github.com/PowerShell/PowerShell/releases/download/v${version}/${package_filename}"

if ! nexus_ops "$full_url" "$file_path" "$compressed" "$nexus_username" "$nexus_password" "$alt_url"; then
    echo "Error: nexus_ops command failed"
    exit 1
fi

# Install PowerShell
echo "Installing Powershell ${version}"
dnf install -y "$file_path"

# cleanup
echo "Cleanup downloaded package"
rm "$file_path"

#note that powershell is already install (otherwise we can't run this command)
#unlike other application we install before checking available versions,
#but since we install a version even if its outdated the order is irrelevant
pwsh -c ". /install/content/helpers/VersionHelper.ps1;Get-GitHubDownloadUrl \
    -RepoOwner 'PowerShell' \
    -RepoName 'PowerShell' \
    -ApplicationName 'Powershell Core/7' \
    -TargetVersion $version \
    -ArtifactRegex 'https:\/\/.*-1\.rh\.x86_64\.rpm'"

#update installed software list (add 2 spaces for new line)
echo -e "$(pwsh --version)  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "PowerShell" \
  --category "Tools" \
  --version "$(pwsh --version)" \
  --artifact "$(command -v pwsh)" \
  --generate-hash
