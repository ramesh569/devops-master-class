#!/bin/bash -e
################################################################################
##  File: ubi-sql-plus.sh
##  Desc: Donwload and Install Oracle Instant Client tools
################################################################################

sqlplus_version=§ubi-sqlplus§
sqltools_version=§ubi-sqltools§
sqlbasic_version=§ubi-sqlbasic§

nexus_username=$1
nexus_password=$2
nexus_url=$3
nexus_group="meso/third-party"

# Source nexuscloud download/upload process helper functions
source /install/helpers/common-nexus-cloud.sh

compressed="."
alt_url="."
dest_path="/install"
install_tools=("basic-${sqlbasic_version}" "sqlplus-${sqlplus_version}" "tools-${sqltools_version}")

# Install all Oracle Instant Client tools fron NexusCloud
for tool in "${install_tools[@]}"; do
    file_name="oracle-instantclient-${tool}-1.el9.x86_64.rpm"
    file_full_url="$nexus_url/$nexus_group/oracle/sql/${file_name}"
    file_path="${dest_path}/${file_name}"
    echo "Downloading ${file_name}"
    if ! nexus_ops "$file_full_url" "$file_path" $compressed "$nexus_username" "$nexus_password" $alt_url; then
        echo "Error: nexus_ops command failed"
        exit 1
    fi

    echo "Installing ${file_name}"
    dnf install -y "$file_path"
    echo "Installation complete"
    tool_name=$(echo "${tool}" | cut -d'-' -f1)
    tool_version=$(echo "${tool}" | grep -oP '(\d+\.\d+\.\d+\.\d+\.\d+)')
    if [[ "${tool_name}" == "tools" ]]; then
        tools_executable=$(rpm -qlp "$file_path" | grep -E '/bin/(expdp|impdp|sqlldr)$' | head -n 1)
        if [[ -z "${tools_executable}" ]]; then
            echo "Error: Oracle Instant Client tools directory not found in ${file_name}"
            exit 1
        fi
        tools_bin_directory=$(dirname "${tools_executable}")
        export PATH="${tools_bin_directory}:${PATH}"
        echo "export PATH=${tools_bin_directory}:\${PATH}" >> /usr/local/start-commands.sh
    fi
    echo "Oracle Instant Client ${tool_name} ${tool_version}" >> /install/InstalledSoftware.txt
    hash_options=()
    environment_options=()
    if [[ "${tool_name}" == "tools" ]]; then
        environment_options=(--environment-variables "PATH=${tools_bin_directory}:\${PATH}")
    fi
    if [[ "${tool_name}" == "sqlplus" ]]; then
        hash_options=(--artifact "$(command -v sqlplus)" --generate-hash)
    fi
    mot docs applications add \
        --name "${tool_name}" \
        --category "Oracle Instant Client" \
        --version "${tool_version}" \
        "${hash_options[@]}" \
        "${environment_options[@]}"
done
