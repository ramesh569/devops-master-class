#!/bin/bash -e
################################################################################
##  File: ubi-azure-cli.sh
##  Desc:  Install Azure CLI (az)
##  Notes: Script based on https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt)
################################################################################
version=§azure-cli§

# Import the Microsoft repository key
rpm --import https://packages.microsoft.com/keys/microsoft.asc

dnf install -y https://packages.microsoft.com/config/rhel/9.0/packages-microsoft-prod.rpm

echo "Installing ${version}"
dnf install -y azure-cli-$version-1.el9.x86_64

#display installed version
echo "az version"
az version --output table

#update installed software list (add 2 spaces for new line)
echo "Azure CLI ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Azure CLI" \
  --category "Tools" \
  --version "${version}" \
  --artifact "$(command -v az)" \
  --generate-hash
