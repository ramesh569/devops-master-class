#!/bin/bash -e
################################################################################
##  File:  pscore.sh
##  Desc:  Installs PowerShell Core
##  Source: https://github.com/PowerShell/PowerShell/releases
################################################################################
powershell_version=$(mot asset version --tool-id "powershell")
powershell_major_version=${powershell_version%%.*}

echo "# Starting install of powershell $powershell_version"

mot asset download \
  --tool-id "powershell" \
  --source "github.com/PowerShell/PowerShell/releases/download/v§version§/powershell-§version§-linux-x64.tar.gz" \
  --destination "./powershell.tar.gz"

install_directory="/opt/microsoft/powershell/$powershell_major_version"
mkdir -p "$install_directory"
tar -xzf "./powershell.tar.gz" -C "$install_directory"
chmod +x "$install_directory/pwsh"
ln -sf "$install_directory/pwsh" /usr/bin/pwsh

rm "./powershell.tar.gz"

echo "# Testing powershell $powershell_version"
pwsh --version

#update installed software list (add 2 spaces for new line)
echo -e "$(pwsh --version)  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "PowerShell" \
  --category "Tools" \
  --version "$(pwsh --version)" \
  --artifact "/usr/bin/pwsh" \
  --generate-hash
