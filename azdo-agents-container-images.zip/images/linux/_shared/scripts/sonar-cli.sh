#!/bin/bash -e
################################################################################
##  File:  sonar-cli.sh
##  Desc:  Installs Sonar Scanner CLI
################################################################################
target_version=§sonar-scanner-cli§
install_directory="/opt/sonar-scanner"

echo "Installing Sonar Scanner CLI $target_version"

mkdir "$install_directory";
cd "$install_directory";

mot asset download \
  --tool-id "sonar-scanner-cli" \
  --source "binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-§version§-linux-x64.zip" \
  --destination "sonar-scanner-cli.zip"

unzip sonar-scanner-cli.zip
rm sonar-scanner-cli.zip
chmod +x sonar-scanner-$target_version-linux-x64/bin/sonar-scanner;

ln -s -f /opt/sonar-scanner/sonar-scanner-$target_version-linux-x64/bin/sonar-scanner /usr/local/bin/sonar-scanner;

#update installed software list (add 2 spaces for new line)
echo "Sonar CLI ${target_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Sonar Scanner CLI" \
  --category "Tools" \
  --version "${target_version}" \
  --artifact "/usr/local/bin/sonar-scanner" \
  --generate-hash