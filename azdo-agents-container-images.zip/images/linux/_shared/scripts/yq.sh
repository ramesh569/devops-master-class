#!/bin/bash -e
################################################################################
##  File:  yq.sh
##  Desc:  Installs yq, a YAML processor, for manipulating YAML files in scripts.
##  Package source: https://mikefarah.gitbook.io/yq/
################################################################################

mot asset download \
  --tool-id "yq" \
  --source "github.com/mikefarah/yq/releases/download/v§version§/yq_linux_amd64" \
  --destination "/usr/bin/yq"

chmod +x "/usr/bin/yq"

version=$(yq --version | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+')
echo "Installed yq ${version}"
echo "yq ${version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "YQ" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/bin/yq" \
  --generate-hash