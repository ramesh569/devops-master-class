#!/bin/bash -e
################################################################################
##  File:  pact-cli.sh
##  Desc:  Installs Pact CLI (contract testing tool)
################################################################################

# Source the helpers for use with the script
source /install/helpers/install.sh

pact_cli_version=§pact-standalone§

echo "Installed pact cli $pact_cli_version"

mot asset download \
  --tool-id "pact-standalone" \
  --source "github.com/pact-foundation/pact-standalone/releases/download/v§version§/pact-§version§-linux-x86_64.tar.gz" \
  --destination "pact-cli.zip"

install_directory="/usr/local/bin/pact-cli"

mkdir -p $install_directory

tar -xf "pact-cli.zip" --directory $install_directory

rm -f "pact-cli.zip"

AddToPath "${install_directory}/pact/bin"

echo "Installed Pact-cli v$pact_cli_version"
echo "Pact-Cli v$pact_cli_version  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Pact CLI" \
  --category "Tools" \
  --version "${pact_cli_version}"
