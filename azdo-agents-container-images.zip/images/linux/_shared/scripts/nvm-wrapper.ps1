<#
.SYNOPSIS
    Create a wrapper to call nvm from powershell
.DESCRIPTION
    Create a nvm command to be run from powershell which calls nvm in a bash script and passes the arguments
#>
function nvm {
    $quotedArgs = ($args | ForEach-Object { "'$_'" }) -join ' '
    $command = 'source $NVM_DIR/nvm.sh && nvm {0}' -f $quotedArgs
    bash -c $command
}