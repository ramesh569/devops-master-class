#!/bin/bash -e
################################################################################
##  File:  aws-cdk.sh
##  Desc:  Installs AWS CDK, downloads the latest release, extracts the binary, and verifies installation.
##  Notes: Installation instructions found at
##         https://docs.aws.amazon.com/cdk/v2/guide/getting-started.html
##         https://github.com/aws/aws-cdk/tree/main?tab=readme-ov-file
################################################################################
source /install/helpers/helper-functions.sh

#alow nodejs to be used
initialize_nodejs

echo "Installing npm package aws-cdk"
#install aws-cdk using npm
npm install -g aws-cdk

# display installed verison
echo "Checking version"
version=$(cdk --version)
echo "The installed version is: $version"
if [[ -z "$version" ]]; then
  echo "Failed to run cdk --version"
  exit 1
fi

# extract version number from output
# output example: OpenBao v2.3.2 (b1a68f558c89d18d38fbb8675bb6fc1d90b71e98), built 2025-08-08T04:05:45Z
# selected output 0.2.10
version=$(echo "$version" | grep -oP '\d+\.\d+\.\d+')
if [[ -z "$version" ]]; then
  echo "Failed to extract AWS CDK version"
  exit 1
fi

# document installation
echo "document installation"
echo "AWS CDK ${version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "AWS CDK" \
  --category "Tools" \
  --version "${version}" \
  --artifact "$(command -v cdk)" \
  --generate-hash