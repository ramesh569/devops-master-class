#!/bin/bash -e
################################################################################
##  File:  pulumi.sh
##  Desc:  Installs Pulumi CLI
################################################################################
target_version=§pulumi§

echo "Installing Pulumi CLI $target_version"
archive_path="pulumi.tar.gz"

# download pulumi
mot asset download \
  --tool-id "pulumi" \
  --source "github.com/pulumi/pulumi/releases/download/v${target_version}/pulumi-v${target_version}-linux-x64.tar.gz" \
  --destination $archive_path

echo "Unzipping Pulumi CLI"
tar --strip=1 -xf "$archive_path" -C /usr/local/bin

echo "Reading contents of /usr/local/bin to confirm Pulumi CLI is present"
ls -l /usr/local/bin

# grab version
echo "Getting Pulumi CLI version"
installed_version=$(pulumi version | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+')
echo "Installed Pulumi CLI version: $installed_version"

# update installed software list (add 2 spaces for new line)
echo "Adding pulumi to installation docs"
echo "Pulumi CLI ${installed_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Pulumi" \
  --category "Tools" \
  --version "${installed_version}" \
  --artifact "/usr/local/bin/pulumi" \
  --generate-hash