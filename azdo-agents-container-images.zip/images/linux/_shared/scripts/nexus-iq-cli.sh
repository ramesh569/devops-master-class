#!/bin/bash -e
################################################################################
##  File:  nexus-iq-cli.sh
##  Desc:  Installs Nexus IQ CLI
################################################################################
source /install/helpers/helper-functions.sh
source /install/helpers/install.sh

version=§nexus-iq§
target_version=$(echo "$version" | sed -E 's/^([0-9]+\.[0-9]+\.[0-9]+).*/\1/')
install_directory="/azp/nexus-iq-cli"

#determine the latest version
pwsh -c ". /install/content/helpers/VersionHelper.ps1;Get-NexusPackagesVersion \
     -ApplicationName 'Nexus IQ CLI' \
     -url 'https://nexus3.rabobank.nl/repository/rabo_thirdparty/com/sonatype/nexusiq-cli/maven-metadata.xml' \
     -TargetVersion $target_version"

download_url="https://download.sonatype.com/clm/scanner/nexus-iq-cli-${version}-linux-x86_64.tgz"

echo "Downloading Nexus IQ CLI version $version from $download_url"
curl -SL "$download_url" -o /tmp/nexus-iq-cli.tgz
mkdir -p "$install_directory"
tar -xvzf /tmp/nexus-iq-cli.tgz -C "$install_directory"

# Cleanup downloaded file
rm /tmp/nexus-iq-cli.tgz

# Find the extracted directory and run the CLI
extracted_dir=$(find "$install_directory" -maxdepth 1 -type d -name "nexus-iq-cli-*" | head -n 1)
"$extracted_dir/bin/nexus-iq-cli" --version

AddToPath "$extracted_dir"
AddToPath "$extracted_dir/bin"

## Check if it works and extract version
cli_version_output=$("$extracted_dir/bin/nexus-iq-cli" --version 2>&1)
echo "$cli_version_output"

# Extract version string like '2.6.0-01' from output
extracted_version=$(echo "$cli_version_output" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+-[0-9]+')
echo "Extracted Nexus IQ CLI version: $extracted_version"

#update installed software list (add 2 spaces for new line)
echo "Nexus IQ CLI ${extracted_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Nexus IQ CLI" \
  --category "Tools" \
  --version "${version}" \
  --artifact "$extracted_dir/bin/nexus-iq-cli" \
  --generate-hash

# Create a temporary directory for Nexus IQ CLI operations
mkdir -p /tmp/nexus-iq
chmod 777 /tmp/nexus-iq