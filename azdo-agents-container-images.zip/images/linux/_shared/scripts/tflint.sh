#!/bin/bash -e
################################################################################
##  File:  tflint.sh
##  Desc:  Installs TFLint (Terraform linter)
################################################################################
version="§tflint§"

echo "Installing TFLint $version"

mot asset download \
  --tool-id "tflint" \
  --source "github.com/terraform-linters/tflint/releases/download/v§version§/tflint_linux_amd64.zip" \
  --destination "tflint_linux_amd64.zip"

#unzip the file and provide execute rights
unzip tflint_linux_amd64.zip -d /usr/local/bin
rm tflint_linux_amd64.zip
chmod +x /usr/local/bin/tflint

echo "The installed version is $(tflint --version)"
echo "TFLint ${version}" >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "TFLint" \
  --category "Tools" \
  --version "${version}" \
  --artifact "/usr/local/bin/tflint" \
  --generate-hash