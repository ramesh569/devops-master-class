#!/bin/bash -e 
################################################################################
##  File:  import-certificates-chrome.sh
##  Desc:  Imports all certificates into the Chrome certificate store
################################################################################

nss_db_dir="/home/AzDevOps/.pki/nssdb"
cert_source_dir="/usr/local/share/ca-certificates"
trust_flags="CT,c,c"   

echo "Resetting NSS database at $nss_db_dir..."
rm -rf "$nss_db_dir"
mkdir -p "$nss_db_dir"

# 3. Initialize the new database (SQLite format)
# Using empty password for convenience; remove '--empty-password' for a prompt
certutil -N -d "sql:$nss_db_dir" --empty-password

# 4. Import all certificates from /usr/local/share/ca-certificates
echo "Importing certificates..."
find "$cert_source_dir" -type f -name "*.crt" | while read -r cert; do
    # Get a friendly name from the filename
    nickname=$(basename "$cert" .crt)
    
    echo "Adding: $nickname"
    # -A: Add, -n: Nickname, -i: Input file, -t: Trust arguments (C=CA)
    certutil -A -d "sql:$nss_db_dir" -t "$trust_flags" -n "$nickname" -i "$cert"
done

echo "Listing certs:";
certutil -L -d sql:$nss_db_dir

# Changing owner
chown AzDevOps -R $nss_db_dir