#!/bin/bash
set -e # Exit immediately if a command exits with a non-zero status.
################################################################################
##  Desc: Install sqlfluff-templater-dbt
################################################################################

source /install/helpers/python-functions.sh

python_install_package "psycopg"
python_install_package "psycopg2-binary"