#!/bin/bash -e
################################################################################
##  File:  firefox-driver.sh
##  Desc:  Installs Firefox and Mozilla GeckoDriver on Linux
################################################################################

# Source helper to persist environment variables
source /install/helpers/etc-environment.sh

echo "Installing Firefox browser and GeckoDriver..."

# Add Mozilla APT repository and signing key
curl -fsSL https://packages.mozilla.org/apt/repo-signing-key.gpg | gpg --dearmor -o /usr/share/keyrings/packages.mozilla.org.gpg
echo "deb [signed-by=/usr/share/keyrings/packages.mozilla.org.gpg] https://packages.mozilla.org/apt mozilla main" >/etc/apt/sources.list.d/mozilla-firefox.list

# Pin Mozilla repo to prefer Firefox packages from it
cat >/etc/apt/preferences.d/mozilla <<'EOF'
Package: *
Pin: origin packages.mozilla.org
Pin-Priority: 100

Package: firefox*
Pin: origin packages.mozilla.org
Pin-Priority: 1000
EOF

# Install Firefox
apt-get update -y
apt-get install -y firefox
set_etc_environment_variable "FIREFOX_BIN" "/usr/bin/firefox"

echo "Firefox installed: $(/usr/bin/firefox --version)"

echo "Fetching latest GeckoDriver release from GitHub..."
# Query releases API and extract tag_name without leading 'v'
gecko_version=$(curl -fsSL https://api.github.com/repos/mozilla/geckodriver/releases/latest | jq -r '.tag_name' | sed 's/^v//')

if [[ -z "${gecko_version}" || "${gecko_version}" == "null" ]]; then
	echo "ERROR: Unable to determine GeckoDriver version." >&2
	exit 1
fi

echo "Using GeckoDriver version: ${gecko_version}"

# Construct download URL for linux64 tarball
base_url="https://github.com/mozilla/geckodriver/releases/download/v${gecko_version}"
tarball="geckodriver-v${gecko_version}-linux64.tar.gz"
download_url="${base_url}/${tarball}"

# Use a temporary directory for geckodriver
workdir=$(mktemp -d)
pushd "${workdir}"

# Download and extract geckodriver
curl -fsSL "${download_url}" -o "${tarball}"
tar -xzf "${tarball}"

# Install binary to /usr/local/bin
install -m 0755 geckodriver /usr/local/bin/geckodriver
set_etc_environment_variable "GECKOWEBDRIVER" "/usr/local/bin/geckodriver"

popd
rm -rf "${workdir}"

# Fail if not installed
if ! command -v /usr/bin/firefox >/dev/null 2>&1; then
  echo "ERROR: Firefox installation failed." >&2
  exit 1
fi

if ! /usr/local/bin/geckodriver --version >/dev/null 2>&1; then
  echo "ERROR: GeckoDriver installation verification failed." >&2
  exit 1
fi

# Print installation verification
echo "Verification:"
echo " - $(/usr/bin/firefox --version 2>/dev/null)"
echo " - $(/usr/local/bin/geckodriver --version 2>/dev/null)"

# Record installed software
echo "Storing Firefox driver information"
firefox_out=$(/usr/bin/firefox --version)
echo "Extracing version from output: ${firefox_out}"
firefox_version=$(echo "${firefox_out}" | grep -oP '([\.\d+]+)')
echo "Firefox version: ${firefox_version}"
echo "Firefox ${firefox_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Firefox" \
  --category "Browsers" \
  --version "${firefox_version}" \
  --artifact "/usr/bin/firefox" \
  --generate-hash

echo "Storing Gecko driver information"
gecko_out=$(/usr/local/bin/geckodriver --version)
echo "Extracting version from output: ${gecko_out}"
gecko_version=$(echo "${gecko_out}" | grep -oP '(?<=geckodriver\s)([\.\d+]+)')
echo "Gecko Driver version: ${gecko_version}"
echo "Gecko Driver ${gecko_version}  " >> /install/InstalledSoftware.txt
mot docs applications add \
  --name "Gecko Driver" \
  --category "Browsers" \
  --version "${gecko_version}" \
  --artifact "/usr/local/bin/geckodriver" \
  --generate-hash

echo "Firefox and GeckoDriver installation complete."

