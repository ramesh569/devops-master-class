#!/bin/bash
# set -e # Exit immediately if a command exits with a non-zero status.
################################################################################
##  Desc: This script is used to check whether the software package already
##        exists in Nexus Cloud or not. If not, download from alternative source
################################################################################

# recursive function, which checks whether package exists in nexus - if not, download from alternative url (source)
# in case if does not exist - upload to nexus cloud and use the package which has already been downloaded

nexus_ops() {
# Due to restrictions of bash functions, positional arguments are used here.
# In case if you using latest argument NAME, you should also set value to all previous parameters.
# Example: download_with_retries $ANDROID_SDK_URL "." "android_sdk.zip"
    local url=$1
    local file_path=$2
    local compressed=$3
    local name=$4
    local pass=$5
    local alturl=$6
    local extra_param=$7

    if [[ -z ${name+x} ]]; then
        local auth_param=""
    else
        local auth_param="-u ${name}:${pass}"
    fi

    if ! download_from_url "${url}" "${file_path}" "${compressed}" "${auth_param}" "${extra_param}"
    then
        echo "##vso[task.logissue type=warning]Failed to download package from primary URL '${url}'"
        if download_from_url "${alturl}" "${file_path}" "${compressed}" "" "${extra_param}"
        then
            if upload_to_url "$url" "$file_path" "$auth_param"
            then
                echo "Upload successful"
                return 0
            else
                echo "##vso[task.logissue type=warning]Failed to upload to '${url}'"
                return 0
            fi
        else
            echo "##vso[task.logissue type=error]Download of packages failed. Upload not initialised."
            return 1
        fi
    fi
}

download_from_url() {
    local url=$1
    local file_path=$2
    local compressed=$3
    local auth_param=$4
    local extra_param=$5

    if [[ $compressed == "compressed" ]]; then
        local command="curl --silent $auth_param '$url' -sL --compressed -o '$file_path' -w '%{http_code}' $extra_param"
    else
        local command="curl --silent $auth_param '$url' -sL -o '$file_path' -w '%{http_code}' $extra_param"
    fi

    echo "${command}"

    echo "Downloading '$url' to '$file_path'"
    local retries=5
    local interval=5
    while [ $retries -gt 0 ]; do
        ((retries--))

        set +e
        # some packages take more than >10 seconds to download
        http_code=$(eval "$command")
        exit_code=$?
        if [ "$http_code" -eq 200 ] && [ $exit_code -eq 0 ]; then
            echo "Download completed"
            return 0
        else
            echo "Error — Either HTTP response code for '$url' is wrong - '$http_code' or exit code '$exit_code'. Waiting $interval seconds before the next attempt, $retries attempts left"
            sleep $interval
        fi
    done
    return 1
}

upload_to_url() {
    local url=$1
    local file_path=$2
    local auth_param=$3

    echo "Uploading '$file_path' to '$url' for future use"
    # Switching to SCP should boost upload performance
    if ! curl -v "${auth_param}" --upload-file "$file_path" "$url"
    then
        return 1
    fi
    return 0
}
