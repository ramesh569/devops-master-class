#!/bin/bash -e
################################################################################
##  File:  install.sh
##  Desc:  Helper functions for installing tools
##  Note:  This script is a subset of runner-images\images\linux\scripts\helpers\install.sh
################################################################################

download_with_retries() {
    # Due to restrictions of bash functions, positional arguments are used here.
    # In case if you using latest argument NAME, you should also set value to all previous parameters.
    # Example: download_with_retries $ANDROID_SDK_URL "." "android_sdk.zip"
    local url="$1"
    local dest="${2:-.}"
    local name="${3:-${url##*/}}"
    local compressed="$4"

    if [[ $compressed == "compressed" ]]; then
        local command="curl $url -4 -sL --compressed -o '$dest/$name' -w '%{http_code}'"
    else
        local command="curl $url -4 -sL -o '$dest/$name' -w '%{http_code}'"
    fi

    echo "Downloading '$url' to '${dest}/${name}'..."
    retries=20
    interval=30
    while [ $retries -gt 0 ]; do
        ((retries--))
        # Temporary disable exit on error to retry on non-zero exit code
        set +e
        http_code=$(eval "$command")
        exit_code=$?
        if [ "$http_code" -eq 200 ] && [ "$exit_code" -eq 0 ]; then
            echo "Download completed"
            return 0
        else
            echo "Error — Either HTTP response code for '$url' is wrong - '$http_code' or exit code is not 0 - '$exit_code'. Waiting $interval seconds before the next attempt, $retries attempts left"
            sleep 30
        fi
        # Enable exit on error back
        set -e
    done

    echo "Could not download $url"
    return 1
}

download_with_retry() {
    local url="$1"
    local download_path="$2"

    if [ -z "$download_path" ]; then
        download_path="/tmp/$(basename "$url")"
    fi

    echo "Downloading package from $url to $download_path..." >&2

    interval=30
    download_start_time=$(date +%s)

    for ((retries=20; retries>0; retries--)); do
        attempt_start_time=$(date +%s)
        if http_code=$(curl -4sSLo "$download_path" "$url" -w '%{http_code}'); then
            attempt_seconds=$(($(date +%s) - attempt_start_time))
            if [ "$http_code" -eq 200 ]; then
                echo "Package downloaded in $attempt_seconds seconds" >&2
                break
            else
                echo "Received HTTP status code $http_code after $attempt_seconds seconds" >&2
            fi
        else
            attempt_seconds=$(($(date +%s) - attempt_start_time))
            echo "Package download failed in $attempt_seconds seconds" >&2
        fi

        if [ "$retries" -le 1 ]; then
            total_seconds=$(($(date +%s) - download_start_time))
            echo "Package download failed after $total_seconds seconds" >&2
            exit 1
        fi

        echo "Waiting $interval seconds before retrying (retries left: $retries)..." >&2
        sleep $interval
    done

    echo "$download_path"
}

## Use dpkg to figure out if a package has already been installed
## Example use:
## if ! IsPackageInstalled packageName; then
##     echo "packageName is not installed!"
## fi
IsPackageInstalled() {
    dpkg -S "$1" &> /dev/null
}

verlte() {
    sorted_version=$(echo -e "$1\n$2" | sort -V | head -n1)
    [  "$1" = "$sorted_version" ]
}

# This function replaces a piece of the PATH variable OR replaces the value of an existing variable in the start-command.sh file
# Useful for when you're installing multiple versions of the same software and they all modify the same exported variable
ReplaceExportVariable() {
  local new_item=$1
  local old_item=$2
  local export_variable=$3
  local start_file="/usr/local/start-commands.sh"

  if grep -Fq "export $export_variable" $start_file
    then
      #get existing path variable from file and replace the old value with the new
    local existing_value
    existing_value=$(grep "export $export_variable" "$start_file")
    local new_value
    new_value=$(echo "$existing_value" | sed -r "s/${old_item}/${new_item}/g")

      #delete the old Path from the file
    sed -i "/export $export_variable=/d" "$start_file"

      #re-add the path to the file
    echo "$new_value" >> "$start_file"
    else
      if [ "$export_variable" == "PATH" ];
      then
    echo "export $export_variable=$PATH:$new_item" >> "$start_file"
      else
    echo "export $export_variable=$new_item" >> "$start_file"
      fi
    fi
}

# This function appends to the PATH variable. It updates the start-commands.sh file accordingly
AddToPath() {
  add_to_path_internal "$1" false
}

# This function prepends to the PATH variable. It updates the start-commands.sh file accordingly
PrependToPath() {
  add_to_path_internal "$1" true
}

# This function appends or prepends to the PATH variable. It updates the start-commands.sh file accordingly
add_to_path_internal() {
  local path_to_add=$1
  local prepend=$2
  local start_file="/usr/local/start-commands.sh"
  local current_path='' #will be set based on start-commands file or current PATH environment variable
  local updated_path='' #will be set with the updated PATH (appended or prepended) with new value

  #if path export is defined in file
  if grep -Fq "export PATH" $start_file; then
    echo 'PATH is already defined in start file. Update export command'
    #store existing path
    current_path=$(grep 'export PATH' "$start_file" | sed 's/export PATH=//')

    #remove existing path export from file
    sed -i '/export PATH=/d' "$start_file"
  else
    #if no path is defined in file use current PATH
    echo 'PATH is not defined in start file. Create export command'
    current_path=$PATH
  fi

  #add new path export to file
  if [ "$prepend" = true ]; then
    echo "Prepending '$path_to_add' to PATH"
    updated_path="$path_to_add:$current_path"
  else
    echo "Appending '$path_to_add' to PATH"
    updated_path="$current_path:$path_to_add"
  fi

  #display final updated value
  echo "export PATH=$updated_path"

  #store value in start-command file
  echo "export PATH=$updated_path" >> "$start_file"
}
