#!/bin/bash -e
################################################################################
##  File:  helper-functions.sh
##  Desc:  Helper functions for Linux
################################################################################

###################
## Common Variables
###################

# NVM Directory
# Note: should match value in GenerateNodeJsDocs.ps1 script
# Used by:
# - nodejs.sh
# - aws-cdk.sh
export NVM_DIR="/etc/skel/.nvm"

###################
## Common Functions
###################

# check the latest version using dkpg
verify_latest_version() {
   latestversion=$1
   targetversion=$2
   name=$3

    if dpkg --compare-versions "$targetversion" lt "$latestversion"; then
       #%0D%0A is carriage return;new line using the bash native \n results in only the first line being displayed in the warning on the AzureDevOps pipeline run page
       echo -e "##vso[task.logissue type=warning]Newer version of $name is available.%0D%0A\tInstalled Version: $targetversion %0D%0A\tAvailable Version: $latestversion"
       echo "##vso[task.complete result=SucceededWithIssues;]"
       return 0
    else
       echo "You are already using latest version of $name"
    fi
}

# download zip, extract it, then link target executable to /usr/local/bin and grant execution access
install-zip-archive() {
   local download_url=$1
   local install_directory=$2
   local executable=$3

   # check if parameters are passed
   if [ -z "$download_url" ] || [ -z "$install_directory" ] || [ -z "$executable" ]; then
      echo "error: Missing parameters calling install-zip-archive"
      return 1
   fi

   local downloaded_archive_name="temp.zip"

   echo "download $download_url to $downloaded_archive_name"
   curl -sL "$download_url" -o "$downloaded_archive_name"

   if [ ! -f "$downloaded_archive_name" ]; then
      echo "error: Failed to download: $download_url"
      return 1
   fi

   # if install_directory does not exist create it
   if [ ! -d "$install_directory" ]; then
      echo "creating $install_directory"
      mkdir -p "$install_directory"
   fi

   echo "unzip $downloaded_archive_name to $install_directory"
   unzip -o "$downloaded_archive_name" -d "$install_directory"

   if [ ! -d "$install_directory" ]; then
      echo "error: Failed to unzip: $downloaded_archive_name"
      return 1
   fi

   echo "listing archive content"
   ls -l "$install_directory"

   if [ ! -f "$install_directory/${executable}" ]; then
      echo "error: ${executable} not found in $install_directory"
      return 1
   fi

   echo "grant execute access"
   chmod +x "$install_directory/${executable}"

   # get the basename (filename) of the executable
   # sometimes we pass /bin/executable and other times we pass just executable
   executable_basename="${executable##*/}"

   # determine symbolic link name
   # the executable (basename) sometimes has an extension, drop the extension in the symbolic link name
   # shellcheck disable=SC2034 # SC2034: Variable extension is assigned but not used
   # but if we do not assign it the previous variable will contain both values
   # due to how the read command interprets
   IFS=. read -r symbolic_link_name extension <<< "$executable_basename"

   # create symbolic link for executable
   if [ -f "/usr/local/bin/${symbolic_link_name}" ]; then
      echo "warning: /usr/local/bin/${symbolic_link_name} already exists. will be overwritten"
   fi
   echo "creating symbolic link /usr/local/bin/${symbolic_link_name} -> $install_directory/${executable}"
   ln -s -f "$install_directory/${executable}" "/usr/local/bin/${symbolic_link_name}"

   # cleanup archive file
   echo "cleanup temporary files"
   rm -rf "$downloaded_archive_name"
}

# initialize NodeJS to be used during installation scripts
initialize_nodejs() {
   # because we install NodeJS through NVM we need to initialize NVM before using NPM or NodeJS
   # in the image this initializion script is added to /usr/local/start-commands.sh
   # but that script hasn't run in the current context of installing tools so we need to call nvm.sh directly here
   echo "Initialize NodeJS by executing nvm.sh" #required to run nvm commands in current script context
   if [ -s "$NVM_DIR/nvm.sh" ]; then
      \. "$NVM_DIR/nvm.sh"
   else
      echo "nvm.sh not found at $NVM_DIR, validate the NodeJS install script has ran"
   fi

   #this installer requires NodeJS/NPM to be installed first.
   if ! command -v npm &> /dev/null
   then
      echo "NPM could not be found, verify if the NodeJS Installation succeded"
      exit 1
   fi
}
