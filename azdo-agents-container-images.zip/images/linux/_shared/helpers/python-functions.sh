#!/bin/bash
AGENT_TOOLSDIRECTORY=/azp/_work/_tool
################################################################################
##  File:  python-functions.sh
##  Desc:  Helper functions for Python
################################################################################
source /install/helpers/helper-functions.sh
version_file_path="/install/versions.xml"

# Run `pip check` and attempt to resolve common issues by installing/upgrading
# the dependencies that `pip check` reports as missing or out-of-range.
python_pip_check_and_resolve() {
    python_command=$1
    python_version_label=$2
    max_attempts=${3:-3}
    root_package_name=$4

    attempt=1
    while (( attempt <= max_attempts )); do
        echo "Running pip check for ${python_version_label} (attempt ${attempt}/${max_attempts})"

        pip_output=$("$python_command" -m pip check 2>&1)
        pip_check_exit_code=$?

        if [ ${pip_check_exit_code} -eq 0 ]; then
            echo "pip check passed for ${python_version_label}"
            return 0
        fi

        echo "pip check failed for ${python_version_label} with exit code ${pip_check_exit_code}"
        if [ -n "$pip_output" ]; then
            echo "$pip_output"
        fi

        requirements_to_fix=()
        while IFS= read -r line; do
            # Example:
            #   black 26.3.1 has requirement pathspec>=1.0.0, but you have pathspec 0.12.1.
            #   readme-renderer 44.0 has requirement docutils>=0.21.2, but you have docutils 0.19.
            # Also seen:
            #   somepkg 1.0.0 requires otherpkg<2,>=1, but you have otherpkg 0.9.
            #   somepkg 1.0.0 requires missingpkg, which is not installed.
            if [[ "$line" =~ has\ requirement\ (.+),\ but\ you\ have\ .*\.?$ ]]; then
                requirements_to_fix+=("${BASH_REMATCH[1]}")
            elif [[ "$line" =~ requires\ (.+),\ but\ you\ have\ .*\.?$ ]]; then
                requirements_to_fix+=("${BASH_REMATCH[1]}")
            elif [[ "$line" =~ requires\ (.+),\ which\ is\ not\ installed\.?$ ]]; then
                requirements_to_fix+=("${BASH_REMATCH[1]}")
            fi
        done <<< "$pip_output"

        if [ ${#requirements_to_fix[@]} -eq 0 ]; then
            echo "pip check failed for ${python_version_label}, but no actionable requirements were parsed."
            echo "##vso[task.logissue type=warning;]${python_version_label} pip check failed with unparsed output. Please investigate."
            return 1
        fi

        echo "Attempting to resolve pip check issues for ${python_version_label}"
        # As part of resolution, also try upgrading the originally installed package to latest.
        # This intentionally relaxes the pinned version from versions.xml when conflicts arise.
        echo "Upgrading root package to latest: ${root_package_name}"
        if ! "$python_command" -m pip install --upgrade "$root_package_name"; then
            echo "##vso[task.logissue type=warning;]Failed to upgrade ${root_package_name} for ${python_version_label}. Continuing resolution attempts."
        fi

        while IFS= read -r requirement_spec; do
            if [ -z "$requirement_spec" ]; then
                continue
            fi
            echo "Upgrading/installing requirement: ${requirement_spec}"
            if ! "$python_command" -m pip install --upgrade "$requirement_spec"; then
                echo "Failed to install/upgrade requirement: ${requirement_spec} for ${python_version_label}. Continuing resolution attempts."
            fi
        done < <(printf '%s\n' "${requirements_to_fix[@]}" | sort -u)

        attempt=$((attempt + 1))
    done

    echo "pip check still failing for ${python_version_label} after ${max_attempts} attempts"
    echo "##vso[task.logissue type=warning;]${python_version_label} has unresolved pip dependencies after ${max_attempts} attempts. Please investigate."
    return 1
}

## Install a Python Package for all installed python versions
python_install_package() {
    package_name=$1
    echo "Installing ${package_name} for all installed python instances"

    #check if versions file is available
    if [ ! -f "$version_file_path" ]; then
        echo "Versions file not found: $version_file_path"
        return 1
    fi

    #check if xmlstarlet is available
    if ! command -v xmlstarlet &> /dev/null; then
        echo "xmlstarlet could not be found"
        return 1
    fi

    mapfile -t installed_python_versions < <(find "$AGENT_TOOLSDIRECTORY/Python" -mindepth 1 -maxdepth 1 -type d -printf '%f\n')
    for full_version in "${installed_python_versions[@]}"; do
        echo "Found Python ${full_version}"
        python_command="$AGENT_TOOLSDIRECTORY/Python/${full_version}/x64/bin/python3"

        IFS=. read -r python_major python_minor _ <<< "$full_version"
        echo "Determine ${package_name} version to install for Python ${python_major}.${python_minor}"

        #determine tool identifier
        echo "Determine python identifier"
        python_identifier=$(xmlstarlet sel -t -v "/tools//tool[@name='Python' and @version='${python_major}.${python_minor}']//@identifier" "$version_file_path")
        echo "Python_identifier is ${python_identifier}"

        #determine package identifier
        package_identifier="${python_identifier}.${package_name}"
        echo "Looking for tool in ${version_file_path} with identifier: ${package_identifier}"
        match_count=$(xmlstarlet sel -t -v "count(/tools//tool[@identifier='${package_identifier}']/@version)" "$version_file_path")
        echo "Found ${match_count} matching entries for ${package_identifier} in ${version_file_path}"
        if (( ${match_count%.*} > 1 )); then
            echo "Warning: multiple tool versions found for ${package_identifier} in ${version_file_path} (${match_count}). Using the first."
        fi

        echo "Extracting version for ${package_identifier} from ${version_file_path}"
        tool_version=$(xmlstarlet sel -t -v "(/tools//tool[@identifier='${package_identifier}']/@version)[1]" "$version_file_path")
        echo "Received version '${tool_version}' for ${package_identifier}"

        #test if version was found
        if [ -z "$tool_version" ]
        then
            echo "Version not specified in ${version_file_path} for identifier: ${package_identifier}"
            exit 1
        fi

        #install tool
        echo "Installing ${package_name} ${tool_version} for Python ${full_version}"

        # if tool version is 'latest', determine the latest version from pypi
        if [[ "$tool_version" == "latest" ]]; then
            if ! "$python_command" -m pip install "${package_name}"; then
                return 1
            fi
        else
            if ! "$python_command" -m pip install "${package_name}==${tool_version}"; then
                return 1
            fi
        fi

        echo "Installed ${package_name} for ${full_version}"

        # verify pip check and resolve issues
        if ! python_pip_check_and_resolve "$python_command" "$full_version" 3 "$package_name"; then
            echo "Failed to resolve pip dependency issues for ${full_version}"
        fi

    done
    echo "Installed ${package_name} for all python instances"
}

## Create symlink for different python installtions
python_create_package_symboliclink() {
    major_minor_version=$1
    source_path=$2
    target_path=$3

    #determine default/system python version
    python_path=$(find $AGENT_TOOLSDIRECTORY/Python -mindepth 1 -maxdepth 1 -name "${major_minor_version}*" -type d)

    echo "Creating Symbolic Link '${python_path}${source_path}' -> '${target_path}'"
    ln -sf "${python_path}${source_path}" "$target_path"
}

## Document installed Python packages in MOT
python_document_installation() {
    local full_version version_major version_minor packages package package_name package_version
    if [[ ! -d "$AGENT_TOOLSDIRECTORY/Python" ]]; then
        return 0
    fi

    find "$AGENT_TOOLSDIRECTORY/Python" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort --version-sort | while read -r full_version; do
        #extract major and minor version to determine install category
        IFS=. read -r version_major version_minor _ <<< "$full_version"

        if ! packages=$("$AGENT_TOOLSDIRECTORY/Python/${full_version}/x64/bin/pip3" list --format=freeze --disable-pip-version-check); then
            echo "Failed to list Python packages for ${full_version}" >&2
            return 1
        fi
        while IFS= read -r package; do
            [[ -n "$package" ]] || continue
            package_name=${package%%==*}
            package_version=${package#*==}
            if ! mot docs applications add \
                --name "$package_name" \
                --category "Python ${version_major}.${version_minor} Packages" \
                --version "$package_version" >/dev/null; then
                echo "Failed to document Python package ${package_name} ${package_version} for ${full_version}" >&2
                return 1
            fi
        done <<< "$packages"
    done
}

#determine latest version of python packges
python_package_version () {
    url=$1
    target_version=$2
    name=$3

    echo "Determining latest version of ${name} from ${url}"

     response=$(curl -sf "$url")
    if [[ $? -ne 0 || -z "$response" ]]; then
         echo "##vso[task.logissue type=warning]Version for ${name} can't be validated against latest because latest version can't be determined from ${url}."
       return 0
      fi

    latest_version=$(echo "$response" | jq -r '.info.version')

     if [[ -z "$latest_version" || "$latest_version" == "null" ]]; then
         echo "##vso[task.logissue type=warning]Version for ${name} can't be validated against latest because latest version can't be determined from ${url}."
       return 0
      fi

    # if target version is 'latest', use the latest version from pypi
    if [[ "$target_version" == "latest" ]]; then
        target_version="$latest_version"
        echo "Target version for $name is set to latest, resolving to: $target_version"
    fi

    verify_latest_version "$latest_version" "$target_version" "$name"
}
