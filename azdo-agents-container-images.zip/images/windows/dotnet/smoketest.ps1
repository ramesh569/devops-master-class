﻿<#
.SYNOPSIS
    Runs all the smoke tests in sequence that are specified below.
.NOTES
    Called by pipeline-extension-image.yml when calling the specific flavour's smoke tests
    Each flavour has its own smoketest file.
.PARAMETER AgentPoolName
    The name of the agent pool that the smoke test is run on
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#import smoke test helpers
Import-Module ".\SmokeTest.Helpers.psm1"

. .\Verify-ConnectionsOnPrem.ps1 -AgentPoolName $AgentPoolName
. .\Verify-ConnectionsCloud.ps1 -AgentPoolName $AgentPoolName
. .\Verify-SonarQube.ps1
. .\Verify-NexusIQ.ps1
. .\Verify-PowerShellCore.ps1
. .\Verify-DotNet.ps1
. .\Verify-SqlPackage.ps1
. .\Verify-MSBuild.ps1
. .\Verify-OpenJdk.ps1 -MajorVersion 'javaLTS17' -DefaultMajorVersion 'javaLTS17'
. .\Verify-GeneratedDocumentation.ps1

write-host "Smoke Test Completed"