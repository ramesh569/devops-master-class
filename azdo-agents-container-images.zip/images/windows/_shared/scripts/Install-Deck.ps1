﻿<#
.SYNOPSIS
    Installs the Deck CLI on windows
.DESCRIPTION
    Installation based on https://docs.konghq.com/deck/latest/installation/#windows
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$installDirectory = "c:\tools\deck"
$version =[version]"§kong-deck§"

#[script]
#Determine if there is a newer version

#determine download link based on version
$installFilePath = "$($installDirectory)\deck.tar.gz"

#create directory in which tool will reside
New-Item -Path $installDirectory -ItemType Directory

#download installation archive
$ProgressPreference = 'SilentlyContinue' #disable progress bar to improve download speed
mot asset download `
  --tool-id "kong-deck" `
  --source "github.com/kong/deck/releases/download/v$version/deck_${version}_windows_amd64.tar.gz" `
  --destination $installFilePath
#extract installation
write-host "Extract installation"
tar -xf $installFilePath -C $installDirectory

#remove installation archive
write-host "Cleanup download"
Remove-Item -Path $installFilePath

#add installation path to machine path so it can be accessed in any directory
write-host "Add $installDirectory to PATH"
Add-MachinePathItem "$installDirectory"

#add installation path as variable for convenience
write-host "Add DECK variable"
setx KONG_DECK "$installDirectory" /m

Add-InstalledSoftwareEntry -Text "Kong decK CLI $version"
Invoke-Mot docs applications add `
    --name "Kong decK CLI" `
    --category "Tools" `
    --version $version `
    --artifact "$installDirectory\deck.exe" `
    --generate-hash