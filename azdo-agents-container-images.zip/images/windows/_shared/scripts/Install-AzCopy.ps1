﻿<#
.SYNOPSIS
    Installs the AzCopy CLI on Windows.
.DESCRIPTION
    Downloads and installs AzCopy CLI from the official Microsoft URL.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" # Stop script on error
$installDirectory = "c:\tools\azcopy" # Installation directory
$azcopyVersion = "§azcopy§"

#[script]
# Define the AzCopy download URL
$azCopyUrl = "https://aka.ms/downloadazcopy-v$azcopyVersion-windows"

#create directory in which tool will reside
New-Item -Path $installDirectory -ItemType Directory

# Define the full path for the downloaded file
$zipFilePath = "$installDirectory\azcopy.zip"

# Download the AzCopy zip file
$ProgressPreference = 'SilentlyContinue' #disable progress bar to improve download speed
Write-Host "Downloading AzCopy from $azCopyUrl..."
try {
    Invoke-WebRequest -Uri $azCopyUrl -OutFile $zipFilePath
} catch {
    Write-Error "Failed to download AzCopy. Error: $_"
    exit 1
}

# Check if the file was downloaded successfully
if (-not (Test-Path -Path $zipFilePath)) {
    Write-Error "Failed to download AzCopy. File not found at $zipFilePath."
    exit 1
}

Write-Host "Download completed successfully."

# Extract the zip file
Write-Host "Extracting AzCopy to $installDirectory..."
Expand-Archive -Path $zipFilePath -DestinationPath $installDirectory -Force

# Remove the zip file after extraction
Write-Host "Removing the downloaded zip file..."
Remove-Item -Path $zipFilePath -Force

# Locate the AzCopy executable file
Write-Host "Searching for AzCopy executable..."
$azCopyExePath = Get-ChildItem -Path $installDirectory -Recurse -Filter "azcopy.exe" | Select-Object -First 1 -ExpandProperty FullName

if (!$azCopyExePath) {
    Write-Error "AzCopy executable not found in $installDirectory."
    exit 1
}

Write-Host "AzCopy executable found at: $azCopyExePath"

# Add the directory containing azcopy.exe to the machine path so it can be accessed in any directory
$azCopyExeDirectory = Split-Path -Path $azCopyExePath -Parent
Write-Host "Adding $azCopyExeDirectory to PATH..."
Add-MachinePathItem "$azCopyExeDirectory"

# Verify installation
Write-Host "Verifying AzCopy installation..."
$azCopyVersionOutput = & "$azCopyExePath" --version
Write-Host "AzCopy version: $azCopyVersionOutput"

# Extract only the version number (e.g., "10.28.0") from the output
$azCopyVersionNumber = ($azCopyVersionOutput | Select-String -Pattern '\d+\.\d+\.\d+').Matches.Value
Write-Host "AzCopy version: $azCopyVersionNumber"

# Add an entry for the installed software
Write-Host "Adding AzCopy to installed software list..."
Add-InstalledSoftwareEntry -Text "AzCopy $azCopyVersionNumber"
Invoke-Mot docs applications add `
    --name "AzCopy" `
    --category "Tools" `
    --version $azCopyVersionNumber `
    --artifact $azCopyExePath `
    --generate-hash

Write-Host "AzCopy installation completed successfully."