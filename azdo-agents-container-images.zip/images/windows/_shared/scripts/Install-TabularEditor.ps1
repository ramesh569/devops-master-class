﻿<#
.SYNOPSIS
    Install Tabular Editor
.DESCRIPTION
    Install Tabular Editor
.NOTES
    Tabular Editor is Tabular Editor 2 (https://github.com/TabularEditor/TabularEditor)
    Tabular Editor 3 is the paid version that requires licenses (https://github.com/TabularEditor/TabularEditor3)
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$installDirectory = "c:\tools\TabularEditor"
$targetVersion = [version]"§tabulareditor§"

#[script]
$archivePath="c:\install\TabularEditor.Portable.zip"

mot asset download `
  --tool-id "tabulareditor" `
  --source "github.com/TabularEditor/TabularEditor/releases/download/$targetVersion/TabularEditor.Portable.zip" `
  --destination $archivePath


#extract tabular editor
Expand-Archive -Path $archivePath -DestinationPath $installDirectory -Force

#add tabular editor to path
Add-MachinePathItem $installDirectory

#remove downloaded installation file
Remove-Item $archivePath

#validate executable is available
$executable =  "$installDirectory\TabularEditor.exe"
if (!(Test-Path($executable))) {
    Write-Host "Unable to find Tabular Editor at expected location $executable"
    Write-Host "Printing directory contents of $installDirectory"
    Get-ChildItem $installDirectory
    throw "Tabular Editor not installed correctly. See logging above"
}

#get installed version
$logFileName = "log.txt"
$process = Start-Process -FilePath $executable -ArgumentList "--version" -RedirectStandardOutput $logFileName -PassThru -NoNewWindow

#give tabular editor time to start up and output version number
Start-Sleep -seconds 10 #increased to 10 seconds because sometimes the version number would not be reported

#stop tabular editor
Stop-Process -Id $process.Id

#get output of command
$logContent = Get-Content $logFileName

#extract version number
$version = ""
foreach($line in $logContent)
{
    if($line -match '(\d+\.\d+\.\d+)')
    {
        $version = $matches[1]
    }
}

#validate if version number was extracted
if ($version -eq "") {
    Write-Host "Unable to determine Tabular Editor version, logging is as following:"
    foreach($line in $logContent) {
        Write-Host $line
    }
    Write-Host "EOF"
    Write-Host "Report desired version number $targetVersion as version"
    $version = $targetVersion
}

#cleanup log
Start-Sleep -seconds 5 #ensure file is not in use before trying to remove
Remove-Item $logFileName

#add tabular editor version to installed software list
Add-InstalledSoftwareEntry -Text "Tabular Editor $version"
Invoke-Mot docs applications add `
    --name "Tabular Editor" `
    --category "Tools" `
    --version $version `
    --artifact $executable `
    --generate-hash