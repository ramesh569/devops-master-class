[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '', Justification = 'Required for keytool integration')]
Param()

#[config]
$certificatesPath = "C:\install\content\certificates"

#[functions]
function Find-KeyStorePath {
  param (
    [parameter(Mandatory = $true)]
    [string]$jre
  )
  $javaHome = $jre
  $libSecurityCacerts = Join-Path 'lib' (Join-Path 'security' 'cacerts')
  $paths = (Join-Path $javaHome $libSecurityCacerts),
  (Join-Path $javaHome (Join-Path jre $libSecurityCacerts)) |
  Where-Object { Test-Path $_ }
  if (-not $paths) {
    throw "No cacerts file found under $javaHome"
  }
  Write-Verbose ("Using key store from '{0}'" -f $paths)
  $paths
}

function Find-KeyToolPath {
  param (
    [parameter(Mandatory = $true)]
    [string]$jre
  )

  $javaHome = $jre
  $ktPath = Join-Path $javaHome (Join-Path bin keytool.exe)
  if (-not (Test-Path $ktPath)) {
    throw "keytool.exe not found in PATH and not relative to $javaHome"
  }
  Write-Verbose ("Using keytool from '{0}'" -f $ktPath)
  $ktPath
}

function Get-CertsToImport {
  param (
    [parameter(Mandatory = $true)]
    [string]$certificatesPath
  )

  Get-ChildItem -Path $certificatesPath -File | Where-Object { $_.Name -like "*.crt" }
}

function Add-JreRootCA {
  [CmdletBinding()]
  param (
    [string]
    $jre,

    [securestring]
    $StorePassword = (ConvertTo-SecureString -AsPlainText -Force 'changeit')
  )

  $KeyStorePath = (Find-KeyStorePath -jre $jre)
  $KeyToolPath = (Find-KeyToolPath -jre $jre)

  function ConvertFrom-SecureStringToPlainText([securestring] $str) {
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($str)
    [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
  }

  function Invoke-KeyTool() {
    param (
      [securestring] $KeyStorePassword,
      [string[]] $options,
      [switch] $shouldThrowOnNonZeroExitcode
    )
    #append keystore path to passed options
    $options += '-keystore', "`"$KeyStorePath`"", '-noprompt'

    #print all options except the password one for logging purposes
    Write-Verbose """$KeyToolPath"" $($options -join ' ') -storepass ****"

    #append password (after logging) to avoid it being printed in the logs
    $options += '-storepass', "`"$(ConvertFrom-SecureStringToPlainText $KeyStorePassword)`""

    $arguments = $options -join ' '
    Start-Process -FilePath $KeyToolPath -ArgumentList $arguments -NoNewWindow -Wait | Out-Null
    $ec = $LASTEXITCODE
    Write-Verbose "Keytool exited with status $ec"
    if (($shouldThrowOnNonZeroExitcode -eq $true) -and ($ec -ne 0)) {
      throw "keytool exited with non-zero exit code"
    }
    $ec
  }

  $certsToImport = Get-CertsToImport $certificatesPath

  foreach ($certToImport in $certsToImport) {
    $CertFilePath = $certToImport.FullName
    $JreCertAlias = $certToImport.Name -replace " ", "_" -replace ".crt", ""

    # check if the keystore already has the certificate in question
    $keytoolResult = Invoke-KeyTool `
      -KeyStorePassword $StorePassword `
      -options '-list', '-alias', $JreCertAlias
    if ($keytoolResult -eq 0) {
      Write-Host "Certificate already exists in $KeyStorePath, removing it..."
      Invoke-KeyTool `
        -KeyStorePassword $StorePassword `
        -options '-delete', '-alias', $JreCertAlias `
        -shouldThrowOnNonZeroExitcode | Out-Null
    }

    Write-Host "Importing '$CertFilePath' to '$KeyStorePath' using alias '$JreCertAlias'..."
    Invoke-KeyTool `
      -KeyStorePassword $StorePassword `
      -options '-importcert', '-alias', $JreCertAlias, '-file', "`"$CertFilePath`"" `
      -shouldThrowOnNonZeroExitcode | Out-Null
  }
}

function Add-WindowsRootCA {
  [CmdletBinding()]
  param (
  )

  $certsToImport = Get-CertsToImport $certificatesPath
  $certStore = "cert:\LocalMachine\Root"

  foreach ($certToImport in $certsToImport) {
    $CertFilePath = $certToImport.FullName
    try {
      $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CertFilePath)
      $certPath = Join-Path $certStore $cert.Thumbprint
      if (-not (Test-Path -LiteralPath $certPath -PathType Leaf)) {
        $rootStore = Get-Item $certStore
        if (-not $rootStore.IsOpen) {
          $rootStore.Open("ReadWrite")
        }
        $rootStore.Add($cert)
        $rootStore.Close()
        Write-Host "Successfully imported '$CertFilePath' to '$certStore'"
      } else {
        Write-Host "Certificate '$CertFilePath' already exists in '$certStore'"
      }
    }
    catch {
      Write-Host "Failed to import '$CertFilePath' to '$certStore': $_"
    }
  }

}

#[script]

# list all certificate files
write-host "Certificate Files found on disk:"
Get-ChildItem -Path $certificatesPath -Filter *.crt

# Get all environment variables that look like a Java Home directory
$javaHomeRegex = "^JAVA_.*?HOME_"
$jdkHomeRegex = "^jdk_.*"
$javaHomes = @{}
foreach ($level in "Machine", "User", "Process") {
  [Environment]::GetEnvironmentVariables($level).GetEnumerator() |
  Where-Object { ($_.Key -match $javaHomeRegex) -or ($_.Key -match $jdkHomeRegex) } |
  ForEach-Object {
    try {
      $javaHomes.Add($_.Value, 1)
      Write-Verbose ("Found JDK at '{0}'" -f $_.Value)
    }
    catch {
      Write-Verbose ("Already have JDK at '{0}' in the list of JDKs to process" -f $_.Value)
    }
  }
}

# Add certificates to the keystores of each JDK that we found
foreach ($javaHome in $javaHomes.Keys) {
  if (-not (Test-Path -Path $javaHome)) {
    Write-Host "The path $javaHome does not exist. Skipping."
    continue;
  }

  Add-JreRootCA -jre $javaHome
}

Add-WindowsRootCA
