﻿<#
.SYNOPSIS
    Install Java
.DESCRIPTION
     Install Java
.NOTES
    Downloads Microsoft's version of the Java JDK instead of Temurin.
.PARAMETER Version
    Version of Java to be installed
.PARAMETER DefaultTo
    Set this version as the default version
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$True, Position=0)]
    [string]$MajorVersion,
    [Parameter(Mandatory=$True, Position=1)]
    [bool]$DefaultTo
)


#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error

# Install Java
Write-Host "Installing Java version: $MajorVersion"

# Determine JAVA_HOME variable name
$javaHomeEnv = "JAVA_HOME_${MajorVersion}_X64"

# determining latest available version
$latestInstallerUrl = "https://aka.ms/download-jdk/microsoft-jdk-$MajorVersion-windows-x64.msi"
$latestInstallerResponse = Invoke-WebRequest -Uri $latestInstallerUrl -Method Head -UseBasicParsing
$contentDisposition = $latestInstallerResponse.Headers['Content-Disposition'] -join ';'
if ($contentDisposition -notmatch 'filename=microsoft-jdk-(?<version>\d+(?:\.\d+){1,5})-windows-x64\.msi') {
    throw "Unable to determine the latest Microsoft Build of OpenJDK version from $latestInstallerUrl"
}
$latestVersion = $Matches.version
Write-Host "Latest Version: $latestVersion"

$installPath = "C:\Java\$MajorVersion"

$installerFilename = "microsoft-jdk-$Version-windows-x64.msi"
$url = "https://aka.ms/download-jdk/$installerFilename"
$installerDirectory = "c:\install"

New-Item -ItemType directory -Path "$installerDirectory" -Force
Write-Host "Downloading from $url"
Invoke-WebRequest -Uri $url -OutFile "$installerDirectory\$installerFilename"
$installFile = "$installerDirectory\$installerFilename"
Write-Host "Installing Java $Version"

$MSIArguments = @(
    "/i"
    "$installFile"
    "INSTALLDIR=$installPath"
    "ADDLOCAL=FeatureMain,FeatureEnvironment,FeatureJarFileRunWith,FeatureJavaHome"
    "/quiet"
)

Start-Process "msiexec.exe" -ArgumentList $MSIArguments -Wait -NoNewWindow

Remove-Item "$installFile"

# Set agent capability variable required by SonarQube
Write-Host "Set 'java' environmental variable as 'yes'"
Set-SystemVariable -SystemVariable 'java' -Value 'yes'

# Set JAVA_HOME_<Major Version>_X64 (JAVA_HOME is already set by installer)
Write-Host "Set $javaHomeEnv environmental variable as $installPath"
Set-SystemVariable -SystemVariable $javaHomeEnv -Value "$installPath"

# Print the value of JAVA_HOME_<Major Version>_X64
$javaHomeValue = Get-SystemVariable -SystemVariable $javaHomeEnv
Write-Host "Value of $javaHomeEnv is $javaHomeValue"

Add-InstalledSoftwareEntry -Text "JAVA JDK v$Version"

# Set this version as default if specified
if ($DefaultTo -eq $true) {
    Write-Host "Set 'JAVA_HOME' environmental variable as $installPath"
    Set-SystemVariable -SystemVariable 'JAVA_HOME' -Value "$installPath"
    Write-Host "Adding $installPath\bin to PATH"
    Add-MachinePathItem -PathItem "$installPath\bin"
}

$motEnvironmentVariables = @(
    "--environment-variables", "$javaHomeEnv=$installPath",
    "--environment-variables", "java=yes"
)
if ($DefaultTo -eq $true) {
    $motEnvironmentVariables += @("--environment-variables", "JAVA_HOME=$installPath")
}

Invoke-Mot docs applications add `
    --name "JAVA JDK" `
    --category "Frameworks" `
    --version $Version `
    --artifact "$installPath\bin\java.exe" `
    --generate-hash `
    $motEnvironmentVariables