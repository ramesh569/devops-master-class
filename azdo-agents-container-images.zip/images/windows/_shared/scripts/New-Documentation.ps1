﻿<#
.SYNOPSIS
    Generate and store general documentation for windows image
.DESCRIPTION
    Generate documentation based on installed software
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error

$docsDirectory = "c:\temp\docs-generation"
$docsMDPath = Join-Path -Path $docsDirectory -ChildPath "documentation.md"
$docsJSONPath = Join-Path -Path $docsDirectory -ChildPath "documentation.json"

#[functions]
function Get-OsInformation() {
    $systemInformation = systeminfo /fo csv | ConvertFrom-Csv | Select-Object -Property 'OS Name', 'OS Version'
    $osName = $($systeminformation.'OS Name')
    $osVersion = $($systeminformation.'OS Version')
    Invoke-Mot docs metadata add `
        --set os-name=$osName `
        --set os-version=$osVersion
}
function Get-WindowsSoftware() {
    write-host "Recording installed software (as reported by add/remove program)"
    $installedItems = Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* `
        | Where-Object { $_.DisplayName -and $_.DisplayName -notlike "Microsoft Visual C++*" } `
        | Select-Object DisplayName, DisplayVersion
    write-host "Found $($installedItems.count) items"

    foreach($installedItem in $installedItems) {
        $standardizedTitle = $installedItem.DisplayName -replace " - ([0-9.]+){3}", ""
        if ([string]::IsNullOrWhiteSpace($standardizedTitle) -or
            [string]::IsNullOrWhiteSpace([string]$installedItem.DisplayVersion)) {
            Write-Warning "Skipping Windows application '$($installedItem.DisplayName)' because its name or version is missing."
            continue
        }

        Invoke-Mot docs applications add `
            --name "$standardizedTitle" `
            --category "Windows-Applications" `
            --version $installedItem.DisplayVersion
    }
    write-host "Recorded installed software"
}

function Get-VisualCPPComponents {
  $regKeys = @(
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
  )

  $items = foreach ($p in $regKeys) {
    Get-ItemProperty -Path $p -ErrorAction SilentlyContinue |
      Where-Object { $_.DisplayName -like "Microsoft Visual C++*" } |
      Select-Object DisplayName, DisplayVersion, PSPath
  }

  $items |
    Sort-Object DisplayName, DisplayVersion |
    ForEach-Object {
      $dn = $_.DisplayName
      $ver = $_.DisplayVersion
      $pspath = $_.PSPath
      $arch = $null
      $mParen = [regex]::Match($dn, '\((x86|x64|arm64|amd64)\)', 'IgnoreCase')
      if ($mParen.Success) { $arch = $mParen.Groups[1].Value.ToLower() }
      if (-not $arch) {
          $mToken = [regex]::Match($dn, '\b(x86|x64|arm64|amd64)\b', 'IgnoreCase')
          if ($mToken.Success) { $arch = $mToken.Groups[1].Value.ToLower() }
      }

          if ($arch -eq 'amd64') { $arch = 'x64' }
      if (-not $arch) {
          if ($pspath -match 'WOW6432Node') { $arch = 'x86' }
          else { $arch = 'x64' }
      }

    # Normalize name: remove arch tokens and trailing '- version'
      $nameNormalized = $dn
      $nameNormalized = $nameNormalized -replace '\s*\((x86|x64|arm64|amd64)\)', ''
      $nameNormalized = $nameNormalized -replace '\b(x86|x64|arm64|amd64)\b', ''
      $nameNormalized = $nameNormalized -replace '\s*-?\s*\d+(\.\d+)*$', ''
      $nameNormalized = ($nameNormalized -replace '\s{2,}', ' ').Trim()

      [PSCustomObject]@{
      Name = $nameNormalized
      Architecture = $arch
      Version = $ver
     }
    }
}

function Add-VisualCPPSection {
  Write-Host "Recording Microsoft Visual C++ Redistributables"
  $vcpp = Get-VisualCPPComponents | Sort-Object Name, Architecture, Version -Unique
  foreach ($v in $vcpp) {
    if ([string]::IsNullOrWhiteSpace($v.Name) -or
        [string]::IsNullOrWhiteSpace([string]$v.Version)) {
      Write-Warning "Skipping Visual C++ component '$($v.Name)' because its name or version is missing."
      continue
    }

    Invoke-Mot docs applications add `
      --name "$($v.Name) ($($v.Architecture))" `
      --category "Visual C++ Redistributables" `
      --version $v.Version
  }
  Write-Host "Recorded Microsoft Visual C++ Redistributables"
}

function Get-WindowsFeaturesList() {
    write-host "Recording Windows Features"
    $windowsFeatures = Get-WindowsFeature | Where-Object {$_.InstallState -eq "Installed"}
    write-host "Found $($windowsFeatures.count) items"

    foreach($windowsFeature in $windowsFeatures) {
        if ([string]::IsNullOrWhiteSpace($windowsFeature.DisplayName) -or
            $null -eq $windowsFeature.AdditionalInfo.MajorVersion -or
            $null -eq $windowsFeature.AdditionalInfo.MinorVersion) {
            Write-Warning "Skipping Windows feature '$($windowsFeature.Name)' because its name or version is missing."
            continue
        }

        Invoke-Mot docs applications add `
            --name $windowsFeature.DisplayName `
            --category "Windows-Features" `
            --version "$($windowsFeature.AdditionalInfo.MajorVersion).$($windowsFeature.AdditionalInfo.MinorVersion)"
    }
    write-host "Recorded Windows Features"
}

function Get-DotNet() {
    write-host "Recording .NET Installations"
    if (Test-Command dotnet) {
        $sdks = dotnet --list-sdks
        if ($LASTEXITCODE -ne 0) { throw ".NET SDK inventory failed with exit code $LASTEXITCODE" }
        $runtimes = dotnet --list-runtimes
        if ($LASTEXITCODE -ne 0) { throw ".NET runtime inventory failed with exit code $LASTEXITCODE" }

        foreach ($sdk in $sdks) {
            if ($sdk -notmatch '^\s*(\S+)\s+\[') {
                throw "Unable to parse .NET SDK inventory entry: '$sdk'"
            }
            Invoke-Mot docs applications add `
                --name ".NET SDK" `
                --category ".NET Frameworks" `
                --version $Matches[1]
        }
        $runtimeVersions = foreach ($runtime in $runtimes) {
            if ($runtime -notmatch '^\s*\S+\s+(\S+)\s+\[') {
                throw "Unable to parse .NET runtime inventory entry: '$runtime'"
            }
            $Matches[1]
        }
        foreach ($runtimeVersion in ($runtimeVersions | Sort-Object -Unique)) {
            Invoke-Mot docs applications add `
                --name ".NET Runtime" `
                --category ".NET Frameworks" `
                --version $runtimeVersion
        }
    }
}

#[script]
write-host "Document Path: $docsMDPath"

#create and navigate to document folder
New-Item $docsDirectory -ItemType Directory -Force | Out-Null
# MOT updates existing records in place without deleting installer records.

#create documentation header
write-host "Generating documentation"
Get-OsInformation

#create installed software list
Get-DotNet

#record powershell documentation for both version of powershell
& c:\install\helpers\Generate-PowershellModulesDocs.ps1
pwsh -File c:\install\helpers\Generate-PowershellModulesDocs.ps1
if ($LASTEXITCODE -ne 0) { throw "PowerShell module inventory failed with exit code $LASTEXITCODE" }

Get-WindowsSoftware
Add-VisualCPPSection
Get-WindowsFeaturesList
Invoke-Mot docs metadata add --set build-id=§BuildId§ --set "§CommitMetadataKey§=§SourceCommit§"

#copy MOT generated documentation to the temporary docs folder
#so it can be picked up by the build and stored as artifact
Copy-Item -Path (Get-InstalledSoftwareManifestMOTPath) -Destination $docsJSONPath

Invoke-Mot docs generate-md --out $docsMDPath