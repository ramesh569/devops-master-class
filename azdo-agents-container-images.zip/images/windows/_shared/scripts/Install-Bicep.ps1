﻿<#
.SYNOPSIS
    Install Bicep
.DESCRIPTION
    Install Bicep
.NOTES
    Installation notes found at https://learn.microsoft.com/en-gb/azure/azure-resource-manager/bicep/install
    Azure DevOps Task Azure CLI automatically installs Bicep when needed (and checks path if bicep is present before downloading)
    Azure DevOps Task Azure PowerShell does not automatically install Bicep when needed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$targetVersion = [version]"§bicep§"

#[script]
#create the install folder
$installPath = "c:\tools\bicep"
$installFilePath = "$installPath\bicep.exe"
New-Item -ItemType Directory -Path $installPath -Force

#download installation archive
$ProgressPreference = 'SilentlyContinue' #disable progress bar to improve download speed

mot asset download `
  --tool-id "bicep" `
  --source "github.com/Azure/bicep/releases/download/v$targetVersion/bicep-win-x64.exe" `
  --destination $installFilePath

Write-Host "Validate download by calling the binary with --version"
& $installFilePath --version
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to download the standalone bicep binary, see logging for more details"
    exit 1
}

Write-Host "Add Bicep to environment Path variable"
Add-MachinePathItem $installPath

$version = ((& $installFilePath --version) | Select-String -Pattern '\d+\.\d+\.\d+').Matches.Value
Add-InstalledSoftwareEntry -Text "Bicep $version"
Invoke-Mot docs applications add `
    --name "Bicep" `
    --category "Tools" `
    --version $version `
    --artifact $installFilePath `
    --generate-hash
