﻿<#
.SYNOPSIS
    Install SonarCube CLI
.DESCRIPTION
    Install SonarCube CLI
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$sonarVersion = [version]"§sonar-scanner-cli§"

#[script]
$installDirectory = "c:\install"
$zipFile = "sonar-scanner-cli-$sonarVersion-windows-x64.zip"
$url = "binaries.sonarsource.com/Distribution/sonar-scanner-cli/$zipFile"
$installationPath = "C:\SonarQube-cli\cli-$sonarVersion"

# Install the CLI
New-Item -ItemType directory -Path "$installationPath" -Force

mot asset download `
  --tool-id "sonar-scanner-cli" `
  --source $url `
  --destination "$installDirectory\$zipFile"

Expand-Archive "$installDirectory\$zipFile" -DestinationPath "$installationPath"

$sonarScannerPath = Get-ChildItem -Path $installationPath -Recurse -File |
    Where-Object { $_.BaseName -eq "sonar-scanner" -and $_.Extension -in ".exe", ".cmd", ".bat" } |
    Select-Object -First 1 -ExpandProperty FullName
if (-not $sonarScannerPath) {
    Write-Error "SonarQube Scanner CLI executable not found"
}

setx SONARCLI "$installationPath" /M

#make cli available from any location
Add-MachinePathItem "$installationPath\bin"

Remove-Item "$installDirectory\$zipFile"

Add-InstalledSoftwareEntry -Text "SonarQube Scanner CLI $sonarVersion"
Invoke-Mot docs applications add `
    --name "SonarQube Scanner CLI" `
    --category "Tools" `
    --version $sonarVersion `
    --artifact $sonarScannerPath `
    --generate-hash