﻿<#
.SYNOPSIS
    Install UV standalone
.DESCRIPTION
    Install UV standalone binary for Windows
.NOTES
    UV is a modern, fast, and secure command-line tool. (https://github.com/astral-sh/uv)
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = 'Stop'
$installDirectory = "c:\tools\uv"
$targetVersion = [version]"§uv§"

#[script]
Write-Host "Installing UV standalone binary"

#store download url and download path


$archivePath = "c:\install\uv-install.zip"

mot asset download `
  --tool-id "uv" `
  --source "github.com/astral-sh/uv/releases/download/$targetVersion/uv-x86_64-pc-windows-msvc.zip" `
  --destination $archivePath

# Unzip the installer
Write-Host "Unzipping UV installer"
Expand-Archive -Path $archivePath -DestinationPath $installDirectory -Force

# Remove the installer
Remove-Item -Path $archivePath -Force

# Add UV to PATH
Write-Host "Adding UV to Machine PATH"
$uvPath = "$installDirectory\uv.exe"
Add-MachinePathItem $installDirectory
Write-Host "UV installed to $uvPath"

# Verify installation
Write-Host "Verifying UV installation"
$uvVersionOutput = & $uvPath --version
Write-Host "UV version output: $uvVersionOutput"

# Extract only the version number from the output
$uvVersion = ($uvVersionOutput | Select-String -Pattern "uv ([0-9]+\.[0-9]+\.[0-9]+)" -AllMatches).Matches[0].Groups[1].Value
Write-Host "Extracted UV version: $uvVersion"

# Add an entry for the installed software
Write-Host "Adding UV to installed software list"
Add-InstalledSoftwareEntry -Text "UV $uvVersion"
Invoke-Mot docs applications add `
    --name "UV" `
    --category "Tool" `
    --version $uvVersion `
    --artifact $uvPath `
    --generate-hash