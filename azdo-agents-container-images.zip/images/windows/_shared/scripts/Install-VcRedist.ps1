<#
.SYNOPSIS
    Install Visual C++ Redistributable (x64) using the official Microsoft installer
.DESCRIPTION
    Downloads https://aka.ms/vc14/vc_redist.x64.exe and performs a silent install.
    For details about the latest supported Visual C++ redistributables see:
    https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170

    Records the installed package name and version in the installed software manifest
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1

$ErrorActionPreference = 'Stop'

$installerUrl = 'https://aka.ms/vc14/vc_redist.x64.exe'
$installerPath = 'C:\install\vc_redist.x64.exe'

Write-Host "Preparing to download and install Visual C++ Redistributable (x64)"

# Ensure install directory exists
$installDir = Split-Path -Path $installerPath -Parent
if (-not (Test-Path -Path $installDir)) {
    New-Item -Path $installDir -ItemType Directory -Force | Out-Null
}

try {
    Write-Host "Downloading Visual C++ Redistributable from $installerUrl"
    Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -ErrorAction Stop

    Write-Host "Installing Visual C++ Redistributable (x64)"
    $proc = Start-Process -FilePath $installerPath -ArgumentList '/install','/quiet','/norestart' -Wait -PassThru -NoNewWindow

    if ($proc.ExitCode -ne 0) {
        throw "Installer exited with code $($proc.ExitCode)"
    }

    Write-Host "Installation completed successfully"
} catch {
    Write-Host "ERROR: Visual C++ install failed: $($_.Exception.Message)"
    exit 1
} finally {
    Write-Host "Cleaning up installer"
    if (Test-Path $installerPath) {
        Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
    }
}

Write-Host "Visual C++ Redistributable installation completed"
