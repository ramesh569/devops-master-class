﻿<#
.SYNOPSIS
    Install Microsoft.SqlPackage
.DESCRIPTION
    Install Microsoft.SqlPackage
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$sqlPackageVersion = '§sqlPackageVersion§'
$installDirectory = "c:\tools\sqlpackage"
$installPath = "$installDirectory\sqlpackage.exe"

#[script]

#install tool
$nugetPackageName = "Microsoft.SqlPackage"
Write-Host "Installing $nugetPackageName"
Test-NuGetPackageVersion -PackageName $nugetPackageName -TargetVersion $sqlPackageVersion
dotnet tool install $nugetPackageName --version $sqlPackageVersion --tool-path $installDirectory

#add installation path to machine path so it can be accessed in any directory
write-host "Add $installDirectory to PATH"
Add-MachinePathItem "$installDirectory"

#add environment variable to signify capability and satisfy demand
#the value is not important, installation directory seems most useful
write-host "Add sqlpackage variable"
setx sqlpackage "$installDirectory" /m

<#
Task SqlDacpacDeploymentOnMachineGroup@0 requires a specific entry in the registry in order to recognize that SqlPackage.exe is installed.
Create the entry in the registry, for more information about the detection see
https://github.com/microsoft/azure-pipelines-extensions/blob/master/TaskModules/powershell/TaskModuleSqlUtility/SqlPackageOnTargetMachines.ps1
#>
New-Item -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Data-Tier Application Framework\170" -Force
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Data-Tier Application Framework\170" -Name "InstallDir" -Value $installDirectory

#add SQLPackage to installed software list
$version = "$(& $installPath /Version)"
Add-InstalledSoftwareEntry -Text ".NET SQLPackage $version"
Invoke-Mot docs applications add `
    --name ".NET SQLPackage" `
    --category "Tools" `
    --version $version `
    --artifact $installPath `
    --generate-hash