﻿<#
.SYNOPSIS
    Install PowerShell 7
.DESCRIPTION
    Install PowerShell 7 (PowerShell 5 comes with the OS)
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$targetVersion = [version]"§powershell§"
$installationPath = "$env:ProgramFiles\PowerShell\7"

#store download url and download path

$powershellArchivePath="c:\install\powershell7.zip"

mot asset download `
  --tool-id "powershell" `
  --source "github.com/PowerShell/PowerShell/releases/download/v$targetVersion/PowerShell-$targetVersion-win-x64.zip" `
  --destination $powershellArchivePath
#expand archive
write-host "Unpacking zip file"
New-Item $installationPath -ItemType directory | Out-Null
Expand-Archive -Path $powershellArchivePath -DestinationPath $installationPath

#remove installation files
Remove-Item $powershellArchivePath

#add powershell to path
Add-MachinePathItem -PathItem "$installationPath"

Invoke-Mot docs applications add `
  --name "PowerShell Core" `
  --category "Tools" `
  --version $targetVersion `
  --artifact "$installationPath\pwsh.exe" `
  --generate-hash