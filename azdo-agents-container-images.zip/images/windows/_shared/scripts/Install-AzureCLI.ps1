﻿<#
.SYNOPSIS
    Installs the Azure CLI on windows
.DESCRIPTION
    Installation based on https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=powershell
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$version=[version]"§azure-cli§"

Write-Host "Download Azure CLI from: $url"
$installerPath="c:\install\AzureCLI.msi"

mot asset download `
  --tool-id "azure-cli" `
  --source "github.com/Azure/azure-cli/releases/download/azure-cli-$version/azure-cli-$version-x64.msi" `
  --destination $installerPath

Start-Process msiexec.exe -Wait -ArgumentList "/I $installerPath /quiet";
Remove-Item $installerPath

$azureCliPath = @(
    "$env:ProgramFiles\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
    "${env:ProgramFiles(x86)}\Microsoft SDKs\Azure\CLI2\wbin\az.cmd"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $azureCliPath) {
    Write-Error "Azure CLI executable not found"
}

Add-InstalledSoftwareEntry -Text "Azure CLI $version"
Invoke-Mot docs applications add `
    --name "Azure CLI" `
    --category "Tools" `
    --version $version `
    --artifact $azureCliPath `
    --generate-hash