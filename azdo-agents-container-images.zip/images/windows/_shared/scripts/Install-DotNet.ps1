﻿<#
.SYNOPSIS
    Install .NET SDKs
.DESCRIPTION
    Install .NET SDKs
.NOTES
    Script based on runner-images\images\win\scripts\Installers\Install-DotnetSDK.ps1
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$dotnetVersions = @('§dotnetSdkLTS§', '§dotnetSdkCurrent§', '§dotnetSdk10§')

#[functions]
function InstallAllValidSdks()
{
    param (
        [Parameter()]
        $DotnetVersions
    )

    # Download installation script.
    $installationName = "dotnet-install.ps1"
    $installationUrl = "https://dot.net/v1/${installationName}"
    Invoke-WebRequest -Uri $installationUrl -OutFile $installationName

    ForEach ($dotnetVersion in $DotnetVersions)
    {
        $sdkVersionsToInstall = Get-SDKVersionsToInstall -DotnetVersion $dotnetVersion

        ForEach ($sdkVersion in $sdkVersionsToInstall)
        {
            InstallSDKVersion -SdkVersion $sdkVersion
        }
    }
}

function Get-SDKVersionsToInstall (
    $DotnetVersion
) {
    $releaseJson = "https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/${DotnetVersion}/releases.json"
    $releasesJsonPath = "releases-${DotnetVersion}.json"
    Invoke-RestMethod -Method Get -Uri $releaseJson -OutFile $releasesJsonPath
    $releasesData = Get-Content -Path $releasesJsonPath | ConvertFrom-Json
    # filtering out the preview/rc releases
    $releases = $releasesData.'releases' | Where-Object { !$_.'release-version'.Contains('-') }

    #only get the latest .NET release
    $releases = $releases | Sort-Object { $_.'release-version' -as [version] } -Descending | Select-Object -First 1


    $sdks = @()
    ForEach ($release in $releases)
    {
        $sdks += $release.'sdk'
        $sdks += $release.'sdks'
    }

    return $sdks.version | Sort-Object { [Version] $_ } -Unique `
                         | Group-Object { $_.Substring(0, $_.LastIndexOf('.') + 2) } `
                         | Foreach-Object { $_.Group[-1] }}

function InstallSDKVersion (
    $SdkVersion
)
{
    if (!(Test-Path -Path "C:\Program Files\dotnet\sdk\$sdkVersion"))
    {
        Write-Host "Installing dotnet $sdkVersion"
        .\dotnet-install.ps1 -Architecture x64 -Version $sdkVersion -InstallDir $(Join-Path -Path $env:ProgramFiles -ChildPath 'dotnet')
    }
    else
    {
        Write-Host "Sdk version $sdkVersion already installed"
    }
}

function RunPostInstallationSteps()
{
    # Add dotnet to PATH
    Add-MachinePathItem "C:\Program Files\dotnet"

    # Add %USERPROFILE%\.dotnet\tools to USER PATH
    # This is the folder in which global dotnet tools are installed when
    # When dotnet tool is installed locally it is placed in nuget directory and a shim is added to this folder
    # For more information see https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-tool-install#global-tools
    Add-DefaultPathItem "%USERPROFILE%\.dotnet\tools"
}

#[script]
InstallAllValidSdks -DotnetVersions $dotnetVersions
RunPostInstallationSteps

$dotnetPath = Join-Path -Path $env:ProgramFiles -ChildPath 'dotnet\dotnet.exe'
Invoke-Mot docs applications add `
    --name ".NET" `
    --category "Frameworks" `
    --version (& $dotnetPath --version) `
    --artifact $dotnetPath `
    --generate-hash
