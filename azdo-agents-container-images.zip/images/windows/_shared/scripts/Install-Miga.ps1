﻿<#
.SYNOPSIS
    Installs the Miga tool on Windows
.DESCRIPTION
    Downloads the MIGA portable executable from Nexus, places it in
    `C:\tools\miga`, adds it to PATH, creates a default config and
    registers the installed software.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop"
$installDirectory = "C:\tools\miga"

#[script]
Write-Host "Installing MIGA"

# Ensure install directory exists
New-Item -Path $installDirectory -ItemType Directory -Force | Out-Null

$downloadFile = "$installDirectory\miga-windows-amd64.exe"

$ProgressPreference = 'SilentlyContinue'

Write-Host "Downloading MIGA via mot asset download"

# Build source URL so we can inspect it at runtime (helps debug NAM substitution/encoding)
$sourceUrl = "https://repo.nexuscloud.aws.rabo.cloud/repository/raw-55/meso/internal/miga/miga/§miga§/miga-windows-amd64.exe"
Write-Host "Resolved MIGA download URL: $sourceUrl"

try {
    mot asset download `
      --tool-id "miga" `
      --source $sourceUrl `
      --destination "$downloadFile"
} catch {
    Write-Error "Failed to download MIGA via mot. Error: $_"
    exit 1
}

if (-not (Test-Path -Path $downloadFile)) {
    Write-Error "Download failed: $downloadFile not found"
    exit 1
}

# Normalize executable name to miga.exe
$exePath = "$installDirectory\miga.exe"
Write-Host "Installing MIGA executable to $exePath"
Move-Item -Path $downloadFile -Destination $exePath -Force

# Add MIGA to PATH
Add-MachinePathItem -PathItem $installDirectory

# Create default config
$configDir = "C:\ProgramData\miga"
New-Item -Path $configDir -ItemType Directory -Force | Out-Null
$configFile = "$configDir\config.yaml"
$logDir = Join-Path $configDir 'logs'
New-Item -Path $logDir -ItemType Directory -Force | Out-Null
$agentSid = (Get-LocalUser -Name 'AzDevOps' -ErrorAction Stop).SID.Value
icacls.exe $logDir /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' "*${agentSid}:(OI)(CI)M"
if ($LASTEXITCODE -ne 0) { throw "Failed to configure log directory permissions: $logDir" }

@"
logging:
  file: 'C:\ProgramData\miga\logs\miga.log'
diagnostics_path: 'C:\azp\agent\_diag\'
metra_endpoint: 'metra-windows.metra.svc.cluster.local:8080'
"@ | Out-File -FilePath $configFile -Encoding ASCII -Force

# Set the MIGA_CONFIG_FILE environment variable to point to the default config
Set-SystemVariable -SystemVariable 'MIGA_CONFIG_FILE' -Value $configFile

Write-Host "Verifying MIGA installation"
try {
    $versionOutput = & "$exePath" --version
    if ($LASTEXITCODE -ne 0) {
        throw "MIGA --version exited with code $LASTEXITCODE"
    }
    Write-Host "$versionOutput"
} catch {
    Write-Error "MIGA failed to execute: $_"
    exit 1
}

# Add MIGA to installed software registry
Add-InstalledSoftwareEntry -Text "$versionOutput"

Invoke-Mot docs applications add `
    --name "MIGA" `
    --category "Tools" `
    --version $versionOutput `
    --artifact $exePath `
    --generate-hash

Write-Host "MIGA installation complete"
