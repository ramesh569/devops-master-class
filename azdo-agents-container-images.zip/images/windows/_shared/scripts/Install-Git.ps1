﻿<#
.SYNOPSIS
    Install Git
.DESCRIPTION
    Install Git
.NOTES
    Script based on runner-images\images\win\scripts\Installers\Install-Git.ps1
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$targetVersion = [version]"§gitwindows§"

#[script]
write-host "Determine GIT client"
#store download url and download path
$installerPath="c:\install\git-install.exe"

#The download filename changes based on the revision
#therefor determine version folder and filename based on the target version
#| Release Name                       | Version   | Version Folder    | Filename
#| ---------------------------------- | --------- | ----------------- | ----------------------- |
#| Git for Windows v2.53.0.windows.1  | 2.53.0.1  | v2.53.0.windows.1 | Git-2.53.0-64-bit.exe   |
#| Git for Windows 2.53.0(2)          | 2.53.0.2  | v2.53.0.windows.2 | Git-2.53.0.2-64-bit.exe |
$versionMajorMinorBuild = @($targetVersion.Major, $targetVersion.Minor, $targetVersion.Build) -Join '.'
$versionFolderName = "v$($versionMajorMinorBuild).windows.$($targetVersion.Revision)"
$versionFileName = $versionMajorMinorBuild
if ($targetVersion.Revision -gt 1) {
    $versionFileName += ".$($targetVersion.Revision)"
}
$versionFileName = "Git-$($versionFileName)-64-bit.exe"

#download git
mot asset download `
  --tool-id "gitwindows" `
  --source "github.com/git-for-windows/git/releases/download/$versionFolderName/$versionFileName" `
  --destination $installerPath

#install git
Start-Process -FilePath $installerPath -ArgumentList (
    "/VERYSILENT", `
    "/NORESTART", `
    "/NOCANCEL", `
    "/SP-", `
    "/CLOSEAPPLICATIONS", `
    "/RESTARTAPPLICATIONS", `
    "/o:PathOption=CmdTools", `
    "/o:BashTerminalOption=ConHost", `
    "/o:EnableSymlinks=Enabled"
) -Wait -PassThru

#disable interactive git credential manager (don't prompt users for input)
[Environment]::SetEnvironmentVariable("GCM_INTERACTIVE", "Never", [System.EnvironmentVariableTarget]::Machine)

#add git to path
$installationPath = "C:\Program Files\Git\bin"
Add-MachinePathItem $installationPath

#download installation file
Remove-Item $installerPath

#add git version to installed software list
$version = "$((& "$installationPath\git.exe" version).trim('git version'))"
Add-InstalledSoftwareEntry -Text "GIT $version"
Invoke-Mot docs applications add `
    --name "GIT" `
    --category "Tools" `
    --version $version `
    --artifact "$installationPath\git.exe" `
    --generate-hash

#tell agent to use GIT version we installed by setting property in \agent\.env file
#https://learn.microsoft.com/en-us/azure/devops/pipelines/agents/windows-agent?view=azure-devops#what-version-of-git-does-my-agent-run
Set-PropertyInEnvFile -Property 'System.PreferGitFromPath' -Value 'true'