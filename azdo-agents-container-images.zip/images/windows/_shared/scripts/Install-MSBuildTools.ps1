<#
.SYNOPSIS
    Install Visual Studio Build Tools
.DESCRIPTION
    Install Visual Studio Build Tools
.NOTES
    Specific component List based on https://learn.microsoft.com/en-us/visualstudio/install/build-tools-container?view=vs-2022
#>

#[includes]
. ..\helpers\InstallHelper.ps1

#[configuration]
$installationPath = "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools"
$installationConfig = "c:\install\.vsconfig"
$installTimeoutInMinutes = 30

#[functions]
function Wait-SetupCompletion {
    #wait until setup is finished
    try {
        $timeoutDeadline = (Get-Date).addminutes($installTimeoutInMinutes)
        Do {
            $timeNow = Get-Date
            if ($timeNow -ge $timeoutDeadline) {
                throw "[Error] Timeout occured after $installTimeoutInMinutes minute(s). Setup did not finish on time"
            } else {
                $setupStatus = Get-Process | Where-Object { $_.ProcessName -like "vs_*" -or $_.ProcessName -eq "setup" }
                Write-Output $($setupStatus | ForEach-Object { "`t$($_.ProcessName) (PID: $($_.Id))`n" })
                if ($setupStatus.Count -eq 0) {
                    Write-Output "Setup Finished"
                    break
                } else {
                    Write-Output "Setup Running"
                }
            }
            Start-Sleep -Seconds 10
        } Until ($timeNow -ge $timeoutDeadline)
    } catch {
        Write-Output "[Error] Unable to monitor setup. $($_.Exception.Message)"
        throw $_.Exception #rethrow error
    }
}

#[script]
$installerFileName = "vs_buildtools.exe"
$installerPath = Join-Path -Path "c:\install" -Child $installerFileName
try {
    Write-Output "Downloading $installerFileName"
    Invoke-WebRequest -uri https://aka.ms/vs/17/release/$installerFileName -OutFile $installerPath

    Write-Output "Execute modification"
    . $installerPath `
        --quiet `
        --norestart `
        --installPath $installationPath `
        --add Microsoft.VisualStudio.Workload.AzureBuildTools `
        --add Microsoft.Net.Component.4.8.1.SDK `
        --add Microsoft.Net.Component.4.8.1.TargetingPack `
        --add Microsoft.VisualStudio.Component.SQL.SSDTBuildSku `
        --remove Microsoft.VisualStudio.Component.Windows10SDK.10240 `
        --remove Microsoft.VisualStudio.Component.Windows10SDK.10586 `
        --remove Microsoft.VisualStudio.Component.Windows10SDK.14393 `
        --remove Microsoft.VisualStudio.Component.Windows81SDK `
        --includeRecommended

    Start-Sleep -Seconds 10 #allow setup process to spawn before monitoring if it is gone

    #wait until setup is finished
    Wait-SetupCompletion
} catch {
    Write-Output "[Error] Unable to start setup. $($_.Exception.Message)"
    throw $_.Exception #rethrow error
}
Write-Output "Finished Visual Studio Build Tools setup"


try {
    Write-Output "Export installation config"
    . $installerPath `
        export `
        --quiet `
        --installPath $installationPath `
        --config $installationConfig

    Start-Sleep -Seconds 10 #allow setup process to spawn before monitoring if it is gone

    #wait until export is completedz
    Wait-SetupCompletion
} catch {
    Write-Output "[Error] Unable to start setup. $($_.Exception.Message)"
    throw $_.Exception #rethrow error
}

$logFiles = Get-ChildItem $Env:Temp | Where-Object BaseName -like "dd_*"
Write-Output "Reading setup log files:"

foreach($log in $logFiles) {
    Write-Output "LOG - $($log.FullName)"
    Get-Content $log.FullName | Write-Output
    Write-Output "EOF - $($log.FullName)"
}

Write-Output "Finished Export of Visual Studio Build Tools setup"
Start-Sleep -Seconds 10 #wait a bit before reading the config file (because setup might still be writing to it)

if (Test-Path $installationConfig) {
    $configuration = Get-Content $installationConfig
    $configuration | Write-Output

    #verify SQL Server Data Tools installation by checking the exported config
    $config = $configuration | ConvertFrom-Json
    if ($config.components -contains "Microsoft.VisualStudio.Component.SQL.SSDTBuildSku") {
        Add-InstalledSoftwareEntry -Text "SQL Server Data Tools - Build Tools"
    } else {
        Write-Warning "##vso[task.logissue type=warning]SQL Server Data Tools installation failed"
    }
} else {
    #verify SQL Server Data Tools by checking if the folder exists
    $ssdtPath = Join-Path -Path "$installationPath" -Child "MSBuild\Microsoft\VisualStudio\v17.0\SSDT"
    if (Test-Path $ssdtPath) {
        Add-InstalledSoftwareEntry -Text "SQL Server Data Tools - Build Tools"
    } else {
        Write-Warning "##vso[task.logissue type=warning]SQL Server Data Tools installation failed"
    }
}

#add to path
$msbuildPath = "$installationPath\MSBuild\Current\Bin"
Add-MachinePathItem $msbuildPath

#verify MSBuild installation by getting MSBuild version
$version = ((& "$msbuildPath\MSBuild.exe" --version) | Select-String -Pattern "^\d+\.\d+\.\d+").ToString()
Add-InstalledSoftwareEntry -Text "MSBuild $version"
Invoke-Mot docs applications add `
    --name "MSBuild" `
    --category "Tools" `
    --version $version `
    --artifact "$msbuildPath\MSBuild.exe" `
    --generate-hash

#cleanup temporary setup file
Write-Output "Cleanup setup file"
if (Test-Path $installerPath) {
    Write-Output "Removing $installerPath"
    Remove-Item -Path $installerPath -Force
}
if (Test-Path $installationConfig) {
    Write-Output "Removing $installationConfig"
    Remove-Item -Path $installationConfig -Force
}
Get-ChildItem $Env:Temp | Where-Object BaseName -like "dd_*" | Remove-Item -Force