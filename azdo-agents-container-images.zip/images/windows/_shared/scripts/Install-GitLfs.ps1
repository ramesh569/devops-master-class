﻿<#
.SYNOPSIS
    Install Git LFS
.DESCRIPTION
    Install Git LFS
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$targetVersion = [version]"§git-lfs§"

#[script]
write-host "Determine GIT LFS client"

$installerPath="c:\install\git-lfs-install.exe"

mot asset download `
  --tool-id "git-lfs" `
  --source "github.com/git-lfs/git-lfs/releases/download/v$targetVersion/git-lfs-windows-v$targetVersion.exe" `
  --destination $installerPath

#install gi-lfs
Start-Process -FilePath $installerPath -ArgumentList (
        "/VERYSILENT", `
        "/NORESTART", `
        "/NOCANCEL", `
        "/SP-", `
        "/CLOSEAPPLICATIONS"
) -Wait -PassThru

#add git-lfs to path
$installationPath = "C:\Program Files\Git LFS"
Add-MachinePathItem $installationPath

#remove downloaded installation file
Remove-Item $installerPath

#add git version to installed software list
#returns git-lfs/3.7.1 (GitHub; windows amd64; go 1.25.1; git b84b3384)
$version = (& "$installationPath\git-lfs.exe" version | Select-String -Pattern "(\d+\.\d+\.\d+)").Matches.Value
Add-InstalledSoftwareEntry -Text "GIT LFS $version"
Invoke-Mot docs applications add `
    --name "GIT LFS" `
    --category "Tools" `
    --version $version `
    --artifact "$installationPath\git-lfs.exe" `
    --generate-hash