﻿<#
.SYNOPSIS
    Install Nexus IQ CLI
.DESCRIPTION
     Install Nexus IQ CLI
.NOTES
    The binaries are stored in the rabobank nexus repository
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error\
$targetFullVersion = "§nexus-iq§"
$versionPattern = "(\d+\.\d+\.\d+)-([0-9]+[+\+\d]*)"
$downloadUrlPattern = "https?://[^`"'\s<>]+/(nexus-iq-cli-$versionPattern-windows-x86_64\.zip)"

#[script]
$downloadZipName = "" #filled later
$shortVersion = "" #filled later

# determine what versions are available
try {
    $availablecontent = Invoke-WebRequest -Uri https://help.sonatype.com/iqserver/product-information/download-and-compatibility -UseBasicParsing
    $availablecontent.Content -match $downloadUrlPattern | Out-Null
    $latestDownloadUrl = $matches[0]
    $latestZipName = $matches[1]
    $latestShortVersion = $matches[2]
}
catch {
    Write-Output "There was an error in determining the latest version of Nexus CLI"
}

# determine what version to download based on provided value for version
if ($targetFullVersion -eq 'latest') {
    $downloadZipName = $latestZipName
    $nexusCliUrl = $latestDownloadUrl
    $shortVersion = $latestShortVersion
} else {
    $downloadZipName = "nexus-iq-cli-$targetFullVersion-windows-x86_64.zip";
    $nexusCliUrl = $latestDownloadUrl -replace [regex]::Escape($latestZipName), $downloadZipName

    # get the main version (for example 1.177.0 from entire zip which is for example 1.77.0-01+532)
    $targetFullVersion -match $versionPattern | Out-Null
    $shortVersion = $matches[1]

    #display warnings and errors about versions being available
    Test-IsLatestVersion -TargetVersion [version]$shortVersion -LatestVersion [version]$latestShortVersion -Name "Nexus CLI"
}

# set installation path and download url
$installFolder = "c:\install";
$nexusIqFolder = "c:\nexus-cli";

# Install the CLI
New-Item -ItemType directory -Path "$nexusIqFolder" -Force

Write-Host "Downloading NEXUS CLI from $nexusCliUrl"
Invoke-WebRequest -Uri $nexusCliUrl -OutFile "$installFolder\$downloadZipName"

Expand-Archive "$installFolder\$downloadZipName" -DestinationPath "$nexusIqFolder"


# Find the extracted Nexus IQ CLI directory (containing a 'bin' subdirectory)
$nexusIqCliDir = Get-ChildItem -Path $nexusIqFolder -Directory -Recurse | Where-Object { Test-Path (Join-Path $_.FullName 'bin') } | Select-Object -First 1
if ($null -eq $nexusIqCliDir) {
    Write-Error "Nexus IQ CLI directory with 'bin' subdirectory not found in $nexusIqFolder"
    exit 1
}

$nexusIqCliPath = Get-ChildItem -Path "$($nexusIqCliDir.FullName)\bin" -File |
    Where-Object { $_.BaseName -eq "nexus-iq-cli" -and $_.Extension -in ".exe", ".cmd", ".bat" } |
    Select-Object -First 1 -ExpandProperty FullName
if (-not $nexusIqCliPath) {
    Write-Error "Nexus IQ CLI executable not found"
    exit 1
}

# Set environment variables to the actual locations
setx NEXUSIQCLI_HOME "$($nexusIqCliDir.FullName)" /M
setx NEXUSIQCLI "$($nexusIqCliDir.FullName)\bin" /M

# Add both the directory and its 'bin' subdirectory to the PATH
Add-MachinePathItem "$($nexusIqCliDir.FullName)"
Add-MachinePathItem "$($nexusIqCliDir.FullName)\bin"

#cleanup temporary files
Remove-Item "$installFolder\$downloadZipName"

Add-InstalledSoftwareEntry -Text "Nexus CLI v$shortVersion"
Invoke-Mot docs applications add `
    --name "Nexus CLI" `
    --category "Tools" `
    --version $shortVersion `
    --artifact $nexusIqCliPath `
    --generate-hash
