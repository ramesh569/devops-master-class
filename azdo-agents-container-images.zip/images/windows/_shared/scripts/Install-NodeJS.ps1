﻿<#
.SYNOPSIS
    Install NodeJS
.DESCRIPTION
    Install NodeJS with with windows archive
.PARAMETER Versions
    Version to be installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
  [Parameter(Mandatory = $True)]
  [version]$TargetVersion
)

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$name = "NodeJS"
$toolsCacheDirectory = "c:\azp\agent\_work\_tool" #should match the AGENT_TOOLSDIRECTORY value set in the agent

#[script]
#disable progress bars to increase Invoke-WebRequest calls
$ProgressPreference = 'SilentlyContinue'
#determine what versions are available
$availableVersionsHtml = Invoke-WebRequest -Uri https://nodejs.org/dist -UseBasicParsing
$availableVersions = ($availableVersionsHtml.links | Select-Object -Property href | Select-String -pattern "([0-9]+\.*){2}[0-9]+").Matches.Value | ForEach-Object { [version]$_ }
$latestVersion = $availableVersions | Where-Object { $_ -gt $version -and $_.Major -eq $targetVersion.Major } | Sort-Object -Descending | Select-Object -First 1

#display warnings and errors about versions being available
Test-IsLatestVersion -TargetVersion $TargetVersion -LatestVersion $latestVersion -Name $name
Test-IsVersionListed -AvailableVersions $availableVersions -TargetVersion $TargetVersion -Name $name

#prepare installation directory
$targetDirectory = "$toolsCacheDirectory\node\$TargetVersion"
write-host "Creating $targetDirectory"
New-Item -Path $targetDirectory -ItemType Directory

#download
$installerPath = "C:\install\node-install.zip"
$downloadUrl = "https://nodejs.org/dist/v$($targetVersion.ToString())/node-v$($targetVersion.ToString())-win-x64.zip"
write-host "Download $name from: $downloadUrl"
Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath

write-host "Extract archive to $targetDirectory"
Expand-Archive -Path $installerPath -DestinationPath $targetDirectory

$intermediateFolder = Get-ChildItem $targetDirectory
write-host "Renaming intermediate folder to x64"
Rename-Item -Path $intermediateFolder.FullName -NewName x64

write-host "Number of files in $targetDirectory\x64"
(Get-ChildItem "$targetDirectory\x64").Count

write-host "Add NodeJS to environment Path variable"
Add-MachinePathItem "$targetDirectory\x64"

#add git version to installed software list
Add-InstalledSoftwareEntry -Text "NodeJS $TargetVersion"
Invoke-Mot docs applications add `
  --name "NodeJS" `
  --category "Frameworks" `
  --version $TargetVersion `
  --artifact "$targetDirectory\x64\node.exe" `
  --generate-hash

#remove installation file
write-host "Removing install file"
Remove-Item $installerPath

#flag installation complete
New-Item -Path "$targetDirectory\x64.complete" #indicate to tool cache this version is available

Write-Host "Finished Installation"

#Install pnpm
#Ensure Node.js and npm are installed
$npmPath = "$targetDirectory\x64\npm.cmd"
if (-Not (Test-Path $npmPath)) {
  Write-Error "npm not found at $npmPath."
  exit 1
}

#Use Nexus NPM
& $npmPath config set registry https://nexus01-eu-west-1.artifactcentral.aws.rabo.cloud/repository/npmjs-org/

#Install pnpm globally using npm
Write-Host "Installing pnpm globally using npm..."
& $npmPath install --verbose -g pnpm

#Get the actual global npm path
$globalNpm = & $npmPath config get prefix
$pnpmPath = Join-Path $globalNpm "pnpm.cmd"
write-host "PNPM installation path is: $pnpmPath"

#Verify installation
if (Test-Path $pnpmPath) {
  Write-Host "Add pnpm to environment Path variable"
  #Add PNPM to environment Path variable
  Add-MachinePathItem $globalNpm
  $pnpmVersion = & $pnpmPath --version
  Write-Host "pnpm installed successfully."
  #add pnpm version to installed software list
  Add-InstalledSoftwareEntry -Text "PNPM $pnpmVersion"
  Invoke-Mot docs applications add `
    --name "PNPM" `
    --category "Package Managers" `
    --version $pnpmVersion `
    --artifact "$pnpmPath" `
    --generate-hash
}
else {
  Write-Error "pnpm installation failed. File not found at $pnpmPath"
}