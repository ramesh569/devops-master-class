<#
.SYNOPSIS
    Script that is run when the agent starts
.DESCRIPTION
    This script runs as soon as a new agent is spun up.
    It checks that AZP_URL & AZP_TOKEN environmental variables are set
    If it's the placeholder agent, it registers it with the agent pool in DevOps but does not run so the agent stays offline
    If it is not the placeholder, it then finally runs the azure pipeline agent that will handle the pending job by listening for them and the agent shows as online in Azure DevOps
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error

# Relevant ENV variables
# AZURE_FEDERATED_TOKEN_FILE
# AZURE_CLIENT_ID
# AZURE_TENANT_ID
# AZURE_AUTHORITY_HOST

# This resource is the "Resource App Id" of the Azure Devops User Impersonation permission
# You can find it in the App Registration > API Permissions > user_impersonation > Popup window
# The .default is here because we are using the client credentials flow, and can not request concent
$Resource="499b84ac-1321-427f-aa17-267ca6975798/.default"

#[script]
if (-not (Test-Path Env:AZP_URL)) {
  Write-Error "error: missing AZP_URL environment variable"
  exit 1
}

if ((Test-Path Env:AZP_WORK) -and -not (Test-Path $Env:AZP_WORK)) {
  New-Item $Env:AZP_WORK -ItemType directory | Out-Null
}

# Let the agent ignore the token env variables
$Env:VSO_AGENT_IGNORE = "AZP_TOKEN,AZP_TOKEN_FILE,AZURE_FEDERATED_TOKEN,AZURE_FEDERATED_TOKEN_FILE,JWT_TOKEN,AZURE_CLIENT_ID,AZURE_TENANT_ID,AZURE_AUTHORITY_HOST"

Set-Location agent

function Get-AzureADToken() {
  $AzureFederatedToken=$(Get-Content ${Env:AZURE_FEDERATED_TOKEN_FILE})

  $tokenUrl = "https://login.microsoftonline.com/${Env:AZURE_TENANT_ID}/oauth2/token"
  $body = @{
    'resource'              = $Resource
    'client_id'             = ${Env:AZURE_CLIENT_ID}
    'grant_type'            = 'client_credentials'
    'client_assertion_type' = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
    'client_assertion'      = $AzureFederatedToken
  }

  $tokenResponse = Invoke-RestMethod -Method Post -Uri $tokenUrl -Body $body
  return $tokenResponse.access_token
}

Write-Host "Configuring Azure Pipelines agent..." -ForegroundColor Cyan
if ((Test-Path Env:REGISTER_PLACEHOLDER_AGENT) -and ($Env:REGISTER_PLACEHOLDER_AGENT -eq "yes")) {
  write-host "note: register placeholder agent but do not run"
  .\config.cmd --unattended `
    --agent "PlaceholderAgent" `
    --url "$(${Env:AZP_URL})" `
    --auth PAT `
    --token "$(Get-AzureADToken)" `
    --pool "$(if (Test-Path Env:AZP_POOL) { ${Env:AZP_POOL} } else { 'Default' })" `
    --work "$(if (Test-Path Env:AZP_WORK) { ${Env:AZP_WORK} } else { '_work' })" `
    --replace
  write-host "Placeholder agent registered. Container no longer required"
  exit 0
}

try
{
  .\config.cmd --unattended `
    --agent "$(if (Test-Path Env:AZP_AGENT_NAME) { ${Env:AZP_AGENT_NAME} } else { hostname })" `
    --url "$(${Env:AZP_URL})" `
    --auth PAT `
    --token "$(Get-AzureADToken)" `
    --pool "$(if (Test-Path Env:AZP_POOL) { ${Env:AZP_POOL} } else { 'Default' })" `
    --work "$(if (Test-Path Env:AZP_WORK) { ${Env:AZP_WORK} } else { '_work' })" `
    --replace

    Write-Host "Running Azure Pipelines agent..." -ForegroundColor Cyan

  # MIGA daemon startup
  $migaProcess = $null
  $migaLog = 'C:\ProgramData\miga\logs\miga.log'
  try {
    $migaExe = 'C:\tools\miga\miga.exe'
    $migaConfig = 'C:\ProgramData\miga\config.yaml'

    if (-not (Test-Path -LiteralPath $migaExe -PathType Leaf)) {
      throw "MIGA executable is missing: $migaExe"
    }

    $env:MIGA_CONFIG_FILE = $migaConfig
    $migaProcess = Start-Process `
      -FilePath $migaExe `
      -ArgumentList 'daemon', '--debug' `
      -WorkingDirectory 'C:\azp' `
      -PassThru `
      -ErrorAction Stop
    Sleep -Seconds 1

    Write-Host "MIGA daemon process launched with PID $($migaProcess.Id)."
  } catch {
    $startupError = $_.Exception.Message
    Write-Warning "MIGA daemon could not be launched. Error: $startupError"
  }

  # The daemon writes its log asynchronously; absence of the log must not stop the agent.
  if (Test-Path -LiteralPath $migaLog -PathType Leaf) {
    try {
      Write-Host "Current MIGA log content:"
      Get-Content -LiteralPath $migaLog -ErrorAction Stop | ForEach-Object { Write-Host $_ }
    } catch {
      Write-Warning "Could not read MIGA log: $($_.Exception.Message)"
    }
  } elseif ($migaProcess) {
    Write-Warning "MIGA has not written '$migaLog' yet."
  }
  #start the azdo agent but pass the handle back to the scropt
  $proc = Start-Process ".\run.cmd" -ArgumentList "--once" -PassThru

  #upgrade the azdo agent priority class to high
  (Get-Process -Id $proc.Id).PriorityClass = 'High'

  #wait for process to complete
  Wait-Process -Id $proc.Id
}
finally
{
  Write-Host "Cleanup. Removing Azure Pipelines agent..." -ForegroundColor Cyan
  .\config.cmd remove --unattended `
    --auth PAT `
    --token "$(Get-AzureADToken)"
}
write-host "Agent finished and removed from Azure DevOps. Container no longer required"
