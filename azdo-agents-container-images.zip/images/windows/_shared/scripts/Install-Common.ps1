﻿<#
.SYNOPSIS
    Perform and install all default actions and tools required for every image
.DESCRIPTION
    The following defaults are installed/configured
        - Create AzDevOps user
        - Azure DevOps Agent
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#[includes]
. ..\helpers\InstallHelper.ps1
. c:\install\content\helpers\VersionHelper.ps1

#[configuration]
$ErrorActionPreference = "Stop" #stop script on error
$accountName = 'AzDevOps' #this value is also defined in the scaledjob
$agentVersion=[version]"§azdo_agent§"

#[script]
write-host "Creating $accountName user"
New-LocalUser `
    -Name $accountName `
    -Description 'AzureDevOps Agent' `
    -NoPassword `
    -UserMayNotChangePassword > $null

write-host "Remove 'user must change password at next logon' for $accountName"
Set-LocalUser -Name $accountName -PasswordNeverExpires $true

write-host "Add $accountName to users group"
Add-LocalGroupMember -Member $accountName -Group Users

#installation of AzureDevOps client
write-host "Determine Azure DevOps client"

#prepare to download agent
$agentDownloadUrl = Get-GitHubDownloadUrl `
                                -RepoOwner 'microsoft' `
                                -RepoName 'azure-pipelines-agent' `
                                -ApplicationName 'Azure DevOps Client' `
                                -TargetVersion $agentVersion `
                                -ArtifactRegex 'https:\/\/.*pipelines-agent-win-x64.*\.zip'

$agentZipFileName = "agent.zip"
$agentDirectory = "\azp\agent"

write-host "Download Azure DevOps agent from: $agentDownloadUrl"
$wc = New-Object System.Net.WebClient
$wc.DownloadFile($agentDownloadUrl, "$(Get-Location)\$agentZipFileName")

write-host "Unpacking zip file"
New-Item $agentDirectory -ItemType directory | Out-Null
Expand-Archive -Path $agentZipFileName -DestinationPath $agentDirectory

Add-InstalledSoftwareEntry -Text "Azure DevOps Agent v$agentVersion"
Invoke-Mot docs applications add `
    --name "Azure DevOps Agent" `
    --category "Tools" `
    --version $agentVersion `
    --artifact "$agentDirectory\bin\Agent.Listener.exe" `
    --generate-hash

write-host "Removing zip file"
Remove-Item $agentZipFileName

$bundledGitPath="$agentDirectory\externals\git"
write-host "Removing outdated bundled version of GIT $bundledGitPath"
Remove-Item $bundledGitPath -Recurse -Force

