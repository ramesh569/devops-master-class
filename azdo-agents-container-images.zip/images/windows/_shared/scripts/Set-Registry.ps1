<#
.Synopsis
    Set Registry Keys
.DESCRIPTION
    Set Registry Keys for different purposes including security hardening
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

#add resgitry keys
$registrySettings = @(
    #patch vulnerability https://msrc.microsoft.com/update-guide/vulnerability/CVE-2013-3900
    @{Path = "HKLM:\Software\Microsoft\Cryptography\Wintrust\Config"; Name = "EnableCertPaddingCheck"; Value = 1; PropertyType = "DWORD" }
    @{Path = "HKLM:\Software\Wow6432Node\Microsoft\Cryptography\Wintrust\Config"; Name = "EnableCertPaddingCheck"; Value = 1; PropertyType = "DWORD" }

    #patch vulnerability SMB Signing Disabled or SMB Signing Not Required
    @{Path = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"; Name = "RequireSecuritySignature"; Value = 1; PropertyType = "DWORD" }
    @{Path = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"; Name = "RequireSecuritySignature"; Value = 1; PropertyType = "DWORD" }

    #patch vulnerability https://nvd.nist.gov/vuln/detail/CVE-2002-1117
    @{Path = "HKLM:\SYSTEM\CurrentControlSet\Control\LSA"; Name = "RestrictAnonymous"; Value = 1; PropertyType = "DWORD" }
    @{Path = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"; Name = "RestrictNullSessAccess"; Value = 1; PropertyType = "DWORD" }
)

$overviewText = ""
ForEach($registrySetting in $registrySettings) {
    $regPath = $registrySetting.Path
    write-host $regPath
    if (-not (Test-Path $regPath)) {
        write-host "`tPath doesn't exist, creating path"
        New-Item -Path $regPath -Force -ErrorAction Continue | Out-Null
    }
    write-host "`tAdding key $($registrySetting.Name):$($registrySetting.Value)"

    New-ItemProperty @registrySetting -Force -ErrorAction Continue | Out-Null
    $overviewText += "$(Join-Path $registrySetting.Path $registrySetting.Name):$((Get-ItemProperty -path $registrySetting.Path).$($registrySetting.Name))`n"
}

write-host "Listing all modified registry keys"
write-host $overviewText
write-host "Script completed"