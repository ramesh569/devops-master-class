<#
.SYNOPSIS
    Functions to help install or document installations
.DESCRIPTION
    Functions to
    * Set Environment Path
    * Create entry for installed software list
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

$InstalledSoftwareListPath = "c:\install\InstalledSoftware.txt"
$MOTInstalledSoftwareListPath = "c:\install\documentation.json"

function Invoke-Mot {
    & mot @args
    if ($LASTEXITCODE -ne 0) {
        throw "MOT command failed ($LASTEXITCODE): $($args -join ' ')"
    }
}

function Add-InstalledSoftwareEntry() {
    param(
        [string]$Text
    )
    write-host "Adding '$Text' to Installed Software list"
    Add-Content -Path $InstalledSoftwareListPath -Value $Text
}

function Get-InstalledSoftwareManifest() {
    if (!(Test-Path($InstalledSoftwareListPath))) {
        throw "Installed Software list not found at '$InstalledSoftwareListPath'"
    }
    return Get-Content $InstalledSoftwareListPath
}

function Get-InstalledSoftwareManifestMOTPath() {
    return $MOTInstalledSoftwareListPath
}

function Connect-Hive {
    param(
        [string]$FileName = "C:\Users\Default\NTUSER.DAT",
        [string]$SubKey = "HKLM\DEFAULT"
    )

    Write-Host "Loading the file $FileName to the Key $SubKey"
    if (Test-Path $SubKey.Replace("\",":")) {
        return
    }

    $result = reg load $SubKey $FileName *>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Failed to load hive: $result"
        exit 1
    }
}

function Disconnect-Hive {
    param(
        [string]$SubKey = "HKLM\DEFAULT"
    )

    Write-Host "Unloading the hive $SubKey"
    if (-not (Test-Path $SubKey.Replace("\",":"))) {
        return
    }

    $result = reg unload $SubKey *>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Failed to unload hive: $result"
        exit 1
    }
}

function Get-SystemVariable {
    param(
        [string]$SystemVariable
    )

    [System.Environment]::GetEnvironmentVariable($SystemVariable, "Machine")
}

function Get-DefaultVariable {
    param(
        [string]$DefaultVariable,
        [string]$Name = "DEFAULT\Environment",
        [bool]$Writable = $false
    )

    $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Name, $Writable)
    $key.GetValue($DefaultVariable, "", "DoNotExpandEnvironmentNames")
    $key.Handle.Close()
    [System.GC]::Collect()
}

function Set-SystemVariable {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [string]$SystemVariable,
        [string]$Value
    )

    if ($PSCmdlet.ShouldProcess("Environment Variable", "Set variable $SystemVariable")) {
        Write-Host "Setting Environment Variable '$SystemVariable' to '$Value'"
        [System.Environment]::SetEnvironmentVariable($SystemVariable, $Value, "Machine")
    }
    Get-SystemVariable $SystemVariable
}

function Set-DefaultVariable {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [string]$DefaultVariable,
        [string]$Value,
        [string]$Name = "DEFAULT\Environment",
        [string]$Kind = "ExpandString",
        [bool]$Writable = $true
    )

    if ($PSCmdlet.ShouldProcess("Default Variable", "Set value $DefaultVariable")) {
        $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Name, $Writable)
        $key.SetValue($DefaultVariable, $Value, $Kind)
        Get-DefaultVariable -DefaultVariable $DefaultVariable -Name $Name
        $key.Handle.Close()
        [System.GC]::Collect()
    }
}

function Get-MachinePath {
    Get-SystemVariable PATH
}

function Get-DefaultPath {
    Get-DefaultVariable Path
}

function Set-MachinePath {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [string]$NewPath
    )

    if ($PSCmdlet.ShouldProcess("Machine PATH Environment Variable", "Set value $NewPath")) {
        Write-Host "Setting Machine Path to '$NewPath'"
        # update system variable (persistant across sessions)
        Set-SystemVariable PATH $NewPath

        # update current powershell session
        $env:Path = $NewPath
    }
}

function Set-DefaultPath {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [string]$NewPath
    )

    if ($PSCmdlet.ShouldProcess("PATH Environment Variable", "Set value $NewPath")) {
        Write-Host "Setting Default Path to '$NewPath'"
        Set-DefaultVariable PATH $NewPath
    }
}

function Test-MachinePath {
    param(
        [string]$PathItem
    )

    $pathItems = (Get-MachinePath).Split(';')
    $pathItems.Contains($PathItem)
}

function Add-MachinePathItem {
    param(
        [string]$PathItem
    )

    $currentPath = Get-MachinePath
    $newPath = $PathItem + ';' + $currentPath
    Set-MachinePath -NewPath $newPath
}

function Add-DefaultPathItem {
    param(
        [string]$PathItem
    )

    Connect-Hive
    $currentPath = Get-DefaultPath
    $newPath = $PathItem + ';' + $currentPath
    Set-DefaultPath -NewPath $newPath
    Disconnect-Hive
}

function Add-DefaultItem {
    param(
        [string]$DefaultVariable,
        [string]$Value,
        [string]$Name = "DEFAULT\Environment",
        [string]$Kind = "ExpandString",
        [bool]$Writable = $true
    )

    Connect-Hive
    $regPath = Join-Path "HKLM:\" $Name
    if (-not (Test-Path $Name)) {
        Write-Host "Creating $regPath key"
        New-Item -Path $regPath -Force | Out-Null
    }
    Set-DefaultVariable -DefaultVariable $DefaultVariable -Value $Value -Name $Name -Kind $Kind -Writable $Writable
    Disconnect-Hive
}

function New-ItemPath {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [string]$Path
    )

    if (-not (Test-Path $Path)) {
        if ($PSCmdlet.ShouldProcess("Create Path $Path")) {
            New-Item -Path $Path -Force -ErrorAction Ignore | Out-Null
        }

    }
}

<#
.SYNOPSIS
    Test if command is available
    Return true if available otherwise return false
.DESCRIPTION
    Test if command is available in one of the path folders
#>
Function Test-Command {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [string]$Command
    )

    $currentActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'stop' #avoid exit by the error thrown at get-command (when the executable is not found)
    try {
        if(Get-Command $Command) {
            return $true
        }
    }
    catch { # catch is required because get-command returns a message and throws an error
        return $false
    } finally {
        #revert to prevous error action preference
        $ErrorActionPreference = $currentActionPreference
    }
}

<#
.SYNOPSIS
    Set Property in agent environment file
.DESCRIPTION
    Set Property in \agent\.env file
    If file doesn't exist it is created
#>
function Set-PropertyInEnvFile() {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory=$true)]
        [string]$Property,

        [Parameter(Mandatory=$true)]
        [string]$Value
    )
    $envFilePath = "C:\azp\agent\.env"
    $lineToAdd = "$Property=$Value"
    Write-Host "Adding property '$Property' to .env file"
    if (!(Test-Path($envFilePath))) {
        New-Item -Path $envFilePath -ItemType File -Value $lineToAdd
        return
    }

    $newDocument = ""
    foreach($line in Get-Content -Path $envFilePath) {
        if ($line -like "$Property=*") {
            if ($line -eq $lineToAdd) {
                write-host "[skip]Property '$property' already set to '$Value'"
            } else {
                write-host "Property Change:`n`tOld:$line`n`tNew:$lineToAdd"
                $line = $lineToAdd
            }
        }
        $newDocument += "$line`n"
    }
    if ($PSCmdlet.ShouldProcess($newDocument, "Set content")) {
        Set-Content -Path $envFilePath -Value $newDocument
    }
}

write-host "Install Helpers loaded"
