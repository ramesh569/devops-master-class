# Introduction
This folder contains scripts that should be copied to the image as-is and contains things such as
public certificates and default package manager configurations

Content for this folder is copied FROM azdo-agents-shared repo by referencing (azdo-agents-shared\tasks\copy-agent-content-task.yml) in azdo-agents-container-images\images\_shared\jobs\stage-build.yml
Content of this folder is copied TO the agent image (see Dockerfile)

# Guidance
Only files specific to container images should be stored in the local folder
files that are relevant to both container images and vmss images should be stored in azdo-agents-shared repo

