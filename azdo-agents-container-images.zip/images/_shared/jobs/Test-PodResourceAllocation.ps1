<#
.SYNOPSIS
    Verify kubernetes resource allocation
.DESCRIPTION
    Verify kubernetes resource allocation based on pipeline definition file
.PARAMETER Pathh
    Pipeline definition file to be verified
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$Path
)

#[Configuration]
$allowedPhaseNames = @(
    'agentPoolsDevPhase',
    'agentPoolsTestPhase',
    'agentPoolsProductionPhase'
)

#[functions]
function Test-File {
    param (
        [Parameter(Mandatory=$true)]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [string] $Name
    )
    write-host "Testing if '$Name' exists at location '$Path'"
    if (!(Test-Path($Path))) {
        throw "$Name File could not be found at $Path"
    }
}


function Test-ResourceAllocation {
    param (
        $FirstPool,
        $SecondPool,
        [int] $IssueCount
    )

    #if either pool is not defined, return the issue count as it was
    if (!$FirstPool -or !$SecondPool) { return $IssueCount }

    if ($FirstPool.podCpuLimit -gt $SecondPool.podCpuLimit) {
        Write-Warning "CPU limit for '$($FirstPool.azdoAgentPoolName)' is greater than '$($SecondPool.azdoAgentPoolName)'. Check your configuration"
        $IssueCount++
    }
    if ($FirstPool.podMemoryLimit -gt $SecondPool.podMemoryLimit) {
        Write-Warning "Memory limit for '$($FirstPool.azdoAgentPoolName)' is greater than '$($SecondPool.azdoAgentPoolName)'. Check your configuration"
        $IssueCount++
    }

    return $IssueCount
}

#[Script]
Test-File -Path $Path -Name "Pipeline definition"

write-host "Installing powershell-yaml"
Install-Module -Name powershell-yaml -Scope CurrentUser -Force

#get pipeline definition
$pipelineDefinition = (Get-Content $Path) | ConvertFrom-Yaml

$issueCount=0

$agentPools = @()

foreach($environment in $pipelineDefinition.extends.parameters.deployments) {
    write-host "$($environment.environmentName)"
    foreach($phase in $environment.Keys | Where-Object { $_ -like "*Phase" }) {
        write-host "`t$($phase)"

        if ($allowedPhaseNames -notcontains $phase) {
            Write-Warning "Phase name '$phase' not allowed. Check spelling"
            $issueCount++
        }

        foreach($agentPool in $environment.$phase) {
            write-host "`t`t$($agentPool.azdoAgentPoolName) ($($agentPool.azdoOrganization) | $($environment.environmentName)\$phase)"

            #check if agent pool is already associated with another scaled job in the same azdoOrganization
            if ($agentPools | Where-Object { $_.azdoAgentPoolName -eq $agentPool.azdoAgentPoolName -and $_.azdoOrganization -eq $agentPool.azdoOrganization }) {
                Write-Warning "Agent pool '$($agentPool.azdoAgentPoolName)' is already associated with another scaled job in the same azdoOrganization. Check your configuration"
                $issueCount++
            } else {
                $agentPools += $agentPool
            }
        }

        if ($clusterCount -eq 0) {
            Write-Warning "Phase name '$phaseName' doesn't have a cluster configuration, define cluster A config"
            $issueCount++
        }
    }
}

write-host "Verifying resource allocation across agent pool groups"
foreach($organization in ($agentPools.azdoOrganization | Select-Object -Unique)) {
    write-host "$($organization)"

    $organizationPools = $agentPools | Where-Object { $_.azdoOrganization -eq $organization }
    $organizationPoolGroups = $organizationPools.azdoAgentPoolName.TrimEnd('[Dev|Test|Prod]').TrimEnd('-') | Select-Object -Unique

    foreach($agentPoolGroup in $organizationPoolGroups) {
        write-host "`t$($agentPoolGroup)"
        $devPool = $organizationPools | Where-Object { $_.azdoAgentPoolName -eq "$($agentPoolGroup)-Dev" }
        $testPool = $organizationPools | Where-Object { $_.azdoAgentPoolName -eq "$($agentPoolGroup)-Test" }
        $prodPool = $organizationPools | Where-Object { $_.azdoAgentPoolName -eq "$($agentPoolGroup)-Prod" }

        #generate warning if dev pool has more resources than test pool
        $issueCount = Test-ResourceAllocation -FirstPool $devPool -SecondPool $testPool -IssueCount $issueCount

        #generate warning if dev or test pool has more resources than production pool
        $issueCount = Test-ResourceAllocation -FirstPool $devPool -SecondPool $prodPool -IssueCount $issueCount
        $issueCount = Test-ResourceAllocation -FirstPool $testPool -SecondPool $prodPool -IssueCount $issueCount
    }
}

write-host "Verification complete"
if ($issueCount -gt 0) {
    Write-Host "##vso[task.logissue type=warning]Configuration issues on image pipeline.yml See logging for more detail"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}

 write-host "Resource allocation validation completed"