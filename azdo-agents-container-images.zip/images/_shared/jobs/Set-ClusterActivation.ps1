[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ClusterName,

    [Parameter(Mandatory=$true)]
    [ValidateSet('Activate','Deactivate')]
    [string]$Action
)
#[Functions]
. $PSScriptRoot\Functions-Keda.ps1

#[Script]
write-host "ClusterName: $ClusterName"
write-host "Action: $Action"

if ($Action -eq 'Activate') {
  write-host "Activating non-canary jobs on cluster $ClusterName"
  if (-not (ActivateClusterNonCanaryJobs -Name $ClusterName)) {
    throw "Failed to activate non-canary ScaledJobs for cluster '$ClusterName'."
  }
} else {
  Write-Host "Deactivating non-canary jobs on cluster $ClusterName"
  if (-not (DeactivateClusterNonCanaryJobs -Name $ClusterName)) {
    throw "Failed to deactivate non-canary ScaledJobs for cluster '$ClusterName'."
  }
}
