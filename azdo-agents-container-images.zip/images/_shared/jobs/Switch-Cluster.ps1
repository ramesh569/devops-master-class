[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$DestinationClusterName
)

. $PSScriptRoot\Functions-Keda.ps1

Switch-ClusterNonCanaryJobs -DestinationName $DestinationClusterName
