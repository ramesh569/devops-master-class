#!/bin/bash -e

echo "# Creating Enterprise Application (Service Principal) for app registration $AZURE_APP_REGISTRATION_ID"
if ! sp_result=$(az ad sp show --id "$AZURE_APP_REGISTRATION_ID"); then
  if [ "$CREATE_IF_MISSING" != "true" ]; then
    echo "Enterprise application for $AZURE_APP_REGISTRATION_ID does not exist and image infrastructure deployment is disabled"
    exit 1
  fi

  echo "Enterprise application not found, creating..."
  sp_result=$(az ad sp create --id "$AZURE_APP_REGISTRATION_ID")
else
  echo "Enterprise application already exists, skipping..."
fi

sp_id=$(echo "$sp_result" | jq -r '.id')

echo "# Setting task variable azureServicePrincipalId to $sp_id"
echo "##vso[task.setvariable variable=azureServicePrincipalId;isOutput=true]$sp_id"