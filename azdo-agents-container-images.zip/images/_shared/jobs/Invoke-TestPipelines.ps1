<#
.SYNOPSIS
    Trigger Multiple Pipelines based on configuration
.DESCRIPTION
    Trigger each pipeline listed in provided file
.PARAMETER TestPipelinesConfigPath
    Path to file containing pipelines to be triggered (file should meet validation requirements of RegressionTest.xsd)
.PARAMETER TimeoutInMinutes
    Maximum time to wait for all triggered pipelines to complete
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $TestPipelinesConfigPath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $RegressionTestAgentPool,

    [Parameter(Mandatory=$true)]
    [ValidateRange(1, 60)]
    [int]$TimeoutInMinutes
)

#[Configuration]
$ErrorActionPreference = "Stop" #stop script on error
$ValidationSchemaFilePath = "$PSScriptRoot\RegressionTest.xsd"
$checkFrequencyInSeconds = 30

#[Classes]
enum TechnicalResult {
    Pending
    Succeeded
    Failed
}

enum FunctionalResult {
    NotRun
    Passed
    Failed
    PartiallySucceeded
}

class RegressionPipelineResult {
    [string]$Name
    [string]$StatusApiUrl
    [string]$ResultUrl
    [string]$RunStatus
    [TechnicalResult]$TechnicalResult
    [FunctionalResult]$FunctionalResult
    [string]$TechnicalMessage

    RegressionPipelineResult([string]$Name, [string]$StatusApiUrl, [string]$ResultUrl) {
        $this.Name = $Name
        $this.StatusApiUrl = $StatusApiUrl
        $this.ResultUrl = $ResultUrl
        $this.RunStatus = 'NotStarted'
        $this.TechnicalResult = [TechnicalResult]::Pending
        $this.FunctionalResult = [FunctionalResult]::NotRun
        $this.TechnicalMessage = ''
    }
}

#[functions]
<#
.SYNOPSIS
    Test if file exists
.DESCRIPTION
    Test if file exists and throws error if file doesn't exist using the name to indicate which file is missing
.PARAMETER Path
    Location file is to be expected
.PARAMETER Name
    Descriptive name of the file to be checked
#>
function Test-File {
    param (
        [Parameter(Mandatory=$true)]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [string] $Name
    )
    if (!(Test-Path($Path))) {
        throw "$Name File could not be found at $Path"
    }
}

<#
.SYNOPSIS
    Validates an xml file against an xml schema file.
.Note
    Downloaded from https://stackoverflow.com/questions/822907/how-do-i-use-powershell-to-validate-xml-files-against-an-xsd
.Example
    PS> dir *.xml | Test-XmlFile schema.xsd
#>
function Test-XmlFile
{
    [CmdletBinding()]
    [OutputType('System.Boolean')]
    param (
        [Parameter(Mandatory=$true)]
        [string] $SchemaFile,

        [Parameter(ValueFromPipeline=$true, Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [alias('Fullname')]
        [string] $XmlFile,

        [scriptblock] $ValidationEventHandler = { Write-Error $args[1].Exception }
    )

    begin {
        $schemaReader = New-Object System.Xml.XmlTextReader $SchemaFile
        $schema = [System.Xml.Schema.XmlSchema]::Read($schemaReader, $ValidationEventHandler)
    }

    process {
        $ret = $true
        try {
            $xml = New-Object System.Xml.XmlDocument
            $xml.Schemas.Add($schema) | Out-Null
            $xml.Load($XmlFile)
            $xml.Validate({
                    throw ([PsCustomObject] @{
                        SchemaFile = $SchemaFile
                        XmlFile = $XmlFile
                        Exception = $args[1].Exception
                    })
                })
        } catch {
            Write-Error $_
            $ret = $false
        }
        $ret
    }

    end {
        $schemaReader.Close()
    }
}

<#
.SYNOPSIS
    Get Pipelines Configuration
.DESCRIPTION
    Get Pipelines Configuration from XML File
.PARAMETER ConfigPath
    Path of configuration file (XML)
#>
function Get-PipelinesFromConfig() {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ConfigPath
    )

    #read xml document
    [xml]$pipelinesDocument = Get-Content -Path $ConfigPath

    #return pipelines as array
    return $pipelinesDocument.pipelines.pipeline
}

function Get-FailedTestCaseTemplate() {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Name,

        [Parameter(Mandatory=$true)]
        [ValidateSet("technical", "pipeline")]
        [string]$FailureType,

        [Parameter(Mandatory=$true)]
        [string]$FailureMessage
    )

    $escapedName = [System.Security.SecurityElement]::Escape($Name)
    $escapedFailureMessage = [System.Security.SecurityElement]::Escape($FailureMessage)
    return "`t`t<testcase name='$escapedName'>`n" ` +
           "`t`t`t<failure type='$FailureType' message='$escapedFailureMessage' />`n" ` +
           "`t`t</testcase>`n"
}

function New-TestReport() {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory=$true)]
        [RegressionPipelineResult[]]$Results,

        [Parameter(Mandatory=$true)]
        [string]$AgentPoolName
    )

    $failedCount = ($Results | Where-Object { $_.TechnicalResult -eq [TechnicalResult]::Failed -or $_.FunctionalResult -ne [FunctionalResult]::Passed } | Measure-Object).Count
    $testReport = "<testsuites tests='$($Results.Count)' failures='$failedCount'>`n"
    $testReport += "`t<testsuite name='$([System.Security.SecurityElement]::Escape($AgentPoolName)) Tests' tests='$($Results.Count)' failures='$failedCount'>`n"
    foreach ($result in $Results) {
        if ($result.TechnicalResult -eq [TechnicalResult]::Failed) {
            $testReport += Get-FailedTestCaseTemplate -Name $result.Name -FailureType technical -FailureMessage $result.TechnicalMessage
        } elseif ($result.FunctionalResult -ne [FunctionalResult]::Passed) {
            $failureMessage = "regression test result: $($result.FunctionalResult) (link: $($result.ResultUrl))"
            $testReport += Get-FailedTestCaseTemplate -Name $result.Name -FailureType pipeline -FailureMessage $failureMessage
        } else {
            $escapedName = [System.Security.SecurityElement]::Escape($result.Name)
            $testReport += "`t`t<testcase name='$escapedName' />`n"
        }
    }
    $testReport += "`t</testsuite>`n</testsuites>`n"

    if ($PSCmdlet.ShouldProcess("pipeline-tests.xml")) {
        $testReport | Out-File -FilePath "pipeline-tests.xml"
    }
}


#[script]
$token = az account get-access-token
$accessToken = ($token | ConvertFrom-Json).accessToken
$authorizationHeader = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$accessToken"))

#test if files exist
Test-File -Path $TestPipelinesConfigPath -Name "Regression Test Configuration"
Test-File -Path $ValidationSchemaFilePath -Name "Regression Test Configuration Validation"

write-host "Validate Regression Test Config"
#test XML validity against XSD
$xsdTest = Test-XmlFile -SchemaFile (Get-Item $ValidationSchemaFilePath).FullName -XmlFile $TestPipelinesConfigPath
if ($xsdTest -eq $true) {
    Write-Host "XSD Validation Completed"
} else {
    Write-Host "XSD Validation Failed"
}

$pipelines = @(Get-PipelinesFromConfig -ConfigPath $TestPipelinesConfigPath)
$pipelineCount = $pipelines.Count
if ($pipelineCount -eq 0) {
    throw "Regression test configuration contains no pipelines"
}

$pipelineResults = @()
$count = 0
foreach($pipeline in $pipelines) {
    $count++

    #convert definition URL to API link
    $uriQueuePipeline =  $pipeline.url.replace("_build?definitionId=","_apis/pipelines/") + '/runs?api-version=6.0-preview.1'

    #print pipeline being started
    write-host "$count/$pipelineCount Starting Pipeline: `n Pipeline Definition: $($pipeline.url)`n Pipeline Trigger: $uriQueuePipeline"
    if ($pipeline.branch) {
        write-host " Branch: $($pipeline.branch)"
    } else {
        write-host " Branch: default"
    }

    $requestBodyPsObject = New-Object -TypeName PSCustomObject

    #add branch target if specified
    if ($pipeline.branch) {
        $resources = [PSCustomObject]@{
            repositories = [PSCustomObject]@{
                self = [PSCustomObject]@{
                    refName = $pipeline.branch
                }
            }
        }
        $requestBodyPsObject | Add-Member -MemberType NoteProperty -Name resources -Value $resources
    }

    #add properties if specified
    $paramList = New-Object -TypeName PSCustomObject
    $paramList | Add-Member -MemberType NoteProperty -Name AgentPool -Value $RegressionTestAgentPool

    if ($pipeline.parameters.parameter) {
        #check if there is multiple parameters
        if ($pipeline.parameters.parameter.count) {
            #multiple parameters
            for($index = 0; $index -lt $pipeline.parameters.parameter.count; $index++) {
                $paramList | Add-Member -MemberType NoteProperty -Name $pipeline.parameters.parameter[$index].name -Value $pipeline.parameters.parameter[$index].value
            }
        } else {
            #single parameter
            $paramList | Add-Member -MemberType NoteProperty -Name $pipeline.parameters.parameter.name -Value $pipeline.parameters.parameter.value
        }
    }

    $requestBodyPsObject | Add-Member -MemberType NoteProperty -Name templateParameters -Value $paramList

    #convert powershell object to json
    $requestBodyJson = $requestBodyPsObject | ConvertTo-Json -Depth 4 #add increased depth to avoid properties being cut-off

    try {
        $result = Invoke-RestMethod `
            -Method Post `
            -Uri $uriQueuePipeline `
            -Headers @{Authorization = $authorizationHeader } `
            -ContentType 'application/json' `
            -Body $requestBodyJson
    } catch {
        $pipelineResult = [RegressionPipelineResult]::new($pipeline.url, '', $pipeline.url)
        $pipelineResult.TechnicalResult = [TechnicalResult]::Failed
        $pipelineResult.TechnicalMessage = "pipeline could not be triggered: $($_.Exception.Message)"
        $pipelineResults += $pipelineResult
        Write-Host " Error: Pipeline could not be triggered: $($_.Exception.Message)"
        continue
    }

    $pipelineName = $result.pipeline.Name

    #determine user friendly result URL
    #example: https://dev.azure.com/raboweb/TAS/_build/results?buildId=3509293
    $pipelineResultUserFriendlyUrl = "$($pipeline.url.split('?')[0])/results?buildId=$($result.id)"
    write-host " Results: $pipelineResultUserFriendlyUrl"

    #determine result API URL
    #example: https://dev.azure.com/raboweb/TAS/_apis/build/builds/3509293?api-version=6.0
    $pipelineResultAPIUrl = "$(($result.url -split('_apis/pipelines'))[0])_apis/build/builds/$($result.id)?api-version=6.0"

    $pipelineResult = [RegressionPipelineResult]::new($pipelineName, $pipelineResultAPIUrl, $pipelineResultUserFriendlyUrl)
    $pipelineResult.RunStatus = $result.state
    $pipelineResults += $pipelineResult
}

# All pipelines are being queued
Write-Host "All regression test pipelines have been queued. Waiting 10 seconds before starting to poll their status."
Start-Sleep -Seconds 10

# All pipelines are queued before polling starts, so their runs proceed in parallel.
$timeoutDeadline = (Get-Date).AddMinutes($TimeoutInMinutes)
Write-Host "Waiting up to $TimeoutInMinutes minute(s) for $($pipelineResults.Count) regression test pipeline(s) to complete."

while ($true) {
    $incompletePipelines = @() # reset each run of checks

    foreach ($pipelineResult in $pipelineResults | Where-Object { $_.TechnicalResult -eq [TechnicalResult]::Pending }) {
        try {
            $response = Invoke-RestMethod `
                -Method Get `
                -Uri $pipelineResult.StatusApiUrl `
                -Headers @{Authorization = $authorizationHeader } `
                -ContentType 'application/json'

            $pipelineResult.RunStatus = $response.status
            $pipelineResult.TechnicalMessage = ''

            if ($pipelineResult.RunStatus -eq 'completed') {
                switch ($response.result) {
                    'succeeded' {
                        $pipelineResult.TechnicalResult = [TechnicalResult]::Succeeded
                        $pipelineResult.FunctionalResult = [FunctionalResult]::Passed
                    }
                    'partiallySucceeded' {
                        $pipelineResult.TechnicalResult = [TechnicalResult]::Succeeded
                        $pipelineResult.FunctionalResult = [FunctionalResult]::PartiallySucceeded
                    }
                    'failed' {
                        $pipelineResult.TechnicalResult = [TechnicalResult]::Succeeded
                        $pipelineResult.FunctionalResult = [FunctionalResult]::Failed
                    }
                    default {
                        $pipelineResult.TechnicalResult = [TechnicalResult]::Failed
                        $pipelineResult.FunctionalResult = [FunctionalResult]::NotRun
                        $pipelineResult.TechnicalMessage = "pipeline completed with unsupported result '$($response.result)' (link: $($pipelineResult.ResultUrl))"
                    }
                }
            }
        } catch {
            $pipelineResult.TechnicalMessage = "status unavailable: $($_.Exception.Message)"
        }

        if ($pipelineResult.TechnicalResult -eq [TechnicalResult]::Pending) {
            $status = if ($pipelineResult.TechnicalMessage) { $pipelineResult.TechnicalMessage } else { $pipelineResult.RunStatus }
            $incompletePipelines += "$($pipelineResult.Name) ($status)"
        }
    }

    if ($incompletePipelines.Count -eq 0) {
        Write-Host "All regression test pipelines have completed."
        break
    }

    $timeNow = Get-Date
    if ($timeNow -ge $timeoutDeadline) {
        foreach ($pipelineResult in $pipelineResults | Where-Object { $_.TechnicalResult -eq [TechnicalResult]::Pending }) {
            $pipelineResult.TechnicalResult = [TechnicalResult]::Failed
            $pipelineResult.FunctionalResult = [FunctionalResult]::NotRun
            $pipelineResult.TechnicalMessage = "timeout after $TimeoutInMinutes minute(s), pipeline status: $($pipelineResult.RunStatus) (link: $($pipelineResult.ResultUrl))"
        }
        Write-Host "Timeout reached. Incomplete pipelines: $($incompletePipelines -join ', ')"
        break
    }

    $timeLeft = New-TimeSpan -Start $timeNow -End $timeoutDeadline
    $sleepDurationInSeconds = [Math]::Min($checkFrequencyInSeconds, [Math]::Max(1, [Math]::Ceiling($timeLeft.TotalSeconds)))
    Write-Host "Waiting for: $($incompletePipelines -join ', '). Retry in $sleepDurationInSeconds seconds. Timeout in $timeLeft"
    Start-Sleep -Seconds $sleepDurationInSeconds
}

foreach ($pipelineResult in $pipelineResults) {
    Write-Host "$($pipelineResult.Name) [$($pipelineResult.ResultUrl)]"
    Write-Host "`tTechnical result: $($pipelineResult.TechnicalResult)"
    Write-Host "`tFunctional result: $($pipelineResult.FunctionalResult)"
    if ($pipelineResult.TechnicalMessage) {
        Write-Host "`tTechnical message: $($pipelineResult.TechnicalMessage)"
    }
}

New-TestReport -Results $pipelineResults -AgentPoolName $RegressionTestAgentPool

if ($pipelineResults | Where-Object { $_.TechnicalResult -eq [TechnicalResult]::Failed }) {
    Write-Host "Validation completed with technical errors. See messages above"
    Write-Host "##vso[task.complete result=Failed;]"
    exit 1
} elseif ($pipelineResults | Where-Object { $_.FunctionalResult -ne [FunctionalResult]::Passed }) {
    Write-Host "Validation completed but not all test pipelines succeeded. See messages above"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
} else {
    Write-Host "Validation completed. All tests passed"
    Write-Host "##vso[task.complete result=Succeeded;]"
}

