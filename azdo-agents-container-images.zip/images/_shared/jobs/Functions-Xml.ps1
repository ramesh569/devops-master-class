[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

<#
.SYNOPSIS
    Validates an xml file against an xml schema file.
.NOTES
    Downloaded from https://stackoverflow.com/questions/822907/how-do-i-use-powershell-to-validate-xml-files-against-an-xsd
.EXAMPLE
    PS> dir *.xml | Test-XmlFile schema.xsd
#>
function Test-XmlFile
{
    [OutputType('System.Boolean')]
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string] $XsdPath,

        [Parameter(ValueFromPipeline=$true, Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [alias('Fullname')]
        [string] $XmlFile,

        [scriptblock] $ValidationEventHandler = { Write-Error $args[1].Exception }
    )

    begin {
        $schemaReader = New-Object System.Xml.XmlTextReader $XsdPath
        $schema = [System.Xml.Schema.XmlSchema]::Read($schemaReader, $ValidationEventHandler)
    }

    process {
        $ret = $true
        try {
            $xml = New-Object System.Xml.XmlDocument
            $xml.Schemas.Add($schema) | Out-Null
            $xml.Load($XmlFile)
            $xml.Validate({
                    throw ([PsCustomObject] @{
                        SchemaFile = $XsdPath
                        XmlFile = $XmlFile
                        Exception = $args[1].Exception
                    })
                })
        } catch {
            Write-Error $_
            $ret = $false
        }
        $ret
    }

    end {
        $schemaReader.Close()
    }
}

function Get-XmlContent {
    param (
        [Parameter(Mandatory=$true)]
        [string]$XmlPath,
        [Parameter(Mandatory=$false)]
        [string]$XsdPath
    )

    #test if file exists
    if (!(Test-Path $XmlPath)) {
        throw "File not found: $XmlPath"
    }

    #determine XSD path
    $xsdFilePath = $XmlPath.replace('.xml', '.xsd')

    #if XSD path is provided, use the provided
    if ($XsdPath) {
        $xsdFilePath = $XsdPath
    }

    #test if XSD file exists
    if (!(Test-Path $xsdFilePath)) {
        throw "XSD File not found: $xsdFilePath"
    }

    #validate XML against XSD
    $xmlValidationResults = Test-XmlFile -XsdPath (Get-Item $xsdFilePath).FullName -XmlFile (Get-Item $XmlPath).FullName
    if ($xmlValidationResults -eq $true) {
        Write-Host "XSD Validation Completed for $((Get-Item $XmlPath).Name)"
    } else {
        Write-Host "XSD Validation Failed for $((Get-Item $XmlPath).Name)"
        return
    }
    #return XML
    return [xml](Get-Content -Path $XmlPath)
}

#write to console the functions have been loaded
Write-Verbose "Loaded $($MyInvocation.MyCommand.Name)"