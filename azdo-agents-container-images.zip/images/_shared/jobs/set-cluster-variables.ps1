[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ClusterName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ResourceGroupName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$Color
)

#[Functions]
. $PSScriptRoot\Functions-Keda.ps1

#[Script]
$clusterState = $null
if (IsAgentPoolActiveOnCluster -ClusterName $ClusterName -AgentPoolName $AgentPoolName ) {
  $clusterState = 'active'
} else {
  $clusterState = 'inactive'
}

write-host "set variable state: $clusterState"
write-host "set variable name: $ClusterName"
write-host "set variable resourceGroupName: $ResourceGroupName"
write-host "set variable color: $Color"

write-host "##vso[task.setvariable variable=state;isOutput=true]$clusterState"
write-host "##vso[task.setvariable variable=name;isOutput=true]$ClusterName"
write-host "##vso[task.setvariable variable=resourceGroupName;isOutput=true]$ResourceGroupName"
write-host "##vso[task.setvariable variable=color;isOutput=true]$Color"

write-host "Script Completed"