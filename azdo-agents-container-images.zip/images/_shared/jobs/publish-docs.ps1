<#
.SYNOPSIS
    Publishes recorded software document to the installed-docs git repository
.PARAMETER AgentPoolName
    The name of the agent pool that the software document was created for.
.PARAMETER DocumentationFolder
    The location of the document to be published
.PARAMETER BuildName
    The Definition Name of the build
.PARAMETER BuildNumber
    The unique number of the build
.PARAMETER DocumentationFileName
    Optional parameter to specify a different file name other than the default
.NOTES
    This file exists in two locations (but will be obsolete with Release Train Management, merging is wasted effort):
    azdo-agents-vm\_cicd\templates\tasks\publish-docs.ps1
    azdo-agents-container-images\images\_shared\jobs\publish-docs.ps1
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $AgentPoolName,
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $DocumentationFolder,
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $BuildName,
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $BuildNumber,
    [Parameter(Mandatory=$false)]
    $DocumentationFileName = 'InstalledSoftware.md'
)
#[Configuration]
$ErrorActionPreference = "Stop" #stop script on error
#[Functions]
<#
.SYNOPSIS
    Returns true if the agent pool is intended for the user
.DESCRIPTION
    Based on the agentpool name determine if the agent pool is intended for the user.
.PARAMETER AgentPoolName
    The name of the agent pool to test access for
#>
Function Test-AgentPoolForUser() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    #if agent pool starts with 'meso'
    if ($AgentPoolName -like "meso*") {
        return $false
    }
    #if agent pool is a canary pool
    if ($AgentPoolName -like "*canary*") {
        return $false
    }
    #if agent pool is a DEV pool
    if ($AgentPoolName -like "*dev*") {
        return $false
    }
    return $true
}

Function Get-NormalizedPoolName() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    $AgentPoolName = $AgentPoolName -replace "greenCanary", "GreenCanary"
    $AgentPoolName = $AgentPoolName -replace "blueCanary", "BlueCanary"
    $AgentPoolName = $AgentPoolName -replace "redCanary", "RedCanary"
    $AgentPoolName = $AgentPoolName -replace "blackCanary", "BlackCanary"
    return $AgentPoolName
}
#[Script]
$agentPoolNameNormalized = Get-NormalizedPoolName -AgentPoolName $AgentPoolName
$agentPoolIntendedForUser = Test-AgentPoolForUser -AgentPoolName $agentPoolNameNormalized
#display script parameters for troubleshooting purposes
write-host "Update Documentation Repository"
write-host "Agent Pool: $AgentPoolName"
write-host "Agent Pool Normalized: $agentPoolNameNormalized"
write-host "Documentation Folder: $DocumentationFolder"
write-host "Documentation Filename: $DocumentationFileName"
write-host "Agent Pool customer facing: $agentPoolIntendedForUser"
$gitRepositoryName = 'azdo-agents-installed-software-docs'
#https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=Windows
$token = az account get-access-token
$accessToken = ($token | ConvertFrom-Json).accessToken
$tokenAsBase64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("`:$accessToken"))
$performPull=$true
if (!(Test-Path($gitRepositoryName))) {
    #clone documentation repository
    write-host "Get Documentation (default branch)"
    git -c http.extraHeader="Authorization: Basic $tokenAsBase64" clone https://raboweb@dev.azure.com/raboweb/Tribe%20Tech4Engineering/_git/$gitRepositoryName
}
#navigate to repository and the installedsoftware folder
write-host "Navigate to docs repository folder"
if ($agentPoolIntendedForUser) {
    Set-Location $gitRepositoryName/InstalledSoftware
} else {
    write-host "Agent pool is not intended for user, using Internal folder"
    Set-Location $gitRepositoryName/InstalledSoftware_MesoInternal
}
#pull repository if clone step was skipped
if ($performPull -eq $true) {
    #perform git pull in azdo-agents-installed-software-docs repository folder
    write-host "Get latest version"
    git -c http.extraHeader="Authorization: Basic $tokenAsBase64" pull
}
#replace (or create) documentation file
write-host "Replace documentation file"

#delete target document before copying new documentation file (to avoid issues with filenames changing cases)
#note we can't just use Remove-Item <filename> because on linux the filesystem is case-sensitive
#however we can get all files with Get-ChildItem and then select the file that matches (case insensitve)
#and then call Remove-Item on the result
$targetFile = "$agentPoolNameNormalized.md"
$targetFileObject = Get-ChildItem | Where-Object -Property Name -eq $targetFile
if ($targetFileObject) {
    write-host "file exists, remove before copying new file"
    $targetFileObject | Remove-Item
}

#don't change to move because some flavours have multiple deployments (for example nodejs and nodejs-build)
Copy-Item -Path "$documentationFolder/$DocumentationFileName" -Destination "$agentPoolNameNormalized.md" -Force -Verbose

#allow change to filename casing to be detected by git
git config core.ignorecase false

$success=$false
$maxAttempts = 5;
for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
    Write-host "Update documentation. Attempt $($attempt)/$maxAttempts"
    #push documentation to main branch
    write-host "Stage changes"
    git add --all
    $commitMessage = "Update Documentation: $($BuildName)-$($BuildNumber) on $($agentPoolNameNormalized)"
    write-host "Create commit with message '$commitMessage'"
    git -c "user.name=Team Meso" -c "user.email=eu.MesoAZDOService@rabobank.com" commit -m $commitMessage
    write-host "Get latest changes"
    git -c "user.name=Team Meso" -c "user.email=eu.MesoAZDOService@rabobank.com" -c http.extraHeader="Authorization: Basic $tokenAsBase64" pull --rebase
    write-host "Push commit to remote"
    git -c http.extraHeader="Authorization: Basic $tokenAsBase64" push
    if ($LASTEXITCODE -eq 0) {
        $success = $true
        break; # exit for loop
    }
    write-host "Push failed, retrying in 10 seconds"
    Start-Sleep -Seconds 10
}
if ($success -eq $false) {
    throw "Failed to update documentation. See logging above."
}
write-host "Documentation updated successfully"