#!/bin/bash -e
normalized_namespace=${NAMESPACE/./-} #replace any dot in namespace variable with a dash

echo "# az aks get-credentials"
az aks get-credentials --admin --name "$AKS_NAME" --resource-group "$RESOURCE_GROUP"

echo "# Creating service account for $AZURE_APP_REGISTRATION_ID"
echo "# service account name: ${SERVICE_ACCOUNT_NAME,,}"
echo "# namespace: ${normalized_namespace,,}"

cat > service-account.yaml << EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  annotations:
    azure.workload.identity/client-id: "$AZURE_APP_REGISTRATION_ID"
  name: "${SERVICE_ACCOUNT_NAME,,}"
  namespace: "${normalized_namespace,,}"
EOF

kubectl apply -f service-account.yaml