#!/bin/bash -e
echo "# az aks get-credentials"
az aks get-credentials --admin --name "$AKS_NAME" --resource-group "$RESOURCE_GROUP"

#normalize namespace
normalized_namespace=${NAMESPACE/./-} #replace any dot in namespace variable with a dash

#define path for deployment files
scaledjob_definition_file="./images/_shared/manifests/scaledjob-agentpool-deployment.yaml"
placeholderagent_definition_file="./images/_shared/manifests/priorityclass-placeholderagent-deployment.yaml"
scaledjob_pdb_definition_file="./images/_shared/manifests/poddisruptionbudget-scaledjob-deployment.yaml"

#copy template to deployment files so we don't modify the templates itself
deployment_document_suffix=""

if [ "${IS_ONE_LAB_DEPLOYMENT}" = "true" ]; then
    echo "OneLab deployment..."
    deployment_document_suffix="-onelab"
fi

if [ "${IS_KATA_DEPLOYMENT}" = "True" ]; then
    echo "KATA deployment..."
    deployment_document_suffix="-kata"
fi

cp --verbose "./images/_shared/manifests/scaledjob-agentpool-template-${LABEL_OS}${deployment_document_suffix}.yaml" "${scaledjob_definition_file}"
cp --verbose "./images/_shared/manifests/priorityclass-placeholderagent-template-${LABEL_OS}${deployment_document_suffix}.yaml" "${placeholderagent_definition_file}"
cp --verbose "./images/_shared/manifests/poddisruptionbudget-scaledjob-template.yaml" "${scaledjob_pdb_definition_file}"

#add deployment files to array
deployment_files=("${scaledjob_definition_file}" "${placeholderagent_definition_file}" "${scaledjob_pdb_definition_file}")
for deployment_definition_file in "${deployment_files[@]}"; do
    echo "Modifying Deployment File: ${deployment_definition_file}"

    echo "Image Repository is ${ACR_REPOSITORY}"
    sed -i "s/@IMAGE_REPOSITORY/${ACR_REPOSITORY}/g" "${deployment_definition_file}"

    echo "ACR Login Server is ${ACR_LOGIN_SERVER}"
    sed -i "s/@ACR_LOGIN_SERVER/${ACR_LOGIN_SERVER}/g" "${deployment_definition_file}"

    echo "Image Version is ${BUILD_NUMBER}"
    sed -i "s/@VERSION@/${BUILD_NUMBER}/g" "${deployment_definition_file}"

    echo "Image (Flavour) Name is ${IMAGE_FLAVOUR}"
    sed -i "s/@FLAVOUR/${IMAGE_FLAVOUR}/g" "${deployment_definition_file}"

    echo "AZDO Url is https://dev.azure.com/${AZDO_ORGANIZATION}"
    sed -i "s/@AZDO_ORGANIZATION/${AZDO_ORGANIZATION}/g" "${deployment_definition_file}"

    echo "AZDO Organization for scaled job name is ${AZDO_ORGANIZATION,,}"
    sed -i "s/@AZDO_SCALEDJOB_ORGANIZATION/${AZDO_ORGANIZATION,,}/g" "${deployment_definition_file}"

    echo "AZDO Agent Pool Name is ${AZDO_AGENT_POOL_NAME}"
    sed -i "s/@AZDO_AGENTPOOL_NAME/${AZDO_AGENT_POOL_NAME,,}/g" "${deployment_definition_file}"

    echo "AZDO Organization URL is https://dev.azure.com/${AZDO_ORGANIZATION}"
    sed -i "s/@AZDO_ORG_URL/https:\/\/dev.azure.com\/${AZDO_ORGANIZATION}/g" "${deployment_definition_file}"

    echo "AZDO Environment is ${AZDO_ENVIRONMENT}"
    sed -i "s/@ENVIRONMENT/${AZDO_ENVIRONMENT}/g" "${deployment_definition_file}"

    echo "Kubernetes Environment Label is ${LABEL_ENVIRONMENT}"
    sed -i "s/@LABEL_ENVIRONMENT/${LABEL_ENVIRONMENT}/g" "${deployment_definition_file}"

    echo "Kubernetes Namespace is ${normalized_namespace,,}"
    sed -i "s/@NAMESPACE/${normalized_namespace,,}/g" "${deployment_definition_file}"

    echo "Pod CPU limit is is ${POD_CPU_LIMIT}"
    sed -i "s/@POD_CPU_LIMIT/${POD_CPU_LIMIT}/g" "${deployment_definition_file}"

    echo "Pod Memory Limit is ${POD_MEMORY_LIMIT}"
    sed -i "s/@POD_MEMORY_LIMIT/${POD_MEMORY_LIMIT}/g" "${deployment_definition_file}"

    # using 0@ instead of @ to ensure yaml stays valid
    echo "Min replica count ${MIN_REPLICA_COUNT}"
    sed -i "s/0@MIN_REPLICA_COUNT/${MIN_REPLICA_COUNT}/g" "${deployment_definition_file}"

    # using 0@ instead of @ to ensure yaml stays valid
    echo "Max replica count ${MAX_REPLICA_COUNT}"
    sed -i "s/0@MAX_REPLICA_COUNT/${MAX_REPLICA_COUNT}/g" "${deployment_definition_file}"

    # using 0@ instead of @ to ensure yaml stays valid
    echo "Polling interval is ${POLLING_INTERVAL}"
    sed -i "s/0@POLLING_INTERVAL/${POLLING_INTERVAL}/g" "${deployment_definition_file}"

    echo "Affinity selector ${AFFINITY}"
    sed -i "s/@AFFINITY_SELECTOR/${AFFINITY}/g" "${deployment_definition_file}"

    echo "Agent registration service account ${AGENT_REGISTRATION_SERVICE_ACCOUNT}"
    sed -i "s/@AGENT_REGISTRATION_SERVICE_ACCOUNT/${AGENT_REGISTRATION_SERVICE_ACCOUNT}/g" "${deployment_definition_file}"

    echo "Modified Manifest:"
    cat "${deployment_definition_file}"
done

echo "Deploy - Job - Placeholder agent registration"
# Deploy placeholder agent registration and throw error if it fails
if ! kubectl apply -f "${placeholderagent_definition_file}"; then
    echo "Failed to deploy placeholder agent registration job. See log above for details."
    exit 1
fi

echo "Deploy - Scaled Job - Agents"
if ! kubectl apply -f "${scaledjob_definition_file}"; then
    echo "Failed to deploy scaled job. See log above for details."
    exit 1
fi

echo "Deploy - PodDisruptionBudget - Scaled Job Pods"
if ! kubectl apply -f "${scaledjob_pdb_definition_file}"; then
    echo "Failed to deploy scaled job PodDisruptionBudget. See log above for details."
    exit 1
fi