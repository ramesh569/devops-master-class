[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ClusterNameToActivate,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ClusterNameToDeactivate,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)
#[Functions]
. $PSScriptRoot\Functions-Keda.ps1

#[Script]
ActivateScaledJob `
    -ClusterName $ClusterNameToActivate `
    -AgentPoolName $AgentPoolName

DeactivateScaledJob `
  -ClusterName $ClusterNameToDeactivate `
  -AgentPoolName $AgentPoolName