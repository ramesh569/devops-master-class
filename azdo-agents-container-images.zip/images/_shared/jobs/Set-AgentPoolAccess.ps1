<#
.SYNOPSIS
    Add default access roles to AZDO Agent Pool
.PARAMETER AzdoOrganization
    Azure DevOps Organization that the authorization group is part of
.PARAMETER AgentPoolName
    Agent Pool to configure
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateSet(
        'raboweb',
        'raboweb-brazil',
        'raboweb-ftbtr',
        'raboweb-na',
        'raboweb-ranz',
        'raboweb-test'
    )]
    [String]$AzdoOrganization,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String]$AgentPoolName

)

#[Functions]
. $PSScriptRoot\Functions-AzdoApi.ps1

function Get-AzureAgentPoolsInOrganization() {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$AzdoOrganization/_apis/distributedtask/pools?api-version=6.0"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken).value}

function Set-AgentPoolAccess() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ReaderGroupId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AdminGroupId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/securityroles/roleassignments/set-role-assignments
    #required access [Graph - Read & Manage]
    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentpoolrole/roleassignments/resources/$($AgentPoolId)?api-version=7.1-preview.1"
    $roleAssignments = @(
        [pscustomobject]@{roleName='Reader';userId=$ReaderGroupId},
        [pscustomobject]@{roleName='Administrator';userId=$AdminGroupId}
    )
    $body = ($roleAssignments | ConvertTo-Json)
    if ($PSCmdlet.ShouldProcess($AgentPoolId, "Set roles on agent pool")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PUT -AccessToken $AccessToken -Body $body
    }
}

#[Script]
#getting access token
$accessToken = (az account get-access-token | ConvertFrom-Json).accessToken

#get target agent pool
write-host "Getting Agent Pools"
$agentPool = Get-AzureAgentPoolsInOrganization -AzdoOrganization $AzdoOrganization -AccessToken $accessToken | Where-Object -Property name -eq $AgentPoolName
if (!($agentPool)) {
    throw "Agentpool $AgentPoolName not found in organization $AzdoOrganization. Alternatively the account running this script doesn't have access"
}

$readerGroupName = Get-TargetGroupName -azdoOrganization $AzdoOrganization -groupType 'agentpool-reader'
$readerGroupId = Get-GroupIdentifier -azdoOrganization $AzdoOrganization -groupName $readerGroupName -returnField originId -accessToken $accessToken

$adminGroupName = Get-TargetGroupName -azdoOrganization $AzdoOrganization -groupType 'agentpool-admin'
$adminGroupId = Get-GroupIdentifier -azdoOrganization $AzdoOrganization -groupName $adminGroupName -returnField originId -accessToken $accessToken

Set-AgentPoolAccess `
    -azdoOrganization $AzdoOrganization `
    -agentPoolId $agentPool.id `
    -readerGroupId $readerGroupId `
    -adminGroupId $adminGroupId `
    -accessToken $accessToken
