<#
.SYNOPSIS
    Add service principal as user in azure devops
.PARAMETER AzdoOrganization
    The name of the azure devops organization to add the user to
.PARAMETER EnterpriseRegistrationName
    The name of the enterprise registration to add as user
.PARAMETER EnterpriseRegistrationId
    The id of the enterprise registration to add as user
.PARAMETER EnterpriseServicePrincipalId
    The id of the enterprise service principal to add as user.
    Value matches 'Application (client) ID' on App Registration
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateSet(
        'raboweb',
        'raboweb-brazil',
        'raboweb-ftbtr',
        'raboweb-na',
        'raboweb-ranz',
        'raboweb-test'
    )]
    [String]$AzdoOrganization,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $EnterpriseRegistrationName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $EnterpriseRegistrationId,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $EnterpriseServicePrincipalId,

    [Parameter(Mandatory=$true)]
    [ValidateSet(
        'stakeholder',
        'express'
    )]
    [String]$LicenseType
)

#[Functions]
. $PSScriptRoot\Functions-AzdoApi.ps1

function Set-AzdoUserAccessLevel() {
  [CmdletBinding(SupportsShouldProcess)]
  param (
    [Parameter(Mandatory=$true)]
    [string]$azdoOrganization,

    [Parameter(Mandatory=$true)]
    [string]$servicePrincipalId,

    [Parameter(Mandatory=$true)]
    [string]$appRegistrationName,

    [Parameter(Mandatory=$true)]
    [string]$appRegistrationId,

    [Parameter(Mandatory=$true)]
    [ValidateSet('stakeholder', 'express')]
    [string]$license,

    [Parameter(Mandatory=$true)]
    [string]$accessToken
  )
  #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/memberentitlementmanagement/service-principal-entitlements/add?view=azure-devops-rest-7.1&tabs=HTTP
  #required access [Member Entitlement Management (Read & Manage), Entitlement (Read)]
  write-host "Adding user $appRegistrationName to $azdoOrganization"
  $uri = "https://vsaex.dev.azure.com/$($azdoOrganization)/_apis/serviceprincipalentitlements?api-version=7.1-preview.1"

  $body = [pscustomobject]@{
    accessLevel=@{
      accountLicenseType="$license"
    };
    servicePrincipal=@{
      origin="AAD"
      applicationId="$appRegistrationId"
      originId="$servicePrincipalId"
      subjectKind="servicePrincipal"
    }
  } | ConvertTo-Json

  write-host "Invoking POST: $uri"
  if ($PSCmdlet.ShouldProcess($azdoOrganization, "Add service principal $servicePrincipalId to azdo organization")) {
    $response = Invoke-WebRequest `
        -Method Post `
        -Uri $uri `
        -Headers @{Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($accessToken)")) } `
        -ContentType 'application/json' `
        -Body $body

    write-host $response
    if ($response.StatusCode -ne 200 -or !(($response | ConvertFrom-Json).isSuccess)) {
      write-host "Failed to add user $appRegistrationName to $azdoOrganization"
      throw "Failed to add user $appRegistrationName to $azdoOrganization"
    }
  }
}

#[Script]
#getting access token
$accessToken = (az account get-access-token | ConvertFrom-Json).accessToken

write-host "Checking if $EnterpriseRegistrationName exists in $AzdoOrganization"
$targetApplicationDescriptor = Get-ApplicationDescriptor -azdoOrganization $AzdoOrganization -EnterpriseRegistrationName $EnterpriseRegistrationName -EnterpriseRegistrationid $EnterpriseRegistrationId -accessToken $accessToken
if (!($targetApplicationDescriptor)) {
  write-host "$EnterpriseRegistrationName ($EnterpriseServicePrincipalId) does not exist in $AzdoOrganization, creating it..."
  Set-AzdoUserAccessLevel -azdoOrganization $AzdoOrganization -servicePrincipalId $EnterpriseServicePrincipalId -appRegistrationName $EnterpriseRegistrationName -appRegistrationId $EnterpriseRegistrationId -license $LicenseType -accessToken $accessToken
  write-host "$EnterpriseRegistrationName added to $AzdoOrganization"
} else {
  write-host "$EnterpriseRegistrationName already exists, no need to add it to $AzdoOrganization"
}