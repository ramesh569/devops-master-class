[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterAState,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterAName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterARG,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterAColor,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterBState,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterBName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterBRG,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $clusterBColor
)
<#
    Deployments will always go to Cluster A before going to Cluster B
    However to determine which physical cluster is designated as A and B we need
    to know which cluster is currently serving the production load

    There are a few scenarios:
    1) Cluster A is active, therefor we should deploy to Cluster B first
    2) Cluster B is active, therefor we should deploy to Cluster A first
    3) Both clusters are active (or inactive), this situation shouldn't occur from a process perspective
       but the script should just assign one of the clusters to go first, it doesn't really matter
       therefor lets deploy to Cluster B first

    Decision Table
    | ------------ | ----------------- | ----------------- |
    | Cluster A    | Cluster B         | Deployment Order  |
    | ------------ | ----------------- | ----------------- |
    | Active       | Inactive          | B -> A            |
    | Inactive     | Active            | A -> B            |
    | Active       | Active            | B -> A            |
    | Inactive     | Inactive          | B -> A            |
    | ------------ | ----------------- | ----------------- |
#>

#display which clusters are active
write-host "Cluster $clusterAName is in $clusterAState state"
write-host "Cluster $clusterBName is in $clusterBState state"

$clusterAColor = (Get-Culture).TextInfo.ToTitleCase($clusterAColor.ToLowerInvariant())
$clusterBColor = (Get-Culture).TextInfo.ToTitleCase($clusterBColor.ToLowerInvariant())

#determine order
if ($clusterAState -eq 'inactive' -and $clusterBState -eq 'active') {
    write-host "Deploy to $clusterAName and afterwards to $clusterBName"
    write-host "##vso[task.setvariable variable=first_cluster_name;isOutput=true]$clusterAName"
    write-host "##vso[task.setvariable variable=first_cluster_rg;isOutput=true]$clusterARG"
    write-host "##vso[task.setvariable variable=first_cluster_color;isOutput=true]$clusterAColor"
    write-host "##vso[task.setvariable variable=second_cluster_name;isOutput=true]$clusterBName"
    write-host "##vso[task.setvariable variable=second_cluster_rg;isOutput=true]$clusterBRG"
    write-host "##vso[task.setvariable variable=second_cluster_color;isOutput=true]$clusterBColor"

    #display output for debugging purposes
    write-host "first_cluster_name=$clusterAName"
    write-host "first_cluster_rg=$clusterARG"
    write-host "first_cluster_color=$clusterAColor"
    write-host "second_cluster_name=$clusterBName"
    write-host "second_cluster_rg=$clusterBRG"
    write-host "second_cluster_color=$clusterBColor"
} else {
    write-host "Deploy to $clusterBName and afterwards to $clusterAName"
    write-host "##vso[task.setvariable variable=first_cluster_name;isOutput=true]$clusterBName"
    write-host "##vso[task.setvariable variable=first_cluster_rg;isOutput=true]$clusterBRG"
    write-host "##vso[task.setvariable variable=first_cluster_color;isOutput=true]$clusterBColor"
    write-host "##vso[task.setvariable variable=second_cluster_name;isOutput=true]$clusterAName"
    write-host "##vso[task.setvariable variable=second_cluster_rg;isOutput=true]$clusterARG"
    write-host "##vso[task.setvariable variable=second_cluster_color;isOutput=true]$clusterAColor"

    #display output for debugging purposes
    write-host "first_cluster_name=$clusterBName"
    write-host "first_cluster_rg=$clusterBRG"
    write-host "first_cluster_color=$clusterBColor"
    write-host "second_cluster_name=$clusterAName"
    write-host "second_cluster_rg=$clusterARG"
    write-host "second_cluster_color=$clusterAColor"
}
