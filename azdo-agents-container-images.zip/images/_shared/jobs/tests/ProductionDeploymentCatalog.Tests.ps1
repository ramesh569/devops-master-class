Describe 'Production deployment catalog' {
	BeforeAll {
		$mosaicPipelinePath = Join-Path $PSScriptRoot '../pipeline-mosaic-deployment-prod.yml'
		$mosaicPipelineContent = Get-Content -Path $mosaicPipelinePath -Raw

		$catalogMatch = [regex]::Match(
			$mosaicPipelineContent,
			'(?ms)- name: agentpoolsToDeploy\s+type: object\s+default:\s+\[(?<values>.*?)\]'
		)
		if (-not $catalogMatch.Success) {
			throw 'Could not find agentpoolsToDeploy in the mosaic production deployment pipeline.'
		}
		$script:catalog = @(
			[regex]::Matches($catalogMatch.Groups['values'].Value, '"(?<definition>[^\"]+)"') |
				ForEach-Object { $_.Groups['definition'].Value }
		)
		$script:catalogPools = @($catalog | ForEach-Object { ($_ -split ':', 2)[0] })

		$deploymentPattern = '(?ms)^\s+- template: /images/_shared/jobs/stage-deploy-agentpool-(?:multi|single)\.yml\s+parameters:\s+(?<parameters>.*?)(?=^\s+- template:|\z)'
		$script:deployments = @(
			[regex]::Matches($mosaicPipelineContent, $deploymentPattern) |
				ForEach-Object {
					$parametersBlock = $_.Groups['parameters'].Value
					$pool = [regex]::Match($parametersBlock, '(?m)^\s*azdoAgentPoolName: "(?<value>[^"]+)"').Groups['value'].Value
					$organization = [regex]::Match($parametersBlock, '(?m)^\s*azdoOrganization: (?<value>\S+)').Groups['value'].Value
					$os = [regex]::Match($parametersBlock, '(?m)^\s*osType: (?<value>\S+)').Groups['value'].Value
					$configs = @([regex]::Matches($parametersBlock, '(?m)^\s*clusterConfig(?:A|B)?:[ \t]+(?<value>\S+)') | ForEach-Object { $_.Groups['value'].Value })
					[PSCustomObject]@{ Identity = "$organization/$pool"; Pool = $pool; Os = $os; Configs = $configs }
				}
		)
		$script:configuredDeployments = @($deployments | ForEach-Object Identity)
	}

	It 'contains each qualified deployment identity exactly once' {
		$catalogPools | Should -HaveCount ($catalogPools | Select-Object -Unique).Count
	}

	It 'matches every configured production deployment' {
		$catalogPools | Sort-Object | Should -Be ($configuredDeployments | Sort-Object)
	}

	It 'uses deployment directives in every catalog entry' {
		$catalog | Should -HaveCount (@($catalog | Where-Object { $_ -match '^[^/]+/[^:]+:(mosaic|no-deploy|.+)$' }).Count)
	}

	It 'skips production deployment stages when all configured clusters already match or no-deploy is specified' {
		foreach ($template in @('multi', 'single')) {
			$content = Get-Content -Path (Join-Path $PSScriptRoot "../stage-deploy-agentpool-$template.yml") -Raw
			$content | Should -Match "dependencies\.PrepareDeployment\.outputs\['DetermineImageVersions\.ImageVersion\."
			$content | Should -Match "dependencies\.PrepareDeployment\.outputs\['DetermineImageVersions\.ClusterAction\."
			$content | Should -Match "'none', 'no-deploy'\)"
		}
	}

	It 'maps each pool to the same clusters as its deployment stage' {
		$groups = [regex]::Match($mosaicPipelineContent, '(?ms)^[ \t]+clusterGroups:[ \t]*\r?\n(?<groups>.*?)(?=^[ \t]+- job:|\z)').Groups['groups'].Value
		$groupLines = @([regex]::Matches($groups, '(?m)^\s+(?<prefix>[\w-]+): \[(?<clusters>[^\]]+)\]') |
			ForEach-Object { [PSCustomObject]@{ Prefix = $_.Groups['prefix'].Value; Clusters = @($_.Groups['clusters'].Value -split ',\s*') } })

		foreach ($deployment in $deployments) {
			$matchingGroups = @($groupLines | Where-Object { $deployment.Pool.StartsWith("$($_.Prefix)-", [StringComparison]::OrdinalIgnoreCase) })
			$matchingGroups | Should -HaveCount 1 -Because "pool '$($deployment.Pool)' must have one cluster group"
			$clusterNames = @($deployment.Configs | ForEach-Object {
				$configPath = Join-Path $PSScriptRoot "..\..\..\..\_shared\variables\$($deployment.Os)\$_"
				$configContent = Get-Content $configPath -Raw
				[regex]::Match($configContent, '(?m)^\s*aksName: (?<name>\S+)').Groups['name'].Value
			})
			$matchingGroups[0].Clusters | Should -Be $clusterNames
		}
	}

	It 'uses the shared production finalize template with the inverse change-creation flag' {
		$mosaicPipelineContent | Should -Match '(?m)^\s+- template: /stages/production-finalize\.yml@shared\s+parameters:\s+createSm9Change: \$\{\{ not\(parameters\.skipChangeCreation\) \}\}'
	}
}
