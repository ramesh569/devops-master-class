BeforeAll {
    . (Join-Path $PSScriptRoot '..\Functions-Keda.ps1')

    function New-TestScaledJob {
        param (
            [string]$Name,
            [string]$Namespace = 'agents',
            [bool]$Paused = $false
        )

        [PSCustomObject]@{
            metadata = [PSCustomObject]@{
                name = $Name
                namespace = $Namespace
                annotations = [PSCustomObject]@{
                    'autoscaling.keda.sh/paused' = "$Paused".ToLowerInvariant()
                }
            }
        }
    }
}

Describe 'Switch-ClusterNonCanaryJobs' {
    BeforeEach {
        $script:sourceName = 'aks-prod-blue-linux-weu'
        $script:destinationName = 'aks-prod-green-linux-neu'
        $script:sourceJobs = @(
            (New-TestScaledJob -Name 'shared')
            (New-TestScaledJob -Name 'fallback')
            (New-TestScaledJob -Name 'already-paused' -Paused $true)
        )
        $script:destinationJobs = @(
            (New-TestScaledJob -Name 'shared')
            (New-TestScaledJob -Name 'destination-only')
        )
        $script:postActivationJobs = $null
        $script:pauseCalls = @()
        $script:activationSucceeds = $true

        Mock ConnectToClusterByName { param($Name) $script:connectedCluster = $Name }
        Mock Get-NonCanaryScaledJobs {
            if ($script:connectedCluster -eq $script:sourceName) {
                return $script:sourceJobs
            }
            if ($null -ne $script:postActivationJobs -and $script:pauseCalls.Count -gt 0) {
                return $script:postActivationJobs
            }
            return $script:destinationJobs
        }
        Mock Set-ScaledJob {
            param($Pause, $TargetScaledJobs)
            $script:pauseCalls += [PSCustomObject]@{
                Pause = $Pause
                Jobs = @($TargetScaledJobs | ForEach-Object { "$($_.metadata.namespace)/$($_.metadata.name)" })
            }
            if (-not $Pause) {
                return $script:activationSucceeds
            }
            return $true
        }
    }

    It 'enables all destination jobs and pauses only enabled matching source jobs' {
        $output = Switch-ClusterNonCanaryJobs -DestinationName $destinationName 6>&1 | Out-String

        $pauseCalls | Should -HaveCount 2
        $pauseCalls[0].Pause | Should -BeFalse
        $pauseCalls[0].Jobs | Should -Be @('agents/shared', 'agents/destination-only')
        $pauseCalls[1].Pause | Should -BeTrue
        $pauseCalls[1].Jobs | Should -Be @('agents/shared')
        $output | Should -Match "fallback.*remains enabled.*no counterpart"
        $output | Should -Not -Match "already-paused.*remains enabled"
    }

    It 'matches namespace as well as name' {
        $script:destinationJobs = @((New-TestScaledJob -Name 'shared' -Namespace 'other'))

        $output = Switch-ClusterNonCanaryJobs -DestinationName $destinationName 6>&1 | Out-String

        $pauseCalls | Should -HaveCount 1
        $output | Should -Match "agents/shared.*remains enabled"
    }

    It 'does not deactivate the source if destination activation fails' {
        $script:activationSucceeds = $false

        { Switch-ClusterNonCanaryJobs -DestinationName $destinationName } |
            Should -Throw '*source cluster was not deactivated*'
        $pauseCalls | Should -HaveCount 1
    }

    It 'does not deactivate the source if a matched destination job is no longer enabled' {
        $script:postActivationJobs = @(
            (New-TestScaledJob -Name 'shared' -Paused $true)
            (New-TestScaledJob -Name 'destination-only')
        )

        { Switch-ClusterNonCanaryJobs -DestinationName $destinationName } |
            Should -Throw '*is not enabled*'
        $pauseCalls | Should -HaveCount 1
    }

    It 'does not activate or deactivate if either inventory fails' {
        Mock Get-NonCanaryScaledJobs { throw 'Inventory failed' }

        { Switch-ClusterNonCanaryJobs -DestinationName $destinationName } |
            Should -Throw '*Inventory failed*'
        $pauseCalls | Should -HaveCount 0
    }

    It 'does not activate or deactivate if destination inventory fails' {
        Mock Get-NonCanaryScaledJobs {
            if ($script:connectedCluster -eq $script:destinationName) {
                throw 'Destination inventory failed'
            }
            return $script:sourceJobs
        }

        { Switch-ClusterNonCanaryJobs -DestinationName $destinationName } |
            Should -Throw '*Destination inventory failed*'
        $pauseCalls | Should -HaveCount 0
    }

    It 'does not deactivate if destination verification inventory fails' {
        Mock Get-NonCanaryScaledJobs {
            if ($script:connectedCluster -eq $script:sourceName) {
                return $script:sourceJobs
            }
            if ($script:pauseCalls.Count -gt 0) {
                throw 'Verification inventory failed'
            }
            return $script:destinationJobs
        }

        { Switch-ClusterNonCanaryJobs -DestinationName $destinationName } |
            Should -Throw '*Verification inventory failed*'
        $pauseCalls | Should -HaveCount 1
    }

    It 'switches from green back to blue using the reverse cluster pairing' {
        $script:sourceName = 'aks-prod-green-linux-neu'
        $script:destinationName = 'aks-prod-blue-linux-weu'

        Switch-ClusterNonCanaryJobs -DestinationName $destinationName

        $pauseCalls | Should -HaveCount 2
        $pauseCalls[1].Jobs | Should -Be @('agents/shared')
    }

    It 'rejects a cluster with no configured pair' {
        { Switch-ClusterNonCanaryJobs -DestinationName 'unknown' } |
            Should -Throw '*No paired cluster configured*'
        $pauseCalls | Should -HaveCount 0
    }
}

Describe 'Get-NonCanaryScaledJobs' {
    It 'excludes canaries from inventory' {
        Mock kubectl {
            $global:LASTEXITCODE = 0
            '{"items":[{"metadata":{"namespace":"agents","name":"shared"}},{"metadata":{"namespace":"agents","name":"shared-canary"}}]}'
        }

        @(Get-NonCanaryScaledJobs) | Should -HaveCount 1
    }

    It 'fails closed when kubectl cannot list jobs' {
        Mock kubectl {
            $global:LASTEXITCODE = 1
            ''
        }

        { Get-NonCanaryScaledJobs } | Should -Throw '*Failed to get ScaledJobs*'
    }
}
