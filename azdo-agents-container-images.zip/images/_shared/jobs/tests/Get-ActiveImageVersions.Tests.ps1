Describe 'Get-ActiveImageVersions' {
	BeforeAll {
		$script:scriptUnderTest = Join-Path -Path $PSScriptRoot -ChildPath '../Get-ActiveImageVersions.ps1'
	}

	BeforeEach {
		$fakeBin = Join-Path $TestDrive 'current-image-bin'
		New-Item -ItemType Directory -Path $fakeBin -Force | Out-Null

		$script:motPath = Join-Path $fakeBin 'mot'
		@'
#!/bin/sh
printf '%s\n' "$*" >> "$MOT_CALL_LOG"
printf '{"id":"event-1","azureDevOpsOrganization":"%s","agentPoolName":"%s","os":"%s","flavour":"%s","version":"%s","resourceId":"pool-1","createdAt":"2026-09-08T00:00:00Z","updatedAt":"2026-09-08T00:00:00Z"}\n' "$CURRENT_ORGANIZATION" "$CURRENT_POOL" "$CURRENT_OS" "$CURRENT_FLAVOUR" "$CURRENT_VERSION"
'@ | Set-Content -Path $motPath
		& chmod +x $motPath

		$azPath = Join-Path $fakeBin 'az'
		@'
#!/bin/sh
printf '{"accessToken":"test-token","expiresOn":"2099-01-01T00:00:00Z"}\n'
'@ | Set-Content -Path $azPath
		& chmod +x $azPath

		$env:PATH = "$fakeBin$([IO.Path]::PathSeparator)$env:PATH"
		$env:MOT_CALL_LOG = Join-Path $TestDrive 'current-image-calls.log'
		Remove-Item $env:MOT_CALL_LOG -ErrorAction SilentlyContinue
		$env:CURRENT_ORGANIZATION = 'Raboweb'
		$env:CURRENT_POOL = 'Shared-EU-Container-Linux-Base-S-Prod'
		$env:CURRENT_OS = 'linux'
		$env:CURRENT_FLAVOUR = 'base'
		$env:CURRENT_VERSION = '20260907.1'
	}

	It 'sets the changelog baseline from the specified agent pool current image' {
		$output = & $scriptUnderTest `
			-AzdoOrganization $env:CURRENT_ORGANIZATION `
			-AzdoAgentPoolName $env:CURRENT_POOL `
			-Os $env:CURRENT_OS `
			-Flavour $env:CURRENT_FLAVOUR `
			-MotExecutablePath $motPath *>&1 | Out-String

		$output | Should -Match 'variable=currentImageVersion]20260907.1'
		Get-Content $env:MOT_CALL_LOG -Raw | Should -Match 'mosaic agent-pools current-image --agent-pool Raboweb/Shared-EU-Container-Linux-Base-S-Prod --output json'
	}

	It 'rejects a current image with a different image identity' {
		$env:CURRENT_FLAVOUR = 'python'

		{
			& $scriptUnderTest `
				-AzdoOrganization $env:CURRENT_ORGANIZATION `
				-AzdoAgentPoolName $env:CURRENT_POOL `
				-Os 'linux' `
				-Flavour 'base' `
				-MotExecutablePath $motPath
		} | Should -Throw "*does not match configured image 'linux/base'*"
	}
}