#!/bin/bash -e
echo "# az aks get-credentials"
az aks get-credentials --admin --name "$AKS_NAME" --resource-group "$RESOURCE_GROUP"

#normalize namespace
normalized_namespace=${NAMESPACE/./-} #replace any dot in namespace variable with a dash

#define path for deployment files
triggerauth_definition_file="./images/_shared/manifests/triggerauthentication-deployment.yaml"

#copy template to deployment files so we don't modify the templates itself
cp --verbose "./images/_shared/manifests/triggerauthentication-template.yaml" "${triggerauth_definition_file}"

echo "Modifying Deployment File: ${triggerauth_definition_file}"

echo "Image (Flavour) Name is ${IMAGE_FLAVOUR}"
sed -i "s/@FLAVOUR/${IMAGE_FLAVOUR}/g" "${triggerauth_definition_file}"

echo "AZDO Organization for scaled job name is ${AZDO_ORGANIZATION,,}"
sed -i "s/@AZDO_SCALEDJOB_ORGANIZATION/${AZDO_ORGANIZATION,,}/g" "${triggerauth_definition_file}"

echo "AZDO Environment is ${AZDO_ENVIRONMENT}"
sed -i "s/@ENVIRONMENT/${AZDO_ENVIRONMENT}/g" "${triggerauth_definition_file}"

echo "Kubernetes Namespace is ${normalized_namespace,,}"
sed -i "s/@NAMESPACE/${normalized_namespace,,}/g" "${triggerauth_definition_file}"

echo "App registration id ${AZURE_APP_REGISTRATION_ID}"
sed -i "s/@AZURE_APP_REGISTRATION_ID/${AZURE_APP_REGISTRATION_ID}/g" "${triggerauth_definition_file}"

echo "Modified Manifest:"
cat "${triggerauth_definition_file}"

echo "Deploy - Trigger Authentication"
kubectl apply -f "${triggerauth_definition_file}"