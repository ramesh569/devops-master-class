[CmdletBinding()]
param(
	[ValidateScript({ Test-Path -Path $_ -PathType Leaf })]
	[string]$AzurePoolsCsvPath,

	[string]$AllPipelineParametersJson,

	[string]$PoolsXmlPath = (Join-Path $PSScriptRoot '../../../infrastructure/agentpools/config/mdppools-shared.xml'),

	[string]$AzdoOrganization = 'raboweb',

	[string]$AzdoProject = 'Tribe Tech4Engineering'
)

$ErrorActionPreference = 'Stop'

if ($env:SYSTEM_ACCESSTOKEN) {
	$azdoHeaders = @{ Authorization = "Bearer $env:SYSTEM_ACCESSTOKEN" }
} else {
	. $PSScriptRoot/Functions-AzdoApi.ps1
	$azdoHeaders = Get-BasicAuthHeaders
}

function Get-MdpAzdoResponse {
	param([string]$Uri)
	return Invoke-RestMethod -Method Get -Uri $Uri -Headers $azdoHeaders
}

$pipelinePaths = @{
	'linux/legacy'  = '/_cicd/pipelines/linux/linux-image.yml'
	'linux/lean'    = '/_cicd/pipelines/linux/linux-light-image.yml'
	'linuxarm/lean' = '/_cicd/pipelines/linux/linuxarm-lean-image.yml'
	'windows/legacy' = '/_cicd/pipelines/windows/windows-image.yml'
	'windows/lean'   = '/_cicd/pipelines/windows/windows-light-image.yml'
	'windows/vs'     = '/_cicd/pipelines/windows/windows-vs-image.yml'
}

if ([bool]$AzurePoolsCsvPath -eq [bool]$AllPipelineParametersJson) {
	throw 'Specify exactly one of -AzurePoolsCsvPath or -AllPipelineParametersJson.'
}

$targets = @{}
$failures = @()
$projectUri = [uri]::EscapeDataString($AzdoProject)
$apiRoot = "https://dev.azure.com/$AzdoOrganization/$projectUri/_apis/build"
$definitions = @((Get-MdpAzdoResponse -Uri "$apiRoot/definitions?includeAllProperties=true&`$top=2000&api-version=7.1").value)
if ($definitions.Count -eq 0) { throw "No build definitions returned from $AzdoProject." }


if ($AzurePoolsCsvPath) {
	[xml]$poolConfig = Get-Content -Path $PoolsXmlPath -Raw
	$exportedPools = @(Import-Csv -Path $AzurePoolsCsvPath)
	foreach ($poolName in @($poolConfig.managedevopspools.mdp.name | Sort-Object -Unique)) {
		if ($poolName -notmatch '^Shared-(?:EU|NEU)-VM-(?<os>LinuxArm|Linux|Windows)-(?<flavour>Legacy|Lean|VS)-') {
			$failures += "Unrecognized MDP pool name: $poolName"
			continue
		}
		$os = $Matches.os.ToLowerInvariant()
		$flavour = $Matches.flavour.ToLowerInvariant()
		$matchesInExport = @($exportedPools | Where-Object { $_.NAME -eq $poolName })
		if ($matchesInExport.Count -eq 0) {
			Write-Warning "No Azure export row for $poolName; cannot determine its current version."
			continue
		}
		if ($matchesInExport.Count -ne 1) {
			$failures += "Expected one Azure export row for $poolName, found $($matchesInExport.Count)"
			continue
		}
		$version = $matchesInExport[0].'TAG: IMAGE_VERSION'
		if ($version -notmatch '^1\.1\.(?<buildId>\d+)$') {
			$failures += "Invalid image version '$version' for $poolName"
			continue
		}
		$key = "$os/$flavour/$version"
		$targets[$key] = [pscustomobject]@{
			Os = $os
			Flavour = $flavour
			Version = $version
			BuildId = $Matches.buildId
			PoolName = $poolName
		}
	}
} else {
	$parameters = $AllPipelineParametersJson | ConvertFrom-Json
	$runCount = [int]$parameters.mdpRunCount
	if ($runCount -lt 1) { throw 'mdpRunCount must be at least 1.' }
	$selected = @{
		'linux/legacy' = $parameters.includeMdpLinuxLegacy
		'linux/lean' = $parameters.includeMdpLinuxLean
		'linuxarm/lean' = $parameters.includeMdpLinuxArmLean
		'windows/legacy' = $parameters.includeMdpWindowsLegacy
		'windows/lean' = $parameters.includeMdpWindowsLean
		'windows/vs' = $parameters.includeMdpWindowsVS
	}
	foreach ($image in @($selected.Keys | Where-Object { $selected[$_] })) {
		$expectedPath = $pipelinePaths[$image]
		$matchingDefinitions = @($definitions | Where-Object { $_.repository.name -eq 'azdo-agents-vm' -and $_.process.yamlFilename -and $_.process.yamlFilename.Replace('\', '/').ToLowerInvariant().TrimStart('/') -eq $expectedPath.TrimStart('/') })
		if ($matchingDefinitions.Count -ne 1) {
			$failures += "Expected one pipeline definition for $expectedPath, found $($matchingDefinitions.Count)"
			continue
		}
		$builds = @((Get-MdpAzdoResponse -Uri "$apiRoot/builds?definitions=$($matchingDefinitions[0].id)&resultFilter=succeeded&`$top=$runCount&api-version=7.1").value)
		foreach ($build in $builds) {
			$os, $flavour = $image.Split('/')
			$version = "1.1.$($build.id)"
			$targets["$image/$version"] = [pscustomobject]@{
				Os = $os
				Flavour = $flavour
				Version = $version
				BuildId = [string]$build.id
				PoolName = $expectedPath
			}
		}
		if ($builds.Count -eq 0) { $failures += "No builds returned for $expectedPath" }
	}
	foreach ($reference in @([string]$parameters.mdpBackfillVersions -split ',' | Where-Object { $_.Trim() })) {
		$reference = $reference.Trim()
		if ($reference -notmatch '^(?<os>linux|linuxarm|windows)/(?<flavour>legacy|lean|vs)/(?<version>1\.1\.(?<buildId>\d+))$') {
			$failures += "Invalid MDP backfill reference '$reference'; expected os/flavour/1.1.buildId."
			continue
		}
		$os = $Matches.os
		$flavour = $Matches.flavour
		$version = $Matches.version
		$buildId = $Matches.buildId
		$image = "$os/$flavour"
		if (-not $pipelinePaths.ContainsKey($image) -or -not $selected[$image]) {
			$failures += "Backfill image '$image' is not selected or has no VM pipeline."
			continue
		}
		$targets["$image/$version"] = [pscustomobject]@{
			Os = $os
			Flavour = $flavour
			Version = $version
			BuildId = $buildId
			PoolName = $pipelinePaths[$image]
		}
	}
}

$created = 0
$existing = 0
foreach ($target in @($targets.Values | Sort-Object Os, Flavour, Version)) {
	$key = "$($target.Os)/$($target.Flavour)/$($target.Version)"
	$lookup = & mot mosaic image-versions get --os $target.Os --flavour $target.Flavour --version $target.Version --output json 2>&1
	if ($LASTEXITCODE -eq 0) {
		$existing++
		Write-Host "Already in Mosaic: $key"
		continue
	}
	try {
		$lookupError = ($lookup | Out-String) | ConvertFrom-Json
	} catch {
		$lookupError = $null
	}
	if ($lookupError.error.status -ne 404) {
		$failures += "Mosaic lookup failed for $key`: $($lookup | Out-String)"
		continue
	}

	$expectedPath = $pipelinePaths["$($target.Os)/$($target.Flavour)"]
	$matchingDefinitions = @($definitions | Where-Object { $_.repository.name -eq 'azdo-agents-vm' -and $_.process.yamlFilename -and $_.process.yamlFilename.Replace('\', '/').ToLowerInvariant().TrimStart('/') -eq $expectedPath.TrimStart('/') })
	if ($matchingDefinitions.Count -ne 1) {
		$failures += "Expected one pipeline definition for $expectedPath, found $($matchingDefinitions.Count)"
		continue
	}

	try {
		$build = Get-MdpAzdoResponse -Uri "$apiRoot/builds/$($target.BuildId)?api-version=7.1"
		if ([string]$build.definition.id -ne [string]$matchingDefinitions[0].id) {
			throw "Build $($target.BuildId) definition $($build.definition.id) does not match $expectedPath definition $($matchingDefinitions[0].id)."
		}
		if (-not $build.sourceBranch -or -not $build.reason) {
			throw "Build $($target.BuildId) has no source branch or reason."
		}
		$artifacts = @((Get-MdpAzdoResponse -Uri "$apiRoot/builds/$($target.BuildId)/artifacts?api-version=7.1").value)
		$artifact = @($artifacts | Where-Object { $_.name -eq 'InstalledSoftware' })
		if ($artifact.Count -ne 1 -or -not $artifact[0].resource.downloadUrl) {
			throw "Build $($target.BuildId) has no downloadable InstalledSoftware artifact."
		}

		$tempPath = Join-Path ([io.path]::GetTempPath()) ("mosaic-mdp-$([guid]::NewGuid().ToString('N'))")
		New-Item -Path $tempPath -ItemType Directory | Out-Null
		try {
			$zipPath = Join-Path $tempPath 'InstalledSoftware.zip'
			Invoke-WebRequest -Uri $artifact[0].resource.downloadUrl -Headers $azdoHeaders -OutFile $zipPath
			Expand-Archive -Path $zipPath -DestinationPath $tempPath
			$docs = @(Get-ChildItem -Path $tempPath -Filter 'InstalledSoftware.json' -File -Recurse)
			if ($docs.Count -ne 1) {
				throw "Expected one InstalledSoftware.json in build $($target.BuildId) artifact, found $($docs.Count)."
			}
			& mot mosaic image-versions create --os $target.Os --flavour $target.Flavour --version $target.Version --build-id $target.BuildId --branch $build.sourceBranch --build-type $build.reason --documentation $docs[0].FullName
			if ($LASTEXITCODE -ne 0) { throw "Mosaic create exited with code $LASTEXITCODE" }
			$created++
		} finally {
			Remove-Item -Path $tempPath -Recurse -Force
		}
	} catch {
		$failures += "Failed to sync $key from $($target.PoolName): $($_.Exception.Message)"
	}
}

Write-Host "MDP Mosaic sync: $created created, $existing already present, $($failures.Count) errors."
foreach ($failure in $failures) { Write-Warning $failure }
if ($failures.Count -gt 0) { throw 'MDP Mosaic image version sync did not complete successfully.' }