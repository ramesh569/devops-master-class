[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

#[Configuration]
$canaryMarker = "canary"

$clusterPairs = @{
    "aks-prod-blue-linux-weu" = "aks-prod-green-linux-neu"
    "aks-prod-blue-linux-eus" = "aks-prod-green-linux-wus"
    "aks-prod-blue-linux-eau" = "aks-prod-green-linux-sau"
    "aks-prod-blue-linux-sbr" = "aks-prod-green-linux-sus"
    "aks-prod-blue-win-weu" = "aks-prod-green-win-neu"
}

#[Public Functions]
function IsAgentPoolActiveOnCluster() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ClusterName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )

    ConnectToClusterByName -Name $ClusterName

    try {
        if (!(kubectl api-resources -o name | Where-Object { $_ -eq 'scaledjobs.keda.sh' })) {
            write-host "ScaledJobs type does not exist. Cluster is inactive"
            return $false
        }

        $scaledJobs = kubectl get scaledjobs -A -o json | ConvertFrom-Json
        if ($LASTEXITCODE -ne 0) {
            throw 'command failed'
        }

        $scaledJob = $scaledJobs.items | Where-Object { $_.spec.triggers.metadata.poolName -eq $AgentPoolName }
        if (!($scaledJob)) {
            write-host "No ScaledJob deployed for AgentPool '$AgentPoolName'. Consider cluster inactive"
            return $false #not active, not deployed
        }

        if (Get-ScaledJobPausedState -ScaledJob $scaledJob) {
            write-host "ScaledJob for AgentPool '$AgentPoolName' is paused. Consider cluster inactive"
            return $false
        }

        write-host "ScaledJob for AgentPool '$AgentPoolName' is active. Consider cluster active"
        return $true
    } catch {
        write-host "Error thrown when requesting scaledjobs, assume cluster is inactive"
        return $false
    }
    write-host "Unable to determine cluster status, assume it is inactive"
    return $false
}

function ActivateScaledJob() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ClusterName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    ConnectToClusterByName -Name $ClusterName
    return Set-ScaledJobsByAgentPoolName -Pause $false -AgentPoolName $AgentPoolName
}

function DeactivateScaledJob() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ClusterName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    ConnectToClusterByName -Name $ClusterName
    return Set-ScaledJobsByAgentPoolName -Pause $true -AgentPoolName $AgentPoolName
}

function ActivateClusterNonCanaryJobs() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name
    )
    ConnectToClusterByName -Name $Name
    return Set-NonCanaryScaledJobs -Pause $false
}

function DeactivateClusterNonCanaryJobs() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name
    )
    ConnectToClusterByName -Name $Name
    return Set-NonCanaryScaledJobs -Pause $true
}

function Switch-ClusterNonCanaryJobs() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$DestinationName
    )

    if ($clusterPairs.ContainsKey($DestinationName)) {
        $sourceName = $clusterPairs[$DestinationName]
    } else {
        $sourceName = $clusterPairs.GetEnumerator() |
            Where-Object { $_.Value -eq $DestinationName } |
            Select-Object -ExpandProperty Key
    }
    if (-not $sourceName) {
        throw "No paired cluster configured for '$DestinationName'."
    }

    ConnectToClusterByName -Name $sourceName
    $sourceJobs = @(Get-NonCanaryScaledJobs)
    ConnectToClusterByName -Name $DestinationName
    $destinationJobs = @(Get-NonCanaryScaledJobs)
    if ($destinationJobs.Count -eq 0) {
        throw "No non-canary ScaledJobs found on destination cluster '$DestinationName'."
    }

    $destinationScaledJobIds = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    foreach ($job in $destinationJobs) {
        [void]$destinationScaledJobIds.Add("$($job.metadata.namespace)/$($job.metadata.name)")
    }

    Write-Host "Activating all non-canary ScaledJobs on $DestinationName"
    if (-not (Set-ScaledJob -Pause $false -TargetScaledJobs $destinationJobs)) {
        throw "Failed to activate non-canary ScaledJobs on '$DestinationName'; source cluster was not deactivated."
    }

    $enabledDestinationJobs = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    foreach ($job in @(Get-NonCanaryScaledJobs)) {
        if (-not (Get-ScaledJobPausedState -ScaledJob $job)) {
            [void]$enabledDestinationJobs.Add("$($job.metadata.namespace)/$($job.metadata.name)")
        }
    }

    $sourceJobsToPause = @(
        foreach ($job in $sourceJobs) {
            if (Get-ScaledJobPausedState -ScaledJob $job) {
                continue
            }
            $agentPoolScaledJobId = "$($job.metadata.namespace)/$($job.metadata.name)"
            if ($enabledDestinationJobs.Contains($agentPoolScaledJobId)) {
                $job
            } elseif ($destinationScaledJobIds.Contains($agentPoolScaledJobId)) {
                throw "Destination ScaledJob '$agentPoolScaledJobId' is not enabled on '$DestinationName'; source cluster was not deactivated."
            } else {
                Write-Host "##vso[task.logissue type=warning]ScaledJob '$agentPoolScaledJobId' remains enabled on '$sourceName': no counterpart on '$DestinationName'."
            }
        }
    )

    if ($sourceJobsToPause.Count -eq 0) {
        Write-Host "No enabled source ScaledJobs have enabled counterparts on $DestinationName."
        return
    }

    ConnectToClusterByName -Name $sourceName
    Write-Host "Deactivating $($sourceJobsToPause.Count) matched ScaledJobs on $sourceName"
    if (-not (Set-ScaledJob -Pause $true -TargetScaledJobs $sourceJobsToPause)) {
        throw "Failed to deactivate matched ScaledJobs on '$sourceName'."
    }
}


#[Private Functions]
function ConnectToClusterByName() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name
    )

    if ($Name -eq $currentCluster) {
        return #target cluster is already active, skip connect step
    }

    $clusters = (az aks list -o json | ConvertFrom-json)
    $targetCluster = $clusters | Where-Object -Property Name -like $Name
    if (!($targetCluster)) {
        throw "Cluster with name '$Name' could not be found."
    }
    az aks get-credentials --resource-group $targetCluster.resourceGroup --name $targetCluster.name --overwrite-existing | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to get credentials for cluster '$Name'."
    }
    kubelogin convert-kubeconfig -l azurecli | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to configure kubelogin for cluster '$Name'."
    }
    $script:currentCluster = $Name
}

function Get-NonCanaryScaledJobs() {
    [CmdletBinding()]
    param ()

    $json = kubectl get scaledjobs -A -o json
    if ($LASTEXITCODE -ne 0) {
        throw 'Failed to get ScaledJobs for cluster inventory.'
    }
    $jobs = $json | ConvertFrom-Json -ErrorAction Stop
    if ($null -eq $jobs.items) {
        throw 'Cluster inventory did not contain a ScaledJobs items list.'
    }
    return @($jobs.items | Where-Object { $_.metadata.name -notlike "*$canaryMarker*" })
}

function Get-ScaledJobsByImageFlavour() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ClusterName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Os,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Flavour
    )

    $imageFlavour = "$Os-$Flavour"
    $clustersToTry = @($ClusterName)

    # add paired cluster to list to try
    if ($clusterPairs.ContainsKey($ClusterName)) {
        $clustersToTry += $clusterPairs[$ClusterName]
    } else {
        $pairedCluster = $clusterPairs.GetEnumerator() | Where-Object { $_.Value -eq $ClusterName } | Select-Object -ExpandProperty Key
        if ($pairedCluster) {
            $clustersToTry += $pairedCluster
        }
    }

    foreach($cluster in $clustersToTry) {
        write-host "Checking cluster $cluster"
        try {
            ConnectToClusterByName -Name $cluster
        } catch {
            write-host "Unable to connect to $cluster"
            continue
        }

        $scaledJobs = (kubectl get scaledjobs -A -o json | ConvertFrom-Json).items
        if ($LASTEXITCODE -ne 0) {
            write-host 'kubectl command failed'
            continue
        }

        if ($scaledJobs.count -eq 0) {
            write-host "No scaled jobs found in the cluster $cluster"
            continue
        }

        $targetScaledJobs = $scaledJobs | Where-Object { $_.spec.jobTargetRef.template.spec.containers[0].image -like "*$imageFlavour*" }
        if ($targetScaledJobs.count -gt 0) {
            return $targetScaledJobs
        }
    }

    throw "Unable to determine version for image $imageFlavour. See messages above for more details."
}

function Set-ScaledJobsByAgentPoolName() {
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [boolean]$Pause,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )

    $targetScaledJobs = (kubectl get scaledjobs -A -o json | ConvertFrom-Json).items | Where-Object { $_.spec.triggers.metadata.poolName -eq $AgentPoolName}
    if (-not $targetScaledJobs -or $targetScaledJobs.Count -eq 0) {
        write-host "No ScaledJobs found for AgentPool '$AgentPoolName'."
        return $false
    }

    return Set-ScaledJob -Pause $Pause -TargetScaledJobs $targetScaledJobs

}

function Get-ScaledJobPausedState() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [object]$ScaledJob
    )

    # if the annotation is not present, the scaledjob is not paused
    # if the annotation is present and set to anything other than true, the scaledjob is not paused
    return $ScaledJob.metadata.annotations.'autoscaling.keda.sh/paused' -eq 'true'
}

function Get-ScaledJobsOverview() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [array]$ScaledJobs
    )

    $overview = $ScaledJobs | ForEach-Object {
            $agentPoolName = ($_.spec.jobTargetRef.template.spec.containers[0].env | Where-Object { $_.name -eq 'AZP_POOL' }).value
            $isPaused = Get-ScaledJobPausedState -ScaledJob $_
            [PSCustomObject]@{
                AGENTPOOLNAME = $agentPoolName
                PAUSED = $isPaused
                NAME = $_.metadata.name
                NAMESPACE = $_.metadata.namespace
            }
        }

    $overview | Format-Table -AutoSize | Out-String -Width 4096 | Write-Host
}

function Set-NonCanaryScaledJobs() {
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [boolean]$Pause
    )

    $targetScaledJobs = (kubectl get scaledjobs -A -o json | ConvertFrom-Json).items | Where-Object { $_.metadata.name -notlike "*$canaryMarker*" }
    if (-not $targetScaledJobs -or $targetScaledJobs.Count -eq 0) {
        write-host "[Error] No non-canary ScaledJobs found."
        return $false
    }

    return Set-ScaledJob -Pause $Pause -TargetScaledJobs $targetScaledJobs
}

function Set-ScaledJob() {
    [CmdletBinding(SupportsShouldProcess)]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [boolean]$Pause,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [array]$TargetScaledJobs
    )

    $pauseValueAsString = $null
    if ($Pause) {
        $pauseValueAsString = "true"
    } else {
        $pauseValueAsString = "false"
    }

    foreach($scaledJob in $TargetScaledJobs)  {
        if ($PSCmdlet.ShouldProcess($($scaledJob.metadata.name), "Set paused to $pauseValueAsString for scaledjob")) {
            write-host "annotating $($scaledJob.metadata.name) with '--overwrite autoscaling.keda.sh/paused=$pauseValueAsString'"
            kubectl annotate scaledjob $scaledJob.metadata.name -n $scaledJob.metadata.namespace --overwrite autoscaling.keda.sh/paused=$pauseValueAsString | Out-Host
            if ($LASTEXITCODE -ne 0) {
                write-host "##vso[task.logissue type=warning]Failed to annotate ScaledJob '$($scaledJob.metadata.name)'."
                return $false
            }
        }
    }

    write-host "Waiting 5 seconds so scaledjobs can properly update their status"
    Start-Sleep -Seconds 5 #wait a bit for status to update

    #validate if each target job is in expected state
    write-host "Validating scaledjob states"
    $success = $true
    $allScaledJobs = (kubectl get scaledjobs -A -o json | ConvertFrom-Json).items
    if ($LASTEXITCODE -ne 0) {
        write-host "##vso[task.logissue type=warning]Failed to get ScaledJobs while validating expected state."
        return $false
    }

    foreach($scaledJob in $TargetScaledJobs)  {
        $updatedScaledJob = $allScaledJobs | Where-Object { $_.metadata.name -eq $scaledJob.metadata.name -and $_.metadata.namespace -eq $scaledJob.metadata.namespace }
        write-host "Validating $($scaledJob.metadata.namespace)/$($scaledJob.metadata.name)"
        $isPaused = Get-ScaledJobPausedState -ScaledJob $updatedScaledJob
        if ($Pause -ne $isPaused) {
            $expectedState = if ($Pause) { 'paused' } else { 'active' }
            write-host "##vso[task.logissue type=warning]ScaledJob '$($scaledJob.metadata.name)' has state '$isPaused' and not '$expectedState' as expected."
            $success = $false
        }
    }

    write-host "Displaying ScaledJob overview"
    Get-ScaledJobsOverview -ScaledJobs $allScaledJobs

    return $success
}

#[Script]
$currentCluster = $null
