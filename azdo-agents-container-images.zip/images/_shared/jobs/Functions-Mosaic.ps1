[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

# [cache]
$mosaicLoginExecutables = @{}

function Connect-Mosaic() {
	param(
		[Parameter(Mandatory = $true)]
		[string]$MotExecutablePath
	)

	if ($script:mosaicLoginExecutables.ContainsKey($MotExecutablePath)) {
		return
	}

	Write-Host "`tLogging in to Mosaic using Azure CLI"
	$loginOutput = & $MotExecutablePath mosaic login --azure-cli 2>&1
	if ($LASTEXITCODE -ne 0) {
		throw "Failed to log in to Mosaic: $($loginOutput -join [Environment]::NewLine)"
	}

	$script:mosaicLoginExecutables[$MotExecutablePath] = $true
}

function Get-AgentPoolExpectedImage() {
	param(
		[Parameter(Mandatory = $true)]
		[string]$Organization,
		[Parameter(Mandatory = $true)]
		[string]$AgentPoolName,
		[Parameter(Mandatory = $true)]
		[string]$MotExecutablePath
	)

	Connect-Mosaic -MotExecutablePath $MotExecutablePath
	$agentPool = "$Organization/$AgentPoolName"

	Write-Host "`tGET Expected Image from Mosaic for agent pool: $agentPool"
	$result = & $MotExecutablePath mosaic agent-pools expected-image --agent-pool $agentPool --output json
	if ($LASTEXITCODE -ne 0) {
		throw "Failed to get the expected image from Mosaic for agent pool '$agentPool': $result"
	}

	try {
		$response = $result | ConvertFrom-Json -ErrorAction Stop
	} catch {
		throw "Failed to parse the expected image response for agent pool '$agentPool': $($_.Exception.Message)"
	}

	if (-not $response.version) {
		throw "Mosaic returned an expected image without a version for agent pool '$agentPool'."
	}

	return $response
}

function Get-AgentPoolCurrentImage() {
	param(
		[Parameter(Mandatory = $true)]
		[string]$Organization,
		[Parameter(Mandatory = $true)]
		[string]$AgentPoolName,
		[Parameter(Mandatory = $true)]
		[string]$MotExecutablePath
	)

	Connect-Mosaic -MotExecutablePath $MotExecutablePath
	$agentPool = "$Organization/$AgentPoolName"

	Write-Host "`tGET Current Image from Mosaic for agent pool: $agentPool"
	$result = & $MotExecutablePath mosaic agent-pools current-image --agent-pool $agentPool --output json
	if ($LASTEXITCODE -ne 0) {
		throw "Failed to get the current image from Mosaic for agent pool '$agentPool': $result"
	}

	try {
		$response = $result | ConvertFrom-Json -ErrorAction Stop
	} catch {
		throw "Failed to parse the current image response for agent pool '$agentPool': $($_.Exception.Message)"
	}

	if (-not $response.version) {
		throw "Mosaic returned a current image without a version for agent pool '$agentPool'."
	}

	return $response
}

function Get-LatestImage() {
	param(
		[Parameter(Mandatory = $true)]
		[string]$Os,
		[Parameter(Mandatory = $true)]
		[string]$Flavour,
		[string]$MotExecutablePath = './mot'
	)

	Connect-Mosaic -MotExecutablePath $MotExecutablePath

	write-host "`tGET Latest Image from Mosaic for OS: $Os, Flavour: $Flavour"
	$result = & $motExecutablePath mosaic image-versions latest --os $Os --flavour $Flavour --output json
	if ($lastexitcode -ne 0) {
		write-host "`t$result"
		return ""
	}

	$response = $result | ConvertFrom-Json
	return $response.version
}
