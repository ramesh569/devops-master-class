<#
.SYNOPSIS
    Get run id of pipeline based on its name
.DESCRIPTION
    Get run id of pipeline based on its name and pipeline definition id
    and store in azuredevops variable so it can be used in a pipeline
.PARAMETER PipelineDefinitionId
    Id of pipeline definition
.PARAMETER RunName
    Name of run that needs to be located
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$PipelineDefinitionId,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$RunName
)

#[Configuration]
$ErrorActionPreference = "Stop" #stop script on error

write-host "Looking up run id"
write-host "Pipeline Definition Id: $PipelineDefinitionId"
write-host "Run Name: $RunName"


$token = az account get-access-token
$accessToken = ($token | ConvertFrom-Json).accessToken

#get runs from definition
$uri = "https://dev.azure.com/Raboweb/Tribe%20Tech4Engineering/_apis/pipelines/$($PipelineDefinitionId)/runs?api-version=7.1-preview.1"
write-host "GET $uri"
$runs = (Invoke-RestMethod `
    -Method Get `
    -Uri $uri `
    -Headers @{Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($accessToken)")) } `
    -ContentType 'application/json').value

$targetRun = $runs | Where-Object -Property Name -like $RunName
if (!($targetRun)) {
    throw "No run found for pipeline definition $PipelineDefinitionId with name '$RunName'"
}

write-host "Run Id: $($targetRun.Id)"
Write-Host "##vso[task.setvariable variable=imageVersionRunId]$($targetRun.Id)"
