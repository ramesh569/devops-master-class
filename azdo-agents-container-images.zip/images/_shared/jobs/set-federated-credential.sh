#!/bin/bash -e
normalized_namespace=${NAMESPACE/./-} #replace any dot in namespace variable with a dash

# KEDA_OPERATOR is a special case, as it is a cluster-wide service account
if [ "$SERVICE_ACCOUNT" == "keda-operator" ]; then
  credential_name="${SERVICE_ACCOUNT,,}-fedid"
else
  credential_name="${SERVICE_ACCOUNT,,}-fedid-${AZDO_ORGANIZATION,,}"
fi

subject="system:serviceaccount:${normalized_namespace,,}:${SERVICE_ACCOUNT,,}"

echo "# az aks get-credentials"
az aks get-credentials --admin --name "$AKS_NAME" --resource-group "$RESOURCE_GROUP"

echo "# az aks show - Get issuer"
issuer=$(az aks show -n "$AKS_NAME" -g "${RESOURCE_GROUP}" --query "oidcIssuerProfile.issuerUrl" -o tsv)

echo "# Creating or updating federated credential for $AZURE_APP_REGISTRATION_ID"
echo "#   Name: $credential_name"
echo "#   Service account: $subject"
echo "#   Issuer: $issuer"

cat > federated-credential.json << EOF
{
  "name": "$credential_name",
  "issuer": "$issuer",
  "subject": "$subject",
  "description": "Kubernetes service account federated identity, Last updated: $(date +%Y%m%d%H%M%S)",
  "audiences": [ "api://AzureADTokenExchange" ]
}
EOF

echo "# Checking if $credential_name already exists"
az
if ! az ad app federated-credential show --id "$AZURE_APP_REGISTRATION_ID" --federated-credential-id "$credential_name";
then
  echo "# $credential_name does not exist yet, creating..."
  echo "# az ad app federated-credential create"
  az ad app federated-credential create --id "$AZURE_APP_REGISTRATION_ID" --parameters federated-credential.json
else
  echo "# $credential_name already exists, updating..."
  echo "# az ad app federated-credential update"
  retries=5
  for ((i=1; i<=retries; i++)); do
    output=$(az ad app federated-credential update --id "$AZURE_APP_REGISTRATION_ID" --federated-credential-id "$credential_name" --parameters federated-credential.json 2>&1)
    if [[ "$output" == *"ERROR: Error due to concurrent requests being made to the tenant. Please wait briefly and retry."* ]]; then
      if [[ $i -lt $retries ]]; then
        echo "# Concurrent request error, retrying in 5 seconds... ($i/$retries)"
        sleep 5
      else
        echo "# Maximum retries reached. Failing."
        echo "$output"
        exit 1
      fi
    else
      echo "$output"
      break
    fi
  done
fi