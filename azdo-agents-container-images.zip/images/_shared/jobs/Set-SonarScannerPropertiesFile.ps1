<#
.SYNOPSIS
    Generate sonar-scanner.properties file
.DESCRIPTION
    Generate sonar-scanner.properties file based on template and inserting sonar project key
.PARAMETER Path
    Path of sonar-scanner.properties file
.PARAMETER SonarProjectKey
    Sonar project key (for example images-linux-base)
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$Path,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$SonarProjectKey
)

#[Configuration]
$ErrorActionPreference = "Stop" #stop script on error

#[functions]
$configuration = @"
## project settings
sonar.projectKey=$SonarProjectKey
sonar.projectName=$SonarProjectKey

## disable kubernetes sensor as it conflicts with yaml sensor
sonar.kubernetes.activate=false

## Disable Rule: For readability and maintenance lines should not exceed a certain length (yaml:LineLengthCheck) limit set to 160
## Justification: Splitting up longer lines in yaml increases complexity and only marginally improves readability.
##                Scrolling left and right is the better option, limit is frequently reached due to yaml structure of AzureDevOps pipeline files
sonar.issue.ignore.multicriteria=e1
sonar.issue.ignore.multicriteria.e1.ruleKey=yaml:LineLengthCheck
sonar.issue.ignore.multicriteria.e1.resourceKey=**/*.yml
"@

Set-Content -Path $Path -Value $configuration

WRite-Host "Configuration written to $Path`nContaining the following configuration"
Get-Content $Path

write-host "Script Completed"
