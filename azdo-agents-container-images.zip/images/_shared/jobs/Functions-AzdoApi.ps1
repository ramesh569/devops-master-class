﻿[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param()

#[Configuration]
#name of each group type
$groupTypeNames = @{
    "agentpool-reader" = "Agent Pool Readers"
    "agentpool-admin" = "Agent Pool Admins"
}

#project in each azdo organization in which the groups are located
$azdoOrganizationTargetProjects = @{
    "raboweb" = "[TAS]"
    "raboweb-brazil" = "[Tribe Tech4Engineering]"
    "raboweb-ftbtr" = "[Tribe Tech4Engineering]"
    "raboweb-na" = "[Tribe Tech4Engineering]"
    "raboweb-ranz" = "[TAS]"
    "raboweb-test" = "[TAS]"
}

#[Caches]
$azdoCallCache = @{} #key: "uri" value: "response"
$azdoGroupIdentierfierCache = @{} #key: "org" value: "response"

#[Functions]
function Invoke-AzureDevOpsApiCall() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Uri,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet('GET', 'POST', 'PUT', 'DELETE', 'PATCH')]
        [string]$Method,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken,

        [Parameter(Mandatory=$false)]
        [int]$MaxAttempts = 1,

        [Parameter(Mandatory=$false)]
        [string]$Body,

        [Parameter(Mandatory=$false)]
        [switch]$AllowCache
    )

    $cacheKey = $null
    if ($AllowCache) {
        #remove spaces and line breaks from body to ensure cache key is consistent
        $compressedBody = $body -replace '\s+', ''
        $cacheKey = "$uri|$compressedBody"
        if ($azdoCallCache.ContainsKey($cacheKey)) {
            Write-Verbose "[Cached Response] $uri (cachekey:$cacheKey)"
            return $azdoCallCache[$cacheKey]
        }
    }

    Write-Verbose "$($Method.ToUpper()) $Uri"
    $params = @{
        Method      = $Method
        Uri         = $Uri
        Headers     = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($AccessToken)")) }
        ContentType = 'application/json'
    }
    if ($PSBoundParameters.ContainsKey('Body')) {
        $params.Body = $Body
    }

    $currentAttempt = 0
    while ($currentAttempt -lt $MaxAttempts) {
        $currentAttempt++
        try {
            #invoke the API call
            $response = Invoke-RestMethod @params

            #handle rate limiting if Retry-After header is present in the response
            if ($response -and $response.Headers -and $response.Headers["Retry-After"]) {
                $retryAfter = [int]$response.Headers["Retry-After"]
                Write-Host "Retry-After header detected. Sleeping for $retryAfter seconds..."
                Start-Sleep -Seconds $retryAfter #ensures we don't make the next API too soon
            }

            #store in cache if it is allowed for this call
            if ($AllowCache) {
                Write-Verbose "[Caching Response] with cachekey:$cacheKey"
                $azdoCallCache[$cacheKey] = $response
            }

            #return the response
            return $response
        } catch {
            #API call failed, log the error and retry if we have attempts left
            Write-Warning "API call failed: $($Method.ToUpper()) $Uri. Attempt $currentAttempt of $MaxAttempts. Error: $_"
            if ($currentAttempt -lt $MaxAttempts) {
                Write-Verbose "Retrying in 5 seconds..."
                Start-Sleep -Seconds 5 #wait before next attempt
            } else {
                #all attempts exhausted, rethrow the error
                throw $_
            }
        }
    }
}

function Get-GroupIdentifier() {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$azdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$groupName,

        [Parameter(Mandatory=$true)]
        [ValidateSet(
            'descriptor',
            'originId'
        )]
        [String]$returnField,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$accessToken
    )

    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/graph/subject-query/query
    #required access [Graph] Read
    Write-Verbose "Getting $returnField for group: $groupName"
    $uri = "https://vssps.dev.azure.com/$($AzdoOrganization)/_apis/graph/subjectquery?api-version=7.1-preview.1"
    $body = [pscustomobject]@{query="$groupName";subjectKind=@('Group')} | ConvertTo-Json

    $groupDetailsResponse = Invoke-AzureDevOpsApiCall `
        -Uri $uri `
        -Method POST `
        -AccessToken $accessToken `
        -Body $body `
        -MaxAttempts 3 `
        -AllowCache

    $returnValue = $groupDetailsResponse.value.$returnField
    if (-not $returnValue) { $returnValue = "" }

    Write-Verbose "`t$($returnField): $returnValue"
    return $returnValue
}

function Get-AllGroupsIdentifier() {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$AccessToken
    )

    #documentation
    # - Subject Query returns up to 100 results and is not pageable
    # - Use Graph Groups (paged) to enumerate all groups and match locally

    #required access [Graph] Read
    $cacheKey = "$AzdoOrganization"
    if ($azdoGroupIdentierfierCache.ContainsKey($cacheKey)) {
        Write-Verbose "[Cached Response] groups for $cacheKey"
        return $azdoGroupIdentierfierCache[$cacheKey]
    }

    $baseUri = "https://vssps.dev.azure.com/$($AzdoOrganization)/_apis/graph/groups?api-version=7.1-preview.1"
    $headers = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($AccessToken)")) }

    $allGroups = @()
    $continuationToken = $null
    do {
        #first call is without continuation token, subsequent calls are with token
        $uri = if ($continuationToken) { "$baseUri&continuationToken=$continuationToken" } else { $baseUri }
        $response = Invoke-WebRequest -Method Get -Uri $uri -Headers $headers -ContentType 'application/json'

        #append current page to all groups
        $page = $response.Content | ConvertFrom-Json
        if ($page -and $page.value) {
            $allGroups += $page.value
        }

        #if there is more data token will be present
        $continuationToken = $response.Headers['X-MS-ContinuationToken']
        if ($continuationToken) { Write-Verbose "Paging Graph groups; continuation token present." }
    } while ($continuationToken)

    Write-Verbose "[Caching Response] groups for $cacheKey"
    $azdoGroupIdentierfierCache[$cacheKey] = $allGroups

    return $allGroups
}

function Get-TargetGroupName() {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$azdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$groupType
    )

    $groupName = $groupTypeNames[$groupType]
    if (!($groupName)) {
        Write-Error "Name for grouptype: '$groupType' not specified. Update this script."
    }
    $groupProject = $azdoOrganizationTargetProjects[$azdoOrganization]
    if (!($groupProject)) {
        Write-Error "Target project for azdo organization: '$azdoOrganization' not specified. Update this script."
    }
    #determine group to add app registration to
    return "$groupProject\$groupName"
}

function Get-ApplicationDescriptor($AzdoOrganization, $EnterpriseRegistrationName, $EnterpriseRegistrationid, $AccessToken) {
    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/ims/identities/read-identities
    #required access [Identity - Read]
    Write-Information "Getting descriptor for enterprise registration: $EnterpriseRegistrationName"
    $uri = "https://vssps.dev.azure.com/$($AzdoOrganization)/_apis/identities?searchFilter=General&filterValue=$($EnterpriseRegistrationName)&queryMembership=None&api-version=7.1-preview.1"
    Write-Host "`tInvoking GET: $uri"
    $applicationDetailsResponse = Invoke-WebRequest `
        -Method Get `
        -Uri $uri `
        -Headers @{Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($AccessToken)")) } `
        -ContentType 'application/json'

    if ($applicationDetailsResponse -and $applicationDetailsResponse.Headers -and $applicationDetailsResponse.Headers["Retry-After"]) {
        $retryAfter = [int]$applicationDetailsResponse.Headers["Retry-After"]
        Write-Host "Retry-After header detected. Sleeping for $retryAfter seconds..."
        Start-Sleep -Seconds $retryAfter
    }

    $responseObject = $applicationDetailsResponse | ConvertFrom-Json
    if ($responseObject.count -eq 0) {
        Write-Host "No application found with name: $EnterpriseRegistrationName"
        return $null
    }

    Write-Host "Matching application registration(s):"
    $responseObject.value | Select-Object -Property `
            Id, `
            @{Name='ApplicationId';Expression={$_.properties.ApplicationId.'$value'}}, `
            @{Name='DirectoryAlias';Expression={$_.properties.DirectoryAlias.'$value'}} `
        | ForEach-Object { write-host $_ }


    $targetAccount = $responseObject.value | Where-Object { $_.properties.ApplicationId.'$value' -eq  $EnterpriseRegistrationid -or $_.properties.DirectoryAlias.'$value' -eq  $EnterpriseRegistrationid} # the field is akwardly named $value hence the single quotes
    if (!$targetAccount) {
        Write-Host "Failed to find application registration with Application Id or Directory Alias: $EnterpriseRegistrationid"
        return $null
    }

    $descriptor = $targetAccount.subjectDescriptor
    if (!($descriptor)) {
        Write-Host $applicationDetailsResponse
    } else {
        Write-Host "`tDescriptor: $descriptor"
    }
    return $descriptor
}

function Get-ProjectsInOrganization() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/projects?api-version=7.1"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken).value
}


<#
.SYNOPSIS
    Get agent pool by name
.DESCRIPTION
    Get a specific agent pool by name within an organization
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolName
    The name of the agent pool
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Get-AgentPool() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/distributedtask/pools?poolName=$($AgentPoolName)&api-version=7.1"
    $agentPool = Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken -AllowCache
    if (!$agentPool -or $agentPool.count -eq 0) {
        throw "Agent pool '$AgentPoolName' not found in organization '$AzdoOrganization'"
    }
    return $agentPool.value
}

<#
.SYNOPSIS
    Get agent queues in project
.DESCRIPTION
    Get a list of agent queues within a project
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER ProjectName
    The name of the project
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Get-AgentQueuesInProject() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/distributedtask/queues?api-version=7.1"
    $agentQueues = Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken -AllowCache
    if (!$agentQueues -or $agentQueues.count -eq 0) {
        throw "No agent queues found in project '$ProjectName' in organization '$AzdoOrganization'"
    }
    return $agentQueues.value
}

<#
.SYNOPSIS
    Get agent queue by name
.DESCRIPTION
    Get a specific agent queue by name within an organization
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER ProjectName
    The name of the project
.PARAMETER AgentQueueName
    The name of the agent queue
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Get-AgentQueue() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentQueueName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/distributedtask/queues?queueName=$($AgentQueueName)&api-version=7.1"

    $agentQueue = Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken -AllowCache
    if (!$agentQueue -or $agentQueue.count -eq 0) {
        throw "Agent queue '$AgentQueueName' not found in project '$ProjectName' in organization '$AzdoOrganization'"
    }

    #return value
    return $agentQueue.value
}

<#
.SYNOPSIS
    Add existing agent pool to projects
.DESCRIPTION
    Add agent pool created on organization level to specified projects
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolName
    The name of the agent pool
    This should match the name of the agent pool created on organization level to avoid confusion
.PARAMETER AgentPoolId
    The ID of the agent pool (on organization level)
.PARAMETER Projects
    An array of project names to add the agent pool to
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.PARAMETER SkipCheck
    When set, the function will skip the check to see if the agent pool already exists in the project and attempt to add it regardless.
    This can be used to speed up execution when you are certain the agent pool is not yet added to any projects
    but should be used with caution as it may result in errors if the agent pool is already added to a project.
    Before setting this flag you should check if the queue already exists
.NOTES
    Required AzureDevOps Access [Agent Pools - Read & Manage]
#>
function New-AgentQueue {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$Projects,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken,

        [Parameter(Mandatory=$false)]
        [switch]$SkipCheck
    )

    foreach($project in $Projects | Select-Object -Unique) {
        if (-not $SkipCheck) {
            #verify if queue already exists
            $uri = "https://dev.azure.com/$($AzdoOrganization)/$($project)/_apis/distributedtask/queues?poolIds=$($AgentPoolId)&api-version=7.1"
            $queue = Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken -AllowCache
            if ($queue.value) {
                Write-Host "`t`t[Skip] Agent pool already exists in project: $project"
                continue
            }
        }
        $uri = "https://dev.azure.com/$($AzdoOrganization)/$($project)/_apis/distributedtask/queues?authorizePipelines=true&api-version=7.1"
        $body = @{
            name = $AgentPoolName
            pool = [pscustomobject]@{id=$AgentPoolId}
        } | ConvertTo-Json
        Write-Host "`t`tAdding to Project: $project"
        if ($PSCmdlet.ShouldProcess($project, "Add agentpool $AgentPoolName to project")) {
            Invoke-AzureDevOpsApiCall -Uri $uri -Method POST -AccessToken $AccessToken -Body $body | Out-Null
        }
    }
}

<#
.SYNOPSIS
    Get agent pools
.DESCRIPTION
    Get a list of agent pools within an organization
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Get-AgentPoolsInOrganization() {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$AzdoOrganization/_apis/distributedtask/pools?api-version=7.1"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken).value
}

<#
.SYNOPSIS
    Create agent pool
.DESCRIPTION
    Create a new agent pool within an organization (at organization level)
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.PARAMETER AgentPoolName
    The name of the agent pool
.PARAMETER OwnerGuid
    Owner GUID
.PARAMETER ProvisionInAllProjects
    When true provision in all projects
#>
function New-AgentPool() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$OwnerGuid,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [bool]$ProvisionInAllProjects
    )

    $uri = "https://dev.azure.com/$AzdoOrganization/_apis/distributedtask/pools?api-version=7.1"
    $body = @{
        name = $AgentPoolName
        autoProvision = $ProvisionInAllProjects
        owner = [pscustomobject]@{id=$OwnerGuid}
    } | ConvertTo-Json
    if ($PSCmdlet.ShouldProcess($AzdoOrganization, "Create agent pool $AgentPoolName")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method POST -AccessToken $AccessToken -Body $body
    }
}


<#
.SYNOPSIS
    Set agent pool ownership
.DESCRIPTION
    Set the owner of the agent pool
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolId
    The ID of the agent pool
.PARAMETER OwnerGuid
    Owner GUID
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.NOTES
    Required AzureDevOps Access [Agent Pools - Read & Manage]
#>
function Set-AgentPoolOwner() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$OwnerGuid,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/distributedtask/pools/$($AgentPoolId)?api-version=7.1"
    $body = @{
        owner = [pscustomobject]@{id=$OwnerGuid}
    } | ConvertTo-Json
    if ($PSCmdlet.ShouldProcess($AgentPoolId, "Set agentpool ownership")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PATCH -AccessToken $AccessToken -Body $body
    }
}


<#
.SYNOPSIS
    Get agent pool queue scope
.DESCRIPTION
    Get the scope for specified agent pool queue
.PARAMETER AzdoOrganizationName
    The Azure DevOps organization name
.PARAMETER AgentPoolId
    The ID of the agent pool (at organizational level)
.PARAMETER ProjectName
    The name of the project
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Get-AgentQueueScopeId() {
    [OutputType('System.String')]
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganizationName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )
    $uri = "https://dev.azure.com/$($AzdoOrganizationName)/$($ProjectName)/_apis/distributedtask/queues?poolIds=$($AgentPoolId)&api-version=7.1"
    $response = Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken
    if (-not $response -or $response.count -eq 0) {
        return "" #return empty string if no queue found.
    }
    return "$($response.value.projectId)_$($response.value.id)" #return <projectId>_<queueId> which is used as scope for security calls
}

<#
.SYNOPSIS
    Get agent pool access on organization level
.DESCRIPTION
    Get list of access set on agent pool on organization level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolId
    The ID of the agent pool
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.NOTES
    Required AzureDevOps Access [Security - Read]
#>
function Get-AgentPoolAccessOnOrganizationLevel() {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/securityroles/roleassignments/list?view=azure-devops-rest-7.1
    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentpoolrole/roleassignments/resources/$($AgentPoolId)?api-version=7.1-preview.1"

    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken).value
}

<#
.SYNOPSIS
    Get agent queue access on project level
.DESCRIPTION
    Get list of access set on agent queue on project level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER ScopeId
    The scope id of the agent queue, or the scope id of all agent queues on project level
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Get-AgentQueueAccessOnProjectLevel() {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganizationName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ScopeId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganizationName)/_apis/securityroles/scopes/distributedtask.agentqueuerole/roleassignments/resources/$($ScopeId)?api-version=7.1-preview.1"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken).value
}

<#
.SYNOPSIS
    Remove agent pool access on organization level
.DESCRIPTION
    Remove all role assignments provided to the function on organization level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolId
    The ID of the agent pool
.PARAMETER roleAssignments
    An array of role assignments to remove
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.NOTES
    Required AzureDevOps Access [Security - Manage]
#>
function Remove-AgentPoolAccessOnOrganizationLevel() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [object[]]$roleAssignments,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/securityroles/roleassignments/set-role-assignments
    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentpoolrole/roleassignments/resources/$($AgentPoolId)?api-version=7.1-preview.1"
    $body = ($roleAssignments.userId | ConvertTo-Json -AsArray)

    if ($PSCmdlet.ShouldProcess($AgentPoolId, "Remove agent pool access on organization level")) {
        Write-Host "`t`tRemoving marked account access"
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PATCH -AccessToken $AccessToken -Body $body | Out-Null
    }
}

<#
.SYNOPSIS
    Remove agent queue access on project level
.DESCRIPTION
    Remove all role assignments provided to the function on project level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolQueueScopeId
    The scope id of the agent queue
.PARAMETER roleAssignments
    An array of role assignments ids to remove
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Remove-AgentQueueAccessOnProjectLevel() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidatePattern('[a-f0-9\-]+_[0-9]+')]
        [string]$AgentPoolQueueScopeId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$RoleAssignmentIds,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentqueuerole/roleassignments/resources/$($AgentPoolQueueScopeId)?api-version=7.1-preview.1"
    $body = ($RoleAssignmentIds | Select-Object -Unique | ConvertTo-Json -AsArray)

    if ($PSCmdlet.ShouldProcess($AgentPoolQueueScopeId, "Remove agent queue access on project level")) {
        Write-Host "`t`tRemoving marked account access"
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PATCH -AccessToken $AccessToken -Body $body | Out-Null
    }


}


<#
.SYNOPSIS
    Add agent pool access on organization level
.DESCRIPTION
    Add readers and admins for the specified agent pool on organization level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolId
    The ID of the agent pool
.PARAMETER ReaderGuids
    An array of Identity GUIDs for the readers groups
.PARAMETER AdminGuids
    An array of Idenity GUIDs for the admins groups
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.NOTES
    Required AzureDevOps Access [Security - Manage]
#>
function New-AgentPoolAccessOnOrganizationLevel() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [AllowEmptyCollection()]
        [string[]]$ReaderGuids,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [AllowEmptyCollection()]
        [string[]]$AdminGuids,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/securityroles/roleassignments/set-role-assignments
    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentpoolrole/roleassignments/resources/$($AgentPoolId)?api-version=7.1-preview.1"
    $roleAssignments = @()
    $AdminGuids | Select-Object -Unique | ForEach-Object { $roleAssignments+= [pscustomobject]@{roleName='Administrator';userId=$_}}
    $ReaderGuids | Select-Object -Unique | ForEach-Object { $roleAssignments+= [pscustomobject]@{roleName='Reader';userId=$_}}
    $body = $roleAssignments | ConvertTo-Json -AsArray

    if ($PSCmdlet.ShouldProcess($AgentPoolId, "Add agent pool access on organization level")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PUT -AccessToken $AccessToken -Body $body | Out-Null
    }
}

<#
.SYNOPSIS
    Add agent queue access on project level
.DESCRIPTION
    Add readers and admins for the specified agent queue on project level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentQueueScopeId
    The scope of the agent pool queue
.PARAMETER ReaderGuids
    An array of Identity GUIDs for the readers groups
.PARAMETER AdminGuids
    An array of Idenity GUIDs for the admins groups
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function New-AgentQueueAccessOnProjectLevel() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentQueueScopeId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [AllowEmptyCollection()]
        [string[]]$ReaderGuids,

        [Parameter(Mandatory=$true)]
        [ValidateNotNull()]
        [AllowEmptyCollection()]
        [string[]]$AdminGuids,

        [Parameter(Mandatory=$false)]
        [ValidateNotNull()]
        [AllowEmptyCollection()]
        [string[]]$UserGuids,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [bool]$Inheritance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentqueuerole/roleassignments/resources/$($AgentQueueScopeId)?api-version=7.1-preview.1"

    $roleAssignments = @()
    #use Where-Object { $_ } to filter out empty strings which would cause the API call to fail
    $AdminGuids | Where-Object { $_ } | Select-Object -Unique | ForEach-Object { $roleAssignments+= [pscustomobject]@{roleName='Administrator';userId=$_}}
    $ReaderGuids | Where-Object { $_ } | Select-Object -Unique | ForEach-Object { $roleAssignments+= [pscustomobject]@{roleName='Reader';userId=$_}}
    $UserGuids | Where-Object { $_ } | Select-Object -Unique | ForEach-Object { $roleAssignments+= [pscustomobject]@{roleName='User';userId=$_}}
    $body = $roleAssignments | ConvertTo-Json -AsArray

    if ($PSCmdlet.ShouldProcess($AgentQueueScopeId, "Add agent queue access on project level")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PUT -AccessToken $AccessToken -Body $body | Out-Null

        if ($Inheritance -eq $false) {
            #Workaround API limitation
            #When adding the permissions the inheritence flag gets switched on again
            #The permissions seem still correct (until inheritance is switch off and on again)
            #To avoid further weird configuration patch the inheritence flag to off again
            Set-AgentQueueInheritance -AzdoOrganization $AzdoOrganization -AgentQueueScopeId $AgentQueueScopeId -Inheritance $Inheritance -AccessToken $AccessToken
        }
    }
}

<#
.SYNOPSIS
    Remove queue (agentpool) from project
.DESCRIPTION
    Remove queue (agentpool) from project, it will remain at organization level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER AgentPoolId
    The ID of the agent pool (on organization level)
.PARAMETER Project
    Name of project from which queue should be removed
.PARAMETER AccessToken
    The personal access token for Azure DevOps
.NOTES
    Required AzureDevOps Access [Agent Pools - Read & Manage]
#>
function Remove-AgentPoolInProject() {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Project,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )
    #get queue id
    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($Project)/_apis/distributedtask/queues?poolIds=$($AgentPoolId)&api-version=7.1"
    $queueId = (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken -AllowCache).value.id

    Remove-AgentQueueInProject -AzdoOrganization $AzdoOrganization -Project $Project -QueueId $queueId -AccessToken $AccessToken
}

<#
.SYNOPSIS
    Remove queue (agentpool) from project
.DESCRIPTION
    Remove queue (agentpool) from project, it will remain at organization level
.PARAMETER AzdoOrganization
    The Azure DevOps organization name
.PARAMETER QueueId
    The ID of the agent queue (on project level)
.PARAMETER Project
    Name of project from which queue should be removed
.PARAMETER AccessToken
    The personal access token for Azure DevOps
#>
function Remove-AgentQueueInProject() {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Project,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$QueueId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken,

        [Parameter(Mandatory=$false)]
        [switch]$Silent
    )

    #delete queue
    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($Project)/_apis/distributedtask/queues/$($queueId)?api-version=7.1"
    if (-not($Silent)) {
        Write-Host "`t`tRemoving from Project: $Project"
    }
    if ($PSCmdlet.ShouldProcess($Project, "Remove agent queue $QueueId from project")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method DELETE -AccessToken $AccessToken
    }
}

function Get-AuthToken {
    [CmdletBinding()]
    param()
    # Check if AZDO_PAT is set for local development
    if ($env:AZDO_PAT) { return $env:AZDO_PAT }

    # Use azure CLI token as primary auth source
    $cli = (az account get-access-token | ConvertFrom-Json).accessToken
    if ($cli) { return $cli }

    throw "No Azure DevOps token found. Login with Azure CLI (az login) or set AZDO_PAT."
}

function Get-BasicAuthHeaders {
	param(
		[Parameter(Mandatory = $false)]
		[ValidateNotNullOrEmpty()]
		[string]$AccessToken
	)

    if (-not $AccessToken) {
        $AccessToken = Get-AuthToken
    }

	return @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$AccessToken")) }
}

function Get-PipelinesInProject {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/pipelines?api-version=7.1-preview.1"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken).value
}

function Get-PipelineDefinition {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$PipelineId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken,

        [Parameter(Mandatory=$false)]
        [switch]$AllowCache
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/build/definitions/$($PipelineId)?api-version=7.1"
    return Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken $AccessToken -AllowCache:$AllowCache
}

function Set-DefaultAgentQueueInPipelineDefinition() {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$PipelineId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$NewAgentQueueName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$NewAgentQueueId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken,

        [Parameter(Mandatory=$false)]
        [switch]$AllowCache

    )

    $pipelineDefinition = Get-PipelineDefinition -AzdoOrganization $AzdoOrganization -ProjectName $ProjectName -PipelineId $PipelineId -AccessToken $AccessToken -AllowCache:$AllowCache

    # Update the agent queue ID in the pipeline definition
    $commentText = "Update default agent to $NewAgentQueueName ($NewAgentQueueId)"
    $pipelineDefinition.queue.id = [int]$NewAgentQueueId
    if ($pipelineDefinition.comment) {
        #comments are like a field, it will be populated with the last comment
        #so replace the comment with our new comment
        $pipelineDefinition.comment = $commentText
    } else {
        #if comment wasn't set, we need to append it as a new field
        $pipelineDefinition | Add-Member -MemberType NoteProperty -Name "comment" -Value $commentText
    }

    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/build/definitions/$($PipelineId)?api-version=7.1"
    if ($PSCmdlet.ShouldProcess($PipelineId, "Update pipeline agent queue")) {
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PUT -AccessToken $AccessToken -Body ($pipelineDefinition | ConvertTo-Json -Depth 10) | Out-Null
    }
}

function Set-AgentQueueInheritance() {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentQueueScopeId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [bool]$Inheritance,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AccessToken
    )


    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/securityroles/scopes/distributedtask.agentqueuerole/roleassignments/resources/$($AgentQueueScopeId)?inheritPermissions=$Inheritance&api-version=7.1-preview.1"
    $action = "Disabling"
    if ($Inheritance) {
        $action = "Enabling"
    }
    if ($PSCmdlet.ShouldProcess($AgentPoolQueueScopeId, "$action permission inheritance on agent queue")) {
        Write-Host "`t`t$action inheritance"
        Invoke-AzureDevOpsApiCall -Uri $uri -Method PATCH -AccessToken $AccessToken | Out-Null
    }
}

function Get-AllProjectPipelineDefinition() {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/build/definitions?includeAllProperties=true&`$top=2000&api-version=7.1"
    $definitions = (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken (Get-AuthToken) -AllowCache).value
    if (-not $definitions) {
    	throw 'No build definitions were returned from Azure DevOps.'
    }
    return $definitions
}

function Get-RecentPipelineRun() {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$PipelineId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]$RunCount
    )

    # note when specifiying top=<number> the API will ONLY return succeeded runs (not partially succeeded, failed, etc)
    # so therefor we instead get ALL runs from the API, and then return only the top number of runs in this function
    $uri = "https://dev.azure.com/$($AzdoOrganization)/$($ProjectName)/_apis/build/builds?definitions=$($PipelineId)&api-version=7.1"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken (Get-AuthToken) -AllowCache).value | Select-Object -First $RunCount
}

function Get-PipelineArtifactInfo() {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$ProjectName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]$RunId
    )

    $uri = "https://dev.azure.com/$AzdoOrganization/$ProjectName/_apis/build/builds/$($RunId)/artifacts?api-version=7.1"
    return (Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -AccessToken (Get-AuthToken) -AllowCache).value
}

#write to console the functions have been loaded
Write-Verbose "Loaded $($MyInvocation.MyCommand.Name)"