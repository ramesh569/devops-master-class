<#
.SYNOPSIS
  Retrieves the current image version for an agent pool from Mosaic.
.PARAMETER AzdoOrganization
  The Azure DevOps organization containing the agent pool.
.PARAMETER AzdoAgentPoolName
  The Azure DevOps agent pool name.
.PARAMETER Os
  The expected operating system of the image.
.PARAMETER Flavour
  The expected flavour of the image.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$AzdoOrganization,

  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$AzdoAgentPoolName,

  [Parameter(Mandatory = $true)]
  [string]$Os,

  [Parameter(Mandatory = $true)]
  [string]$Flavour,

  [string]$MotExecutablePath = 'mot'
)
#[Functions]
. $PSScriptRoot\Functions-Mosaic.ps1

#[Script]
Write-Host "AgentPool: $AzdoOrganization/$AzdoAgentPoolName"
Write-Host "Os: $Os"
Write-Host "Flavour: $Flavour"

$currentImage = Get-AgentPoolCurrentImage -Organization $AzdoOrganization -AgentPoolName $AzdoAgentPoolName -MotExecutablePath $MotExecutablePath
if ($currentImage.azureDevOpsOrganization -ine $AzdoOrganization -or $currentImage.agentPoolName -ine $AzdoAgentPoolName) {
  throw "Mosaic returned current image data for '$($currentImage.azureDevOpsOrganization)/$($currentImage.agentPoolName)' while resolving '$AzdoOrganization/$AzdoAgentPoolName'."
}
if ($currentImage.os -ine $Os -or $currentImage.flavour -ine $Flavour) {
  throw "Mosaic current image '$($currentImage.os)/$($currentImage.flavour)' does not match configured image '$Os/$Flavour' for '$AzdoOrganization/$AzdoAgentPoolName'."
}

Write-Host "Using current image version for diff: $($currentImage.version)"
Write-Host "##vso[task.setvariable variable=currentImageVersion]$($currentImage.version)"