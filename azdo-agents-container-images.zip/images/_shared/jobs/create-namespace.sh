#!/bin/bash -e
aks_name=$1
resource_group=$2
namespace=$3

echo "aks_name: $aks_name"
echo "resource_group: $resource_group"
echo "namespace: $namespace"

# check if variables are specified
if [[ -z "$aks_name" || -z "$resource_group" || -z "$namespace" ]]; then
    echo "Error: Missing required variables"
    exit 1
fi

# normalize namespace
normalized_namespace=${namespace/./-} #replace any dot in namespace variable with a dash

echo "normalized namespace: $normalized_namespace"

echo "# az aks get-credentials"
if ! az aks get-credentials --admin --name "$aks_name" --resource-group "$resource_group"; then
    echo "Error getting credentials"
    exit 1
fi

# create namespace for scaled job
if kubectl get namespace "${normalized_namespace,,}" > /dev/null 2>&1; then
    echo "Namespace ${normalized_namespace,,} already exists. Skip Creation"
    exit 0
fi

echo "Creating namespace ${normalized_namespace,,}"
if ! kubectl create namespace "${normalized_namespace,,}"; then
    echo "Error creating namespace"
    exit 1
fi
