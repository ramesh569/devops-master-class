<#
.SYNOPSIS
    Wait until placeholder agent scaled job completed
.DESCRIPTION
    Script checks if placeholder agent is the correct version by verifiying the AGENT_IMAGE_VERSION capabilities
    If version matches the script ends, otherwise it waits and checks again until timeout is reached.
.PARAMETER AzdoOrganization
    The Azure DevOps organization the agent pool is located in
.PARAMETER AgentPoolName
    The name of the agent pool to wait for
.PARAMETER TargetAgentImageVersion
    The target agent image version to wait for
.PARAMETER TimeoutInMinutes
    The timeout in minutes to wait for the placeholder agent to be updated
#>
[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AzdoOrganization,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$TargetAgentImageVersion,

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [int]$TimeoutInMinutes = 15

)
#[Configuration]
$checkFrequencyInSeconds = 30

#[Functions]
. $PSScriptRoot\Functions-AzdoApi.ps1

function Get-AgentPoolVersion() {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]$AgentPoolId
    )

    $uri = "https://dev.azure.com/$($AzdoOrganization)/_apis/distributedtask/pools/$($AgentPoolId)/agents?agentName=PlaceholderAgent&includeCapabilities=true&api-version=7.1"
    $response = Invoke-AzureDevOpsApiCall -Uri $uri -Method GET -accessToken $accessToken

    if ($response.count -eq 0) {
        return "no-placeholder-agent"
    }

    $version = $response.value[0].systemCapabilities.AGENT_IMAGE_VERSION
    return $version
}

function Wait-DeploymentCompletion() {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AzdoOrganization,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]$AgentPoolId,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$TargetAgentImageVersion,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [int]$TimeoutInMinutes
    )

    #wait until placeholder agent is updated
    try {
        $timeoutDeadline = (Get-Date).addminutes($TimeoutInMinutes)
        Write-Output "Waiting for placeholder agent to be updated to target version '$TargetAgentImageVersion'."
        Do {
            $timeNow = Get-Date
            if ($timeNow -ge $timeoutDeadline) {
                throw "[Error] Timeout occured after $TimeoutInMinutes minute(s). Placeholder agent is not updated to target version '$TargetAgentImageVersion'"
            } else {
                $actualVersion = Get-AgentPoolVersion -AzdoOrganization $AzdoOrganization -AgentPoolId $AgentPoolId
                if ($actualVersion -eq $TargetAgentImageVersion) {
                    Write-Output "Placeholder agent succesfully updated to target version"
                    break
                } else {
                    #determine time left until timeout
                    $timeLeft = New-TimeSpan -Start $timeNow -End $timeoutDeadline
                    Write-Output "Placeholder agent not updated, retry in $checkFrequencyInSeconds seconds. Timeout in $timeLeft`n`tActual version: $actualVersion`n`tTarget version: $TargetAgentImageVersion"
                }
            }
            Start-Sleep -Seconds $checkFrequencyInSeconds
        } Until ($timeNow -ge $timeoutDeadline)
    } catch {
        Write-Output "[Error] Unable to get placeholder agent. $($_.Exception.Message)"
        throw $_.Exception #rethrow error
    }
}

#[Script]
$token = az account get-access-token
$accessToken = ($token | ConvertFrom-Json).accessToken

#get agent pool id
Write-Output "Getting Agentpool $AgentPoolName in $AzdoOrganization"
$agentPoolId = (Get-AgentPool -AzdoOrganization $AzdoOrganization -AgentPoolName $AgentPoolName -accessToken $accessToken).id

#get agent placeholder agent version
Wait-DeploymentCompletion `
    -AzdoOrganization $AzdoOrganization `
    -AgentPoolId $agentPoolId `
    -TargetAgentImageVersion $TargetAgentImageVersion `
    -TimeoutInMinutes $TimeoutInMinutes
