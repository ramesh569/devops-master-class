﻿<#
.SYNOPSIS
    Set versions in script files
.DESCRIPTION
    Replace version placeholders in script files with values based on verson xml file
.PARAMETER VersionFilePath
    Path to version xml file
.PARAMETER TargetPaths
    Path in which script files should be updated
    You can define multiple paths seperated by comma or semicolon
.PARAMETER ImageOs
    Operating System of image being build
.PARAMETER ImageFlavour
    Flavour of the image being build
.PARAMETER BuildId
    BuildId of current pipeline
.PARAMETER ImageType
    Base or extension image, determining which commit metadata key is recorded.
.PARAMETER SkipFileList
    List of files to be skipped for transformation
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$VersionFilePath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$TargetPaths,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ImageOs,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$ImageFlavour,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$BuildId,

    [Parameter(Mandatory=$false)]
    [ValidateSet('base', 'extension')]
    [string]$ImageType = 'base',

    [Parameter(Mandatory=$false)]
    [ValidateNotNullOrEmpty()]
    [string]$SkipFileList
)

#[Configuration]
$ErrorActionPreference = "Stop" #stop script on error
$sourceCommit = git -C $PSScriptRoot rev-parse HEAD
if ($LASTEXITCODE -ne 0) {
    throw 'Could not determine the checked-out container image repository commit.'
}
$commitMetadataKey = if ($ImageType -eq 'base') { 'base-commit' } else { 'derived-commit' }

#[functions]
function Test-File {
    param (
        [Parameter(Mandatory=$true)]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [string] $Name
    )
    if (!(Test-Path($Path))) {
        throw "$Name File could not be found at $Path"
    }
}

<#
.SYNOPSIS
    Validates an xml file against an xml schema file.
.Note
    Downloaded from https://stackoverflow.com/questions/822907/how-do-i-use-powershell-to-validate-xml-files-against-an-xsd
.Example
    PS> dir *.xml | Test-XmlFile schema.xsd
#>
function Test-XmlFile
{
    [CmdletBinding()]
    [OutputType('System.Boolean')]
    param (
        [Parameter(Mandatory=$true)]
        [string] $SchemaFile,

        [Parameter(ValueFromPipeline=$true, Mandatory=$true, ValueFromPipelineByPropertyName=$true)]
        [alias('Fullname')]
        [string] $XmlFile,

        [scriptblock] $ValidationEventHandler = { Write-Error $args[1].Exception }
    )

    begin {
        $schemaReader = New-Object System.Xml.XmlTextReader $SchemaFile
        $schema = [System.Xml.Schema.XmlSchema]::Read($schemaReader, $ValidationEventHandler)
    }

    process {
        $ret = $true
        try {
            $xml = New-Object System.Xml.XmlDocument
            $xml.Schemas.Add($schema) | Out-Null
            $xml.Load($XmlFile)
            $xml.Validate({
                    throw ([PsCustomObject] @{
                        SchemaFile = $SchemaFile
                        XmlFile = $XmlFile
                        Exception = $args[1].Exception
                    })
                })
        } catch {
            Write-Error $_
            $ret = $false
        }
        $ret
    }

    end {
        $schemaReader.Close()
    }
}

<#
.SYNOPSIS
    Get all versions
.DESCRIPTION
    Get all versions from xml document and return as array
.PARAMETER VersionFilePath
    Path to version xml file
#>
function Get-VersionsFromConfig() {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$VersionFilePath
    )

    #read xml document
    [xml]$versionDocument = Get-Content -Path $VersionFilePath

    #return versions as array
    return $VersionDocument.tools.tool
}

#[script]
#determine what the xsd should be named
$VersionValidationSchemaFilePath=$VersionFilePath.replace('.xml', '.xsd')

#test if files exist
Test-File -Path $VersionFilePath -Name "Tool Versions file"
Test-File -Path $VersionValidationSchemaFilePath -Name "Tool Versions Validation Schema file"

write-host "Validate Tool Versions List"
#test XML validity against XSD
$xsdTest = Test-XmlFile -SchemaFile (Get-Item $VersionValidationSchemaFilePath).FullName -XmlFile $VersionFilePath
if ($xsdTest -eq $true) {
    Write-Host "XSD Validation Completed"
} else {
    Write-Host "XSD Validation Failed"
}

#get tool versions
$toolVersions = Get-VersionsFromConfig -VersionFilePath $VersionFilePath

#test duplicate identifiers
foreach($tool in $toolVersions) {
    $toolsBySameIdentifier = $toolVersions | Where-Object {$_.identifier -eq $tool.identifier}
    if ($toolsBySameIdentifier.count -gt 1) {
        write-warning "$($tool.identifier) is defined more than once"
        $toolsBySameIdentifier | ForEach-Object {write-host "$($_.identifier) | $($_.name) | $($_.version)" }
    }
}

$filesToSkip = $SkipFileList.split(';');
foreach($Path in $TargetPaths -split '[,;]') {
    write-host "Getting script files in $Path and subfolders"
    $errorCount = 0
    ForEach($scriptFile in (Get-ChildItem $Path -Recurse | Where-Object {$_.Extension -in ('.sh', '.ps1') -or $_.Basename -in ('dockerfile', 'Hotfix')})) {

        if($scriptFile.BaseName -in $filesToSkip) {
            write-host "[Skip] $($scriptFile.FullName)"
            continue
        }

        #load script
        $scriptContent = Get-Content -Path $scriptFile.FullName -Encoding utf8

        if ($scriptContent | Select-String '§.*') {
            write-host "[Edit] $($scriptFile.FullName)"
        } else {
            write-host "[Skip] $($scriptFile.FullName)"
            continue
        }

        #replace all placeholders
        foreach($tool in $toolVersions) {
            $scriptContent = $scriptContent.replace("§$($tool.identifier)§", $tool.version)
        }

        #replace all special placeholders
        $scriptContent = $scriptContent.replace("§Os§", $ImageOs)
        $scriptContent = $scriptContent.replace("§Flavour§", $ImageFlavour)
        $scriptContent = $scriptContent.replace("§BuildId§", $BuildId)
        $scriptContent = $scriptContent.replace("§SourceCommit§", $sourceCommit)
        $scriptContent = $scriptContent.replace("§CommitMetadataKey§", $commitMetadataKey)

        #check if any placeholders were not defined
        foreach($unchangedPlaceholder in $scriptContent | Select-String "§.*") {
            Write-Warning "$unchangedPlaceholder has not been set to a specific version in $scriptFile"
            $errorCount++
        }

        #store modified script
        Set-Content -Path $scriptFile.FullName -Value $scriptContent -Encoding utf8
    }
}

if ($errorCount -gt 0) {
    write-host "Some versions have not been set, see logging above."
    # exit 1 # Versions are now replaced in MOT, so it shouldn't fail on this.
}

write-host "Script Completed"
