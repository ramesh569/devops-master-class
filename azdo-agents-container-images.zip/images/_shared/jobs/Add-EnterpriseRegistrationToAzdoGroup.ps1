<#
.SYNOPSIS
    Add Enterprise Application to Azure DevOps Group
.PARAMETER AzdoOrganization
    Azure DevOps Organization that the authorization group is part of
.PARAMETER GroupType
    Type of Access Group
.PARAMETER EnterpriseRegistrationName
    Name of the enterprise registrion to add as member
.PARAMETER EnterpriseRegistrationid
    Id of the enterprise registration to add as member
    Value matches 'Application (client) ID' on App Registration
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateSet(
        'raboweb',
        'raboweb-brazil',
        'raboweb-ftbtr',
        'raboweb-na',
        'raboweb-ranz',
        'raboweb-test'
    )]
    [String]$AzdoOrganization,

    [Parameter(Mandatory=$true)]
    [ValidateSet(
        'agentpool-reader',
        'agentpool-admin'
    )]
    [String]$GroupType,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $EnterpriseRegistrationName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    $EnterpriseRegistrationid
)

#[Functions]
. $PSScriptRoot\Functions-AzdoApi.ps1

function New-GroupMembership {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [Parameter(Mandatory=$true)]
        [string]$azdoOrganization,

        [Parameter(Mandatory=$true)]
        [string]$subjectDescriptor,

        [Parameter(Mandatory=$true)]
        [string]$containerDescriptor,

        [Parameter(Mandatory=$true)]
        [string]$accessToken
    )
    #documentation https://learn.microsoft.com/en-us/rest/api/azure/devops/graph/memberships/add
    #required access [Graph - Read & Manage]
    $uri = "https://vssps.dev.azure.com/$($azdoOrganization)/_apis/graph/memberships/$($subjectDescriptor)/$($containerDescriptor)?api-version=7.2-preview.1"
    write-host "Invoking PUT: $uri"
    if ($PSCmdlet.ShouldProcess($uri)) {
        Invoke-WebRequest `
            -Method Put `
            -Uri $uri `
            -Headers @{Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($accessToken)")) } `
            -ContentType 'application/json'
    }
}

#[Script]
$accessToken = (az account get-access-token | ConvertFrom-Json).accessToken

$targetAzdoGroup = Get-TargetGroupName -groupType $GroupType -azdoOrganization $AzdoOrganization
write-host "Script is going to add '$EnterpriseRegistrationName' to '$targetAzdoGroup'"

#get application descriptor
$targetApplicationDescriptor = Get-ApplicationDescriptor -azdoOrganization $AzdoOrganization -EnterpriseRegistrationName $EnterpriseRegistrationName -EnterpriseRegistrationid $EnterpriseRegistrationId -accessToken $accessToken
if (!($targetApplicationDescriptor)) {
    throw "Failed to get application registration descriptor, this could mean that the service principal has not been added to the Azure DevOps organization"
}

#get group descriptor
$targetGroupDescriptor = Get-GroupIdentifier -azdoOrganization $AzdoOrganization -groupName $targetAzdoGroup -returnField descriptor -accessToken $accessToken

#update group membership
New-GroupMembership -azdoOrganization $AzdoOrganization -subjectDescriptor $targetApplicationDescriptor -containerDescriptor $targetGroupDescriptor -accessToken $accessToken

write-host "Script completed"
