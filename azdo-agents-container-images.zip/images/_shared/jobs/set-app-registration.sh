#!/bin/bash -e

# The manifest is required for setting the correct API Permission in the app registration
# 499b84ac-1321-427f-aa17-267ca6975798 = Azure Devops
# ee69721e-6c3a-468f-a9ec-302d16a4c599 = user_impersonation

echo "# Create app registration manifest"
cat > app-registration-manifest.json << EOF
[{
    "resourceAppId": "499b84ac-1321-427f-aa17-267ca6975798",
    "resourceAccess": [
        {
            "id": "ee69721e-6c3a-468f-a9ec-302d16a4c599",
            "type": "Scope"
        }
   ]
}]
EOF

echo "# Looking up app registration $APP_REGISTRATION_NAME"
app_id=$(az ad app list --display-name "$APP_REGISTRATION_NAME" --query '[0].appId' --output tsv)

if [ -z "$app_id" ]; then
    if [ "$CREATE_IF_MISSING" != "true" ]; then
        echo "App registration $APP_REGISTRATION_NAME does not exist and image infrastructure deployment is disabled"
        exit 1
    fi

    echo "# az ad app create $APP_REGISTRATION_NAME"
    app_id=$(az ad app create --display-name "$APP_REGISTRATION_NAME" --required-resource-accesses @app-registration-manifest.json | jq -r '.appId')
fi

# Disable SC2181 because the command needs to assign the value to APP_ID but we still want to check the response code
# shellcheck disable=SC2181
if [ -z "$app_id" ]; then
    echo "Failed to create app registration"
    exit 1
fi

echo "# Setting task variable azureAppRegistrationId to $app_id"
echo "##vso[task.setvariable variable=azureAppRegistrationId;isOutput=true]$app_id"