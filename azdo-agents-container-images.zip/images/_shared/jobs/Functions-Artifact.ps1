[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param()

# [Configuration]
$script:AzdoOrganization = 'Raboweb'
$script:AzdoProject = 'Tribe Tech4Engineering'
$script:SharedRepositoryName = 'azdo-agents-shared'
$script:UploadScriptRelativePath = 'scripts/New-MosaicImageVersion.ps1'
$script:WorkspaceRootName = 'sbom-sync'

function Write-PipelineWarning {
	param(
		[Parameter(Mandatory = $true)]
		[string]$Message
	)

	Write-Host "##vso[task.logissue type=warning]$Message"
}



function Normalize-YamlPath {
	param(
		[Parameter(Mandatory = $true)]
		[string]$PathValue
	)

	$normalized = $PathValue -replace '\\', '/'
	if (-not $normalized.StartsWith('/')) {
		$normalized = "/$normalized"
	}

	return $normalized.ToLowerInvariant()
}

function Get-JsonValue {
	param(
		[Parameter(Mandatory = $true)]
		[pscustomobject]$Object,

		[Parameter(Mandatory = $true)]
		[string]$PropertyName,

		[Parameter(Mandatory = $false)]
		[object]$Default = $null
	)

	if ($Object.PSObject.Properties.Name -contains $PropertyName) {
		return $Object.$PropertyName
	}

	return $Default
}

function Get-SelectedTargets {
	param(
		[Parameter(Mandatory = $true)]
		[pscustomobject]$ParametersObject
	)

	$selectedTargets = @()
	$includeParameterNames = @($ParametersObject.PSObject.Properties.Name | Where-Object { $_ -like 'include*' })

	foreach ($includeParameterName in $includeParameterNames) {
		$includeValue = [bool](Get-JsonValue -Object $ParametersObject -PropertyName $includeParameterName -Default $false)
		if (-not $includeValue) {
			continue
		}

		if ($includeParameterName -notmatch '^include(?<os>Linux|Windows)(?<flavour>[A-Za-z0-9]+)$') {
			Write-PipelineWarning -Message "Skipping parameter '$includeParameterName': expected format include<Linux|Windows><Flavour>."
			continue
		}

		$os = $Matches.os.ToLowerInvariant()
		$flavour = $Matches.flavour.ToLowerInvariant()
		$selectedTargets += @{
			key = "$os-$flavour"
			os = $os
			flavour = $flavour
			yamlPath = "/images/$os/$flavour/pipeline.yml"
		}
	}

	return $selectedTargets
}

function Get-SbomSyncWorkspaceRoot {
	$workspaceBase = $env:PIPELINE_WORKSPACE
	if (-not $workspaceBase) {
		$workspaceBase = $env:BUILD_SOURCESDIRECTORY
	}
	if (-not $workspaceBase) {
		$workspaceBase = $env:AGENT_TEMPDIRECTORY
	}

	if (-not $workspaceBase) {
		throw 'Unable to determine a workspace root. Expected PIPELINE_WORKSPACE, BUILD_SOURCESDIRECTORY, or AGENT_TEMPDIRECTORY.'
	}

	return Join-Path -Path $workspaceBase -ChildPath $script:WorkspaceRootName
}

function Get-MosaicUploadScriptPath {
	$sourcesDirectory = $env:BUILD_SOURCESDIRECTORY
	if (-not $sourcesDirectory) {
		throw 'BUILD_SOURCESDIRECTORY is required to locate the shared Mosaic upload script.'
	}

	return Join-Path -Path $sourcesDirectory -ChildPath (Join-Path $script:SharedRepositoryName $script:UploadScriptRelativePath)
}

function Get-MosaicSyncContext {
	[pscustomobject]@{
		AzdoOrganization = $script:AzdoOrganization
		AzdoProject = $script:AzdoProject
		WorkspaceRoot = Get-SbomSyncWorkspaceRoot
		UploadScriptPath = Get-MosaicUploadScriptPath
	}
}