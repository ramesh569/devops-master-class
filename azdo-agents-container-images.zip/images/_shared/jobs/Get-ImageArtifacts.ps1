[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param(
	[Parameter(Mandatory = $true)]
	[ValidateNotNullOrEmpty()]
	[string]$AllPipelineParametersJson
)

$ErrorActionPreference = 'Stop'

. $PSScriptRoot\Functions-Artifact.ps1
. $PSScriptRoot\Functions-AzdoApi.ps1

# [Script]
$parametersObject = $AllPipelineParametersJson | ConvertFrom-Json
$selectedTargets = Get-SelectedTargets -ParametersObject $parametersObject
if ($selectedTargets.Count -eq 0) {
	Write-PipelineWarning -Message 'No image flavours selected. Nothing to process.'
	return
}

# get all pipeline definitions in the project
$context = Get-MosaicSyncContext
$definitions = Get-AllProjectPipelineDefinition -AzdoOrganization $context.AzdoOrganization -ProjectName $context.AzdoProject

$workspaceRoot = $context.WorkspaceRoot
New-Item -Path $workspaceRoot -ItemType Directory -Force | Out-Null

$stats = [ordered]@{
	selectedFlavours = $selectedTargets.Count
	matchedDefinitions = 0
	runsChecked = 0
	artifactMissing = 0
	docsMissing = 0
	downloadSucceeded = 0
	downloadFailed = 0
	definitionsMissing = 0
}

foreach ($target in $selectedTargets) {
	Write-Host "`nProcessing [$($target.key)]"
	$normalizedTargetPath = Normalize-YamlPath -PathValue $target.yamlPath
	$matchingDefinitions = @($definitions | Where-Object {
		$_.process -and $_.process.yamlFilename -and (Normalize-YamlPath -PathValue $_.process.yamlFilename) -eq $normalizedTargetPath
	})

	if ($matchingDefinitions.Count -eq 0) {
		$stats.definitionsMissing++
		Write-PipelineWarning -Message "No build definition found for yaml path '$($target.yamlPath)' ($($target.key))."
		continue
	}

	if ($matchingDefinitions.Count -gt 1) {
		Write-PipelineWarning -Message "Multiple build definitions matched '$($target.yamlPath)'. Using first match id $($matchingDefinitions[0].id)."
	}

	$definition = $matchingDefinitions[0]
	$stats.matchedDefinitions++

	Write-Host "Reading Processing [$($target.key)] definition id $($definition.id) name '$($definition.name)'"
	$builds = Get-RecentPipelineRun -AzdoOrganization $context.AzdoOrganization -ProjectName $context.AzdoProject -PipelineId $definition.id -RunCount ([int](Get-JsonValue -Object $parametersObject -PropertyName 'runCount' -Default 10))

	if (-not $builds -or $builds.Count -eq 0) {
		Write-PipelineWarning -Message "No runs found for definition id $($definition.id) ($($target.key))."
		continue
	}

	$artifactsDownloadedForFlavour = 0
	foreach ($build in $builds) {
		$stats.runsChecked++
		$runFolder = Join-Path -Path $workspaceRoot -ChildPath "$($target.key)/$($build.id)-$($build.buildNumber)"
		New-Item -Path $runFolder -ItemType Directory -Force | Out-Null

		$artifactResponse = Get-PipelineArtifactInfo -AzdoOrganization $context.AzdoOrganization -ProjectName $context.AzdoProject -RunId $build.id

		$targetArtifact = $artifactResponse | Where-Object { $_.name -eq 'InstalledSoftware' }
		if (-not $targetArtifact) {
			$stats.artifactMissing++
			Write-Host "InstalledSoftware artifact not found for $($target.key) run $($build.id) ($($build.buildNumber)). Skipping run."
			continue
		}

		$zipPath = Join-Path -Path $runFolder -ChildPath 'InstalledSoftware.zip'
		$extractPath = Join-Path -Path $runFolder -ChildPath 'InstalledSoftware'

		try {
			$headers = Get-BasicAuthHeaders
			Invoke-WebRequest -Method Get -Uri $targetArtifact.resource.downloadUrl -Headers $headers -OutFile $zipPath -ErrorAction Stop
			Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

			$docsPath = Get-ChildItem -Path $extractPath -Filter 'documentation.json' -File -Recurse | Select-Object -First 1
			if (-not $docsPath) {
				$stats.docsMissing++
				Write-Host "documentation.json not found in InstalledSoftware for $($target.key) run $($build.id) ($($build.buildNumber)). Skipping run."
				continue
			}

			$stats.downloadSucceeded++
			Write-Host "Downloaded InstalledSoftware for $($target.key) run $($build.id) ($($build.buildNumber))."
			$artifactsDownloadedForFlavour++
		} catch {
			$stats.downloadFailed++
			Write-Host "Failed to download or extract InstalledSoftware for $($target.key) run $($build.id) ($($build.buildNumber)). Skipping run."
			continue
		}
	}
	if ($artifactsDownloadedForFlavour -eq 0) {
		Write-PipelineWarning -Message "No artifacts downloaded for $($target.key)."
	}
}

Write-Host '--- Artifact download summary ---'
Write-Host "selectedFlavours : $($stats.selectedFlavours)"
Write-Host "matchedDefinitions: $($stats.matchedDefinitions)"
Write-Host "definitionsMissing: $($stats.definitionsMissing)"
Write-Host "runsChecked       : $($stats.runsChecked)"
Write-Host "artifactMissing   : $($stats.artifactMissing)"
Write-Host "docsMissing       : $($stats.docsMissing)"
Write-Host "downloadSucceeded : $($stats.downloadSucceeded)"
Write-Host "downloadFailed    : $($stats.downloadFailed)"