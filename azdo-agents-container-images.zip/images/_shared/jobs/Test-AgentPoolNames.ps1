<#
.SYNOPSIS
    Verify agent pool names and configuration
.DESCRIPTION
    Verify agent pool names and configuration based on pipeline definition file
.PARAMETER PipelinePath
    Pipeline definition file to be verified
.PARAMETER AgentConfigurationFolder
    Folder containing the agent pool configuration files
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$PipelinePath,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentConfigurationFolder
)

#[Configuration]
$allowedEnvironments = @(
    'Dev',
    'Test',
    'Prod',
    'Fall'
)
$allowedSizes = @(
    '2XS',
    'XS',
    'S',
    'M',
    'L',
    'XL',
    '2XL',
    '3XL',
    '4XL'
)

#[functions]
function Test-File {
    param (
        [Parameter(Mandatory=$true)]
        [string] $Path,

        [Parameter(Mandatory=$true)]
        [string] $Name
    )
    write-host "Testing if '$Name' exists at location '$Path'"
    if (!(Test-Path($Path))) {
        throw "$Name File or folder could not be found at $Path"
    }
}

#[Script]
Test-File -Path $PipelinePath -Name "Pipeline definition"
Test-File -Path $AgentConfigurationFolder -Name "Agent configuration folder"

write-host "Installing powershell-yaml"
Install-Module -Name powershell-yaml -Scope CurrentUser -Force

#get pipeline definition
$pipelineDefinition = (Get-Content $PipelinePath) | ConvertFrom-Yaml
$osType = $pipelineDefinition.extends.parameters.osType

#agent flavour is generally speaking the 5th element of the agent pool name
#however for base image (types) its usually 'Base' regardless of the actual value
#the flavour (such as OneLab, UBI and AWS) is already defined in the 1st element
$agentFlavour = $pipelineDefinition.extends.parameters.imageFlavour
if ($pipelineDefinition.extends.parameters.imageType -eq "base") {
    $agentFlavour = "(Base|$($pipelineDefinition.extends.parameters.imageFlavour))"
}

# UBI Images are of OS Type Linux but the OS element should be called UBI
$pipelineFolderName = ($PipelinePath -split '[\/]')[-2]
if ($pipelineFolderName -eq "ubi" -or $pipelineFolderName -eq "legacy")
{
    write-host "Image identified as UBI image, changing OS type to 'UBI'"
    $osType = "UBI"
}

#determine agent name regex
$agentRegex = "^[\w]+-" + `
              "[\w]+-" + `
              "Container-" + `
              "$($osType)-" + `
              "$($agentFlavour)-" + `
              "($($allowedSizes -join '|'))-" + `
              "($($allowedEnvironments -join '|'))$"
$preMigrationAgentRegex = "^Rabo-" + `
                          "(CloudOnly-)*" + `
                          "Kubernetes-" + `
                          "([\w]+-)*" + `
                          "$($osType)-" + `
                          "(Dev|Test|Production|Fallback)" + `
                          "(-$($agentFlavour))*" + `
                          "(-[\w]+)*$"


#get all defined pipelines from pipeline configuration config
$agentPools = @()
foreach($xml in Get-ChildItem -Path $AgentConfigurationFolder -Filter "agentpools*.xml") {
    write-host "Loading agent pools from $($xml.FullName)"
    $xmlContent = [xml](Get-Content -Path $xml.FullName)
    foreach($agentPool in $xmlContent.agentpools.agentpool) {
        write-host "`t$($agentPool.organization)\$($agentPool.name)"
        $agentPools += Select-Object -InputObject $agentPool -Property organization, name
    }
}

$issueCount=0 #keep track of issues

write-host "Validating agent pools in pipeline definition"
#loop through all agent pools defined in the pipeline definition
foreach($environment in $pipelineDefinition.extends.parameters.deployments) {
    write-host "$($environment.environmentName)"
    foreach($phase in $environment.Keys | Where-Object { $_ -like "*Phase" }) {
        write-host "`t`t$($phase)"

        foreach($agentPool in $environment.$phase) {
            $agentPoolOrganization = $agentPool.azdoOrganization
            $agentPoolName = $agentPool.azdoAgentPoolName
            write-host "`t`t`t$agentPoolOrganization\$agentPoolName"

            #check if agent pool meets naming convention
            #https://confluence.dev.rabobank.nl/spaces/MTTAS/pages/1304790276/Migration+Guide+-+Agent+Pool+Name+Change#MigrationGuideAgentPoolNameChange-NamingConvention
            if ($agentPoolName -inotmatch $agentRegex -and $agentPoolName -inotmatch $preMigrationAgentRegex) {
                Write-Warning "Agent pool name '$agentPoolName' (in $agentPoolOrganization) does not meet naming convention. Check spelling. Name should meet one of the following regex:`n$agentRegex`n$preMigrationAgentRegex"
                $issueCount++
            }

            #check if agent pool is defined in the agent pools configuration
            if (!($agentPools | Where-Object { $_.name -eq $agentPoolName -and $_.organization -eq $agentPoolOrganization })) {
                Write-Warning "Agent pool '$agentPoolOrganization\$agentPoolName' is not defined in the agent pools configuration. Add to configuration and run create agent pool pipeline"
                $issueCount++
            }
        }
    }
}

write-host "Verification complete"
if ($issueCount -gt 0) {
    Write-Host "##vso[task.logissue type=warning]Configuration issues on image pipeline.yml See logging for more detail"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}

 write-host "Agent pool validation completed"