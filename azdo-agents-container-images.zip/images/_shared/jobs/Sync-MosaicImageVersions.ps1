[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param(
	[Parameter(Mandatory = $true)]
	[ValidateNotNullOrEmpty()]
	[string]$AllPipelineParametersJson
)

$ErrorActionPreference = 'Stop'

. $PSScriptRoot\Functions-Artifact.ps1

# [Script]
$parametersObject = $AllPipelineParametersJson | ConvertFrom-Json
$selectedTargets = Get-SelectedTargets -ParametersObject $parametersObject
if ($selectedTargets.Count -eq 0) {
	Write-PipelineWarning -Message 'No image flavours selected. Nothing to process.'
	return
}

$context = Get-MosaicSyncContext
$uploadScriptPath = $context.UploadScriptPath
if (-not (Test-Path -Path $uploadScriptPath -PathType Leaf)) {
	throw "Upload script not found at $uploadScriptPath"
}

$workspaceRoot = $context.WorkspaceRoot
if (-not (Test-Path -Path $workspaceRoot -PathType Container)) {
	Write-PipelineWarning -Message "Workspace root '$workspaceRoot' does not exist. Nothing to sync."
	return
}

$selectedTargetLookup = @{}
foreach ($target in $selectedTargets) {
	$selectedTargetLookup[$target.key] = $true
}

$stats = [ordered]@{
	selectedFlavours = $selectedTargets.Count
	artifactsProcessed = 0
	uploadSucceeded = 0
	uploadFailed = 0
	unknownTargets = 0
}

$documentationFiles = Get-ChildItem -Path $workspaceRoot -Filter 'documentation.json' -File -Recurse
write-host "Found $($documentationFiles.Count) documentation.json files in workspace root '$workspaceRoot'."
foreach ($documentationFile in $documentationFiles) {
	write-host "`nProcessing documentation file: $($documentationFile.FullName)" # start with new line for log clarity
	# sample documentationFile fullname:
	# /azp/_work/1/sbom-sync/windows-base/22193270-20260518.2/InstalledSoftware/InstalledSoftware/documentation.json
	$fileParts = $documentationFile.FullName -split '[\\/]'
	$runFolder = $fileParts[-4] # 22193270-20260518.2
	$targetKey = $fileParts[-5] # windows-base

	if (-not $selectedTargetLookup.ContainsKey($targetKey)) {
		continue
	}

	if ($targetKey -notmatch '^(?<os>[a-z0-9]+)-(?<flavour>[a-z0-9]+)$') {
		$stats.unknownTargets++
		Write-PipelineWarning -Message "Unable to parse target key '$targetKey' from '$($documentationFile.FullName)'. Skipping file."
		continue
	}

	$os = $Matches.os
	$flavour = $Matches.flavour
	$buildNumber = Split-Path -Path $runFolder -Leaf
	if ($buildNumber -notmatch '^[0-9]+-(?<version>.+)$') {
		$stats.unknownTargets++
		Write-PipelineWarning -Message "Unable to parse build information from '$runFolder'. Skipping file."
		continue
	}

	$version = $Matches.version
	$stats.artifactsProcessed++

	try {
		Write-Host "Syncing Mosaic version: $os/$flavour/$version"
		& $uploadScriptPath -Os $os -Flavour $flavour -Version $version -DocsPath $documentationFile.FullName -SkipIfExists $true
		$stats.uploadSucceeded++
		Write-Host "Uploaded or skipped existing Mosaic version: $os/$flavour/$version"
	} catch {
		$stats.uploadFailed++
		Write-PipelineWarning -Message ('Mosaic upload failed for {0} version {1}: {2}' -f $targetKey, $version, $_.Exception.Message)
		continue
	}
}

Write-Host '--- Sync summary ---'
Write-Host "selectedFlavours  : $($stats.selectedFlavours)"
Write-Host "artifactsProcessed: $($stats.artifactsProcessed)"
Write-Host "uploadSucceeded   : $($stats.uploadSucceeded)"
Write-Host "uploadFailed      : $($stats.uploadFailed)"
Write-Host "unknownTargets    : $($stats.unknownTargets)"

if ($stats.uploadFailed -gt 0) {
	Write-PipelineWarning -Message "Completed with upload failures: $($stats.uploadFailed). Review warnings above for details."
}