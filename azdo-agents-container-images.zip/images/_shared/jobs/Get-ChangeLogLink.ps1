<#
.SYNOPSIS
    Generate link highlighting differences between versions
.DESCRIPTION
    Generate AzureDevOps GIT compare link between current version and to-be-deployed version
.PARAMETER TargetBuildIdentifier
    BuildName of version that is to-be-deployed and hence we want to create a compare link for
.PARAMETER SourceDocument
    Source document (usually Test)
.PARAMETER TargetDocument
    Target document (usually Production)
.EXAMPLE
    Get-ChangelogLink.ps1 -TargetBuildIdentifier "20230719.1" -SourceDocument "Shared-EU-Container-Linux-DotNet-S-Test.md" -TargetDocument "Shared-EU-Container-Linux-DotNet-S-Prod.md"
.NOTES
    This file is located in multiple places and needs to be kept in sync manually
        azdo-agents\_cicd\templates\tasks\Get-ChangeLogLink.ps1
        azdo-agents-container-images\images\_shared\jobs\Get-ChangeLogLink.ps1
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String]$TargetBuildIdentifier,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String]$SourceDocument,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [String]$TargetDocument
)


$token = az account get-access-token
$accessToken = ($token | ConvertFrom-Json).accessToken

#[Configuration]
$ErrorActionPreference = "Stop" #stop script on error

#[Script]
write-host "Input Parameters"
write-host "Target BuildName: $TargetBuildIdentifier"
write-host "Source Document: $SourceDocument"
write-host "Target Document: $TargetDocument"

#standardize input
$SourceDocument = $SourceDocument.Trim()
$TargetDocument = $TargetDocument.Trim()

$gitRepositoryName = 'azdo-agents-installed-software-docs'

#https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=Windows
$tokenAsBase64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("`:$accessToken"))

$performPull=$true
if (!(Test-Path($gitRepositoryName))) {
    #clone documentation repository
    write-host "Get Documentation Repository (default branch)"
    git -c http.extraHeader="Authorization: Basic $tokenAsBase64" clone https://raboweb@dev.azure.com/raboweb/Tribe%20Tech4Engineering/_git/$gitRepositoryName
    $performPull=$false
}

#navigate to repository and the installedsoftware folder
write-host "Navigate to docs repository folder"
Set-Location $gitRepositoryName/InstalledSoftware

#pull repository if clone step was skipped
if ($performPull -eq $true) {
    #perform git pull in azdo-agents-installed-software-docs repository folder
    write-host "Get latest version"
    git -c http.extraHeader="Authorization: Basic $tokenAsBase64" pull
}

#get latest commit information to target document
write-host "Getting commit details on $TargetDocument"
$targetFileLastCommitDetails = git log -1 --pretty=oneline  -- "$TargetDocument"
if (!$targetFileLastCommitDetails) {
    Write-Host "##vso[task.logissue type=warning]Target document not found in git log. This warning can be ignored if this is a new image never deployed to production"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}
write-host "Last commit on ${TargetDocument} is ${targetFileLastCommitDetails}"

if (!($targetFileLastCommitDetails -Match "(?<audience>\w+)-(?<region>\w+)-(?<technology>\w+)-(?<os>\w+)-(?<flavour>\w+)-(?<size>\w+)-(?<environment>\w+)")) {
    Write-Host "##vso[task.logissue type=warning]Target document does not match expected pattern. This warning can be ignored if this is a new image never deployed to production"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}

#split image details into OS and image name
#to support 'os-image-version' and 'os - image-version' comment formats
$imageOs = $Matches.os
$imageName = $Matches.flavour
write-host "Image OS: $imageOs"
write-host "Image Name: $imageName"

#get build id from target document
write-host "Getting build-id from $TargetDocument"
if (!(Test-Path($TargetDocument))) {
    Write-Host "##vso[task.logissue type=warning]Target document not found on disk. This warning can be ignored if the documentation in production was removed from repository"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}

$targetDocumentContent = Get-Content $TargetDocument
$targetImageIdFromFile = $targetDocumentContent | Select-String -pattern "build-id[:]* ([0-9\.]*)" | ForEach-Object { $_.Matches.Groups[1].Value }
write-host "Last Build-id from target document content is ${targetImageIdFromFile}"

#get all commits to source document
write-host "Getting all commits on ${sourceDocument}"
$sourceFileCommitDetails = git log --pretty=oneline  -- "${sourceDocument}"

#get commit matching latest version deployed based on build-id in target document
#when version has been deployed to same environment multiple times (for example as a result of a rollback or re-deploy) multiple commits will be returned, select first (most recent)
$targetVersionCommitDetails = $sourceFileCommitDetails | Select-String "$($imageOs)(-| - )+$($imageName)-$($targetImageIdFromFile) on $($SourceDocument.trim('.md'))" | Select-Object -First 1

#if no commit could be found, use provided build number instead
if (!($targetVersionCommitDetails)) {
    $targetVersionCommitDetails = $sourceFileCommitDetails | Select-String "$($imageOs)(-| - )+$($imageName)-$($targetImageIdFromCommit) on $($SourceDocument.trim('.md'))" | Select-Object -First 1
}

#check if any commit has been found based on build-id from target document or provided build number
if ($targetVersionCommitDetails -match "[0-9a-f]{40}") {
    $targetVersionCommitId = $Matches[0]
    write-host "Target commit: $targetVersionCommitId"
} else {
    Write-Host "##vso[task.logissue type=warning]Version $targetImageIdFromFile or $targetImageIdFromCommit not found in history of $SourceDocument"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}

#get commit matching the provided build name (e.g. the version that was provided to this script, usually the version that is to be deployed)
$sourceVersionCommitDetails = $sourceFileCommitDetails | Select-String "$($imageOs)(-| - )+$($imageName)-$($TargetBuildIdentifier) on $($SourceDocument.trim('.md'))"
if ($sourceVersionCommitDetails -match "[0-9a-f]{40}") {
    $sourceVersionCommitId = $Matches[0]
    write-host "Source commit: $sourceVersionCommitId"
} else {
    Write-Host "##vso[task.logissue type=warning]Version $TargetBuildIdentifier not found in history of $SourceDocument"
    Write-Host "##vso[task.complete result=SucceededWithIssues;]"
    exit 0
}

#return compare URL
$compareUrl = "https://dev.azure.com/raboweb/Tribe%20Tech4Engineering/_git/azdo-agents-installed-software-docs?path=/InstalledSoftware/${sourceDocument}&_a=compare&oversion=GC${targetVersionCommitId}&mversion=GC${sourceVersionCommitId}"
write-host "Compare URL"
return $compareUrl
