<#
.SYNOPSIS
    Validates deployment parameters for agent pool deployments to ensure they meet expected conventions and requirements.
.PARAMETER agentPoolName
    The name of the agent pool being deployed. Expected to follow naming conventions that include OS type and phase.
.PARAMETER osType
    The operating system type for the agent pool (e.g., 'windows' or 'linux'). Should match the OS type indicated in the agent pool name.
.PARAMETER phase
    The deployment phase (e.g., 'dev', 'test', 'production'). Production also covers pools with a '-Fall' suffix.
.PARAMETER imageVersion
    The version of the image being deployed. This should be defined to ensure the correct image is used for deployment.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param (
    [Parameter(Mandatory = $true)]
    [string]$agentPoolName,
    [Parameter(Mandatory = $true)]
    [string]$osType,
    [Parameter(Mandatory = $true)]
    [string]$phase,
    [Parameter(Mandatory = $true)]
    [string]$imageVersion
)

$phaseAndPoolNameConvention = @{
    'test' = @('-Test')
    'production' = @('-Prod', '-Fall')
    'dev' = @('-Dev')
}

$errorFound = $false

write-host "Validating deployment parameters"
# display all parameters for visibility in logs
foreach($param in $PSBoundParameters.GetEnumerator()) {
    write-host "$($param.Key): $($param.Value)"
}

# validate OS Type matches agent pool name convention
if ($agentPoolName -like '*-Windows-*') {
    if ($osType -ne 'windows') {
        Write-Host "##vso[task.logissue type=error]OS type '$osType' does not match agent pool name '$agentPoolName'"
        $errorFound = $true
    }
} else {
    if ($osType -ne 'linux') {
        Write-Host "##vso[task.logissue type=error]OS type '$osType' does not match agent pool name '$agentPoolName'"
        $errorFound = $true
    }
}

# validate phase matches agent pool name convention
if ($phaseAndPoolNameConvention.ContainsKey($phase)) {
    $expectedPoolNameSuffixes = $phaseAndPoolNameConvention[$phase]
    $hasExpectedSuffix = $expectedPoolNameSuffixes | Where-Object { $agentPoolName.EndsWith($_) }
    if (-not $hasExpectedSuffix) {
        Write-Host "##vso[task.logissue type=error]Phase '$phase' does not match agent pool name '$agentPoolName'"
        $errorFound = $true
    }
} else {
    Write-Host "##vso[task.logissue type=error]Unknown phase '$phase'. Unable to validate agent pool name convention."
    $errorFound = $true
}

if (-not $imageVersion) {
    Write-Host "##vso[task.logissue type=error]Image version for '$agentPoolName' is not defined. Unable to deploy"
    $errorFound = $true
}

if ($errorFound) {
    write-host "Validation Completed with Errors. See above messages for details."
    exit 1
}

write-host "Validation Completed"