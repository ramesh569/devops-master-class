<#
.SYNOPSIS
    Verifies that Kubectl is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Kubectl Smoketest"
Test-Command -Command kubectl -DisplayName 'Kubectl'

write-host "Kubectl Smoketest Completed."
