<#
.SYNOPSIS
    Test that NexusIQ is installed
.DESCRIPTION
    Tests whether NexusIQ is available on the command line
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting NexusIQ Smoketest"
Test-Command -Command nexus-iq-cli -DisplayName 'Nexus IQ CLI'
