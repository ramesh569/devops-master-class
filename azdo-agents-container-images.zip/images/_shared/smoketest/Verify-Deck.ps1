<#
.SYNOPSIS
    Verifies that Kong decK is installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Kong decK Smoketest"

#verify if deck command is available (which validates its installed and in the environment path)
Test-Command -Command deck -DisplayName 'Kong decK'
