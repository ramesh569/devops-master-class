<#
.SYNOPSIS
    Starts nginx and verifies it is running
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting nginx Smoketest"

Test-Command -Command nginx -DisplayName 'nginx'

try {
    & nginx
    if ($LASTEXITCODE -ne 0) {
        throw "nginx failed to start (exit code: $LASTEXITCODE)"
    }

    # Basic health check on configured unprivileged endpoint.
    $statusCode = & curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8080/health
    if ($statusCode -eq '200') {
        Write-Host "Success - nginx is running and responded with HTTP 200"
    }
    else {
        Show-Warning -Message "Failed - nginx is running but returned HTTP status code '$statusCode'"
    }
}
catch {
    Show-Warning -Message "Failed - nginx smoketest failed: $($_.Exception.Message)"
}
