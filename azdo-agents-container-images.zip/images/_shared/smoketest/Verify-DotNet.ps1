<#
.SYNOPSIS
    Verifies that .NET is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting .NET Smoketest"
Test-Command -Command dotnet -DisplayName '.NET CLI'
dotnet --list-sdks
dotnet --list-runtimes
