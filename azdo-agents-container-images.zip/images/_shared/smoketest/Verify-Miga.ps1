<#
.SYNOPSIS
    Verifies that MIGA is installed and running correctly
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting MIGA Smoketest"

Test-Command -Command miga -DisplayName 'MIGA'

$miga = Get-Command -Name miga -ErrorAction SilentlyContinue
if ($miga) {
    Write-Host "Test Resolving 'miga --version'"
    & $miga.Source --version
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "'miga --version' failed, see logging for more details"
    }
}

$isWindowsAgent = Get-IsWindows
$configPath = if ($isWindowsAgent) { 'C:\ProgramData\miga\config.yaml' } else { '/etc/miga/config.yaml' }

if (Test-Path -LiteralPath $configPath -PathType Leaf) {
    Write-Host "Success - MIGA configuration file exists at '$configPath'"
} else {
    Show-Warning -Message "Failed - MIGA configuration file is missing at '$configPath'"
}

if ($isWindowsAgent) {
    $migaDaemon = Get-Process -Name miga -ErrorAction SilentlyContinue
    if ($migaDaemon) {
        Write-Host 'Success - MIGA daemon process is running'
    } else {
        Show-Warning -Message 'Failed - MIGA daemon process is not running'
    }
    $configuredMigaPath = [Environment]::GetEnvironmentVariable('MIGA_CONFIG_FILE', 'Machine')
    if (-not $configuredMigaPath -or $configuredMigaPath -ine $configPath) {
        Show-Warning -Message "Failed - MIGA_CONFIG_FILE is not set to '$configPath'"
    }

    $migaLogPath = 'C:\ProgramData\miga\logs\miga.log'
    $writeProbe = Join-Path (Split-Path -Parent $migaLogPath) ("write-probe-{0}.tmp" -f [guid]::NewGuid())
    try {
        New-Item -Path $writeProbe -ItemType File -ErrorAction Stop | Out-Null
        Write-Host "Success - MIGA log directory is writable by $([Environment]::UserName)"
    } catch {
        Show-Warning -Message "Failed - MIGA log directory is not writable by $([Environment]::UserName): $_"
    } finally {
        if (Test-Path -LiteralPath $writeProbe) {
            Remove-Item -LiteralPath $writeProbe -ErrorAction Stop
        }
    }
    try {
        $migaLog = Get-Item -LiteralPath $migaLogPath -ErrorAction Stop
        if ($migaLog.Length -eq 0) {
            Show-Warning -Message "Failed - MIGA has not emitted any runtime logs at '$migaLogPath'"
        } else {
            Get-Content -LiteralPath $migaLogPath -TotalCount 1 -ErrorAction Stop | Out-Null
            if (Select-String -LiteralPath $migaLogPath -Pattern 'pipeline_scope_context_detected', 'worker_log_detected' -SimpleMatch -Quiet -ErrorAction Stop) {
                Write-Host 'Success - MIGA reported pipeline_scope_context_detected or worker_log_detected'
            } else {
                Show-Warning -Message "Failed - MIGA did not report pipeline_scope_context_detected or worker_log_detected in '$migaLogPath'"
            }
        }
    } catch {
        Show-Warning -Message "Failed - MIGA runtime logs are missing or unreadable at '$migaLogPath': $_"
    }
} else {
    $migaDaemon = Get-Process -Name miga -ErrorAction SilentlyContinue
    if ($migaDaemon) {
        Write-Host 'Success - MIGA daemon process is running'
    } else {
        Show-Warning -Message 'Failed - MIGA daemon process is not running'
    }
}

if (-not $isWindowsAgent -and $miga) {
    $migaLogPath = '/azp/miga.log'
    try {
        $migaLog = Get-Item -LiteralPath $migaLogPath -ErrorAction Stop
        if ($migaLog.Length -eq 0) {
            Show-Warning -Message "Failed - MIGA has not emitted any runtime logs at '$migaLogPath'"
        } else {
            Get-Content -LiteralPath $migaLogPath -TotalCount 1 -ErrorAction Stop | Out-Null
            Write-Host "Success - MIGA has emitted readable runtime logs at '$migaLogPath'"
            if (Select-String -LiteralPath $migaLogPath -Pattern 'pipeline_scope_context_detected', 'worker_log_detected' -SimpleMatch -Quiet -ErrorAction Stop) {
                Write-Host 'Success - MIGA reported pipeline_scope_context_detected or worker_log_detected'
            } else {
                Show-Warning -Message 'Failed - MIGA did not report pipeline_scope_context_detected or worker_log_detected in this run'
            }
        }
    } catch {
        Show-Warning -Message "Failed - MIGA runtime logs are missing or unreadable at '$migaLogPath': $_"
    }
}