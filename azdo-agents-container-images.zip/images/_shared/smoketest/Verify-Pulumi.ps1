<#
.SYNOPSIS
    Verifies that Pulumi is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Pulumi Smoketest"
Test-Command -Command pulumi -DisplayName 'Pulumi CLI'

write-host "Test Resolving 'pulumi version'"
pulumi version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'pulumi version' failed, see logging for more details"
}
