﻿<#
.SYNOPSIS
    Verifies that Locale is properly configured
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Locale Smoketest"
Test-Command -Command locale -DisplayName 'Locale'

#getting locale output and storing it
$output = $(locale)
Write-Host "Printing locale output"
$output

$expectedSettings = @(
    "LANG=en_US.UTF-8"
    "LC_ALL=en_US.UTF-8"
)

Write-Host "Testing specific locale settings:"
if ((Get-OsType) -eq 'Ubuntu') {
    # this setting is specific to Ubuntu and does not apply to RHEL/UBI
    $expectedSettings += "LANGUAGE=en_US:en"
}

foreach($setting in $expectedSettings)
{
    if (!($output.contains($setting))) {
        Show-Warning -Message "[FAIL] $setting not configured"
    } else {
        Write-Host "[PASS] $setting"
    }
}

#printing the characters will not be something we can automatically check,
#but it should help engineers validate unicode characters are displayed properly
Write-Host "Print some unicode characters"
$textWithUnicode = @"
• ‘single’ and “double” quotes
• Curly apostrophes: “We’ve been here”
• Latin-1 apostrophe and accents: '´`
• ‚deutsche‘ „Anführungszeichen“
• †, ‡, ‰, •, 3–4, —, −5/+5, ™, …
• ASCII safety test: 1lI|, 0OD, 8B
╭────────────────────────────╮
• the euro symbol: │ 14.95 € │
╰────────────────────────────╯
• Math ∮ E⋅da = Q, n → ∞, ∑ f(i) = ∏ g(i)
• Math Continued ∀x∈ℝ: ⌈x⌉ = −⌊−x⌋, α ∧ ¬β = ¬(¬α ∨ β)
"@
$textWithUnicode #output


Write-Host "Locale test completed"