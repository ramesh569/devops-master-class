<#
.SYNOPSIS
    Verifies that sqlfluff-templater-dbt is properly installed
#>

[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting sqlfluff-templater-dbt Smoketest"
Write-Host "Verify sqlfluff-templater-dbt package"
pip show sqlfluff-templater-dbt
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "Package 'sqlfluff-templater-dbt' is not installed"
}

Write-Host "Verify sqlfluff-templater-dbt can be imported"
python3 -c 'import sqlfluff_templater_dbt'
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "Package 'sqlfluff-templater-dbt' could not be imported"
}
