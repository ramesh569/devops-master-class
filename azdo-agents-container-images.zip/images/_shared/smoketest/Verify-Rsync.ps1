<#
.SYNOPSIS
    Verifies that rsync is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting rsync Smoketest"
Test-Command -Command rsync -DisplayName 'rsync'
rsync --version