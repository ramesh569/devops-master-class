<#
.SYNOPSIS
    Verifies that on-premise resources can be reached by an agent that is connected and not cloud-only
.PARAMETER AgentPoolName
    Agent Pool Name used to detrmine whether firewall tests should be ran
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)


#[Configuration]
$rules = @(
    [PSCustomObject]@{ComputerName = "nexus3.rabobank.nl"; Port = "443"; Check ="Unknown"}

    [PSCustomObject]@{ComputerName = "rass-cdp.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "devaut-rbcd.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "devaut.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "vanda.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "speed.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "psi.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "online.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "rfdetectie.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "windows.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "speed-platform.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "fortress.nexus-docker.rabobank.nl"; Port = "443"; Check ="Unknown"}

    [PSCustomObject]@{ComputerName = "sonar.rabobank.nl"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "sonar.test.rabobank.nl"; Port = "443"; Check ="Unknown"}
)

#[Script]
write-host "Agent Pool Name: $AgentPoolName"

if (!(Get-IsAgentPoolExpressRouteConnected -AgentPoolName $AgentPoolName)) {
    write-host "Agent Pool is not connected to on-prem. Skip on-prem firewall rules"
    return
}

#Test each firewall rule
$allRulesPassed = $true
foreach ($rule in $rules) {
    if (Get-IsWindows) {
        [string]$rule.Check = (Test-NetConnection -Port $rule.Port -ComputerName $rule.ComputerName -InformationLevel Detailed | Select-Object -ExpandProperty TcpTestSucceeded)
    } else {
        [string]$rule.Check = (Test-Connection -TCPPort $rule.Port -ComputerName $rule.ComputerName -ErrorAction Continue)
    }
    if ($rule.Check -ne "True") {
        $allRulesPassed = $false
    }
}

# Print list with checked rules
$rules

# Report error to release on error
if (!$allRulesPassed) {
    Show-Warning -Message "Not all firewall rules have passed, see logging for more details."
}