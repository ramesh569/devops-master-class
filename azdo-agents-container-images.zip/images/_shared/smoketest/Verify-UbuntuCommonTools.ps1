<#
.SYNOPSIS
    Verifies tools installed by the Ubuntu common script
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Ubuntu common tools Smoketest"

$commands = @(
    'traceroute'
    'curl'
    'wget'
    'dialog'
    'lzma'
    'zip'
    'unzip'
    'jq'
    'fc-list'
    'update-ca-certificates'
    'add-apt-repository'
    'python3'
    'gpg-agent'
    'mysql'
    'file'
    'certutil'
    'gdb'
    'osslsigncode'
    'gcc'
    'make'
)

foreach ($command in $commands) {
    Test-Command -Command $command -DisplayName $command
}