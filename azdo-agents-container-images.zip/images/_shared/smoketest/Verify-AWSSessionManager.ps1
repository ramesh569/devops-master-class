<#
.SYNOPSIS
    Verifies that AWS Session Manager is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

write-host "Starting AWS Session Manager Smoketest"
Test-Command -Command session-manager-plugin -DisplayName 'AWS Session Manager'
session-manager-plugin --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'session-manager-plugin --version' failed, see logging for more details"
}