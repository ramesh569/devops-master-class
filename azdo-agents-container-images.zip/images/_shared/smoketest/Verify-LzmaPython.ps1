<#
.SYNOPSIS
    Verifies that lzma python library is functioning
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting LZMA python Smoketest"

Set-Content "test.py" -Value @"
import lzma
print("[Test] Create LZMA Archive")
data = b"This is test data to verify if compression works"
with lzma.open("test.lzma", "w") as f:
  f.write(data)

print("[Test] Open LZMA Archive")
with lzma.open("test.lzma") as f:
  file_content = f.read()

print("Test Completed")
"@

#run python scripts
python test.py

#cleanup test files
Remove-Item "test.lzma"
Remove-Item "test.py"
