﻿<#
.SYNOPSIS
    Helper functions for smoke tests
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

<#
.SYNOPSIS
    Show Warning
.DESCRIPTION
    Show Warning that is displayed in AzureDevOps log and AzureDevOps pipeline run page
.PARAMETER Message
    Message to be displayed
#>
function Show-Warning() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Message
    )
    Write-Output "##vso[task.logissue type=warning]$Message"
    Write-Output "##vso[task.complete result=SucceededWithIssues;]"
}

<#
.SYNOPSIS
    Return True if agent pool is a cloud only agent pool
.DESCRIPTION
    Function returns True if the agent pool is a cloud only agent pool based on the agent pool name
.PARAMETER AgentPoolName
    Name of the agent pool
#>
function Get-IsAgentPoolCloudOnly() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    return ($AgentPoolName -like '*-CloudOnly-*')
}

<#
.SYNOPSIS
    Return True if agent pool is an isolated agent pool
.DESCRIPTION
    Function returns True if the agent pool is a isolated agent pool based on the agent pool name
.PARAMETER AgentPoolName
    Name of the agent pool
#>
function Get-IsAgentPoolIsolated() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    return ($AgentPoolName -like '*OneLab*')
}

<#
.SYNOPSIS
    Return True if agent pool is an express route connected agent pool
.DESCRIPTION
    Function returns True if the agent pool is an express route connected agent pool based on the agent pool name
.PARAMETER AgentPoolName
    Name of the agent pool
#>
function Get-IsAgentPoolExpressRouteConnected() {
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$AgentPoolName
    )
    return !(Get-IsAgentPoolCloudOnly -AgentPoolName $AgentPoolName)
}

<#
.SYNOPSIS
    Return True if running on windows agent
.DESCRIPTION
    Get OS environment variable to determine if agent is running windows
#>
function Get-IsWindows() {
    [CmdletBinding()]
    [OutputType([bool])]
    param()
    return ($env:OS -like "*Windows*")
}

<#
.SYNOPSIS
    Get the operating system type of the agent
.DESCRIPTION
    Function returns the operating system type as a string, e.g., "Windows", "Ubuntu", or "RHEL"
#>
function Get-OsType() {
    [CmdletBinding()]
    [OutputType([string])]
    param()
    if (Get-IsWindows) {
        return "Windows"
    }
    if ($env:OSTYPE -like "*linux*") {
        if (Test-Path -Path "/etc/os-release") {
            $osRelease = Get-Content -Path "/etc/os-release" | Out-String
            if ($osRelease -like "*ubuntu*") {
                return "Ubuntu"
            }
            if ($osRelease -like "*rhel*") {
                return "RHEL"
            }
        }
    }
    return "Unknown"
}


<#
.SYNOPSIS
    Test if command is available
    Print message if available and print warning if it is not
.DESCRIPTION
    Test if command is available in one of the path folders
#>
Function Test-Command {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$Command,
        [Parameter(Mandatory=$true)]
        [string]$DisplayName
    )

    $currentActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'stop' #avoid exit by the error thrown at get-command (when the executable is not found)
    try {
        if(Get-Command $Command) {
            Write-Output "Success - Command '$Command' available"
        }
    }
    catch { # catch is required because get-command returns a message and throws an error
        Show-Warning -Message "Failed - Command '$Command' not recognized. Verify if '$DisplayName' is installed correctly"
    } finally {
        #revert to prevous error action preference
        $ErrorActionPreference = $currentActionPreference
    }
}


<#
.SYNOPSIS
    Test Edit/Modify Permissions on provided paths (files and/or folders)
.DESCRIPTION
    Test if agent has access to modify specified files or create files in provided folders
.PARAMETER Paths
    List of file and/or folder paths to test modify permissions on
#>
function Test-EditPermission()
{
    [CmdletBinding()]
    param (
        [string[]]$Paths
    )
    foreach ($path in $Paths) {
        write-host "Validate $path"

        if (Test-Path -Path $path -PathType Container) {
            #path is container, so create a file as test
            try {
                 $testFile = Join-Path -Path $path -ChildPath "test.txt"
                 New-Item -Path $testFile -Value "Smoketest" -ItemType File -Force -ErrorAction Stop | Out-Null
            } catch {
                Show-Warning -Message "##vso[task.logissue type=warning;][Failed] Could not create file in folder $path. Please check permissions and ownership."
                continue
            }
            Write-Host "[Success] Write access verified on folder $path"
            continue
        }

        if (Test-Path -Path $path -PathType Leaf) {
            #path is file, so try to edit the file as test
            try {
                 $c = Get-Content -Path $path -ErrorAction Stop
                 $c += "`n"
                 Set-Content -Path $path -Value $c -ErrorAction Stop | Out-Null
                 Write-Host "[Success] Write access verified on file $path"
                 continue
            } catch {
                Show-Warning -Message "##vso[task.logissue type=warning;][Failed] Could not edit file $path. Please check permissions and ownership."
                continue
            }
        }
    }
}