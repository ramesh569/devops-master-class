<#
.SYNOPSIS
    Verifies that Java build tools are properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [switch]$Ant,
    [switch]$Maven,
    [switch]$Structurizr
)

Write-Host "Starting Java build tools Smoketest"

$commands = @()
if ($Ant) {
    $commands += @{ Command = 'ant'; DisplayName = 'Apache Ant'; Arguments = @('-version') }
}
if ($Maven) {
    $commands += @{ Command = 'mvn'; DisplayName = 'Apache Maven'; Arguments = @('--version') }
}
if ($Structurizr) {
    $commands += @{ Command = 'structurizr'; DisplayName = 'Structurizr CLI'; Arguments = @('help') }
}

foreach ($command in $commands) {
    Test-Command -Command $command.Command -DisplayName $command.DisplayName
    if (!(Get-Command $command.Command -ErrorAction SilentlyContinue)) {
        continue
    }

    Write-Host "Test Resolving '$($command.Command) $($command.Arguments -join ' ')'"
    & $command.Command @($command.Arguments)
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "'$($command.Command)' failed, see logging for more details"
    }
}
