<#
.SYNOPSIS
    Test that Git is properly installed
    Self-hosted agents for Windows use portable version of Git upon a checkout task
    https://learn.microsoft.com/en-us/azure/devops/pipelines/agents/windows-agent?view=azure-devops#what-version-of-git-does-my-agent-run
.DESCRIPTION
    Test whether Git is functioning properly
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Git smoke test"
Test-Command -Command git -DisplayName 'GIT'
