<#
.SYNOPSIS
    Verifies that Pact CLI is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Pact CLI Smoketest"

Test-Command -Command pact-broker -DisplayName 'Pact CLI'

Write-Host "Test Resolving 'pact-broker version'"
pact-broker version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'pact-broker version' failed, see logging for more details"
}