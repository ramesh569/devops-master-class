<#
.SYNOPSIS
    Verifies powershell modules are installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

function Test-Module() {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$Name
    )

    if(Get-Module -ListAvailable -Name $Name) {
        Write-Output "Success - Module '$Name' available"
    } else {
        Show-Warning -Message "Failed - Module '$Name' not found. Verify if '$Name' is installed correctly"
    }
}

write-host "Powershell Modules Smoketest"

Test-Module -Name Az
Test-Module -name Pester
Test-Module -Name PSScriptAnalyzer
Test-Module -Name MarkdownPS
Test-Module -Name SqlServer

