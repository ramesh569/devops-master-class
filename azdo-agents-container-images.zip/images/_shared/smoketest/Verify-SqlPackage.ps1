<#
.SYNOPSIS
    Verifies that Microsoft.SqlPackage is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Microsoft.SqlPackage Smoketest"
Test-Command -Command sqlpackage -DisplayName 'Microsoft SqlPackage'
sqlpackage /Version
