<#
.SYNOPSIS
    Verifies that semgrep is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting semgrep Smoketest"
Test-Command -Command semgrep -DisplayName 'semgrep'

Write-Host "Getting semgrep version"
semgrep --version