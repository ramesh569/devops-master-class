<#
.SYNOPSIS
    Verifies that minimal resources can be reached by an agent
.PARAMETER AgentPoolName
    Agent Pool Name used to detrmine whether extended tests should be ran as well
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#[Configuration]
$rules = @(
    [PSCustomObject]@{ComputerName = "mesoagents.azurecr.io"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "dev.azure.com"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "pipelinebreakerv2prd.azurewebsites.net"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "sm9changesv2prd.azurewebsites.net"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "azdoagentshistoryprd.azurewebsites.net"; Port = "443"; Check ="Unknown"}
)

#[Script]
write-host "Agent Pool Name: $AgentPoolName"
#Test each firewall rule
$allRulesPassed = $true

#test rules
foreach ($rule in $rules) {
    if (Get-IsWindows) {
        [string]$rule.Check = (Test-NetConnection -Port $rule.Port -ComputerName $rule.ComputerName -InformationLevel Detailed | Select-Object -ExpandProperty TcpTestSucceeded)
    } else {
        [string]$rule.Check = (Test-Connection -TCPPort $rule.Port -ComputerName $rule.ComputerName -ErrorAction Continue)
    }
    if ($rule.Check -ne "True") {
        $allRulesPassed = $false
    }
}

write-host "Rules"
$rules

# Report error to release on error
if (!$allRulesPassed) {
    Show-Warning -Message "Not all firewall rules have passed, see logging for more details."
}