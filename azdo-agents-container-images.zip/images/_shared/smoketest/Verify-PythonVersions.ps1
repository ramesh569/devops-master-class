<#
.SYNOPSIS
    Verifies each Python version installed in the agent tool cache
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [string[]]$Versions
)

Write-Host "Starting Python versions Smoketest"

foreach ($version in $Versions) {
    $pythonPath = "/azp/_work/_tool/Python/$version/x64/bin/python3"
    $completePath = "/azp/_work/_tool/Python/$version/x64.complete"

    if (!(Test-Path -Path $pythonPath -PathType Leaf)) {
        Show-Warning -Message "Python $version not found at '$pythonPath'"
        continue
    }
    if (!(Test-Path -Path $completePath -PathType Leaf)) {
        Show-Warning -Message "Python $version tool-cache marker not found at '$completePath'"
    }

    Write-Host "Test Resolving Python $version"
    & $pythonPath --version
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "Python $version failed to report its version"
    }
}