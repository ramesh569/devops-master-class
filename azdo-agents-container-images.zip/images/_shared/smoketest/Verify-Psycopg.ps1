<#
.SYNOPSIS
    Verifies that psycopg is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

$packageList=@(
    "psycopg",
    "psycopg2-binary"
)

Write-Host "Starting psycopg Smoketest"
Test-Command -Command pip -DisplayName 'pip'

Write-Host "Verify if all expected packages are installed"
$missingPackages = @()
foreach ($package in $packageList) {
    pip show $package | Out-Null
    if ($LASTEXITCODE -ne 0) {
        $missingPackages += $package
    }
}
if ($missingPackages.Count -gt 0) {
    Show-Warning -Message "The following expected packages are missing:`n $($missingPackages -join "`n")"
} else {
    Write-Host "Following packages are checked and found installed:`n $($packageList -join "`n")"
}
