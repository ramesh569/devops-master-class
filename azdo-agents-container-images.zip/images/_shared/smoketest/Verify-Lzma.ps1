<#
.SYNOPSIS
    Verifies that lzma is functioning
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting lzma Smoketest"
Test-Command -Command lzma -DisplayName 'lzma'


$uncompressedFile = "test.txt"
$compressedFile = "$uncompressedFile.lzma"

Write-Host "Creaing Test File"
Set-Content $uncompressedFile -Value "This is a test file to verify if compression works"
$originalContent = Get-Content $uncompressedFile #store original content for compare later

Write-Host "Read current Directory"
(Get-ChildItem .).name

Write-Host "Compressing"
lzma $uncompressedFile

Write-Host "Read current Directory"
(Get-ChildItem .).name

Write-Host "Reading compressed file"
lzmainfo $compressedFile

Write-Host "Uncompressing"
unlzma $compressedFile

Write-Host "Read current Directory"
(Get-ChildItem .).name

Write-Host "Compare Original file with Uncompressed File"
Compare-Object `
    -ReferenceObject $originalContent `
    -DifferenceObject (Get-Content $uncompressedFile)

Write-Host "Cleanup Files"
Remove-Item $uncompressedFile