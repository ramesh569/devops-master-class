<#
.SYNOPSIS
    Verifies that sqlfluff is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting sqlfluff Smoketest"
Test-Command -Command sqlfluff -DisplayName 'sqlfluff'

Write-Host "Getting sqlfluff version"
sqlfluff --version
