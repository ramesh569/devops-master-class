<#
.SYNOPSIS
    Test that terraform is properly installed
.DESCRIPTION
    Tests the 3 most commonly used commands
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting terraform smoke test"
$testDirectory = "./terraform-test"
$testFile = "./test-files/terraform-test.tf"

$originalDirectory = Get-Location
try {
    New-Item -Path $testDirectory -ItemType Directory
    Copy-Item -Path $testFile -Destination "$testDirectory/main.tf"
    Set-Location $testDirectory #go to new test directory
    terraform init
    terraform validate
    Write-Host "Test 2 Successful"
} catch {
    Show-Warning -Message "Test 2 Failed. Failed to initialize terraform.";
} finally {
    Set-Location $originalDirectory #go back to original directory
}


