<#
.SYNOPSIS
    Verifies Linux browser automation tools
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [switch]$Playwright,
    [switch]$Selenium,
    [switch]$Xvfb
)

Write-Host "Starting browser automation Smoketest"

$commands = @()
if ($Playwright) {
    $commands += @{ Command = 'playwright'; DisplayName = 'Playwright'; Arguments = @('--version') }
}
if ($Xvfb) {
    $commands += @(
        @{ Command = 'Xvfb'; DisplayName = 'X virtual framebuffer'; Arguments = @('-help') }
        @{ Command = 'Xephyr'; DisplayName = 'Xephyr'; Arguments = @('-help') }
        @{ Command = 'scrot'; DisplayName = 'scrot'; Arguments = @('--version') }
    )
}

foreach ($command in $commands) {
    Test-Command -Command $command.Command -DisplayName $command.DisplayName
    if (!(Get-Command $command.Command -ErrorAction SilentlyContinue)) {
        continue
    }

    Write-Host "Test Resolving '$($command.Command) $($command.Arguments -join ' ')'"
    & $command.Command @($command.Arguments)
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "'$($command.Command)' failed, see logging for more details"
    }
}

if ($Xvfb) {
    Write-Host "Test importing Xvfb Python packages"
    python3 -c 'import pyvirtualdisplay, pyscreenshot, PIL'
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "Importing pyvirtualdisplay, pyscreenshot and PIL failed"
    }
}

if ($Selenium) {
    $seleniumJar = $env:SELENIUM_JAR_PATH
    if ([string]::IsNullOrWhiteSpace($seleniumJar)) {
        $seleniumJar = '/usr/local/bin/selenium-server.jar'
    }

    if (Test-Path -Path $seleniumJar -PathType Leaf) {
        Write-Host "Success - Selenium Server available at '$seleniumJar'"
    } else {
        Show-Warning -Message "Failed - Selenium Server not found at '$seleniumJar'"
    }
}