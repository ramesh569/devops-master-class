<#
.SYNOPSIS
    Verifies that Tesseract is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Tesseract Smoketest"
Test-Command -Command tesseract -DisplayName 'Tesseract'
tesseract --version