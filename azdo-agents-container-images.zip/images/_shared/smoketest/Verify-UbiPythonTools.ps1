<#
.SYNOPSIS
    Verifies Python tools installed by the UBI Python script
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting UBI Python tools Smoketest"

$packages = @(
    'twine'
    'requests'
    'pytest'
    'pytest-cov'
    'isort'
    'flake8'
    'black'
    'boto3'
    'awscli'
    'mypy'
    'pyyaml'
    'pipx'
)

python3 -m pip show @packages | Out-Null
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "One or more UBI Python tools are not installed: $($packages -join ', ')"
} else {
    Write-Host "Success - UBI Python tools are installed"
}