<#
.SYNOPSIS
    Verifies that UV is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting uv Smoketest"
Test-Command -Command uv -DisplayName 'uv'

Write-Host "Getting uv version"
uv --version

Write-Host "Starting uvx Smoketest"
Test-Command -Command uvx -DisplayName 'uvx'

Write-Host "Getting uvx version"
uvx --version
