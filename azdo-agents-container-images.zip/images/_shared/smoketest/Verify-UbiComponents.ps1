<#
.SYNOPSIS
    Verifies components installed by the UBI image scripts
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting UBI components Smoketest"

$commands = @(
    @{ Command = 'rpm'; DisplayName = 'RPM'; Arguments = @('--version') }
    @{ Command = 'ps'; DisplayName = 'procps'; Arguments = @('--version') }
    @{ Command = 'git'; DisplayName = 'Git'; Arguments = @('--version') }
    @{ Command = 'curl'; DisplayName = 'curl'; Arguments = @('--version') }
    @{ Command = 'wget'; DisplayName = 'wget'; Arguments = @('--version') }
    @{ Command = 'zip'; DisplayName = 'zip'; Arguments = @('--version') }
    @{ Command = 'unzip'; DisplayName = 'unzip'; Arguments = @('-v') }
    @{ Command = 'jq'; DisplayName = 'jq'; Arguments = @('--version') }
    @{ Command = 'gpg'; DisplayName = 'GnuPG'; Arguments = @('--version') }
    @{ Command = 'java'; DisplayName = 'OpenJDK'; Arguments = @('-version') }
    @{ Command = 'javac'; DisplayName = 'OpenJDK compiler'; Arguments = @('-version') }
    @{ Command = 'mvn'; DisplayName = 'Apache Maven'; Arguments = @('--version') }
    @{ Command = 'python3'; DisplayName = 'Python'; Arguments = @('--version') }
    @{ Command = 'expdp'; DisplayName = 'Oracle Data Pump Export'; Arguments = @('HELP=YES') }
    @{ Command = 'impdp'; DisplayName = 'Oracle Data Pump Import'; Arguments = @('HELP=YES') }
    @{ Command = 'sqlldr'; DisplayName = 'Oracle SQL Loader'; Arguments = @('-help') }
)

foreach ($command in $commands) {
    Test-Command -Command $command.Command -DisplayName $command.DisplayName
    if (!(Get-Command $command.Command -ErrorAction SilentlyContinue)) {
        continue
    }

    Write-Host "Test Resolving '$($command.Command) $($command.Arguments -join ' ')'"
    & $command.Command @($command.Arguments)
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "'$($command.Command)' failed, see logging for more details"
    }
}

$oraclePatch = Get-ChildItem -Path '/agent/oracle' -Filter opatch -File -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match '/OPatch/opatch$' } |
    Select-Object -First 1
if ($oraclePatch) {
    Write-Host "Success - Oracle Suite OPatch available at '$($oraclePatch.FullName)'"
    & $oraclePatch.FullName version
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "Oracle Suite OPatch failed to report its version"
    }
} else {
    Show-Warning -Message "Failed - Oracle Suite OPatch not found below '/agent/oracle'"
}