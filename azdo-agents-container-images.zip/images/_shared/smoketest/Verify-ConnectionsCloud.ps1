<#
.SYNOPSIS
    Verifies that cloud resources can be reached by an agent that is connected and not cloud-only
.PARAMETER AgentPoolName
    Agent Pool Name used to detrmine whether extended tests should be ran as well
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$AgentPoolName
)

#[Configuration]
$basicRules = @(
    [PSCustomObject]@{ComputerName = "mesoagents.azurecr.io"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "dev.azure.com"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "pipelinebreakerv2prd.azurewebsites.net"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "sm9changesv2prd.azurewebsites.net"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "azdoagentshistoryprd.azurewebsites.net"; Port = "443"; Check ="Unknown"}
)
$extendedrules = @(
    [PSCustomObject]@{ComputerName = "ac-nx-eu-west-1.artifactcentral.aws.rabonet.com"; Port = "443"; Check ="Unknown"}
    [PSCustomObject]@{ComputerName = "repo.nexuscloud.aws.rabo.cloud"; Port = "443"; Check ="Unknown"}
)

#[Script]
write-host "Agent Pool Name: $AgentPoolName"

#Test each firewall rule
$allRulesPassed = $true

#test basic rules
foreach ($rule in $basicRules) {
    if (Get-IsWindows) {
        [string]$rule.Check = (Test-NetConnection -Port $rule.Port -ComputerName $rule.ComputerName -InformationLevel Detailed | Select-Object -ExpandProperty TcpTestSucceeded)
    } else {
        [string]$rule.Check = (Test-Connection -TCPPort $rule.Port -ComputerName $rule.ComputerName -ErrorAction Continue)
    }
    if ($rule.Check -ne "True") {
        $allRulesPassed = $false
    }
}

write-host "Basic Rules"
$basicRules

#test extended rules
if (Get-IsAgentPoolIsolated -AgentPoolName $AgentPoolName) {
    write-host "Agent Pool is identified as isolated, skip extended firewall rule tests"
} else {
    foreach ($rule in $extendedrules) {
        if (Get-IsWindows) {
            [string]$rule.Check = (Test-NetConnection -Port $rule.Port -ComputerName $rule.ComputerName -InformationLevel Detailed | Select-Object -ExpandProperty TcpTestSucceeded)
        } else {
            [string]$rule.Check = (Test-Connection -TCPPort $rule.Port -ComputerName $rule.ComputerName -ErrorAction Continue)
        }
        if ($rule.Check -ne "True") {
            $allRulesPassed = $false
        }
    }

    # Print list with checked rules
    write-host "Extended Rules"
    $extendedRules
}

# Report error to release on error
if (!$allRulesPassed) {
    Show-Warning -Message "Not all firewall rules have passed, see logging for more details."
}