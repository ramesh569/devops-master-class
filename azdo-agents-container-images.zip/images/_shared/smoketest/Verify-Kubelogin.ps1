<#
.SYNOPSIS
    Verifies that kubelogin is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting kubelogin Smoketest"
Test-Command -Command kubelogin -DisplayName 'kubelogin'
kubelogin --version