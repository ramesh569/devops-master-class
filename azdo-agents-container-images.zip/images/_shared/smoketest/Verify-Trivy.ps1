<#
.SYNOPSIS
    Verifies that Trivy is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Trivy Smoketest"
Test-Command -Command trivy -DisplayName 'Trivy'
trivy --version