<#
.SYNOPSIS
    Verifies that Powershell Core is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Powershell Core Smoketest"
Test-Command -Command pwsh -DisplayName 'Powershell Core/7'