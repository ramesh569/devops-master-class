<#
.SYNOPSIS
    Verifies that Tabular Editor is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Tabular Editor Smoketest"

Test-Command -Command TabularEditor.exe -DisplayName 'Tabular Editor'

$executable = 'C:\tools\TabularEditor\TabularEditor.exe'
if (Test-Path -Path $executable -PathType Leaf) {
    Write-Host "Success - Tabular Editor available at '$executable'"
} else {
    Show-Warning -Message "Failed - Tabular Editor not found at '$executable'"
}