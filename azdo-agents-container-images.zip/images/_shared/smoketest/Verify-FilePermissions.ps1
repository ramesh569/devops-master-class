<#
.SYNOPSIS
    Verifies general file permissions
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Verify General File Permissions"
if (Get-IsWindows) {
    Write-Host "No general file permissions to verify on Windows"
} else {
    Test-EditPermission -Paths @(
        "/home/AzDevOps/.config"
    )
}
Write-host "Verify General File Permissions - Completed"