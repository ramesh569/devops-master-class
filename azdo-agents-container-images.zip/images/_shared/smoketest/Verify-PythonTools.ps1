<#
.SYNOPSIS
    Verifies separately installed Python tools
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Python tools Smoketest"

$commands = @(
    @{ Command = 'dbt'; DisplayName = 'dbt-databricks'; Arguments = @('--version') }
    @{ Command = 'tox'; DisplayName = 'Tox'; Arguments = @('--version') }
)

foreach ($command in $commands) {
    Test-Command -Command $command.Command -DisplayName $command.DisplayName
    if (!(Get-Command $command.Command -ErrorAction SilentlyContinue)) {
        continue
    }

    Write-Host "Test Resolving '$($command.Command) $($command.Arguments -join ' ')'"
    & $command.Command @($command.Arguments)
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "'$($command.Command)' failed, see logging for more details"
    }
}