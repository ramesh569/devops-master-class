<#
.SYNOPSIS
    Verifies that Ansible is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

write-host "Starting Ansible Smoketest"
Test-Command -Command ansible -DisplayName 'Ansible'
ansible --version