<#
.SYNOPSIS
    Verifies that poetry is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting poetry Smoketest"
Test-Command -Command poetry -DisplayName 'poetry'

Write-Host "Getting poetry version"
poetry --version

Write-Host "Verify user can write to poetry config"
try {
    poetry config virtualenvs.in-project true
    Write-Host "[Success] Write to poetry Config"
} catch {
    Write-Warning "[Failed] Write to poetry Config"
}

Write-Host "Verify Permissions"
if (-not(Get-IsWindows)) {
    Test-EditPermission -Paths @(
        "/home/AzDevOps/.config/pypoetry"
    )
}

