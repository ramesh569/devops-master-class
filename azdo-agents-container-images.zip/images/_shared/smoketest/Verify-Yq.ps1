<#
.SYNOPSIS
    Test that yq is properly installed
.DESCRIPTION
    Tests the 3 most commonly used commands
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting yq smoke test"
$testFile = "./test-files/yq-test.yml"
$invalidTestFile = "./test-files/yq-test-invalid.yml"

Write-Host "Invalidate the invalid test file"
Add-Content -Path $invalidTestFile -Value "- item3:" #this is invalid yaml on purpose

# Print out the file
Write-Host "Testing the following file: $testFile"
yq e $testFile

# Test 1: Read a specific value (settings.database.port)
$test1_output = "5432"
$test1 = yq ".settings.database.port" $testFile
if ($test1 -ne $test1_output) {
    Write-Warning "Test 1 Failed. Expected Output: $test1_output but got $test1"
} else {
    Write-Host "Test 1 Success."
}

# Test 2: Change a value in the yaml (settings.enabled)
$test2_output = "false"
yq -i ".settings.enabled = $test2_output" $testFile > $null
$test2 = yq ".settings.enabled" $testFile
if ($test2 -ne $test2_output) {
    Write-Warning "Test 2 Failed. Expected Output: $test2_output but got $test2"
} else {
    Write-Host "Test 2 Success."
}

# Test 3: Read a list value (list[1])
$test3_output = "item2"
$test3 = yq ".list[1]" $testFile
if ($test3 -ne $test3_output) {
    Write-Warning "Test 3 Failed. Expected Output: $test3_output but got $test3"
} else {
    Write-Host "Test 3 Success."
}

# Test 4: Validate an invalid YAML file (should error)
$test4 = yq e $invalidTestFile 2>&1 | Out-String
if ($test4.Contains("Error") -or $test4.Contains("syntax error") -or $test4.Contains("parsing error")) {
    Write-Host "Test 4 Success (invalid YAML detected as expected)"
} else {
    Write-Warning "Test 4 Failed. Invalid YAML not detected."
}

# Test 5: Validate a valid YAML file (should not error)
$test5 = yq e $testFile 2>&1 | Out-String
if (-not ($test5.Contains("Error") -or $test5.Contains("syntax error") -or $test5.Contains("parsing error"))) {
    Write-Host "Test 5 Success (valid YAML detected as expected)"
} else {
    Write-Warning "Test 5 Failed. Valid YAML reported as invalid."
}
