<#
.SYNOPSIS
    Verifies that pip is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

#list of pip packages that should be installed on agent by python script
#this list does not include additional packages installed seperately such as semgrep, poetry, tox
$packageList=@(
    "pip",
    "pipx",
    "wheel",
    "setuptools"
)

Write-Host "Starting pip Smoketest"
Test-Command -Command pip -DisplayName 'pip'

Write-Host "Getting pip version"
pip --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'pip --version' failed, see logging for more details"
}

Write-Host "Verify if all dependencies are compatible"
pip check
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'pip check' failed, see logging for more details. This is likely due to docsutils being in conflict, which we don't install. So goodjob python having a trash package manager"
}

Write-Host "Verify if all expected packages are installed"
$missingPackages = @()
foreach ($package in $packageList) {
    pip show $package | Out-Null
    if ($LASTEXITCODE -ne 0) {
        $missingPackages += $package
    }
}
if ($missingPackages.Count -gt 0) {
    Show-Warning -Message "The following expected packages are missing:`n $($missingPackages -join "`n")"
} else {
    Write-Host "Following packages are checked and found installed:`n $($packageList -join "`n")"
}

Write-Host "Verify user can write to pip config"
try {
    pip config --user set install.timeout 30
    Write-Host "[Success] Write to PIP Config"
} catch {
    Write-Warning "[Failed] Write to PIP Config"
}

Write-Host "Verify Permissions"
if (Get-IsWindows) {
    Test-EditPermission -Paths @(
        "C:\ProgramData\pip\pip.ini"
    )
} else {
    Test-EditPermission -Paths @(
        "/home/AzDevOps/.config/pip/pip.conf"
    )
}

