<#
.SYNOPSIS
    Verifies that AWS CDK is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting AWS CDK Smoketest"
Test-Command -Command cdk -DisplayName 'AWS CDK'

#keep track of location we started, we want to return there after the test
$originalLocation = Get-Location

write-host "Testing project initialization"
New-Item -Path 'hello-cdk' -Type Directory | Set-Location
cdk init sample-app --language=typescript
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'cdk init sample-app --language=typescript' failed, see logging for more details"
}

#change directory back to original location (to avoid interfering with any subsequent tests)
Set-Location $originalLocation

