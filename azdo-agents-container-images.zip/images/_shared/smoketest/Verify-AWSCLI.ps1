<#
.SYNOPSIS
    Verifies that AWS CLI is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

write-host "Starting AWS CLI Smoketest"
Test-Command -Command aws -DisplayName 'AWS CLI'
aws --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'aws --version' failed, see logging for more details"
}