<#
.SYNOPSIS
	Verifies that mongosh is installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting mongosh smoke test"
Test-Command -Command mongosh -DisplayName 'Mongosh'

