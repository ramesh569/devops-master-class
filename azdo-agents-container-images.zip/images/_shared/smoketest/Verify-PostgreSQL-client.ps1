<#
.SYNOPSIS
    Verifies that PostgreSQL Client is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting PostgreSQL Client Smoketest"
Test-Command -Command psql -DisplayName 'PostgreSQL Client'
psql --version
