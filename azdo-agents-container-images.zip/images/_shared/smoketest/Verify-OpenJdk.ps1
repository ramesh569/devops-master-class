<#
.SYNOPSIS
    Test that Java version is properly installed
.DESCRIPTION
    Ensures that the java path is properly set in the PATH variable and that the environmental
    variables have also been set.
.PARAMETER MajorVersion
    The major version of the Java version being tested
.PARAMETER DefaultMajorVersion
    The major version that should be set on the default JAVA_HOME variable
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$MajorVersion,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string]$DefaultMajorVersion
)

Write-Host "Starting Smoke Test for JAVA v$MajorVersion"

$expectedJavaPath = ""
$expectedDefaultJavaPath = ""
if (Get-IsWindows) {
    $expectedJavaPath = "c:\Java\$MajorVersion"
    $expectedDefaultJavaPath = "c:\Java\$DefaultMajorVersion"
} else {
    $expectedJavaPath = "/usr/lib/jvm/temurin-$MajorVersion-jdk-amd64"
    $expectedDefaultJavaPath = "/usr/lib/jvm/temurin-$DefaultMajorVersion-jdk-amd64"

}

$environmentVariableName = "JAVA_HOME_${MajorVersion}_X64"
$defaultEnvVariableName = "JAVA_HOME"

#Test 1: Verify the java major version environmental variable is set to expected path
$testResult1 = [Environment]::GetEnvironmentVariable($environmentVariableName)
if($testResult1 -ne $expectedJavaPath) {
    Show-Warning -Message "Failed - Test 1 Variable $environmentVariableName is set to expected path. `n`tExpected: $expectedJavaPath`n`tActual: $testResult1"
} else {
    Write-Host "Success - Test 1 Variable $environmentVariableName is set to expected path."
}

#Test 2: Verify the default java version environmental variable is set to expected path
$testResult2 = [Environment]::GetEnvironmentVariable($defaultEnvVariableName)
if($testResult2 -ne $expectedDefaultJavaPath) {
    Show-Warning -Message "Failed - Test 2 Variable $defaultEnvVariableName is set to expected path. `n`tExpected: $expectedDefaultJavaPath`n`tActual: $testResult2"
} else {
    Write-Host "Success - Test 2 Variable $environmentVariableName is set to expected path."
}

#TODO: Fix after development window on 27/03/2024
#Commented out temporarily due to invalid PATH variable
#Setting it to a correct version will update the default version in prod for all teams

#Test 3: Verify the PATH variable contains the default java version path
# $testResult3 = [Environment]::GetEnvironmentVariable("PATH")
# if($testResult3 -NotLike "*$expectedDefaultJavaPath*") {
#     Show-Warning "Failed - Test 3 Default Java path is included in environment PATH variable. PATH does not contain '$expectedDefaultJavaPath'`nPATH: $($Env:PATH)"
# } else {
#     Write-Host "Success - Test 3 Default Java path is included in environment PATH variable."
# }

#Test 4: Verify the javac command can be executed
Test-Command -Command 'javac' -DisplayName 'Java Compiler'
