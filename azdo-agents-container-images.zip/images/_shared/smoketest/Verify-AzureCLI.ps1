<#
.SYNOPSIS
    Verifies that the Azure CLI is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Azure CLI Smoketest"
Test-Command -Command az -DisplayName 'Azure CLI'
