<#
.SYNOPSIS
    Verifies that opentofu is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting OpenTofu Smoketest"
Test-Command -Command tofu -DisplayName 'tofu'
tofu --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'tofu --version' failed, see logging for more details"
}