<#
.SYNOPSIS
    Verifies that MSBuild is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting MSBuild Smoketest"

Test-Command -Command MSBuild -DisplayName 'MSBuild'

write-host "Test Resolving 'MSBuild --version'"
MSBuild --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'MSBuild --version' failed, see logging for more details"
}
