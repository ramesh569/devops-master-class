<#
.SYNOPSIS
    Test that Git LFS is properly installed
.DESCRIPTION
    Test whether Git LFS is functioning properly
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Git smoke test"
Test-Command -Command git-lfs -DisplayName 'GIT'