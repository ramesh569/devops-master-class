<#
.SYNOPSIS
    Verifies that CloudFoundry is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Cloud Foundry Smoketest"

write-host "[Test Commands]"
Test-Command -Command cf -DisplayName 'Cloud Foundry'

write-host "Test Resolving 'cf'"
cf --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'cf --version' failed, see logging for more details"
}

if (!(Get-IsWindows)) {
    write-host "Test Resolving '/etc/pcf8/cf'"
    /etc/pcf8/cf --version

    if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'/etc/pcf8/cf --version' failed, see logging for more details"
}
}