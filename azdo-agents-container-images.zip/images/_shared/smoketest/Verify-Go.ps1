<#
.SYNOPSIS
    Verifies that Go is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Go Smoketest"

Test-Command -Command go -DisplayName 'Go'

Write-Host "Test Resolving 'go version'"
go version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'go version' failed, see logging for more details"
}