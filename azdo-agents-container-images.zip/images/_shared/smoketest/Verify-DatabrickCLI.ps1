<#
.SYNOPSIS
    Verifies that Databrick CLI is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Databrick CLI Smoketest"
Test-Command -Command databricks -DisplayName 'Databrick CLI'
databricks --version