<#
.SYNOPSIS
    Verifies that the TFLint is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting TFLint Smoketest"
Test-Command -Command tflint -DisplayName 'TFLint'

write-host "TFLint Smoketest Completed."
