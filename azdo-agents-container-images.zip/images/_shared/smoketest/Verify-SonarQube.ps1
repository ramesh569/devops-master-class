<#
.SYNOPSIS
    Test that SonarQube is installed
.DESCRIPTION
    Tests whether SonarQube is available on the command line or installed directory
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting SonarQube Smoketest"
if (Get-IsWindows) {
    if (Test-Path -LiteralPath "C:\sonarqube-cli") {
        Write-Host "Success - SonarQube installation directory found"
    } else {
        Show-Warning -Message "Failed - SonarQube installation directory not found"
    }
} else {
    Test-Command -Command sonar-scanner -DisplayName 'Sonar Scanner'
}
