<#
.SYNOPSIS
    Verifies that Microsoft SQL Server tools are properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Microsoft SQL Server tools Smoketest"

Test-Command -Command sqlcmd -DisplayName 'Microsoft SQL Server tools'

Write-Host "Test Resolving 'sqlcmd -?'"
sqlcmd '-?'
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'sqlcmd -?' failed, see logging for more details"
}