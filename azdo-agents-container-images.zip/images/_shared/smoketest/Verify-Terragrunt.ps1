<#
.SYNOPSIS
    Verifies that Terragrunt is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Terragrunt Smoketest"

Test-Command -Command terragrunt -DisplayName 'Terragrunt'

Write-Host "Test Resolving 'terragrunt --version'"
terragrunt --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'terragrunt --version' failed, see logging for more details"
}