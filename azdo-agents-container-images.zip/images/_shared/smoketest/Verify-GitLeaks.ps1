<#
.SYNOPSIS
    Verifies that Gitleaks is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting gitleaks Smoketest"
Test-Command -Command gitleaks -DisplayName 'gitleaks'

Write-Host "Getting gitleaks version"
gitleaks --version
