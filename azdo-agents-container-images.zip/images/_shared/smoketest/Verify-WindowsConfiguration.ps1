<#
.SYNOPSIS
    Verifies Windows runtime and security configuration
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Windows configuration Smoketest"

$registrySettings = @(
    @{ Path = 'HKLM:\Software\Microsoft\Cryptography\Wintrust\Config'; Name = 'EnableCertPaddingCheck' }
    @{ Path = 'HKLM:\Software\Wow6432Node\Microsoft\Cryptography\Wintrust\Config'; Name = 'EnableCertPaddingCheck' }
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'; Name = 'RequireSecuritySignature' }
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters'; Name = 'RequireSecuritySignature' }
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Control\LSA'; Name = 'RestrictAnonymous' }
    @{ Path = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'; Name = 'RestrictNullSessAccess' }
)

foreach ($setting in $registrySettings) {
    $actualValue = Get-ItemPropertyValue -Path $setting.Path -Name $setting.Name -ErrorAction SilentlyContinue
    if ($actualValue -eq 1) {
        Write-Host "Success - Registry setting '$($setting.Path)\$($setting.Name)' is enabled"
    } else {
        Show-Warning -Message "Failed - Registry setting '$($setting.Path)\$($setting.Name)' is not enabled"
    }
}

$vcRuntimePath = 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64'
$vcRuntimeInstalled = Get-ItemPropertyValue -Path $vcRuntimePath -Name Installed -ErrorAction SilentlyContinue
if ($vcRuntimeInstalled -eq 1) {
    Write-Host "Success - Visual C++ Redistributable x64 is installed"
} else {
    Show-Warning -Message "Failed - Visual C++ Redistributable x64 is not installed"
}