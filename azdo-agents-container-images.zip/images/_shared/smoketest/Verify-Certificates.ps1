<#
.SYNOPSIS
    Verifies that image certificates are installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [switch]$Chrome
)

Write-Host "Starting certificates Smoketest"

$sourceDirectory = if (Get-IsWindows) { 'C:\install\content\certificates' } else { '/install/content/certificates' }
$certificates = Get-ChildItem -Path $sourceDirectory -Filter '*.crt' -File -ErrorAction SilentlyContinue
if (!$certificates) {
    Show-Warning -Message "Failed - No source certificates found at '$sourceDirectory'"
    return
}

foreach ($certificateFile in $certificates) {
    $certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($certificateFile.FullName)

    if (Get-IsWindows) {
        if (Test-Path -Path "Cert:\LocalMachine\Root\$($certificate.Thumbprint)") {
            Write-Host "Success - Certificate '$($certificateFile.Name)' is installed in the Windows root store"
        } else {
            Show-Warning -Message "Failed - Certificate '$($certificateFile.Name)' is not installed in the Windows root store"
        }
        continue
    }

    $installedPaths = @(
        "/usr/local/share/ca-certificates/$($certificateFile.Name)"
        "/etc/pki/ca-trust/source/anchors/$($certificateFile.Name)"
    )
    if ($installedPaths | Where-Object { Test-Path -Path $_ -PathType Leaf }) {
        Write-Host "Success - Certificate '$($certificateFile.Name)' is installed in the OS trust source"
    } else {
        Show-Warning -Message "Failed - Certificate '$($certificateFile.Name)' is not installed in the OS trust source"
    }
}

if ($Chrome) {
    Test-Command -Command certutil -DisplayName 'NSS certificate tools'
    if (Get-Command certutil -ErrorAction SilentlyContinue) {
        $nssCertificates = certutil -L -d 'sql:/home/AzDevOps/.pki/nssdb'
        foreach ($certificateFile in $certificates) {
            if ($nssCertificates -match [regex]::Escape($certificateFile.BaseName)) {
                Write-Host "Success - Certificate '$($certificateFile.Name)' is installed in the Chrome NSS store"
            } else {
                Show-Warning -Message "Failed - Certificate '$($certificateFile.Name)' is not installed in the Chrome NSS store"
            }
        }
    }
}