<#
.SYNOPSIS
    Verifies that NodeJS is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [switch]$Yarn
)

write-host "Starting NodeJS Smoketest"

write-host "[Test Commands]"
Test-Command -Command node -DisplayName 'NodeJS'
Test-Command -Command npm -DisplayName 'npm'
Test-Command -Command pnpm -DisplayName 'pnpm'
if ($Yarn) {
    Test-Command -Command yarn -DisplayName 'Yarn'
}

write-host "[Test Getting Versions]"
write-host "Getting NodeJS version"
node --version
write-host "Getting NPM version"
npm --version
write-host "Getting pnpm version"
pnpm --version
if ($Yarn) {
    write-host "Getting Yarn version"
    yarn --version
}