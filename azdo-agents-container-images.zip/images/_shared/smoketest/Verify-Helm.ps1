<#
.SYNOPSIS
    Verifies that Helm is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Helm Smoketest"
Test-Command -Command helm -DisplayName 'Helm'

# define public helm repos and packages to test
$publicPackages = @()
$publicPackages += @{ repoName = "elastic"; repoUrl = "https://helm.elastic.co"; packageName = "kibana" }
$publicPackages += @{ repoName = "gitlab.io"; repoUrl = "https://charts.gitlab.io"; packageName = "openbao" }
$publicPackages += @{ repoName = "helm"; repoUrl = "https://charts.helm.sh/stable"; packageName = "nginx" }
$publicPackages += @{ repoName = "incubator"; repoUrl = "https://charts.helm.sh/incubator"; packageName = "jenkins" }
$publicPackages += @{ repoName = "hashicorp"; repoUrl = "https://helm.releases.hashicorp.com"; packageName = "consul" }
$publicPackages += @{ repoName = "harbor"; repoUrl = "https://helm.goharbor.io"; packageName = "harbor" }
$publicPackages += @{ repoName = "fairwinds-stable"; repoUrl = "https://charts.fairwinds.com/stable"; packageName = "nginx" }
$publicPackages += @{ repoName = "apache-airflow"; repoUrl = "https://airflow.apache.org"; packageName = "airflow" }
$publicPackages += @{ repoName = "appscode"; repoUrl = "https://charts.appscode.com/stable/"; packageName = "kubed" }
$publicPackages += @{ repoName = "meshery"; repoUrl = "https://meshery.io/charts"; packageName = "meshery" }
$publicPackages += @{ repoName = "prometheus-community"; repoUrl = "https://prometheus-community.github.io/helm-charts"; packageName = "kube-prometheus-stack" }
$publicPackages += @{ repoName = "grafana"; repoUrl = "https://grafana.github.io/helm-charts"; packageName = "grafana" }
$publicPackages += @{ repoName = "ingress-nginx"; repoUrl = "https://kubernetes.github.io/ingress-nginx"; packageName = "ingress-nginx" }


$testId = 1 # keep track which test we are executing for the log
try {
    foreach($publicPackage in $publicPackages) {
        $repoName = $publicPackage.repoName
        $repoUrl = $publicPackage.repoUrl
        $packageName = $publicPackage.packageName

        # Test if the repository can be added
        try {
            helm repo add $repoName $repoUrl > $null
            Write-Host "[PASS] [$testId] Added repo $repoName ($repoUrl)"
        } catch {
            Write-Warning "[FAIL] [$testId] Unable to add repo $repoName ($repoUrl)"
            continue
        }
        $testId++

        # Test if the repository can be searched and if the expected package is found
        try {
            helm search repo "$repoName/$packageName" > $null
            Write-Host "[PASS] [$testId] Searched repo $repoName for package $packageName"
        } catch {
            Write-Warning "[FAIL] [$testId] Unable to search repo $repoName for package $packageName"
        }
        $testId++

        # Test if we can remove the repository (and it is also good to cleanup after ourselves)
        try {
            helm repo remove $repoName > $null
            Write-Host "[PASS] [$testId] Removed repo $repoName (cleanup after smoketest)"
        } catch {
            Write-Warning "[FAIL] [$testId] Unable to remove repo $repoName"
        }
        $testId++
    }
}
catch {
    Write-Warning "Test Failed. See error above"
}
Write-Host "Helm Smoketest Completed."
