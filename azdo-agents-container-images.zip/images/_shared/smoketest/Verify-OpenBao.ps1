<#
.SYNOPSIS
    Verifies that openbao is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting OpenBao Smoketest"
Test-Command -Command bao -DisplayName 'openbao'
bao --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'bao --version' failed, see logging for more details"
}
