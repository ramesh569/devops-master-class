<#
.SYNOPSIS
    Verifies the Azure DevOps agent installation
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting Azure DevOps agent installation Smoketest"

$agentListener = if (Get-IsWindows) { 'C:\azp\agent\bin\Agent.Listener.exe' } else { '/azp/bin/Agent.Listener' }
if (Test-Path -Path $agentListener -PathType Leaf) {
    Write-Host "Success - Azure DevOps agent listener available at '$agentListener'"
} else {
    Show-Warning -Message "Failed - Azure DevOps agent listener not found at '$agentListener'"
}

if (Get-IsWindows) {
    if (Get-LocalUser -Name AzDevOps -ErrorAction SilentlyContinue) {
        Write-Host "Success - Local user 'AzDevOps' exists"
    } else {
        Show-Warning -Message "Failed - Local user 'AzDevOps' does not exist"
    }
} elseif (Test-Path -Path '/azp/start.sh' -PathType Leaf) {
    Write-Host "Success - Azure DevOps agent startup script available"
} else {
    Show-Warning -Message "Failed - Azure DevOps agent startup script not found at '/azp/start.sh'"
}