<#
.SYNOPSIS
    Verifies installed Linux browsers and web drivers
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [switch]$Chrome,
    [switch]$Edge,
    [switch]$Firefox
)

Write-Host "Starting browsers Smoketest"

$commands = @()
if ($Chrome) {
    $commands += @(
        @{ Command = 'google-chrome'; DisplayName = 'Google Chrome'; Arguments = @('--version') }
        @{ Command = 'chromedriver'; DisplayName = 'ChromeDriver'; Arguments = @('--version') }
    )
}
if ($Edge) {
    $commands += @(
        @{ Command = 'microsoft-edge'; DisplayName = 'Microsoft Edge'; Arguments = @('--version') }
        @{ Command = 'msedgedriver'; DisplayName = 'Microsoft Edge WebDriver'; Arguments = @('--version') }
    )
}
if ($Firefox) {
    $commands += @(
        @{ Command = 'firefox'; DisplayName = 'Firefox'; Arguments = @('--version') }
        @{ Command = 'geckodriver'; DisplayName = 'GeckoDriver'; Arguments = @('--version') }
    )
}

foreach ($command in $commands) {
    Test-Command -Command $command.Command -DisplayName $command.DisplayName
    if (!(Get-Command $command.Command -ErrorAction SilentlyContinue)) {
        continue
    }

    Write-Host "Test Resolving '$($command.Command) $($command.Arguments -join ' ')'"
    & $command.Command @($command.Arguments)
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "'$($command.Command)' failed, see logging for more details"
    }
}