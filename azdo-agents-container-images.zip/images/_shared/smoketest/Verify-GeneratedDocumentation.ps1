<#
.SYNOPSIS
    Verifies that image documentation was generated
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

Write-Host "Starting generated documentation Smoketest"

$markdownPath = if (Get-IsWindows) { 'C:\temp\docs-generation\documentation.md' } else { '/tmp/InstalledSoftware/documentation.md' }
$jsonPath = if (Get-IsWindows) { 'C:\temp\docs-generation\documentation.json' } else { '/tmp/InstalledSoftware/documentation.json' }

if ((Test-Path -Path $markdownPath) -and (Get-Item $markdownPath).Length -gt 0)  {
    Write-Host "Success - Generated Markdown documentation is available at $markdownPath"
} else {
    Show-Warning -Message "Failed - Generated Markdown documentation is missing or empty at '$markdownPath'"
}

if (Test-Path -Path $jsonPath)  {
    Write-Host "Success - Generated JSON documentation is available at $jsonPath"
} else {
    Show-Warning -Message "Failed - Generated JSON documentation is missing at '$jsonPath'"
}

try {
    $documentation = Get-Content -Path $jsonPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($null -eq $documentation) {
        throw 'JSON document is empty'
    }
    if ($documentation.schemaVersion -ne 1 -or $null -eq $documentation.metadata -or
        $null -eq $documentation.applications -or $null -eq $documentation.certificates) {
        throw 'JSON has an incomplete or unsupported schema'
    }
    if (-not $documentation.metadata.'build-id') {
        throw 'JSON is missing build metadata'
    }

    $agentName = if (Get-IsWindows) { 'Azure DevOps Agent' } else { 'AzureDevOps Agent' }
    if ($documentation.applications.Tools.applications.PSObject.Properties.Name -notcontains $agentName) {
        throw "JSON is missing persistent application '$agentName'"
    }

    $scannedApplications = @(
        foreach ($category in $documentation.applications.PSObject.Properties) {
            foreach ($application in $category.Value.applications.PSObject.Properties) {
                foreach ($version in $application.Value.versions.PSObject.Properties) {
                    if ($version.Value.artifacts -and $version.Value.type -in @('ELF', 'executable') -and
                        @($version.Value.artifacts | Where-Object { $_.path -and $_.sha256 }).Count -gt 0) {
                        $version.Value
                    }
                }
            }
        }
    )
    if ($scannedApplications.Count -eq 0) {
        throw 'JSON contains no scanned application binaries with hashes'
    }

    $certificates = @($documentation.certificates.PSObject.Properties.Value)
    if ($certificates.Count -eq 0 -or
        @($certificates | Where-Object { $_.certSha256 -and ($_.files -or $_.sources) }).Count -eq 0) {
        throw 'JSON contains no scanned certificates with a hash and file or trust-store source'
    }

    $markdown = Get-Content -Path $markdownPath -Raw -ErrorAction Stop
    if ($markdown -notmatch '## Installed Software' -or $markdown -notmatch '## Certificates') {
        throw 'MOT Markdown is missing application or certificate sections'
    }
    Write-Host "Success - Generated JSON documentation is valid at $jsonPath"
} catch {
    Show-Warning -Message "Failed - Generated JSON is invalid at '$jsonPath': $($_.Exception.Message)"
}