<#
.SYNOPSIS
    Verifies that SQL*Plus is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting SQL*Plus Smoketest"
Test-Command -Command sqlplus -DisplayName 'SQL*Plus CLI'

write-host "Test Resolving 'sqlplus version'"
sqlplus -v
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'sqlplus version' failed, see logging for more details"
}
