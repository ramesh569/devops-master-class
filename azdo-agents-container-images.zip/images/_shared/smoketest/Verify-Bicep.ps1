<#
.SYNOPSIS
    Verifies that Bicep is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param()

write-host "Starting Bicep Smoketest"

Test-Command -Command bicep -DisplayName 'Bicep CLI'

write-host "Test Resolving 'bicep --version'"
bicep --version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'bicep --version' failed, see logging for more details"
}

#because bicep standalone is installed az bicep should also return a value without requiring a installation
write-host "Test Resolving 'az bicep version'"
az bicep version
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'az bicep version' failed, see logging for more details"
}