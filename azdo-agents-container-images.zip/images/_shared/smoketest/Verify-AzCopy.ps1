<#
.SYNOPSIS
    Verifies that AzCopy is properly installed
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()

write-host "Starting AzCopy Smoketest"
Test-Command -Command azcopy -DisplayName 'AzCopy'
azcopy --version