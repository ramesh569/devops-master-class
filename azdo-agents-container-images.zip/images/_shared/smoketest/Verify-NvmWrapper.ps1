<#
.SYNOPSIS
    Verifies the PowerShell wrapper for NVM
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
Param(
    [string[]]$Versions = @()
)

Write-Host "Starting NVM wrapper Smoketest"

$wrapperPath = Join-Path -Path $env:NVM_DIR -ChildPath 'nvm.ps1'
if (!(Test-Path -Path $wrapperPath -PathType Leaf)) {
    Show-Warning -Message "Failed - NVM PowerShell wrapper not found at '$wrapperPath'"
    return
}

. $wrapperPath
if (!(Get-Command nvm -ErrorAction SilentlyContinue)) {
    Show-Warning -Message "Failed - NVM PowerShell wrapper did not define the 'nvm' command"
    return
}

Write-Host "Test Resolving 'nvm current'"
nvm current
if ($LASTEXITCODE -ne 0) {
    Show-Warning -Message "'nvm current' failed, see logging for more details"
}

foreach ($version in $Versions) {
    $nodePath = Join-Path -Path $env:NVM_DIR -ChildPath "versions/node/v$version/bin/node"
    if (!(Test-Path -Path $nodePath -PathType Leaf)) {
        Show-Warning -Message "Node.js $version not found at '$nodePath'"
        continue
    }

    Write-Host "Test Resolving Node.js $version"
    & $nodePath --version
    if ($LASTEXITCODE -ne 0) {
        Show-Warning -Message "Node.js $version failed to report its version"
    }
}