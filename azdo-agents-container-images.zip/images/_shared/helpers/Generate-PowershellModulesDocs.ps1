<#
.SYNOPSIS
    Records installed PowerShell modules in MOT documentation.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'Write-Host is required for AZDO pipeline output')]
param ()
$ErrorActionPreference = 'Stop'

write-host "Recording PowerShell $($PSVersionTable.PSVersion) modules"

$moduleCategory = "PowerShell $($PSVersionTable.PSVersion.Major) Modules"
$powershellModulesList = @(Get-Module -ListAvailable | Sort-Object -Property Name, Version -Unique)
write-host "Found $($powershellModulesList.count) modules"
foreach($module in $powershellModulesList) {
    if ($null -eq $module -or [string]::IsNullOrWhiteSpace([string]$module.Name)) {
        Write-Warning "Skipping PowerShell module with a missing or empty name."
        continue
    }

    $moduleVersion = $null
    if ([string]::IsNullOrWhiteSpace([string]$module.Version) -or
        -not [version]::TryParse([string]$module.Version, [ref]$moduleVersion)) {
        Write-Warning "Skipping PowerShell module '$($module.Name)' because its version is missing or invalid: '$($module.Version)'."
        continue
    }

    mot docs applications add `
        --name $module.Name `
        --category $moduleCategory `
        --version $module.Version
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to document PowerShell module '$($module.Name)'"
    }
}

write-host "Recorded PowerShell modules"
