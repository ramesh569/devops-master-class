<#
.SYNOPSIS
Runs PowerShell Script Analyzer (PSScriptAnalyzer) on all files. Displays the results in a table. Will fail on errors, but not on warnings or informational messages.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'For clarity we want to use colors, which is only possible with Write-Host')]
Param()

$results = Invoke-ScriptAnalyzer -Recurse -Path .
$results | Format-Table

Write-Host "Script analysis completed. Total issues found: $($results.Count)"
if ($results.Count -gt 0) {
  $errorCount = ($results | Where-Object { $_.Severity -eq 'Error' }).Count
  $warningCount = ($results | Where-Object { $_.Severity -eq 'Warning' }).Count
  $informationalCount = ($results | Where-Object { $_.Severity -eq 'Information' }).Count
  Write-Host "`t Errors: $errorCount" -ForegroundColor Magenta
  Write-Host "`t Warnings: $warningCount" -ForegroundColor Yellow
  Write-Host "`t Information: $informationalCount" -ForegroundColor Cyan
  Write-Host "`t Some might be auto fixable by running 'Invoke-ScriptAnalyzer -Recurse -Path * -Fix'" -ForegroundColor DarkGray
  Write-Host "`t`t Running -Fix might change the names of your functions (if you're using pluralization). Please review the changes before committing." -ForegroundColor DarkGray
}

if ($results.Severity -contains 'Error') {
  Write-Error "Script analysis found errors. Please fix the issues before committing."
  exit 1
} else {
  Write-Host "Script analysis passed with no errors." -ForegroundColor Green
  exit 0
}