<#
.SYNOPSIS
Runs ShellCheck on all .sh files. Displays all results in the console. Will fail if any issues are found.
#>
[CmdletBinding()]
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingWriteHost', '', Justification = 'For clarity we want to use colors, which is only possible with Write-Host')]
Param()

$shFiles = Get-ChildItem -Path "$PSScriptRoot/../.." -Recurse -Filter *.sh | Select-Object -ExpandProperty FullName

$allResults = @()
foreach ($file in $shFiles) {
  Write-Host "Analyzing: $file" -ForegroundColor Cyan
  $fileResults = & shellcheck "$file" --format=gcc 2>&1
  if ($LASTEXITCODE -ne 0) {
    foreach($resultLine in $fileResults) {
      $allResults += $resultLine
    }
  }
}

if ($allResults.Count -gt 0) {
  Write-Host "ShellCheck found the following issues:" -ForegroundColor Magenta
  foreach ($entry in $allResults) {
    Write-Host $entry
  }
  Write-Error "ShellCheck found issues in one or more .sh files."
  exit 1
} else {
  Write-Host "All .sh files passed ShellCheck." -ForegroundColor Green
  exit 0
}