---
name: mot-installation-script
description: "Use when creating a new Linux, UBI, or Windows installation script that must fetch software through MOT assets, install or extract it, register the installed application, and regenerate MOT documentation."
---

# Create Installation Scripts with MOT Assets

Use this skill when creating a new installer for a runtime, SDK, CLI, tool, package, archive, binary, or other software artifact in this repository.

The central contract is: **MOT supplies the asset, the script installs usable software, and MOT records the resulting installation.** Do not replace MOT asset retrieval with a direct web download when the asset can be represented by a configured MOT source.

## Scope the Work

1. Identify the target operating system and the narrowest image/script directory that owns the installer.
2. Inspect the nearest installer for the same platform and installation format.
3. Inspect the platform's helper functions, version placeholders, pipeline caller, and documentation-generation entry point.
4. Reuse the repository's local naming, paths, error handling, PATH, environment-variable, and installed-software conventions.
5. Keep the change limited to the new installer and directly required registration or pipeline wiring.

Do not assume that a similar script is correct for a different OS. Use equivalent implementations only to resolve a platform-specific question.

## Required Workflow

### 1. Define the asset contract

Before writing the installer, determine:

- The exact MOT `tool-id` from the target operating system's version catalog. For Linux and UBI, inspect `images/linux/_shared/versions.xml`; for Windows, inspect `images/windows/_shared/versions.xml`; use the equivalent catalog when another image scope owns the installer. The identifier must match the catalog's `tool` `identifier` exactly; do not invent a new label based on the display name.
- The source path or URL template, including the exact version placeholder and platform/architecture suffix.
- Whether the artifact is an installer, archive, standalone executable, package, or another file type.
- The expected version supplied by the image template or script parameters.
- Whether the source is resolved through the repository's normal Nexus configuration or is an explicitly supported remote-only source.

Use the version catalog as the source of truth for the asset version. If the script needs that catalog-defined version for anything besides the asset URL, such as an install directory, archive name, package configuration, logging, or documentation, retrieve it with the catalog-aware MOT command:

```text
mot asset version --tool-id <catalog identifier>
```

The source URL commonly contains `§version§`; MOT resolves that placeholder using the matching catalog/tool configuration. Confirm the resolved source and platform-specific filename before writing the installer.

Use the MOT CLI download contract:

```text
mot asset download --tool-id <catalog identifier> --source <source> --destination <path>
```

The repository normally provides `--nexus-base-url` through MOT configuration or the build environment. Do not add `--nexus-base-url`, Nexus credentials, or equivalent connection flags to a new installation script unless the surrounding pipeline explicitly requires an override. Never put credentials in the script, source URL, logs, or MOT documentation. Use `--skip-nexus` only for an explicitly supported remote-only case.

`mot asset download` normally performs the asset availability and resolution work as part of the download. Treat a failed download, unresolved version placeholder, or incorrect architecture as a blocking installation error. The installer should fail with a useful message rather than continue with a missing or wrong file.

### 2. Download through MOT

Create a deterministic temporary destination under the image's existing install/download area. Use `mot asset download` for every binary, installer, archive, or package fetched for the installation, passing the catalog `tool-id` from the target OS version catalog.

Do not use `Invoke-WebRequest`, `curl`, `wget`, package-manager URLs, or ad hoc web requests as a substitute for MOT asset download. Package managers are acceptable only for software intentionally managed by the OS package system and explicitly supported by the local image convention.

Use `--destination` explicitly. Clean up the downloaded artifact after installation unless it is intentionally part of the final image.

### 3. Install the software

Implement the actual platform installation:

- Run MSI or other installers with the repository's non-interactive options.
- Extract archives into a versioned or stable installation directory.
- Place standalone binaries in the local tools directory.
- Set machine-wide PATH entries or environment variables only when the software is intended to be available that way.
- Preserve existing versions and default-version behavior where the image supports side-by-side runtimes.
- Use the repository's helpers instead of duplicating PATH, environment-variable, or installed-software-list logic.

After installation, validate the expected executable, directory, or package state. Prefer invoking the installed tool's version command when practical. Fail if the expected installation location is absent or the executable cannot run.

### 4. Record the installation

Every newly installed software item must have a persistent MOT application record created at installation time:

```text
mot docs applications add \
  --name "<display name>" \
  --category "<repository category>" \
  --version <installed version> \
  --install-location <stable executable or installed file> \
  --generate-hash
```

Use the actual discovered version when possible. Use the requested version only when the executable cannot report a version and the surrounding implementation documents that limitation.

Choose the category from the nearest platform equivalent. Do not mark an installation-time application as `--generated`; generated records are for records rebuilt during documentation discovery and cleanup.

Use `--install-location` and `--generate-hash` when the installed file exists at a stable path. Record only environment variables actually established by this installer, using repeated `--environment-variables KEY=VALUE` arguments. Never record secrets, temporary download paths, or inferred variables.

Also update `/install/InstalledSoftware.txt` through the repository helper when the platform's installers use that human-readable inventory. Keep the text entry and MOT application record aligned.

### 5. Regenerate MOT documentation

Wire the installer into the existing image build flow, then invoke the platform's existing MOT documentation-generation command or helper after installation. Do not create a separate documentation format or bypass the repository's generator.

The generated pass must be able to remove and recreate generated records without removing the persistent record created by the installer. Confirm that the final MOT manifest contains the new application and that its version, category, install location, hash, and environment metadata are correct.

For this repository, Windows documentation is generated by `images/windows/_shared/scripts/New-Documentation.ps1`, while Linux and UBI use their existing shared documentation helpers. Locate the current caller before adding pipeline wiring.

## Platform Patterns

### Windows PowerShell

Follow nearby scripts such as `Install-Bicep.ps1`, `Install-Deck.ps1`, and `Install-PowershellCore.ps1`:

- Set `$ErrorActionPreference = "Stop"` for installers that must stop on failure.
- Use `mot asset download` with a concrete destination.
- Use `Expand-Archive`, `Start-Process`, or the appropriate installer command.
- Add the final directory with `Add-MachinePathItem` when required.
- Validate the installed executable before registering it.
- Use a stable executable path for `--install-location`.

### Linux and UBI

Follow the nearest shared installer and its OS-specific package conventions. Use MOT for fetched archives, packages, and binaries, then install or extract them into the image's established path. Register the persistent application before the shared documentation helper runs, and preserve the distinction between installation-time and generated package records.

## Review Checklist

- [ ] The installer is placed in the correct OS/image scope.
- [ ] The MOT `tool-id`, source, version, and architecture are explicit and correct.
- [ ] Every fetched binary, installer, archive, or package uses `mot asset download`, which performs the normal asset availability and resolution work.
- [ ] `mot asset version` is used when the catalog-defined version is needed elsewhere in the script.
- [ ] The downloaded artifact is actually installed or extracted.
- [ ] The installed executable, package, or directory is validated.
- [ ] PATH and environment variables are established through local helpers where applicable.
- [ ] Temporary download files are removed.
- [ ] `/install/InstalledSoftware.txt` is updated when required by the platform.
- [ ] A persistent `mot docs applications add` record exists with the correct name, category, version, location, hash, and evidence-based environment variables.
- [ ] The record is not incorrectly marked `--generated`.
- [ ] The installer is wired into the image build.
- [ ] The existing platform MOT documentation generator is invoked afterward.
- [ ] Regeneration preserves the persistent application record and includes the new software in the final manifest.

## Validation

Use the narrowest available validation:

1. Inspect the script for the required `mot asset download`, installation, validation, and `mot docs applications add` stages.
2. Run the repository's native PowerShell or shell validation if one exists and does not require setup.
3. If the environment has MOT configured and the source is available, run a focused installer smoke test that exercises the download and installation.
4. Verify the generated MOT manifest after the normal documentation pass.

Do not initialize package managers, install dependencies, or download an asset solely for validation. Do not invent credentials or bypass Nexus to make a validation command pass.
