---
name: mot-installation-docs
description: "Use when adding, reviewing, or fixing MOT documentation commands in a specific Linux, UBI, or Windows installation script or operating-system image, especially application records, generated package inventory, runtime tracking, or documentation regeneration."
---

# MOT Documentation for Installation Scripts

Use this skill when an installation script changes the software inventory recorded by MOT.

## Scope The Work

Start by selecting the narrowest useful scope:

- **Specific script:** inspect and change only the named installer or documentation helper, plus its direct caller and tests if present.
- **Operating system:** limit the inventory to `images/linux/**`, `images/linux/_shared/**`, `images/windows/**`, or the explicitly named UBI path.
- **Script and operating system:** use both constraints when a shared filename exists on multiple platforms.
- **Shared behavior:** expand to the nearest equivalent implementation only when the script is shared, the requested convention is cross-platform, or the local command delegates documentation generation elsewhere.

State the scope before searching. Do not scan or modify unrelated OS implementations merely because they contain similar MOT commands. When comparing equivalents, keep the requested script/OS as the change target and use other implementations only as evidence.

## Workflow

1. Record the requested script and OS scope.
2. Inventory what each in-scope script actually installs, downloads, extracts, configures, exposes on `PATH`, writes to `/install/InstalledSoftware.txt`, or makes available through environment variables.
3. Inventory every nearby `mot docs` command and documentation-generation helper within that scope.
4. Build a coverage map from each installed or exposed software item to its MOT record. Treat missing records, incomplete fields, wrong categories, missing environment metadata, and incorrect lifecycle flags as documentation gaps even when other MOT commands already exist.
5. Determine whether each required record is installation-time metadata or final inventory metadata.
6. Compare only with the nearest equivalent implementation needed to resolve ambiguity; do not use an existing MOT command as proof that coverage is complete.
7. Make the smallest change within scope that brings every identified software item up to the MOT documentation contract.
8. Validate command flags, category, version source, install location, environment metadata, and regeneration behavior within the same scope.

The primary question is: **Does every relevant installation or configuration step have the correct MOT documentation record?** Search existing MOT commands to map coverage, but also inspect the installation steps that have no MOT command so missing documentation is found and added.

## Record Types

### Persistent installation records

Use `mot docs applications add` when an installation script records software that must persist across later documentation generation.

These records commonly also append a human-readable entry to `/install/InstalledSoftware.txt`. Examples include:

- Main runtimes such as Python or `.NET`.
- SDK and runtime versions discovered during `.NET` installation.
- Tools installed by dedicated scripts.

Include `--artifact` and `--generate-hash` when the installer has a stable executable path. Preserve relevant environment-variable metadata. Reinstallation overwrites matching records without an extra flag. On Windows, use the shared `Invoke-Mot` helper so a failed documentation command stops the installation.

### Environment variables

For every in-scope installation script, inspect the script and its direct helper/configuration calls for environment-variable assignments or exports that are relevant to locating or using the installed software. Include those values with repeated `--environment-variables KEY=VALUE` arguments. Record only variables supported by that code path; never infer, guess, or hallucinate environment-variable names or values.

Apply the same evidence-based rule to all runtime and tool variables, such as home directories, plugin locations, package-manager directories, and tool-specific paths. If an in-scope script does not establish or expose a variable, omit it rather than borrowing it from another operating system, another script, or convention. Never record secrets or transient shell-local values.

### Generated inventory records

Documentation-generation passes add or update inventory records in place. MOT no longer distinguishes generated and persistent applications or supports application removal. Do not delete the whole documentation file to refresh inventory: it also contains installer-authored records.

Examples include:

- Python packages discovered by `python_document_installation`.
- APT or RPM package inventory entries.

Do not add package-inventory records to the persistent installation list unless the existing implementation explicitly requires that list for another output.

## CLI Semantics

Use the MOT CLI flags according to their actual command contracts:

- `docs applications add` upserts matching records; `--generated` and `docs applications remove` are not supported.
- `docs applications scan` inventories native runnable programs (Linux ELF executables or Windows PE `.exe` files), not scripts or shared libraries. It refreshes documented artifact paths and retains unrelated records; there is no `--mode` flag.
- `docs certificates scan` replaces the certificate inventory; certificate add/remove are no longer supported.
- `docs metadata add --set KEY=VALUE` updates existing keys without deleting unrelated metadata; metadata remove is no longer supported.
- All documentation writes overwrite their targeted entries without `--force`; the flag is not supported.
- `--generate-hash` requires `--artifact` to point to an existing file.
- `--out` selects the documentation output file when the configured default is not appropriate.

Do not clear certificates or metadata before scanning/updating them. Verify command exit status in PowerShell; `$ErrorActionPreference` alone does not make native-command failures terminating.

## Repository Conventions

- Linux and UBI documentation passes update package inventory in place in `images/linux/_shared/scripts/generate-docs.sh` and `images/linux/_shared/scripts/ubi/ubi-generate-docs.sh`.
- Python runtimes use the `Runtimes` category. Python packages use `Python <major>.<minor> Packages`.
- `.NET`, `.NET SDK`, and `.NET Runtime` records use the `Frameworks` category.
- Keep runtime or SDK records separate from package-inventory categories.
- Check both the standard Linux and UBI implementation when changing a shared language/runtime convention.

## Review Checklist

- Search `mot docs` commands only in the selected script and OS scope first.
- Search installation actions in the same scope independently of MOT commands; include downloads, package installs, extracted tools, runtime setup, PATH changes, environment exports, and persistent software-list entries.
- Create an installation-to-MOT coverage map and flag every installed or exposed item with no corresponding record.
- Expand the search to shared helpers or equivalent OS implementations only when the scope rules above require it.
- Confirm whether the command runs during installation or documentation generation.
- Confirm no unsupported `--generated`, `--force`, or `applications remove` commands remain.
- Certificate scans replace their section without cleanup; application scans refresh documented artifact paths but leave unrelated records in place.
- Check for duplicate records caused by both installer and documentation-pass registration.
- Check the name, category, version, install location, hash, and environment-variable arguments against neighboring scripts.
- Inspect every in-scope installer and its direct helpers for environment-variable assignments or exports; every `--environment-variables` value must have a source in that code path.
- Check all in-scope scripts for relevant environment variables, and omit any variable that is not explicitly established by the corresponding code path.
- Confirm that every documentation gap found in the coverage map is either fixed or explicitly justified as intentionally undocumented.
- Confirm that regeneration updates inventory without losing installer-authored records.
- Run the narrowest available validation, such as a targeted `rg`/`awk` inspection or the repository's native shell validation. Do not initialize tools or install dependencies just for validation.
